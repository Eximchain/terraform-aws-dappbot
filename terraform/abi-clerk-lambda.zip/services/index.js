module.exports = {
  cloudfront : require('./cloudfront'),
  codepipeline : require('./codepipeline'),
  dynamoDB : require('./dynamoDB'),
  route53 : require('./route53'),
  s3 : require('./s3')
}