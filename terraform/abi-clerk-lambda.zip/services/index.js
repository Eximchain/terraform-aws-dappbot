module.exports = {
  cloudfront : require('./cloudfront'),
  codepipeline : require('./codepipeline'),
  cognito : require('./cognito'),
  dynamoDB : require('./dynamoDB'),
  route53 : require('./route53'),
  s3 : require('./s3')
}