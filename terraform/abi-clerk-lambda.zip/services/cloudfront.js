"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var assert_1 = __importDefault(require("assert"));
var uuid_1 = __importDefault(require("uuid"));
var common_1 = require("../common");
var env_1 = require("../env");
var cloudfront = new env_1.AWS.CloudFront({ apiVersion: '2018-11-05' });
function promiseCreateCloudfrontDistribution(appName, dappOwner, s3Origin, dappDNS) {
    // TODO: Origin Access Identity
    // TODO: Verify that we want these args
    var maxRetries = 5;
    var extraTags = [common_1.dappNameTag(appName), common_1.dappOwnerTag(dappOwner)];
    var params = {
        DistributionConfigWithTags: {
            DistributionConfig: {
                CallerReference: uuid_1.default(),
                DefaultRootObject: 'index.html',
                Aliases: {
                    Quantity: 1,
                    Items: [dappDNS]
                },
                ViewerCertificate: {
                    ACMCertificateArn: env_1.certArn,
                    SSLSupportMethod: 'sni-only',
                },
                Origins: {
                    Quantity: 1,
                    Items: [{
                            Id: 's3-origin',
                            DomainName: s3Origin,
                            S3OriginConfig: {
                                OriginAccessIdentity: ''
                            }
                        }],
                },
                DefaultCacheBehavior: {
                    TargetOriginId: 's3-origin',
                    ForwardedValues: {
                        QueryString: false,
                        Cookies: {
                            Forward: 'none'
                        },
                        Headers: {
                            Quantity: 0
                        }
                    },
                    TrustedSigners: {
                        Quantity: 0,
                        Enabled: false
                    },
                    ViewerProtocolPolicy: 'redirect-to-https',
                    MinTTL: 0,
                    AllowedMethods: {
                        Quantity: 7,
                        Items: ['GET', 'HEAD', 'OPTIONS', 'PUT', 'PATCH', 'POST', 'DELETE']
                    }
                },
                Enabled: true,
                Comment: "Cloudfront distribution for ".concat(appName)
            },
            Tags: {
                Items: common_1.defaultTags.concat(extraTags)
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.createDistributionWithTags(params).promise(); }, maxRetries);
}
function promiseGetCloudfrontDistributionConfig(distroId) {
    var maxRetries = 5;
    var params = {
        Id: distroId
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.getDistributionConfig(params).promise(); }, maxRetries);
}
function promiseDisableCloudfrontDistribution(distroId) {
    var maxUpdateRetries = 5;
    return promiseGetCloudfrontDistributionConfig(distroId).then(function (result) {
        console.log("Get Cloudfront Distro Config Success", result);
        var config = result.DistributionConfig;
        config.Enabled = false;
        var params = {
            Id: distroId,
            IfMatch: result.ETag,
            DistributionConfig: config
        };
        return common_1.addAwsPromiseRetries(function () { return cloudfront.updateDistribution(params).promise(); }, maxUpdateRetries);
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseUpdateCloudfrontDistributionOriginAndEnable(distroId, s3Origin) {
    var maxUpdateRetries = 5;
    return promiseGetCloudfrontDistributionConfig(distroId).then(function (result) {
        console.log("Get Cloudfront Distro Config Success", result);
        var config = result.DistributionConfig;
        console.log("Origin", config.Origins.Items[0]);
        var originItem = {
            Id: 's3-origin',
            DomainName: s3Origin,
            OriginPath: '',
            S3OriginConfig: {
                OriginAccessIdentity: ''
            },
            CustomHeaders: {
                Quantity: 0
            }
        };
        config.Origins.Items[0] = originItem;
        config.Enabled = true;
        var params = {
            Id: distroId,
            IfMatch: result.ETag,
            DistributionConfig: config
        };
        return common_1.addAwsPromiseRetries(function () { return cloudfront.updateDistribution(params).promise(); }, maxUpdateRetries);
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseDeleteCloudfrontDistribution(distroId) {
    var maxRetries = 5;
    var params = {
        Id: distroId
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.deleteDistribution(params).promise(); }, maxRetries);
}
function promiseListCloudfrontDistributions(marker) {
    var maxRetries = 5;
    var params = marker ? { Marker: marker } : {};
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listDistributions(params).promise(); }, maxRetries);
}
function promiseListTagsForCloudfrontDistribution(distroArn) {
    var maxRetries = 5;
    var params = {
        Resource: distroArn
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listTagsForResource(params).promise(); }, maxRetries);
}
function promiseCreateCloudfrontInvalidation(distroId, pathPrefix) {
    if (pathPrefix === void 0) { pathPrefix = '/'; }
    var maxRetries = 5;
    var params = {
        DistributionId: distroId,
        InvalidationBatch: {
            CallerReference: uuid_1.default(),
            Paths: {
                Quantity: 1,
                Items: [
                    pathPrefix + "*"
                ]
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.createInvalidation(params).promise(); }, maxRetries);
}
function getConflictingDistribution(dappDNS) {
    return __awaiter(this, void 0, void 0, function () {
        var conflictingAlias, marker, existingDistroResult, existingDistroPage, existingDistrosMatchingAlias;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    conflictingAlias = dappDNS;
                    marker = '';
                    _a.label = 1;
                case 1:
                    if (!true) return [3 /*break*/, 3];
                    return [4 /*yield*/, promiseListCloudfrontDistributions(marker)];
                case 2:
                    existingDistroResult = _a.sent();
                    if (!existingDistroResult.DistributionList) {
                        return [2 /*return*/, null];
                    }
                    existingDistroPage = existingDistroResult.DistributionList;
                    if (!existingDistroPage.Items) {
                        return [2 /*return*/, null];
                    }
                    existingDistrosMatchingAlias = existingDistroPage.Items.filter(function (item) { return item.Aliases.Quantity === 1; })
                        .filter(function (item) { return item.Aliases.Items[0] === conflictingAlias; });
                    assert_1.default(existingDistrosMatchingAlias.length <= 1, "Found " + existingDistrosMatchingAlias.length + " distribution with matching CNAME instead of at most 1. This must be a bug!");
                    if (existingDistrosMatchingAlias.length == 1) {
                        return [2 /*return*/, existingDistrosMatchingAlias[0]];
                    }
                    if (existingDistroPage.IsTruncated) {
                        marker = existingDistroPage.Marker;
                    }
                    else {
                        return [2 /*return*/, null];
                    }
                    return [3 /*break*/, 1];
                case 3: return [2 /*return*/];
            }
        });
    });
}
function getDistributionOwner(distroArn) {
    return __awaiter(this, void 0, void 0, function () {
        var listTagsResponse, distroTags, dappOwnerTagList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseListTagsForCloudfrontDistribution(distroArn)];
                case 1:
                    listTagsResponse = _a.sent();
                    distroTags = listTagsResponse.Tags.Items || [];
                    dappOwnerTagList = distroTags.filter(function (tag) { return tag.Key === 'DappOwner'; });
                    assert_1.default(dappOwnerTagList.length == 1, "Found " + dappOwnerTagList.length + " tags with Key 'DappOwner' instead of exactly 1. This must be a bug!");
                    return [2 /*return*/, dappOwnerTagList[0].Value];
            }
        });
    });
}
exports.default = {
    createDistro: promiseCreateCloudfrontDistribution,
    getDistroConfig: promiseGetCloudfrontDistributionConfig,
    disableDistro: promiseDisableCloudfrontDistribution,
    deleteDistro: promiseDeleteCloudfrontDistribution,
    listTags: promiseListTagsForCloudfrontDistribution,
    updateOriginAndEnable: promiseUpdateCloudfrontDistributionOriginAndEnable,
    getConflictingDistro: getConflictingDistribution,
    getDistroOwner: getDistributionOwner,
    invalidateDistroPrefix: promiseCreateCloudfrontInvalidation
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xvdWRmcm9udC5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jbG91ZGZyb250LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxrREFBNEI7QUFDNUIsOENBQTBCO0FBQzFCLG9DQUF5RjtBQUN6Riw4QkFBc0M7QUFFdEMsSUFBTSxVQUFVLEdBQUcsSUFBSSxTQUFHLENBQUMsVUFBVSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFbEUsU0FBUyxtQ0FBbUMsQ0FBQyxPQUFjLEVBQUUsU0FBZ0IsRUFBRSxRQUFlLEVBQUUsT0FBYztJQUMxRywrQkFBK0I7SUFDL0IsdUNBQXVDO0lBRXZDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLFNBQVMsR0FBRyxDQUFDLG9CQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUscUJBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBRWhFLElBQUksTUFBTSxHQUFHO1FBQ1QsMEJBQTBCLEVBQUU7WUFDeEIsa0JBQWtCLEVBQUU7Z0JBQ2hCLGVBQWUsRUFBRSxjQUFNLEVBQUU7Z0JBQ3pCLGlCQUFpQixFQUFFLFlBQVk7Z0JBQy9CLE9BQU8sRUFBRTtvQkFDTCxRQUFRLEVBQUUsQ0FBQztvQkFDWCxLQUFLLEVBQUUsQ0FBQyxPQUFPLENBQUM7aUJBQ25CO2dCQUNELGlCQUFpQixFQUFHO29CQUNoQixpQkFBaUIsRUFBRyxhQUFPO29CQUMzQixnQkFBZ0IsRUFBRyxVQUFVO2lCQUNoQztnQkFDRCxPQUFPLEVBQUU7b0JBQ0wsUUFBUSxFQUFFLENBQUM7b0JBQ1gsS0FBSyxFQUFFLENBQUM7NEJBQ0osRUFBRSxFQUFFLFdBQVc7NEJBQ2YsVUFBVSxFQUFFLFFBQVE7NEJBQ3BCLGNBQWMsRUFBRTtnQ0FDWixvQkFBb0IsRUFBRSxFQUFFOzZCQUMzQjt5QkFDSixDQUFDO2lCQUNMO2dCQUNELG9CQUFvQixFQUFFO29CQUNsQixjQUFjLEVBQUUsV0FBVztvQkFDM0IsZUFBZSxFQUFFO3dCQUNiLFdBQVcsRUFBRSxLQUFLO3dCQUNsQixPQUFPLEVBQUU7NEJBQ0wsT0FBTyxFQUFFLE1BQU07eUJBQ2xCO3dCQUNELE9BQU8sRUFBRTs0QkFDTCxRQUFRLEVBQUUsQ0FBQzt5QkFDZDtxQkFDSjtvQkFDRCxjQUFjLEVBQUU7d0JBQ1osUUFBUSxFQUFFLENBQUM7d0JBQ1gsT0FBTyxFQUFFLEtBQUs7cUJBQ2pCO29CQUNELG9CQUFvQixFQUFFLG1CQUFtQjtvQkFDekMsTUFBTSxFQUFFLENBQUM7b0JBQ1QsY0FBYyxFQUFFO3dCQUNaLFFBQVEsRUFBRSxDQUFDO3dCQUNYLEtBQUssRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQztxQkFDdEU7aUJBQ0o7Z0JBQ0QsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsT0FBTyxFQUFFLDhCQUE4QixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7YUFDMUQ7WUFDRCxJQUFJLEVBQUU7Z0JBQ0YsS0FBSyxFQUFFLG9CQUFXLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQzthQUN2QztTQUNKO0tBQ0osQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBdkQsQ0FBdUQsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUMzRyxDQUFDO0FBRUQsU0FBUyxzQ0FBc0MsQ0FBQyxRQUFlO0lBQzNELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULEVBQUUsRUFBRSxRQUFRO0tBQ2YsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsU0FBUyxvQ0FBb0MsQ0FBQyxRQUFlO0lBQ3pELElBQUksZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLE9BQU8sc0NBQXNDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVMsTUFBTTtRQUN4RSxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzVELElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxrQkFBd0MsQ0FBQztRQUM3RCxNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUV2QixJQUFJLE1BQU0sR0FBRztZQUNULEVBQUUsRUFBRSxRQUFRO1lBQ1osT0FBTyxFQUFFLE1BQU0sQ0FBQyxJQUFJO1lBQ3BCLGtCQUFrQixFQUFFLE1BQU07U0FDN0IsQ0FBQztRQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3pHLENBQUMsQ0FBQztTQUNELEtBQUssQ0FBQyxVQUFTLEdBQUc7UUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMxQixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBRUQsU0FBUyxrREFBa0QsQ0FBQyxRQUFlLEVBQUUsUUFBZTtJQUN4RixJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQztJQUN6QixPQUFPLHNDQUFzQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFTLE1BQU07UUFDeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsa0JBQXdDLENBQUM7UUFDN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLFVBQVUsR0FBRztZQUNiLEVBQUUsRUFBRSxXQUFXO1lBQ2YsVUFBVSxFQUFFLFFBQVE7WUFDcEIsVUFBVSxFQUFFLEVBQUU7WUFDZCxjQUFjLEVBQUU7Z0JBQ1osb0JBQW9CLEVBQUUsRUFBRTthQUMzQjtZQUNELGFBQWEsRUFBRTtnQkFDWCxRQUFRLEVBQUUsQ0FBQzthQUNkO1NBQ0osQ0FBQztRQUNGLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQztRQUNyQyxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUV0QixJQUFJLE1BQU0sR0FBRztZQUNULEVBQUUsRUFBRSxRQUFRO1lBQ1osT0FBTyxFQUFFLE1BQU0sQ0FBQyxJQUFJO1lBQ3BCLGtCQUFrQixFQUFFLE1BQU07U0FDN0IsQ0FBQztRQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3pHLENBQUMsQ0FBQztTQUNELEtBQUssQ0FBQyxVQUFTLEdBQUc7UUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMxQixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBRUQsU0FBUyxtQ0FBbUMsQ0FBQyxRQUFlO0lBQ3hELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULEVBQUUsRUFBRSxRQUFRO0tBQ2YsQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNuRyxDQUFDO0FBRUQsU0FBUyxrQ0FBa0MsQ0FBQyxNQUFhO0lBQ3JELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFDOUMsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE5QyxDQUE4QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2xHLENBQUM7QUFFRCxTQUFTLHdDQUF3QyxDQUFDLFNBQWdCO0lBQzlELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRSxTQUFTO0tBQ3RCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDcEcsQ0FBQztBQUVELFNBQVMsbUNBQW1DLENBQUMsUUFBZSxFQUFFLFVBQXFCO0lBQXJCLDJCQUFBLEVBQUEsZ0JBQXFCO0lBQy9FLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULGNBQWMsRUFBRSxRQUFRO1FBQ3hCLGlCQUFpQixFQUFFO1lBQ2YsZUFBZSxFQUFFLGNBQU0sRUFBRTtZQUN6QixLQUFLLEVBQUU7Z0JBQ0gsUUFBUSxFQUFFLENBQUM7Z0JBQ1gsS0FBSyxFQUFFO29CQUNBLFVBQVUsTUFBRztpQkFDbkI7YUFDSjtTQUNKO0tBQ0osQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNuRyxDQUFDO0FBRUQsU0FBZSwwQkFBMEIsQ0FBQyxPQUFjOzs7Ozs7b0JBQ2hELGdCQUFnQixHQUFHLE9BQU8sQ0FBQztvQkFDM0IsTUFBTSxHQUFHLEVBQUUsQ0FBQzs7O3lCQUNULElBQUk7b0JBQzRDLHFCQUFNLGtDQUFrQyxDQUFDLE1BQU0sQ0FBQyxFQUFBOztvQkFBL0Ysb0JBQW9CLEdBQTJCLFNBQWdEO29CQUNuRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLEVBQUM7d0JBQ3ZDLHNCQUFPLElBQUksRUFBQztxQkFDZjtvQkFDRyxrQkFBa0IsR0FBRyxvQkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDL0QsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBQzt3QkFDMUIsc0JBQU8sSUFBSSxFQUFDO3FCQUNmO29CQUNHLDRCQUE0QixHQUFHLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxDQUFDLEVBQTNCLENBQTJCLENBQUM7eUJBQzNDLE1BQU0sQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBbUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxnQkFBZ0IsRUFBekQsQ0FBeUQsQ0FBQyxDQUFDO29CQUN0SSxnQkFBTSxDQUFDLDRCQUE0QixDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsV0FBUyw0QkFBNEIsQ0FBQyxNQUFNLGdGQUE2RSxDQUFDLENBQUM7b0JBRTVLLElBQUksNEJBQTRCLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTt3QkFDMUMsc0JBQU8sNEJBQTRCLENBQUMsQ0FBQyxDQUFDLEVBQUM7cUJBQzFDO29CQUVELElBQUksa0JBQWtCLENBQUMsV0FBVyxFQUFFO3dCQUNoQyxNQUFNLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxDQUFDO3FCQUN0Qzt5QkFBTTt3QkFDSCxzQkFBTyxJQUFJLEVBQUM7cUJBQ2Y7Ozs7OztDQUVSO0FBRUQsU0FBZSxvQkFBb0IsQ0FBQyxTQUFnQjs7Ozs7d0JBQ3pCLHFCQUFNLHdDQUF3QyxDQUFDLFNBQVMsQ0FBQyxFQUFBOztvQkFBNUUsZ0JBQWdCLEdBQUcsU0FBeUQ7b0JBQzVFLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztvQkFDL0MsZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUF2QixDQUF1QixDQUFDLENBQUM7b0JBQ3pFLGdCQUFNLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRSxXQUFTLGdCQUFnQixDQUFDLE1BQU0seUVBQXNFLENBQUMsQ0FBQztvQkFDN0ksc0JBQU8sZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDOzs7O0NBQ3BDO0FBRUQsa0JBQWU7SUFDWCxZQUFZLEVBQUcsbUNBQW1DO0lBQ2xELGVBQWUsRUFBRyxzQ0FBc0M7SUFDeEQsYUFBYSxFQUFHLG9DQUFvQztJQUNwRCxZQUFZLEVBQUcsbUNBQW1DO0lBQ2xELFFBQVEsRUFBRyx3Q0FBd0M7SUFDbkQscUJBQXFCLEVBQUcsa0RBQWtEO0lBQzFFLG9CQUFvQixFQUFHLDBCQUEwQjtJQUNqRCxjQUFjLEVBQUcsb0JBQW9CO0lBQ3JDLHNCQUFzQixFQUFHLG1DQUFtQztDQUMvRCxDQUFDIn0=