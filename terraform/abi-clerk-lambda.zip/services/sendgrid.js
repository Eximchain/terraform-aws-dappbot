"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var mail_1 = __importDefault(require("@sendgrid/mail"));
var env_1 = require("../env");
var USING_SENDGRID = false;
if (env_1.sendgridApiKey && env_1.sendgridApiKey !== "") {
    mail_1.default.setApiKey(env_1.sendgridApiKey);
    USING_SENDGRID = true;
}
var FROM_ADDRESS = 'dappbot@eximchain.com';
function sendConfirmationMail(owner, dappname, dappDNS) {
    var confirmationParam = {
        from: FROM_ADDRESS,
        to: owner,
        subject: dappname + " generation complete!",
        text: dappname + " generation has completed!  You may now view your dapp at " + dappDNS + "."
    };
    if (USING_SENDGRID) {
        return mail_1.default.send(confirmationParam);
    }
    else {
        var msg = "No Sendgrid API key loaded, not sending following email: " + JSON.stringify(confirmationParam, undefined, 2);
        console.log(msg);
        return Promise.resolve(msg);
    }
}
exports.default = {
    sendConfirmation: sendConfirmationMail
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZGdyaWQuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvc2VuZGdyaWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSx3REFBb0M7QUFDcEMsOEJBQXdDO0FBRXhDLElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQztBQUUzQixJQUFJLG9CQUFjLElBQUksb0JBQWMsS0FBSyxFQUFFLEVBQUM7SUFDMUMsY0FBTSxDQUFDLFNBQVMsQ0FBQyxvQkFBYyxDQUFDLENBQUM7SUFDakMsY0FBYyxHQUFHLElBQUksQ0FBQztDQUN2QjtBQUVELElBQU0sWUFBWSxHQUFHLHVCQUF1QixDQUFDO0FBRzdDLFNBQVMsb0JBQW9CLENBQUMsS0FBWSxFQUFFLFFBQWUsRUFBRSxPQUFjO0lBQ3pFLElBQUksaUJBQWlCLEdBQUc7UUFDdEIsSUFBSSxFQUFHLFlBQVk7UUFDbkIsRUFBRSxFQUFHLEtBQUs7UUFDVixPQUFPLEVBQU0sUUFBUSwwQkFBdUI7UUFDNUMsSUFBSSxFQUFNLFFBQVEsa0VBQTZELE9BQU8sTUFBRztLQUMxRixDQUFBO0lBQ0QsSUFBSSxjQUFjLEVBQUM7UUFDakIsT0FBTyxjQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7S0FDdkM7U0FBTTtRQUNMLElBQUksR0FBRyxHQUFHLDhEQUE0RCxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUcsQ0FBQztRQUN4SCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3QjtBQUVILENBQUM7QUFFRCxrQkFBZTtJQUNiLGdCQUFnQixFQUFHLG9CQUFvQjtDQUN4QyxDQUFBIn0=