"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var codepipeline = new env_1.AWS.CodePipeline();
var PipelineJobs;
(function (PipelineJobs) {
    PipelineJobs["POC_CLEANUP"] = "POC_CLEANUP";
    PipelineJobs["ENTERPRISE_GITHUB_COMMIT"] = "ENTERPRISE_GITHUB_COMMIT";
})(PipelineJobs || (PipelineJobs = {}));
function pocPipelineParams(dappName, pipelineName, destBucket, owner) {
    var pipelineParam = {
        pipeline: {
            name: pipelineName,
            roleArn: env_1.pipelineRoleArn,
            version: 1,
            artifactStore: {
                location: env_1.artifactBucket,
                type: 'S3'
            },
            stages: [
                {
                    "name": "FetchDappseed",
                    "actions": [
                        {
                            "name": "Source",
                            "actionTypeId": {
                                "category": "Source",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "configuration": {
                                "S3Bucket": env_1.dappseedBucket,
                                "S3ObjectKey": dappName + "/dappseed.zip"
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "BuildDapp",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "name": "Build",
                            "actionTypeId": {
                                "category": "Build",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "CodeBuild"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "configuration": {
                                "ProjectName": env_1.codebuildId
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "DeployToS3",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "name": "Deploy",
                            "actionTypeId": {
                                "category": "Deploy",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "runOrder": 1,
                            "configuration": {
                                "BucketName": destBucket,
                                "Extract": "true"
                            }
                        },
                        {
                            "name": "Cleanup",
                            "actionTypeId": {
                                "category": "Invoke",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "Lambda"
                            },
                            "runOrder": 2,
                            "configuration": {
                                "FunctionName": env_1.servicesLambdaFxnName,
                                "UserParameters": JSON.stringify({
                                    Job: PipelineJobs.POC_CLEANUP,
                                    OwnerEmail: owner,
                                    DestinationBucket: destBucket,
                                    DappName: dappName
                                })
                            }
                        }
                    ]
                }
            ]
        }
    };
    return pipelineParam;
}
function enterpriseSrcPipelineParams(dappName, pipelineName, owner, targetRepoName, targetRepoOwner) {
    var pipelineParam = {
        pipeline: {
            name: pipelineName,
            roleArn: env_1.pipelineRoleArn,
            version: 1,
            artifactStore: {
                location: env_1.artifactBucket,
                type: 'S3'
            },
            stages: [
                {
                    "name": "FetchDappseed",
                    "actions": [
                        {
                            "name": "Source",
                            "actionTypeId": {
                                "category": "Source",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "configuration": {
                                "S3Bucket": env_1.dappseedBucket,
                                "S3ObjectKey": dappName + "/dappseed.zip"
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "BuildDapp",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "name": "Build",
                            "actionTypeId": {
                                "category": "Build",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "CodeBuild"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "configuration": {
                                "ProjectName": env_1.codebuildGenerateId
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "CommitToGithub",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "name": "Commit",
                            "actionTypeId": {
                                "category": "Invoke",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "Lambda"
                            },
                            "runOrder": 1,
                            "configuration": {
                                "FunctionName": env_1.servicesLambdaFxnName,
                                "UserParameters": JSON.stringify({
                                    Job: PipelineJobs.ENTERPRISE_GITHUB_COMMIT,
                                    OwnerEmail: owner,
                                    DappName: dappName,
                                    TargetRepoName: targetRepoName,
                                    TargetRepoOwner: targetRepoOwner
                                })
                            }
                        }
                    ]
                }
            ]
        }
    };
    return pipelineParam;
}
function enterpriseBuildPipelineParams(dappName, owner, pipelineName, targetRepoName, targetRepoOwner, destBucket) {
    var pipelineParam = {
        pipeline: {
            name: pipelineName,
            roleArn: env_1.pipelineRoleArn,
            version: 1,
            artifactStore: {
                location: env_1.artifactBucket,
                type: 'S3'
            },
            stages: [
                {
                    "name": "FetchSource",
                    "actions": [
                        {
                            "name": "Source",
                            "actionTypeId": {
                                "category": "Source",
                                "owner": "ThirdParty",
                                "version": "1",
                                "provider": "GitHub"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "SOURCE"
                                }
                            ],
                            "configuration": {
                                "Owner": targetRepoOwner,
                                "Repo": targetRepoName,
                                "Branch": "master",
                                "OAuthToken": env_1.githubToken
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "BuildDapp",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "SOURCE"
                                }
                            ],
                            "name": "Build",
                            "actionTypeId": {
                                "category": "Build",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "CodeBuild"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "configuration": {
                                "ProjectName": env_1.codebuildBuildId
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "DeployToS3",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "name": "Deploy",
                            "actionTypeId": {
                                "category": "Deploy",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "runOrder": 1,
                            "configuration": {
                                "BucketName": destBucket,
                                "Extract": "true"
                            }
                        },
                        {
                            "name": "Cleanup",
                            "actionTypeId": {
                                "category": "Invoke",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "Lambda"
                            },
                            "runOrder": 2,
                            "configuration": {
                                "FunctionName": env_1.servicesLambdaFxnName,
                                "UserParameters": JSON.stringify({
                                    Job: PipelineJobs.POC_CLEANUP,
                                    OwnerEmail: owner,
                                    DestinationBucket: destBucket,
                                    DappName: dappName
                                })
                            }
                        }
                    ]
                }
            ]
        }
    };
    return pipelineParam;
}
function promiseCreatePipeline(params) {
    var maxRetries = 5;
    return common_1.addAwsPromiseRetries(function () { return codepipeline.createPipeline(params).promise(); }, maxRetries);
}
function promiseCreatePocPipeline(dappName, pipelineName, destBucket, owner) {
    return promiseCreatePipeline(pocPipelineParams(dappName, pipelineName, destBucket, owner));
}
function promiseCreateEnterpriseSrcPipeline(dappName, pipelineName, owner, targetRepoName, targetRepoOwner) {
    return promiseCreatePipeline(enterpriseSrcPipelineParams(dappName, pipelineName, owner, targetRepoName, targetRepoOwner));
}
function promiseCreateEnterpriseBuildPipeline(dappName, owner, pipelineName, targetRepoName, targetRepoOwner, destBucket) {
    return promiseCreatePipeline(enterpriseBuildPipelineParams(dappName, owner, pipelineName, targetRepoName, targetRepoOwner, destBucket));
}
function promiseRunPipeline(pipelineName) {
    var maxRetries = 5;
    var params = {
        name: pipelineName
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.startPipelineExecution(params).promise(); }, maxRetries);
}
function promiseDeletePipeline(pipelineName) {
    var maxRetries = 5;
    var params = {
        name: pipelineName
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.deletePipeline(params).promise(); }, maxRetries);
}
function promiseCompleteJob(jobId) {
    var maxRetries = 5;
    var params = {
        jobId: jobId
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobSuccessResult(params).promise(); }, maxRetries);
}
function promiseFailJob(jobId, err) {
    var maxRetries = 5;
    var params = {
        jobId: jobId,
        failureDetails: {
            type: 'JobFailed',
            message: JSON.stringify(err)
        }
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobFailureResult(params).promise(); }, maxRetries);
}
exports.default = {
    createPocPipeline: promiseCreatePocPipeline,
    createEnterpriseSrcPipeline: promiseCreateEnterpriseSrcPipeline,
    createEnterpriseBuildPipeline: promiseCreateEnterpriseBuildPipeline,
    run: promiseRunPipeline,
    delete: promiseDeletePipeline,
    completeJob: promiseCompleteJob,
    failJob: promiseFailJob
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZXBpcGVsaW5lLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL2NvZGVwaXBlbGluZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG9DQUFpRDtBQUNqRCw4QkFBc0s7QUFHdEssSUFBTSxZQUFZLEdBQUcsSUFBSSxTQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFFNUMsSUFBSyxZQUdKO0FBSEQsV0FBSyxZQUFZO0lBQ2IsMkNBQTJCLENBQUE7SUFDM0IscUVBQXFELENBQUE7QUFDekQsQ0FBQyxFQUhJLFlBQVksS0FBWixZQUFZLFFBR2hCO0FBRUQsU0FBUyxpQkFBaUIsQ0FBQyxRQUFlLEVBQUUsWUFBbUIsRUFBRSxVQUFpQixFQUFFLEtBQVk7SUFDNUYsSUFBSSxhQUFhLEdBQXVCO1FBQ3BDLFFBQVEsRUFBRTtZQUNOLElBQUksRUFBRSxZQUFZO1lBQ2xCLE9BQU8sRUFBRSxxQkFBZTtZQUN4QixPQUFPLEVBQUUsQ0FBQztZQUNWLGFBQWEsRUFBRTtnQkFDWCxRQUFRLEVBQUUsb0JBQWM7Z0JBQ3hCLElBQUksRUFBRSxJQUFJO2FBQ2I7WUFDRCxNQUFNLEVBQUU7Z0JBQ0o7b0JBQ0ksTUFBTSxFQUFFLGVBQWU7b0JBQ3ZCLFNBQVMsRUFBRTt3QkFDUDs0QkFDSSxNQUFNLEVBQUUsUUFBUTs0QkFDaEIsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxRQUFRO2dDQUNwQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsSUFBSTs2QkFDbkI7NEJBQ0QsaUJBQWlCLEVBQUU7Z0NBQ2Y7b0NBQ0ksTUFBTSxFQUFFLFVBQVU7aUNBQ3JCOzZCQUNKOzRCQUNELGVBQWUsRUFBRTtnQ0FDYixVQUFVLEVBQUUsb0JBQWM7Z0NBQzFCLGFBQWEsRUFBSyxRQUFRLGtCQUFlOzZCQUM1Qzs0QkFDRCxVQUFVLEVBQUUsQ0FBQzt5QkFDaEI7cUJBQ0o7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksTUFBTSxFQUFFLFdBQVc7b0JBQ25CLFNBQVMsRUFBRTt3QkFDUDs0QkFDSSxnQkFBZ0IsRUFBRTtnQ0FDZDtvQ0FDSSxNQUFNLEVBQUUsVUFBVTtpQ0FDckI7NkJBQ0o7NEJBQ0QsTUFBTSxFQUFFLE9BQU87NEJBQ2YsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxPQUFPO2dDQUNuQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsV0FBVzs2QkFDMUI7NEJBQ0QsaUJBQWlCLEVBQUU7Z0NBQ2Y7b0NBQ0ksTUFBTSxFQUFFLE9BQU87aUNBQ2xCOzZCQUNKOzRCQUNELGVBQWUsRUFBRTtnQ0FDYixhQUFhLEVBQUUsaUJBQVc7NkJBQzdCOzRCQUNELFVBQVUsRUFBRSxDQUFDO3lCQUNoQjtxQkFDSjtpQkFDSjtnQkFDRDtvQkFDSSxNQUFNLEVBQUUsWUFBWTtvQkFDcEIsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLGdCQUFnQixFQUFFO2dDQUNkO29DQUNJLE1BQU0sRUFBRSxPQUFPO2lDQUNsQjs2QkFDSjs0QkFDRCxNQUFNLEVBQUUsUUFBUTs0QkFDaEIsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxRQUFRO2dDQUNwQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsSUFBSTs2QkFDbkI7NEJBQ0QsVUFBVSxFQUFFLENBQUM7NEJBQ2IsZUFBZSxFQUFFO2dDQUNiLFlBQVksRUFBRyxVQUFVO2dDQUN6QixTQUFTLEVBQUUsTUFBTTs2QkFDcEI7eUJBQ0o7d0JBQ0Q7NEJBQ0ksTUFBTSxFQUFFLFNBQVM7NEJBQ2pCLGNBQWMsRUFBRTtnQ0FDWixVQUFVLEVBQUUsUUFBUTtnQ0FDcEIsT0FBTyxFQUFFLEtBQUs7Z0NBQ2QsU0FBUyxFQUFFLEdBQUc7Z0NBQ2QsVUFBVSxFQUFFLFFBQVE7NkJBQ3ZCOzRCQUNELFVBQVUsRUFBQyxDQUFDOzRCQUNaLGVBQWUsRUFBRTtnQ0FDYixjQUFjLEVBQUUsMkJBQXFCO2dDQUNyQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29DQUM3QixHQUFHLEVBQUUsWUFBWSxDQUFDLFdBQVc7b0NBQzdCLFVBQVUsRUFBRSxLQUFLO29DQUNqQixpQkFBaUIsRUFBRyxVQUFVO29DQUM5QixRQUFRLEVBQUcsUUFBUTtpQ0FDdEIsQ0FBQzs2QkFDTDt5QkFDSjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7S0FDSixDQUFDO0lBQ0YsT0FBTyxhQUFhLENBQUM7QUFDekIsQ0FBQztBQUVELFNBQVMsMkJBQTJCLENBQUMsUUFBZSxFQUFFLFlBQW1CLEVBQUUsS0FBWSxFQUFFLGNBQXFCLEVBQUUsZUFBc0I7SUFDbEksSUFBSSxhQUFhLEdBQXVCO1FBQ3BDLFFBQVEsRUFBRTtZQUNOLElBQUksRUFBRSxZQUFZO1lBQ2xCLE9BQU8sRUFBRSxxQkFBZTtZQUN4QixPQUFPLEVBQUUsQ0FBQztZQUNWLGFBQWEsRUFBRTtnQkFDWCxRQUFRLEVBQUUsb0JBQWM7Z0JBQ3hCLElBQUksRUFBRSxJQUFJO2FBQ2I7WUFDRCxNQUFNLEVBQUU7Z0JBQ0o7b0JBQ0ksTUFBTSxFQUFFLGVBQWU7b0JBQ3ZCLFNBQVMsRUFBRTt3QkFDUDs0QkFDSSxNQUFNLEVBQUUsUUFBUTs0QkFDaEIsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxRQUFRO2dDQUNwQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsSUFBSTs2QkFDbkI7NEJBQ0QsaUJBQWlCLEVBQUU7Z0NBQ2Y7b0NBQ0ksTUFBTSxFQUFFLFVBQVU7aUNBQ3JCOzZCQUNKOzRCQUNELGVBQWUsRUFBRTtnQ0FDYixVQUFVLEVBQUUsb0JBQWM7Z0NBQzFCLGFBQWEsRUFBSyxRQUFRLGtCQUFlOzZCQUM1Qzs0QkFDRCxVQUFVLEVBQUUsQ0FBQzt5QkFDaEI7cUJBQ0o7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksTUFBTSxFQUFFLFdBQVc7b0JBQ25CLFNBQVMsRUFBRTt3QkFDUDs0QkFDSSxnQkFBZ0IsRUFBRTtnQ0FDZDtvQ0FDSSxNQUFNLEVBQUUsVUFBVTtpQ0FDckI7NkJBQ0o7NEJBQ0QsTUFBTSxFQUFFLE9BQU87NEJBQ2YsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxPQUFPO2dDQUNuQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsV0FBVzs2QkFDMUI7NEJBQ0QsaUJBQWlCLEVBQUU7Z0NBQ2Y7b0NBQ0ksTUFBTSxFQUFFLE9BQU87aUNBQ2xCOzZCQUNKOzRCQUNELGVBQWUsRUFBRTtnQ0FDYixhQUFhLEVBQUUseUJBQW1COzZCQUNyQzs0QkFDRCxVQUFVLEVBQUUsQ0FBQzt5QkFDaEI7cUJBQ0o7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksTUFBTSxFQUFFLGdCQUFnQjtvQkFDeEIsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLGdCQUFnQixFQUFFO2dDQUNkO29DQUNJLE1BQU0sRUFBRSxPQUFPO2lDQUNsQjs2QkFDSjs0QkFDRCxNQUFNLEVBQUUsUUFBUTs0QkFDaEIsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxRQUFRO2dDQUNwQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsUUFBUTs2QkFDdkI7NEJBQ0QsVUFBVSxFQUFDLENBQUM7NEJBQ1osZUFBZSxFQUFFO2dDQUNiLGNBQWMsRUFBRSwyQkFBcUI7Z0NBQ3JDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7b0NBQzdCLEdBQUcsRUFBRSxZQUFZLENBQUMsd0JBQXdCO29DQUMxQyxVQUFVLEVBQUUsS0FBSztvQ0FDakIsUUFBUSxFQUFHLFFBQVE7b0NBQ25CLGNBQWMsRUFBRSxjQUFjO29DQUM5QixlQUFlLEVBQUUsZUFBZTtpQ0FDbkMsQ0FBQzs2QkFDTDt5QkFDSjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7S0FDSixDQUFDO0lBQ0YsT0FBTyxhQUFhLENBQUM7QUFDekIsQ0FBQztBQUVELFNBQVMsNkJBQTZCLENBQUMsUUFBZSxFQUFFLEtBQVksRUFBRSxZQUFtQixFQUFFLGNBQXFCLEVBQUUsZUFBc0IsRUFBRSxVQUFpQjtJQUN2SixJQUFJLGFBQWEsR0FBdUI7UUFDcEMsUUFBUSxFQUFFO1lBQ04sSUFBSSxFQUFFLFlBQVk7WUFDbEIsT0FBTyxFQUFFLHFCQUFlO1lBQ3hCLE9BQU8sRUFBRSxDQUFDO1lBQ1YsYUFBYSxFQUFFO2dCQUNYLFFBQVEsRUFBRSxvQkFBYztnQkFDeEIsSUFBSSxFQUFFLElBQUk7YUFDYjtZQUNELE1BQU0sRUFBRTtnQkFDSjtvQkFDSSxNQUFNLEVBQUUsYUFBYTtvQkFDckIsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLE1BQU0sRUFBRSxRQUFROzRCQUNoQixjQUFjLEVBQUU7Z0NBQ1osVUFBVSxFQUFFLFFBQVE7Z0NBQ3BCLE9BQU8sRUFBRSxZQUFZO2dDQUNyQixTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsUUFBUTs2QkFDdkI7NEJBQ0QsaUJBQWlCLEVBQUU7Z0NBQ2Y7b0NBQ0ksTUFBTSxFQUFFLFFBQVE7aUNBQ25COzZCQUNKOzRCQUNELGVBQWUsRUFBRTtnQ0FDYixPQUFPLEVBQUUsZUFBZTtnQ0FDeEIsTUFBTSxFQUFFLGNBQWM7Z0NBQ3RCLFFBQVEsRUFBRSxRQUFRO2dDQUNsQixZQUFZLEVBQUUsaUJBQVc7NkJBQzVCOzRCQUNELFVBQVUsRUFBRSxDQUFDO3lCQUNoQjtxQkFDSjtpQkFDSjtnQkFDRDtvQkFDSSxNQUFNLEVBQUUsV0FBVztvQkFDbkIsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLGdCQUFnQixFQUFFO2dDQUNkO29DQUNJLE1BQU0sRUFBRSxRQUFRO2lDQUNuQjs2QkFDSjs0QkFDRCxNQUFNLEVBQUUsT0FBTzs0QkFDZixjQUFjLEVBQUU7Z0NBQ1osVUFBVSxFQUFFLE9BQU87Z0NBQ25CLE9BQU8sRUFBRSxLQUFLO2dDQUNkLFNBQVMsRUFBRSxHQUFHO2dDQUNkLFVBQVUsRUFBRSxXQUFXOzZCQUMxQjs0QkFDRCxpQkFBaUIsRUFBRTtnQ0FDZjtvQ0FDSSxNQUFNLEVBQUUsT0FBTztpQ0FDbEI7NkJBQ0o7NEJBQ0QsZUFBZSxFQUFFO2dDQUNiLGFBQWEsRUFBRSxzQkFBZ0I7NkJBQ2xDOzRCQUNELFVBQVUsRUFBRSxDQUFDO3lCQUNoQjtxQkFDSjtpQkFDSjtnQkFDRDtvQkFDSSxNQUFNLEVBQUUsWUFBWTtvQkFDcEIsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLGdCQUFnQixFQUFFO2dDQUNkO29DQUNJLE1BQU0sRUFBRSxPQUFPO2lDQUNsQjs2QkFDSjs0QkFDRCxNQUFNLEVBQUUsUUFBUTs0QkFDaEIsY0FBYyxFQUFFO2dDQUNaLFVBQVUsRUFBRSxRQUFRO2dDQUNwQixPQUFPLEVBQUUsS0FBSztnQ0FDZCxTQUFTLEVBQUUsR0FBRztnQ0FDZCxVQUFVLEVBQUUsSUFBSTs2QkFDbkI7NEJBQ0QsVUFBVSxFQUFFLENBQUM7NEJBQ2IsZUFBZSxFQUFFO2dDQUNiLFlBQVksRUFBRyxVQUFVO2dDQUN6QixTQUFTLEVBQUUsTUFBTTs2QkFDcEI7eUJBQ0o7d0JBQ0Q7NEJBQ0ksTUFBTSxFQUFFLFNBQVM7NEJBQ2pCLGNBQWMsRUFBRTtnQ0FDWixVQUFVLEVBQUUsUUFBUTtnQ0FDcEIsT0FBTyxFQUFFLEtBQUs7Z0NBQ2QsU0FBUyxFQUFFLEdBQUc7Z0NBQ2QsVUFBVSxFQUFFLFFBQVE7NkJBQ3ZCOzRCQUNELFVBQVUsRUFBQyxDQUFDOzRCQUNaLGVBQWUsRUFBRTtnQ0FDYixjQUFjLEVBQUUsMkJBQXFCO2dDQUNyQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29DQUM3QixHQUFHLEVBQUUsWUFBWSxDQUFDLFdBQVc7b0NBQzdCLFVBQVUsRUFBRSxLQUFLO29DQUNqQixpQkFBaUIsRUFBRyxVQUFVO29DQUM5QixRQUFRLEVBQUcsUUFBUTtpQ0FDdEIsQ0FBQzs2QkFDTDt5QkFDSjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7S0FDSixDQUFDO0lBQ0YsT0FBTyxhQUFhLENBQUM7QUFDekIsQ0FBQztBQUVELFNBQVMscUJBQXFCLENBQUMsTUFBVTtJQUNyQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsWUFBWSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBN0MsQ0FBNkMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNqRyxDQUFDO0FBRUQsU0FBUyx3QkFBd0IsQ0FBQyxRQUFlLEVBQUUsWUFBbUIsRUFBRSxVQUFpQixFQUFFLEtBQVk7SUFDbkcsT0FBTyxxQkFBcUIsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQy9GLENBQUM7QUFFRCxTQUFTLGtDQUFrQyxDQUFDLFFBQWUsRUFBRSxZQUFtQixFQUFFLEtBQVksRUFBRSxjQUFxQixFQUFFLGVBQXNCO0lBQ3pJLE9BQU8scUJBQXFCLENBQUMsMkJBQTJCLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDOUgsQ0FBQztBQUNELFNBQVMsb0NBQW9DLENBQUMsUUFBZSxFQUFFLEtBQVksRUFBRSxZQUFtQixFQUFFLGNBQXFCLEVBQUUsZUFBc0IsRUFBRSxVQUFpQjtJQUM5SixPQUFPLHFCQUFxQixDQUFDLDZCQUE2QixDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUM1SSxDQUFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxZQUFtQjtJQUMzQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxJQUFJLEVBQUUsWUFBWTtLQUNyQixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsWUFBWSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFyRCxDQUFxRCxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3pHLENBQUM7QUFFRCxTQUFTLHFCQUFxQixDQUFDLFlBQW1CO0lBQzlDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULElBQUksRUFBRSxZQUFZO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxZQUFZLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE3QyxDQUE2QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2pHLENBQUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLEtBQVk7SUFDcEMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsS0FBSyxFQUFHLEtBQUs7S0FDaEIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsU0FBUyxjQUFjLENBQUMsS0FBWSxFQUFFLEdBQU87SUFDekMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsS0FBSyxFQUFHLEtBQUs7UUFDYixjQUFjLEVBQUc7WUFDYixJQUFJLEVBQUcsV0FBVztZQUNsQixPQUFPLEVBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7U0FDaEM7S0FDSixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsWUFBWSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFsRCxDQUFrRCxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3RHLENBQUM7QUFFRCxrQkFBZTtJQUNYLGlCQUFpQixFQUFFLHdCQUF3QjtJQUMzQywyQkFBMkIsRUFBRSxrQ0FBa0M7SUFDL0QsNkJBQTZCLEVBQUUsb0NBQW9DO0lBQ25FLEdBQUcsRUFBRSxrQkFBa0I7SUFDdkIsTUFBTSxFQUFFLHFCQUFxQjtJQUM3QixXQUFXLEVBQUUsa0JBQWtCO0lBQy9CLE9BQU8sRUFBRyxjQUFjO0NBQzNCLENBQUEifQ==