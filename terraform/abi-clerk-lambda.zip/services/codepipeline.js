"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var codepipeline = new env_1.AWS.CodePipeline();
function pipelineParams(dappName, pipelineName, destBucket, owner) {
    var pipelineParam = {
        pipeline: {
            name: pipelineName,
            roleArn: env_1.pipelineRoleArn,
            version: 1,
            artifactStore: {
                location: env_1.artifactBucket,
                type: 'S3'
            },
            stages: [
                {
                    "name": "FetchDappseed",
                    "actions": [
                        {
                            "name": "Source",
                            "actionTypeId": {
                                "category": "Source",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "configuration": {
                                "S3Bucket": env_1.dappseedBucket,
                                "S3ObjectKey": dappName + "/dappseed.zip"
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "BuildDapp",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "DAPPSEED"
                                }
                            ],
                            "name": "Build",
                            "actionTypeId": {
                                "category": "Build",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "CodeBuild"
                            },
                            "outputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "configuration": {
                                "ProjectName": env_1.codebuildId
                            },
                            "runOrder": 1
                        }
                    ]
                },
                {
                    "name": "DeployToS3",
                    "actions": [
                        {
                            "inputArtifacts": [
                                {
                                    "name": "BUILD"
                                }
                            ],
                            "name": "Deploy",
                            "actionTypeId": {
                                "category": "Deploy",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "S3"
                            },
                            "runOrder": 1,
                            "configuration": {
                                "BucketName": destBucket,
                                "Extract": "true"
                            }
                        },
                        {
                            "name": "Cleanup",
                            "actionTypeId": {
                                "category": "Invoke",
                                "owner": "AWS",
                                "version": "1",
                                "provider": "Lambda"
                            },
                            "runOrder": 2,
                            "configuration": {
                                "FunctionName": env_1.servicesLambdaFxnName,
                                "UserParameters": JSON.stringify({
                                    OwnerEmail: owner,
                                    DestinationBucket: destBucket,
                                    DappName: dappName
                                })
                            }
                        }
                    ]
                }
            ]
        }
    };
    return pipelineParam;
}
function promiseCreatePipeline(dappName, pipelineName, destBucket, owner) {
    var maxRetries = 5;
    var params = pipelineParams(dappName, pipelineName, destBucket, owner);
    return common_1.addAwsPromiseRetries(function () { return codepipeline.createPipeline(params).promise(); }, maxRetries);
}
function promiseRunPipeline(pipelineName) {
    var maxRetries = 5;
    var params = {
        name: pipelineName
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.startPipelineExecution(params).promise(); }, maxRetries);
}
function promiseDeletePipeline(pipelineName) {
    var maxRetries = 5;
    var params = {
        name: pipelineName
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.deletePipeline(params).promise(); }, maxRetries);
}
function promiseCompleteJob(jobId) {
    var maxRetries = 5;
    var params = {
        jobId: jobId
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobSuccessResult(params).promise(); }, maxRetries);
}
function promiseFailJob(jobId, err) {
    var maxRetries = 5;
    var params = {
        jobId: jobId,
        failureDetails: {
            type: 'JobFailed',
            message: JSON.stringify(err)
        }
    };
    return common_1.addAwsPromiseRetries(function () { return codepipeline.putJobFailureResult(params).promise(); }, maxRetries);
}
exports.default = {
    create: promiseCreatePipeline,
    run: promiseRunPipeline,
    delete: promiseDeletePipeline,
    completeJob: promiseCompleteJob,
    failJob: promiseFailJob
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZXBpcGVsaW5lLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL2NvZGVwaXBlbGluZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG9DQUFpRDtBQUNqRCw4QkFBa0g7QUFHbEgsSUFBTSxZQUFZLEdBQUcsSUFBSSxTQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFFNUMsU0FBUyxjQUFjLENBQUMsUUFBZSxFQUFFLFlBQW1CLEVBQUUsVUFBaUIsRUFBRSxLQUFZO0lBQ3pGLElBQUksYUFBYSxHQUF1QjtRQUNwQyxRQUFRLEVBQUU7WUFDTixJQUFJLEVBQUUsWUFBWTtZQUNsQixPQUFPLEVBQUUscUJBQWU7WUFDeEIsT0FBTyxFQUFFLENBQUM7WUFDVixhQUFhLEVBQUU7Z0JBQ1gsUUFBUSxFQUFFLG9CQUFjO2dCQUN4QixJQUFJLEVBQUUsSUFBSTthQUNiO1lBQ0QsTUFBTSxFQUFFO2dCQUNKO29CQUNJLE1BQU0sRUFBRSxlQUFlO29CQUN2QixTQUFTLEVBQUU7d0JBQ1A7NEJBQ0ksTUFBTSxFQUFFLFFBQVE7NEJBQ2hCLGNBQWMsRUFBRTtnQ0FDWixVQUFVLEVBQUUsUUFBUTtnQ0FDcEIsT0FBTyxFQUFFLEtBQUs7Z0NBQ2QsU0FBUyxFQUFFLEdBQUc7Z0NBQ2QsVUFBVSxFQUFFLElBQUk7NkJBQ25COzRCQUNELGlCQUFpQixFQUFFO2dDQUNmO29DQUNJLE1BQU0sRUFBRSxVQUFVO2lDQUNyQjs2QkFDSjs0QkFDRCxlQUFlLEVBQUU7Z0NBQ2IsVUFBVSxFQUFFLG9CQUFjO2dDQUMxQixhQUFhLEVBQUssUUFBUSxrQkFBZTs2QkFDNUM7NEJBQ0QsVUFBVSxFQUFFLENBQUM7eUJBQ2hCO3FCQUNKO2lCQUNKO2dCQUNEO29CQUNJLE1BQU0sRUFBRSxXQUFXO29CQUNuQixTQUFTLEVBQUU7d0JBQ1A7NEJBQ0ksZ0JBQWdCLEVBQUU7Z0NBQ2Q7b0NBQ0ksTUFBTSxFQUFFLFVBQVU7aUNBQ3JCOzZCQUNKOzRCQUNELE1BQU0sRUFBRSxPQUFPOzRCQUNmLGNBQWMsRUFBRTtnQ0FDWixVQUFVLEVBQUUsT0FBTztnQ0FDbkIsT0FBTyxFQUFFLEtBQUs7Z0NBQ2QsU0FBUyxFQUFFLEdBQUc7Z0NBQ2QsVUFBVSxFQUFFLFdBQVc7NkJBQzFCOzRCQUNELGlCQUFpQixFQUFFO2dDQUNmO29DQUNJLE1BQU0sRUFBRSxPQUFPO2lDQUNsQjs2QkFDSjs0QkFDRCxlQUFlLEVBQUU7Z0NBQ2IsYUFBYSxFQUFFLGlCQUFXOzZCQUM3Qjs0QkFDRCxVQUFVLEVBQUUsQ0FBQzt5QkFDaEI7cUJBQ0o7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksTUFBTSxFQUFFLFlBQVk7b0JBQ3BCLFNBQVMsRUFBRTt3QkFDUDs0QkFDSSxnQkFBZ0IsRUFBRTtnQ0FDZDtvQ0FDSSxNQUFNLEVBQUUsT0FBTztpQ0FDbEI7NkJBQ0o7NEJBQ0QsTUFBTSxFQUFFLFFBQVE7NEJBQ2hCLGNBQWMsRUFBRTtnQ0FDWixVQUFVLEVBQUUsUUFBUTtnQ0FDcEIsT0FBTyxFQUFFLEtBQUs7Z0NBQ2QsU0FBUyxFQUFFLEdBQUc7Z0NBQ2QsVUFBVSxFQUFFLElBQUk7NkJBQ25COzRCQUNELFVBQVUsRUFBRSxDQUFDOzRCQUNiLGVBQWUsRUFBRTtnQ0FDYixZQUFZLEVBQUcsVUFBVTtnQ0FDekIsU0FBUyxFQUFFLE1BQU07NkJBQ3BCO3lCQUNKO3dCQUNEOzRCQUNJLE1BQU0sRUFBRSxTQUFTOzRCQUNqQixjQUFjLEVBQUU7Z0NBQ1osVUFBVSxFQUFFLFFBQVE7Z0NBQ3BCLE9BQU8sRUFBRSxLQUFLO2dDQUNkLFNBQVMsRUFBRSxHQUFHO2dDQUNkLFVBQVUsRUFBRSxRQUFROzZCQUN2Qjs0QkFDRCxVQUFVLEVBQUMsQ0FBQzs0QkFDWixlQUFlLEVBQUU7Z0NBQ2IsY0FBYyxFQUFFLDJCQUFxQjtnQ0FDckMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQ0FDN0IsVUFBVSxFQUFFLEtBQUs7b0NBQ2pCLGlCQUFpQixFQUFHLFVBQVU7b0NBQzlCLFFBQVEsRUFBRyxRQUFRO2lDQUN0QixDQUFDOzZCQUNMO3lCQUNKO3FCQUNKO2lCQUNKO2FBQ0o7U0FDSjtLQUNKLENBQUM7SUFDRixPQUFPLGFBQWEsQ0FBQztBQUN6QixDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxRQUFlLEVBQUUsWUFBbUIsRUFBRSxVQUFpQixFQUFFLEtBQVk7SUFDaEcsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHLGNBQWMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RSxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxZQUFZLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE3QyxDQUE2QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2pHLENBQUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLFlBQW1CO0lBQzNDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULElBQUksRUFBRSxZQUFZO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxZQUFZLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXJELENBQXFELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDekcsQ0FBQztBQUVELFNBQVMscUJBQXFCLENBQUMsWUFBbUI7SUFDOUMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsSUFBSSxFQUFFLFlBQVk7S0FDckIsQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFlBQVksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQTdDLENBQTZDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDakcsQ0FBQztBQUVELFNBQVMsa0JBQWtCLENBQUMsS0FBWTtJQUNwQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxLQUFLLEVBQUcsS0FBSztLQUNoQixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsWUFBWSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFsRCxDQUFrRCxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3RHLENBQUM7QUFFRCxTQUFTLGNBQWMsQ0FBQyxLQUFZLEVBQUUsR0FBTztJQUN6QyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxLQUFLLEVBQUcsS0FBSztRQUNiLGNBQWMsRUFBRztZQUNiLElBQUksRUFBRyxXQUFXO1lBQ2xCLE9BQU8sRUFBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztTQUNoQztLQUNKLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxZQUFZLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxELENBQWtELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEcsQ0FBQztBQUVELGtCQUFlO0lBQ1gsTUFBTSxFQUFFLHFCQUFxQjtJQUM3QixHQUFHLEVBQUUsa0JBQWtCO0lBQ3ZCLE1BQU0sRUFBRSxxQkFBcUI7SUFDN0IsV0FBVyxFQUFFLGtCQUFrQjtJQUMvQixPQUFPLEVBQUcsY0FBYztDQUMzQixDQUFBIn0=