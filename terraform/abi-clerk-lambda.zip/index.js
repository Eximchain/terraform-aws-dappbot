'use strict';
const api = require('./api');
const validate = require('./validate');

exports.handler = async (event) => {
    console.log("request: " + JSON.stringify(event));

    let method = event.pathParameters.proxy;
    let body = null;
    if (event.body) {
        body = JSON.parse(event.body);
    }
    let authorizedUser = event.requestContext.authorizer.claims["cognito:username"];
    let email = event.requestContext.authorizer.claims.email;

    let responsePromise = (async function(method) {
        switch(method) {
            case 'create':
                await validate.create(body, authorizedUser, email);
                console.log("Create validation passed");
                return api.create(body, email);
            case 'read':
                await validate.read(body);
                return api.read(body, email);
            case 'update':
                await validate.update(body);
                return api.update(body, email);
            case 'delete':
                await validate.delete(body);
                return api.delete(body);
            case 'list':
                return api.list(email);
            default:
                throw new Error("Unrecognized method name ".concat(method));
        }
    })(method);

    let response = await responsePromise;
    return response;
};