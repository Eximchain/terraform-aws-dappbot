"use strict";
// CUSTOM ERROR TYPES
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ProcessingError = /** @class */ (function () {
    function ProcessingError(message) {
        this.name = "ProcessingError";
        this.message = message;
    }
    return ProcessingError;
}());
exports.ProcessingError = ProcessingError;
var StateValidationError = /** @class */ (function (_super) {
    __extends(StateValidationError, _super);
    function StateValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "StateValidationError";
        return _this;
    }
    return StateValidationError;
}(ProcessingError));
exports.StateValidationError = StateValidationError;
var PermissionError = /** @class */ (function (_super) {
    __extends(PermissionError, _super);
    function PermissionError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "PermissionError";
        return _this;
    }
    return PermissionError;
}(ProcessingError));
exports.PermissionError = PermissionError;
var InternalProcessingError = /** @class */ (function (_super) {
    __extends(InternalProcessingError, _super);
    function InternalProcessingError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "InternalProcessingError";
        return _this;
    }
    return InternalProcessingError;
}(ProcessingError));
exports.InternalProcessingError = InternalProcessingError;
// ASSERT METHODS
function assert(condition, message, errorType) {
    if (errorType === void 0) { errorType = ProcessingError; }
    if (!condition) {
        throw new errorType(message);
    }
}
function assertStateValid(condition, message) {
    return assert(condition, message, StateValidationError);
}
exports.assertStateValid = assertStateValid;
function assertPermission(condition, message) {
    return assert(condition, message, PermissionError);
}
exports.assertPermission = assertPermission;
function assertInternal(condition) {
    var message = "Internal error during processing";
    return assert(condition, message, InternalProcessingError);
}
exports.assertInternal = assertInternal;
function throwInternalValidationError() {
    return assertInternal(false);
}
exports.throwInternalValidationError = throwInternalValidationError;
exports.default = { assertStateValid: assertStateValid, assertPermission: assertPermission, assertInternal: assertInternal, throwInternalValidationError: throwInternalValidationError };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JzLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVycm9ycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7QUFFckI7SUFHSSx5QkFBWSxPQUFjO1FBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUcsaUJBQWlCLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0IsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0FBQyxBQVBELElBT0M7QUFQWSwwQ0FBZTtBQVM1QjtJQUEwQyx3Q0FBZTtJQUNyRCw4QkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxzQkFBc0IsQ0FBQzs7SUFDdkMsQ0FBQztJQUNMLDJCQUFDO0FBQUQsQ0FBQyxBQUxELENBQTBDLGVBQWUsR0FLeEQ7QUFMWSxvREFBb0I7QUFPakM7SUFBcUMsbUNBQWU7SUFDaEQseUJBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcsaUJBQWlCLENBQUM7O0lBQ2xDLENBQUM7SUFDTCxzQkFBQztBQUFELENBQUMsQUFMRCxDQUFxQyxlQUFlLEdBS25EO0FBTFksMENBQWU7QUFPNUI7SUFBNkMsMkNBQWU7SUFDeEQsaUNBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcseUJBQXlCLENBQUM7O0lBQzFDLENBQUM7SUFDTCw4QkFBQztBQUFELENBQUMsQUFMRCxDQUE2QyxlQUFlLEdBSzNEO0FBTFksMERBQXVCO0FBT3BDLGlCQUFpQjtBQUVqQixTQUFTLE1BQU0sQ0FBQyxTQUFhLEVBQUUsT0FBYyxFQUFFLFNBQXlCO0lBQXpCLDBCQUFBLEVBQUEsMkJBQXlCO0lBQ3BFLElBQUksQ0FBQyxTQUFTLEVBQUU7UUFDWixNQUFNLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ2hDO0FBQ0wsQ0FBQztBQUVELFNBQWdCLGdCQUFnQixDQUFDLFNBQWEsRUFBRSxPQUFjO0lBQzFELE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztBQUM1RCxDQUFDO0FBRkQsNENBRUM7QUFFRCxTQUFnQixnQkFBZ0IsQ0FBQyxTQUFhLEVBQUUsT0FBYztJQUMxRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0FBQ3ZELENBQUM7QUFGRCw0Q0FFQztBQUVELFNBQWdCLGNBQWMsQ0FBQyxTQUFhO0lBQ3hDLElBQUksT0FBTyxHQUFHLGtDQUFrQyxDQUFDO0lBQ2pELE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztBQUMvRCxDQUFDO0FBSEQsd0NBR0M7QUFFRCxTQUFnQiw0QkFBNEI7SUFDeEMsT0FBTyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakMsQ0FBQztBQUZELG9FQUVDO0FBRUQsa0JBQWUsRUFBRSxnQkFBZ0Isa0JBQUEsRUFBRSxnQkFBZ0Isa0JBQUEsRUFBRSxjQUFjLGdCQUFBLEVBQUUsNEJBQTRCLDhCQUFBLEVBQUUsQ0FBQyJ9