"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __importDefault(require("./services"));
var errors_1 = require("./errors");
var common_1 = require("./common");
var dynamoDB = services_1.default.dynamoDB, route53 = services_1.default.route53, cloudfront = services_1.default.cloudfront, s3 = services_1.default.s3, codepipeline = services_1.default.codepipeline;
var validate_1 = __importDefault(require("./validate"));
var logErr = function (stage, err) { console.log("Error on " + stage + ": ", err); };
var logNonFatalErr = function (stage, reason) { console.log("Ignoring non-fatal error during " + stage + ": " + reason); };
var logSuccess = function (stage, res) { console.log("Successfully completed " + stage + "; result: ", res); };
function callAndLog(stage, promise) {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, promise];
                case 1:
                    res = _a.sent();
                    logSuccess(stage, res);
                    return [2 /*return*/, res];
                case 2:
                    err_1 = _a.sent();
                    logErr(stage, err_1);
                    throw err_1;
                case 3: return [2 /*return*/];
            }
        });
    });
}
function createProcessorForTier(tier) {
    switch (tier) {
        case common_1.DappTiers.POC:
            return createLegacyPoc;
        case common_1.DappTiers.STANDARD:
            return createStandardDapp;
        case common_1.DappTiers.PROFESSIONAL:
            throw new errors_1.StateValidationError("PROFESSIONAL tier not yet implemented for 'create'");
        case common_1.DappTiers.ENTERPRISE:
            return createEnterpriseDapp;
        default:
            throw new errors_1.StateValidationError("No 'create' processor exists for invalid tier '" + tier + "'");
    }
}
function processorCreate(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, processOp, tier, tierProcessor;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    // Check if the dbItem exists so the compiler knows the object can be referenced below
                    if (!dbItem.Item)
                        throw new errors_1.StateValidationError('Create error: Corresponding DynamoDB record could not be found.');
                    processOp = validate_1.default.stateCreate(dbItem);
                    if (!processOp) {
                        console.log("Ignoring operation 'create'");
                        return [2 /*return*/, {}];
                    }
                    tier = dbItem.Item.Tier.S;
                    tierProcessor = createProcessorForTier(tier);
                    return [2 /*return*/, tierProcessor(dappName, dbItem.Item)];
            }
        });
    });
}
function createLegacyPoc(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var abi, addr, web3URL, guardianURL, bucketName, owner, pipelineName, dnsName, s3Dns, enableCORSPromise, putLoadingPagePromise, cloudfrontDistroId, cloudfrontDns, newDistroResult, newDistro, err_2, _a, conflictingDistro, err_3, createPipelinePromise, createDnsRecordPromise;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    abi = dappItem.Abi.S;
                    addr = dappItem.ContractAddr.S;
                    web3URL = dappItem.Web3URL.S;
                    guardianURL = dappItem.GuardianURL.S;
                    bucketName = dappItem.S3BucketName.S;
                    owner = dappItem.OwnerEmail.S;
                    pipelineName = dappItem.PipelineName.S;
                    dnsName = dappItem.DnsName.S;
                    s3Dns = s3.bucketEndpoint(bucketName);
                    return [4 /*yield*/, callAndLog('Create S3 Bucket', s3.createBucketWithTags(bucketName, dappName, owner))];
                case 1:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Set Bucket Readable', s3.setBucketPublic(bucketName))];
                case 2:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Configure Bucket Website', s3.configureBucketWebsite(bucketName))];
                case 3:
                    _b.sent();
                    enableCORSPromise = callAndLog('Enable Bucket CORS', s3.enableBucketCors(bucketName, dnsName));
                    putLoadingPagePromise = callAndLog('Put Loading Page', s3.putLoadingPage(bucketName));
                    return [4 /*yield*/, Promise.all([enableCORSPromise, putLoadingPagePromise])];
                case 4:
                    _b.sent();
                    _b.label = 5;
                case 5:
                    _b.trys.push([5, 7, , 16]);
                    return [4 /*yield*/, callAndLog('Create Cloudfront Distro', cloudfront.createDistro(dappName, owner, s3Dns, dnsName))];
                case 6:
                    newDistroResult = _b.sent();
                    newDistro = newDistroResult.Distribution;
                    cloudfrontDistroId = newDistro.Id;
                    cloudfrontDns = newDistro.DomainName;
                    return [3 /*break*/, 16];
                case 7:
                    err_2 = _b.sent();
                    _a = err_2.code;
                    switch (_a) {
                        case 'CNAMEAlreadyExists': return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 14];
                case 8:
                    _b.trys.push([8, 12, , 13]);
                    return [4 /*yield*/, callAndLog('Get Conflicting Cloudfront Distro', cloudfront.getConflictingDistro(dnsName))];
                case 9:
                    conflictingDistro = _b.sent();
                    return [4 /*yield*/, validate_1.default.conflictingDistroRepurposable(conflictingDistro, owner)];
                case 10:
                    _b.sent();
                    // Check if the distro exists so the compiler knows the object can be referenced below
                    if (!conflictingDistro)
                        throw new errors_1.InternalProcessingError("Got CNAMEAlreadyExists, but no conflicting distributions were found.  Bug!");
                    // Required vars to exit the block without errors
                    cloudfrontDistroId = conflictingDistro.Id;
                    cloudfrontDns = conflictingDistro.DomainName;
                    return [4 /*yield*/, callAndLog('Update Cloudfront Origin', cloudfront.updateOriginAndEnable(cloudfrontDistroId, s3Dns))];
                case 11:
                    _b.sent();
                    return [3 /*break*/, 13];
                case 12:
                    err_3 = _b.sent();
                    logErr("Repurpose existing Cloudfrong Distribution", err_3);
                    throw err_3;
                case 13: return [3 /*break*/, 15];
                case 14:
                    logErr("Create Cloudfront Distribution", err_2);
                    throw err_2;
                case 15: return [3 /*break*/, 16];
                case 16: return [4 /*yield*/, callAndLog('Put DappSeed', s3.putDappseed({ dappName: dappName, web3URL: web3URL, guardianURL: guardianURL, abi: abi, addr: addr, cdnURL: cloudfrontDns }))];
                case 17:
                    _b.sent();
                    createPipelinePromise = callAndLog('Create POC CodePipeline', codepipeline.createPocPipeline(dappName, pipelineName, bucketName, owner));
                    createDnsRecordPromise = callAndLog('Create Route 53 record', route53.createRecord(dnsName, cloudfrontDns));
                    return [4 /*yield*/, Promise.all([createPipelinePromise, createDnsRecordPromise])];
                case 18:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Set DynamoDB item BUILDING_DAPP', dynamoDB.setItemBuilding(dappItem, cloudfrontDistroId, cloudfrontDns))];
                case 19:
                    _b.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function createStandardDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Set DynamoDB item AVAILABLE', dynamoDB.setItemAvailable(dappItem))];
                case 1:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function createEnterpriseDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var abi, addr, web3URL, guardianURL, bucketName, owner, pipelineName, dnsName, targetRepoName, targetRepoOwner, s3Dns, enableCORSPromise, putLoadingPagePromise, cloudfrontDistroId, cloudfrontDns, newDistroResult, newDistro, err_4, _a, conflictingDistro, err_5, createPipelinePromise, createDnsRecordPromise;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    abi = dappItem.Abi.S;
                    addr = dappItem.ContractAddr.S;
                    web3URL = dappItem.Web3URL.S;
                    guardianURL = dappItem.GuardianURL.S;
                    bucketName = dappItem.S3BucketName.S;
                    owner = dappItem.OwnerEmail.S;
                    pipelineName = dappItem.PipelineName.S;
                    dnsName = dappItem.DnsName.S;
                    targetRepoName = dappItem.TargetRepoName.S;
                    targetRepoOwner = dappItem.TargetRepoOwner.S;
                    s3Dns = s3.bucketEndpoint(bucketName);
                    return [4 /*yield*/, callAndLog('Create S3 Bucket', s3.createBucketWithTags(bucketName, dappName, owner))];
                case 1:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Set Bucket Readable', s3.setBucketPublic(bucketName))];
                case 2:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Configure Bucket Website', s3.configureBucketWebsite(bucketName))];
                case 3:
                    _b.sent();
                    enableCORSPromise = callAndLog('Enable Bucket CORS', s3.enableBucketCors(bucketName, dnsName));
                    putLoadingPagePromise = callAndLog('Put Loading Page', s3.putLoadingPage(bucketName));
                    return [4 /*yield*/, Promise.all([enableCORSPromise, putLoadingPagePromise])];
                case 4:
                    _b.sent();
                    _b.label = 5;
                case 5:
                    _b.trys.push([5, 7, , 16]);
                    return [4 /*yield*/, callAndLog('Create Cloudfront Distro', cloudfront.createDistro(dappName, owner, s3Dns, dnsName))];
                case 6:
                    newDistroResult = _b.sent();
                    newDistro = newDistroResult.Distribution;
                    cloudfrontDistroId = newDistro.Id;
                    cloudfrontDns = newDistro.DomainName;
                    return [3 /*break*/, 16];
                case 7:
                    err_4 = _b.sent();
                    _a = err_4.code;
                    switch (_a) {
                        case 'CNAMEAlreadyExists': return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 14];
                case 8:
                    _b.trys.push([8, 12, , 13]);
                    return [4 /*yield*/, callAndLog('Get Conflicting Cloudfront Distro', cloudfront.getConflictingDistro(dnsName))];
                case 9:
                    conflictingDistro = _b.sent();
                    return [4 /*yield*/, validate_1.default.conflictingDistroRepurposable(conflictingDistro, owner)];
                case 10:
                    _b.sent();
                    // Check if the distro exists so the compiler knows the object can be referenced below
                    if (!conflictingDistro)
                        throw new errors_1.InternalProcessingError("Got CNAMEAlreadyExists, but no conflicting distributions were found.  Bug!");
                    // Required vars to exit the block without errors
                    cloudfrontDistroId = conflictingDistro.Id;
                    cloudfrontDns = conflictingDistro.DomainName;
                    return [4 /*yield*/, callAndLog('Update Cloudfront Origin', cloudfront.updateOriginAndEnable(cloudfrontDistroId, s3Dns))];
                case 11:
                    _b.sent();
                    return [3 /*break*/, 13];
                case 12:
                    err_5 = _b.sent();
                    logErr("Repurpose existing Cloudfrong Distribution", err_5);
                    throw err_5;
                case 13: return [3 /*break*/, 15];
                case 14:
                    logErr("Create Cloudfront Distribution", err_4);
                    throw err_4;
                case 15: return [3 /*break*/, 16];
                case 16: return [4 /*yield*/, callAndLog('Put DappSeed', s3.putDappseed({ dappName: dappName, web3URL: web3URL, guardianURL: guardianURL, abi: abi, addr: addr, cdnURL: cloudfrontDns }))];
                case 17:
                    _b.sent();
                    createPipelinePromise = callAndLog('Create Enterprise CodePipeline', codepipeline.createEnterprisePipeline(dappName, pipelineName, owner, targetRepoName, targetRepoOwner));
                    createDnsRecordPromise = callAndLog('Create Route 53 record', route53.createRecord(dnsName, cloudfrontDns));
                    return [4 /*yield*/, Promise.all([createPipelinePromise, createDnsRecordPromise])];
                case 18:
                    _b.sent();
                    return [4 /*yield*/, callAndLog('Set DynamoDB item BUILDING_DAPP', dynamoDB.setItemBuilding(dappItem, cloudfrontDistroId, cloudfrontDns))];
                case 19:
                    _b.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function updateProcessorForTier(tier) {
    switch (tier) {
        case common_1.DappTiers.POC:
            return updateLegacyPoc;
        case common_1.DappTiers.STANDARD:
            return updateStandardDapp;
        case common_1.DappTiers.PROFESSIONAL:
            throw new errors_1.StateValidationError("PROFESSIONAL tier not yet implemented for 'update'");
        case common_1.DappTiers.ENTERPRISE:
            return updateEnterpriseDapp;
        default:
            throw new errors_1.StateValidationError("No 'update' processor exists for invalid tier '" + tier + "'");
    }
}
function processorUpdate(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, processOp, tier, tierProcessor;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    if (!dbItem.Item)
                        throw new errors_1.StateValidationError('Update error: Corresponding DynamoDB record could not be found.');
                    processOp = validate_1.default.stateUpdate(dbItem);
                    if (!processOp) {
                        console.log("Ignoring operation 'update'");
                        return [2 /*return*/, {}];
                    }
                    tier = dbItem.Item.Tier.S;
                    tierProcessor = updateProcessorForTier(tier);
                    return [2 /*return*/, tierProcessor(dappName, dbItem.Item)];
            }
        });
    });
}
function updateLegacyPoc(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var abi, addr, web3URL, guardianURL, cdnURL;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    abi = dappItem.Abi.S;
                    addr = dappItem.ContractAddr.S;
                    web3URL = dappItem.Web3URL.S;
                    guardianURL = dappItem.GuardianURL.S;
                    cdnURL = dappItem.CloudfrontDnsName.S;
                    return [4 /*yield*/, callAndLog('Update DappSeed', s3.putDappseed({ dappName: dappName, web3URL: web3URL, guardianURL: guardianURL, abi: abi, addr: addr, cdnURL: cdnURL }))];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Set DynamoDB item BUILDING_DAPP', dynamoDB.setItemBuilding(dappItem))];
                case 2:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function updateStandardDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Set DynamoDB item AVAILABLE', dynamoDB.setItemAvailable(dappItem))];
                case 1:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function updateEnterpriseDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var abi, addr, web3URL, guardianURL, cdnURL;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    abi = dappItem.Abi.S;
                    addr = dappItem.ContractAddr.S;
                    web3URL = dappItem.Web3URL.S;
                    guardianURL = dappItem.GuardianURL.S;
                    cdnURL = dappItem.CloudfrontDnsName.S;
                    return [4 /*yield*/, callAndLog('Update DappSeed', s3.putDappseed({ dappName: dappName, web3URL: web3URL, guardianURL: guardianURL, abi: abi, addr: addr, cdnURL: cdnURL }))];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Set DynamoDB item BUILDING_DAPP', dynamoDB.setItemBuilding(dappItem))];
                case 2:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function deleteProcessorForTier(tier) {
    switch (tier) {
        case common_1.DappTiers.POC:
            return deleteLegacyPoc;
        case common_1.DappTiers.STANDARD:
            return deleteStandardDapp;
        case common_1.DappTiers.PROFESSIONAL:
            throw new errors_1.StateValidationError("PROFESSIONAL tier not yet implemented for 'delete'");
        case common_1.DappTiers.ENTERPRISE:
            return deleteEnterpriseDapp;
        default:
            throw new errors_1.StateValidationError("No 'delete' processor exists for invalid tier '" + tier + "'");
    }
}
function processorDelete(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, processOp, tier, tierProcessor;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Get Dapp DynamoDb Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    if (!dbItem.Item)
                        throw new errors_1.StateValidationError('Delete error: Corresponding DynamoDB record could not be found.');
                    processOp = validate_1.default.stateDelete(dbItem);
                    if (!processOp) {
                        console.log("Ignoring operation 'delete'");
                        return [2 /*return*/, {}];
                    }
                    tier = dbItem.Item.Tier.S;
                    tierProcessor = deleteProcessorForTier(tier);
                    return [2 /*return*/, tierProcessor(dappName, dbItem.Item)];
            }
        });
    });
}
function deleteLegacyPoc(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var bucketName, cloudfrontDistroId, cloudfrontDns, pipelineName, dnsName, deleteDnsRecordPromise, deletePipelinePromise, err_6, err_7;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    bucketName = dappItem.S3BucketName.S;
                    cloudfrontDistroId = dappItem.CloudfrontDistributionId.S;
                    cloudfrontDns = dappItem.CloudfrontDnsName.S;
                    pipelineName = dappItem.PipelineName.S;
                    dnsName = dappItem.DnsName.S;
                    deleteDnsRecordPromise = callAndLog('Delete Route53 Record', route53.deleteRecord(dnsName, cloudfrontDns));
                    deletePipelinePromise = callAndLog('Delete CodePipeline', codepipeline.delete(pipelineName));
                    return [4 /*yield*/, Promise.all([deleteDnsRecordPromise, deletePipelinePromise])];
                case 1:
                    _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 5, , 6]);
                    return [4 /*yield*/, callAndLog('Disable Cloudfront distro', cloudfront.disableDistro(cloudfrontDistroId))];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Delete Cloudfront distro', Promise.resolve("TODO: Cloudfront's delete is turned off until we have a working strategy."))];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 6];
                case 5:
                    err_6 = _a.sent();
                    switch (err_6.code) {
                        case 'NoSuchDistribution':
                            logNonFatalErr('Disable Cloudfront distro', "Distribution already deleted.");
                            break;
                        default:
                            throw err_6;
                    }
                    return [3 /*break*/, 6];
                case 6:
                    _a.trys.push([6, 9, , 10]);
                    return [4 /*yield*/, callAndLog('Empty S3 Bucket', s3.emptyBucket(bucketName))];
                case 7:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Delete S3 Bucket', s3.deleteBucket(bucketName))];
                case 8:
                    _a.sent();
                    return [3 /*break*/, 10];
                case 9:
                    err_7 = _a.sent();
                    switch (err_7.code) {
                        case 'NoSuchBucket':
                            logNonFatalErr('Empty S3 Bucket', 'Bucket already deleted.');
                            break;
                        default:
                            throw err_7;
                    }
                    return [3 /*break*/, 10];
                case 10: return [4 /*yield*/, callAndLog('Delete DynamoDB item', dynamoDB.deleteItem(dappName))];
                case 11:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function deleteStandardDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('Delete DynamoDB item', dynamoDB.deleteItem(dappName))];
                case 1:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
function deleteEnterpriseDapp(dappName, dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var bucketName, cloudfrontDistroId, cloudfrontDns, pipelineName, dnsName, deleteDnsRecordPromise, deletePipelinePromise, err_8, err_9;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    bucketName = dappItem.S3BucketName.S;
                    cloudfrontDistroId = dappItem.CloudfrontDistributionId.S;
                    cloudfrontDns = dappItem.CloudfrontDnsName.S;
                    pipelineName = dappItem.PipelineName.S;
                    dnsName = dappItem.DnsName.S;
                    deleteDnsRecordPromise = callAndLog('Delete Route53 Record', route53.deleteRecord(dnsName, cloudfrontDns));
                    deletePipelinePromise = callAndLog('Delete CodePipeline', codepipeline.delete(pipelineName));
                    return [4 /*yield*/, Promise.all([deleteDnsRecordPromise, deletePipelinePromise])];
                case 1:
                    _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 5, , 6]);
                    return [4 /*yield*/, callAndLog('Disable Cloudfront distro', cloudfront.disableDistro(cloudfrontDistroId))];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Delete Cloudfront distro', Promise.resolve("TODO: Cloudfront's delete is turned off until we have a working strategy."))];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 6];
                case 5:
                    err_8 = _a.sent();
                    switch (err_8.code) {
                        case 'NoSuchDistribution':
                            logNonFatalErr('Disable Cloudfront distro', "Distribution already deleted.");
                            break;
                        default:
                            throw err_8;
                    }
                    return [3 /*break*/, 6];
                case 6:
                    _a.trys.push([6, 9, , 10]);
                    return [4 /*yield*/, callAndLog('Empty S3 Bucket', s3.emptyBucket(bucketName))];
                case 7:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Delete S3 Bucket', s3.deleteBucket(bucketName))];
                case 8:
                    _a.sent();
                    return [3 /*break*/, 10];
                case 9:
                    err_9 = _a.sent();
                    switch (err_9.code) {
                        case 'NoSuchBucket':
                            logNonFatalErr('Empty S3 Bucket', 'Bucket already deleted.');
                            break;
                        default:
                            throw err_9;
                    }
                    return [3 /*break*/, 10];
                case 10: return [4 /*yield*/, callAndLog('Delete DynamoDB item', dynamoDB.deleteItem(dappName))];
                case 11:
                    _a.sent();
                    return [2 /*return*/, {}];
            }
        });
    });
}
exports.default = {
    create: processorCreate,
    update: processorUpdate,
    delete: processorDelete
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvY2Vzc29yLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInByb2Nlc3Nvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0RBQWtDO0FBQ2xDLG1DQUF5RTtBQUN6RSxtQ0FBcUM7QUFDN0IsSUFBQSxzQ0FBUSxFQUFFLG9DQUFPLEVBQUUsMENBQVUsRUFBRSwwQkFBRSxFQUFFLDhDQUFZLENBQWM7QUFDckUsd0RBQWtDO0FBSWxDLElBQU0sTUFBTSxHQUFHLFVBQUMsS0FBWSxFQUFFLEdBQU8sSUFBTyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQVksS0FBSyxPQUFJLEVBQUUsR0FBRyxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUE7QUFDckYsSUFBTSxjQUFjLEdBQUcsVUFBQyxLQUFZLEVBQUUsTUFBYSxJQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQW1DLEtBQUssVUFBSyxNQUFRLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQTtBQUM5SCxJQUFNLFVBQVUsR0FBRyxVQUFDLEtBQVksRUFBRSxHQUFPLElBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBMEIsS0FBSyxlQUFZLEVBQUUsR0FBRyxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUE7QUFFL0csU0FBZSxVQUFVLENBQWEsS0FBWSxFQUFFLE9BQTJCOzs7Ozs7O29CQUU3RCxxQkFBTSxPQUFPLEVBQUE7O29CQUFuQixHQUFHLEdBQUcsU0FBYTtvQkFDdkIsVUFBVSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDdkIsc0JBQU8sR0FBRyxFQUFDOzs7b0JBRVgsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDbkIsTUFBTSxLQUFHLENBQUM7Ozs7O0NBRWpCO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxJQUFXO0lBQ3ZDLFFBQU8sSUFBSSxFQUFFO1FBQ1QsS0FBSyxrQkFBUyxDQUFDLEdBQUc7WUFDZCxPQUFPLGVBQWUsQ0FBQztRQUMzQixLQUFLLGtCQUFTLENBQUMsUUFBUTtZQUNuQixPQUFPLGtCQUFrQixDQUFDO1FBQzlCLEtBQUssa0JBQVMsQ0FBQyxZQUFZO1lBQ3ZCLE1BQU0sSUFBSSw2QkFBb0IsQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO1FBQ3pGLEtBQUssa0JBQVMsQ0FBQyxVQUFVO1lBQ3JCLE9BQU8sb0JBQW9CLENBQUM7UUFDaEM7WUFDSSxNQUFNLElBQUksNkJBQW9CLENBQUMsb0RBQWtELElBQUksTUFBRyxDQUFDLENBQUM7S0FDakc7QUFDTCxDQUFDO0FBRUQsU0FBZSxlQUFlLENBQUMsUUFBZTs7Ozs7d0JBQzNCLHFCQUFNLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUE7O29CQUExRSxNQUFNLEdBQUcsU0FBaUU7b0JBRWhGLHNGQUFzRjtvQkFDdEYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3dCQUFFLE1BQU0sSUFBSSw2QkFBb0IsQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO29CQUVoSCxTQUFTLEdBQUcsa0JBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzdDLElBQUksQ0FBQyxTQUFTLEVBQUU7d0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO3dCQUMzQyxzQkFBTyxFQUFFLEVBQUM7cUJBQ2I7b0JBRUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQVcsQ0FBQztvQkFDcEMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUVqRCxzQkFBTyxhQUFhLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQzs7OztDQUMvQztBQUVELFNBQWUsZUFBZSxDQUFDLFFBQWUsRUFBRSxRQUFxQjs7Ozs7O29CQUM3RCxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFXLENBQUM7b0JBQy9CLElBQUksR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQVcsQ0FBQztvQkFDekMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBVyxDQUFDO29CQUN2QyxXQUFXLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFXLENBQUM7b0JBQy9DLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQVcsQ0FBQztvQkFDL0MsS0FBSyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBVyxDQUFDO29CQUN4QyxZQUFZLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFXLENBQUM7b0JBQ2pELE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQVcsQ0FBQztvQkFDdkMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBRTFDLHFCQUFNLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsb0JBQW9CLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFBOztvQkFBMUYsU0FBMEYsQ0FBQztvQkFFM0YscUJBQU0sVUFBVSxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBQTs7b0JBQXZFLFNBQXVFLENBQUM7b0JBQ3hFLHFCQUFNLFVBQVUsQ0FBQywwQkFBMEIsRUFBRSxFQUFFLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBQTs7b0JBQW5GLFNBQW1GLENBQUM7b0JBQ2hGLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7b0JBQy9GLHFCQUFxQixHQUFHLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBRTFGLHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLEVBQUE7O29CQUE3RCxTQUE2RCxDQUFDOzs7O29CQU1wQyxxQkFBTSxVQUFVLENBQUMsMEJBQTBCLEVBQUUsVUFBVSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFBOztvQkFBeEgsZUFBZSxHQUFHLFNBQXNHO29CQUN4SCxTQUFTLEdBQUcsZUFBZSxDQUFDLFlBQTRCLENBQUM7b0JBQzdELGtCQUFrQixHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUM7b0JBQ2xDLGFBQWEsR0FBRyxTQUFTLENBQUMsVUFBVSxDQUFDOzs7O29CQUU5QixLQUFBLEtBQUcsQ0FBQyxJQUFJLENBQUE7OzZCQUNOLG9CQUFvQixDQUFDLENBQXJCLHdCQUFvQjs7Ozs7b0JBRU8scUJBQU0sVUFBVSxDQUFDLG1DQUFtQyxFQUFFLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFBOztvQkFBbkgsaUJBQWlCLEdBQUcsU0FBK0Y7b0JBQ3ZILHFCQUFNLGtCQUFRLENBQUMsNkJBQTZCLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLEVBQUE7O29CQUF0RSxTQUFzRSxDQUFDO29CQUV2RSxzRkFBc0Y7b0JBQ3RGLElBQUksQ0FBQyxpQkFBaUI7d0JBQUUsTUFBTSxJQUFJLGdDQUF1QixDQUFDLDRFQUE0RSxDQUFDLENBQUM7b0JBRXhJLGlEQUFpRDtvQkFDakQsa0JBQWtCLEdBQUcsaUJBQWlCLENBQUMsRUFBRSxDQUFDO29CQUMxQyxhQUFhLEdBQUcsaUJBQWlCLENBQUMsVUFBVSxDQUFDO29CQUU3QyxxQkFBTSxVQUFVLENBQUMsMEJBQTBCLEVBQUUsVUFBVSxDQUFDLHFCQUFxQixDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUE7O29CQUF6RyxTQUF5RyxDQUFDOzs7O29CQUUxRyxNQUFNLENBQUMsNENBQTRDLEVBQUUsS0FBRyxDQUFDLENBQUM7b0JBQzFELE1BQU0sS0FBRyxDQUFDO3lCQUVkLHlCQUFNOztvQkFFTixNQUFNLENBQUMsZ0NBQWdDLEVBQUUsS0FBRyxDQUFDLENBQUM7b0JBQzlDLE1BQU0sS0FBRyxDQUFDOzt5QkFJdEIscUJBQU0sVUFBVSxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUUsUUFBUSxVQUFBLEVBQUUsT0FBTyxTQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUUsSUFBSSxNQUFBLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFBQTs7b0JBQXRILFNBQXNILENBQUM7b0JBRW5ILHFCQUFxQixHQUFHLFVBQVUsQ0FBQyx5QkFBeUIsRUFBRSxZQUFZLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDekksc0JBQXNCLEdBQUcsVUFBVSxDQUFDLHdCQUF3QixFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7b0JBQ2hILHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLEVBQUE7O29CQUFsRSxTQUFrRSxDQUFDO29CQUVuRSxxQkFBTSxVQUFVLENBQUMsaUNBQWlDLEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBQTs7b0JBQTFILFNBQTBILENBQUM7b0JBRTNILHNCQUFPLEVBQUUsRUFBQzs7OztDQUNiO0FBRUQsU0FBZSxrQkFBa0IsQ0FBQyxRQUFlLEVBQUUsUUFBcUI7Ozs7d0JBQ3BFLHFCQUFNLFVBQVUsQ0FBQyw2QkFBNkIsRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQTs7b0JBQXBGLFNBQW9GLENBQUM7b0JBRXJGLHNCQUFPLEVBQUUsRUFBQzs7OztDQUNiO0FBRUQsU0FBZSxvQkFBb0IsQ0FBQyxRQUFlLEVBQUUsUUFBcUI7Ozs7OztvQkFDbEUsR0FBRyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBVyxDQUFDO29CQUMvQixJQUFJLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFXLENBQUM7b0JBQ3pDLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQVcsQ0FBQztvQkFDdkMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBVyxDQUFDO29CQUMvQyxVQUFVLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFXLENBQUM7b0JBQy9DLEtBQUssR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQVcsQ0FBQztvQkFDeEMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBVyxDQUFDO29CQUNqRCxPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFXLENBQUM7b0JBQ3ZDLGNBQWMsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQVcsQ0FBQztvQkFDckQsZUFBZSxHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBVyxDQUFDO29CQUN2RCxLQUFLLEdBQUcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFFMUMscUJBQU0sVUFBVSxDQUFDLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUE7O29CQUExRixTQUEwRixDQUFDO29CQUUzRixxQkFBTSxVQUFVLENBQUMscUJBQXFCLEVBQUUsRUFBRSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFBOztvQkFBdkUsU0FBdUUsQ0FBQztvQkFDeEUscUJBQU0sVUFBVSxDQUFDLDBCQUEwQixFQUFFLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFBOztvQkFBbkYsU0FBbUYsQ0FBQztvQkFDaEYsaUJBQWlCLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixFQUFFLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztvQkFDL0YscUJBQXFCLEdBQUcsVUFBVSxDQUFDLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztvQkFFMUYscUJBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixFQUFFLHFCQUFxQixDQUFDLENBQUMsRUFBQTs7b0JBQTdELFNBQTZELENBQUM7Ozs7b0JBTXBDLHFCQUFNLFVBQVUsQ0FBQywwQkFBMEIsRUFBRSxVQUFVLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUE7O29CQUF4SCxlQUFlLEdBQUcsU0FBc0c7b0JBQ3hILFNBQVMsR0FBRyxlQUFlLENBQUMsWUFBNEIsQ0FBQztvQkFDN0Qsa0JBQWtCLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQztvQkFDbEMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxVQUFVLENBQUM7Ozs7b0JBRTlCLEtBQUEsS0FBRyxDQUFDLElBQUksQ0FBQTs7NkJBQ04sb0JBQW9CLENBQUMsQ0FBckIsd0JBQW9COzs7OztvQkFFTyxxQkFBTSxVQUFVLENBQUMsbUNBQW1DLEVBQUUsVUFBVSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUE7O29CQUFuSCxpQkFBaUIsR0FBRyxTQUErRjtvQkFDdkgscUJBQU0sa0JBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsRUFBQTs7b0JBQXRFLFNBQXNFLENBQUM7b0JBRXZFLHNGQUFzRjtvQkFDdEYsSUFBSSxDQUFDLGlCQUFpQjt3QkFBRSxNQUFNLElBQUksZ0NBQXVCLENBQUMsNEVBQTRFLENBQUMsQ0FBQztvQkFFeEksaURBQWlEO29CQUNqRCxrQkFBa0IsR0FBRyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7b0JBQzFDLGFBQWEsR0FBRyxpQkFBaUIsQ0FBQyxVQUFVLENBQUM7b0JBRTdDLHFCQUFNLFVBQVUsQ0FBQywwQkFBMEIsRUFBRSxVQUFVLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBQTs7b0JBQXpHLFNBQXlHLENBQUM7Ozs7b0JBRTFHLE1BQU0sQ0FBQyw0Q0FBNEMsRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDMUQsTUFBTSxLQUFHLENBQUM7eUJBRWQseUJBQU07O29CQUVOLE1BQU0sQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDOUMsTUFBTSxLQUFHLENBQUM7O3lCQUl0QixxQkFBTSxVQUFVLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxRQUFRLFVBQUEsRUFBRSxPQUFPLFNBQUEsRUFBRSxXQUFXLGFBQUEsRUFBRSxHQUFHLEtBQUEsRUFBRSxJQUFJLE1BQUEsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQyxFQUFBOztvQkFBdEgsU0FBc0gsQ0FBQztvQkFFbkgscUJBQXFCLEdBQUcsVUFBVSxDQUFDLGdDQUFnQyxFQUFFLFlBQVksQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQztvQkFDNUssc0JBQXNCLEdBQUcsVUFBVSxDQUFDLHdCQUF3QixFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7b0JBQ2hILHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLEVBQUE7O29CQUFsRSxTQUFrRSxDQUFDO29CQUVuRSxxQkFBTSxVQUFVLENBQUMsaUNBQWlDLEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBQTs7b0JBQTFILFNBQTBILENBQUM7b0JBRTNILHNCQUFPLEVBQUUsRUFBQzs7OztDQUNiO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxJQUF1QjtJQUNuRCxRQUFPLElBQUksRUFBRTtRQUNULEtBQUssa0JBQVMsQ0FBQyxHQUFHO1lBQ2QsT0FBTyxlQUFlLENBQUM7UUFDM0IsS0FBSyxrQkFBUyxDQUFDLFFBQVE7WUFDbkIsT0FBTyxrQkFBa0IsQ0FBQztRQUM5QixLQUFLLGtCQUFTLENBQUMsWUFBWTtZQUN2QixNQUFNLElBQUksNkJBQW9CLENBQUMsb0RBQW9ELENBQUMsQ0FBQztRQUN6RixLQUFLLGtCQUFTLENBQUMsVUFBVTtZQUNyQixPQUFPLG9CQUFvQixDQUFDO1FBQ2hDO1lBQ0ksTUFBTSxJQUFJLDZCQUFvQixDQUFDLG9EQUFrRCxJQUFJLE1BQUcsQ0FBQyxDQUFDO0tBQ2pHO0FBQ0wsQ0FBQztBQUVELFNBQWUsZUFBZSxDQUFDLFFBQWU7Ozs7O3dCQUMzQixxQkFBTSxVQUFVLENBQUMsbUJBQW1CLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBMUUsTUFBTSxHQUFHLFNBQWlFO29CQUVoRixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7d0JBQUUsTUFBTSxJQUFJLDZCQUFvQixDQUFDLGlFQUFpRSxDQUFDLENBQUM7b0JBRWhILFNBQVMsR0FBRyxrQkFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDN0MsSUFBSSxDQUFDLFNBQVMsRUFBRTt3QkFDWixPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7d0JBQzNDLHNCQUFPLEVBQUUsRUFBQztxQkFDYjtvQkFFRyxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBVyxDQUFDO29CQUNwQyxhQUFhLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRWpELHNCQUFPLGFBQWEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDOzs7O0NBQy9DO0FBRUQsU0FBZSxlQUFlLENBQUMsUUFBZSxFQUFFLFFBQXFCOzs7Ozs7b0JBQzdELEdBQUcsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQVcsQ0FBQztvQkFDL0IsSUFBSSxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBVyxDQUFDO29CQUN6QyxPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFXLENBQUM7b0JBQ3ZDLFdBQVcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQVcsQ0FBQztvQkFDL0MsTUFBTSxHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFXLENBQUM7b0JBRXBELHFCQUFNLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUUsUUFBUSxVQUFBLEVBQUUsT0FBTyxTQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUUsSUFBSSxNQUFBLEVBQUUsTUFBTSxRQUFBLEVBQUUsQ0FBQyxDQUFDLEVBQUE7O29CQUExRyxTQUEwRyxDQUFDO29CQUMzRyxxQkFBTSxVQUFVLENBQUMsaUNBQWlDLEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBdkYsU0FBdUYsQ0FBQztvQkFFeEYsc0JBQU8sRUFBRSxFQUFDOzs7O0NBQ2I7QUFFRCxTQUFlLGtCQUFrQixDQUFDLFFBQWUsRUFBRSxRQUFxQjs7Ozt3QkFDcEUscUJBQU0sVUFBVSxDQUFDLDZCQUE2QixFQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBcEYsU0FBb0YsQ0FBQztvQkFFckYsc0JBQU8sRUFBRSxFQUFDOzs7O0NBQ2I7QUFFRCxTQUFlLG9CQUFvQixDQUFDLFFBQWUsRUFBRSxRQUFxQjs7Ozs7O29CQUNsRSxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFXLENBQUM7b0JBQy9CLElBQUksR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQVcsQ0FBQztvQkFDekMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBVyxDQUFDO29CQUN2QyxXQUFXLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFXLENBQUM7b0JBQy9DLE1BQU0sR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBVyxDQUFDO29CQUVwRCxxQkFBTSxVQUFVLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLFFBQVEsVUFBQSxFQUFFLE9BQU8sU0FBQSxFQUFFLFdBQVcsYUFBQSxFQUFFLEdBQUcsS0FBQSxFQUFFLElBQUksTUFBQSxFQUFFLE1BQU0sUUFBQSxFQUFFLENBQUMsQ0FBQyxFQUFBOztvQkFBMUcsU0FBMEcsQ0FBQztvQkFDM0cscUJBQU0sVUFBVSxDQUFDLGlDQUFpQyxFQUFFLFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQTs7b0JBQXZGLFNBQXVGLENBQUM7b0JBRXhGLHNCQUFPLEVBQUUsRUFBQzs7OztDQUNiO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxJQUF1QjtJQUNuRCxRQUFPLElBQUksRUFBRTtRQUNULEtBQUssa0JBQVMsQ0FBQyxHQUFHO1lBQ2QsT0FBTyxlQUFlLENBQUM7UUFDM0IsS0FBSyxrQkFBUyxDQUFDLFFBQVE7WUFDbkIsT0FBTyxrQkFBa0IsQ0FBQztRQUM5QixLQUFLLGtCQUFTLENBQUMsWUFBWTtZQUN2QixNQUFNLElBQUksNkJBQW9CLENBQUMsb0RBQW9ELENBQUMsQ0FBQztRQUN6RixLQUFLLGtCQUFTLENBQUMsVUFBVTtZQUNyQixPQUFPLG9CQUFvQixDQUFDO1FBQ2hDO1lBQ0ksTUFBTSxJQUFJLDZCQUFvQixDQUFDLG9EQUFrRCxJQUFJLE1BQUcsQ0FBQyxDQUFDO0tBQ2pHO0FBQ0wsQ0FBQztBQUVELFNBQWUsZUFBZSxDQUFDLFFBQWU7Ozs7O3dCQUMzQixxQkFBTSxVQUFVLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBL0UsTUFBTSxHQUFHLFNBQXNFO29CQUVyRixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7d0JBQUUsTUFBTSxJQUFJLDZCQUFvQixDQUFDLGlFQUFpRSxDQUFDLENBQUM7b0JBRWhILFNBQVMsR0FBRyxrQkFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDN0MsSUFBSSxDQUFDLFNBQVMsRUFBRTt3QkFDWixPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7d0JBQzNDLHNCQUFPLEVBQUUsRUFBQztxQkFDYjtvQkFFRyxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBVyxDQUFDO29CQUNwQyxhQUFhLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRWpELHNCQUFPLGFBQWEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDOzs7O0NBQy9DO0FBRUQsU0FBZSxlQUFlLENBQUMsUUFBZSxFQUFFLFFBQXFCOzs7Ozs7b0JBQzdELFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQVcsQ0FBQztvQkFDL0Msa0JBQWtCLEdBQUcsUUFBUSxDQUFDLHdCQUF3QixDQUFDLENBQVcsQ0FBQztvQkFDbkUsYUFBYSxHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFXLENBQUM7b0JBQ3ZELFlBQVksR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQVcsQ0FBQztvQkFDakQsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBVyxDQUFDO29CQUV2QyxzQkFBc0IsR0FBRyxVQUFVLENBQUMsdUJBQXVCLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztvQkFDM0cscUJBQXFCLEdBQUcsVUFBVSxDQUFDLHFCQUFxQixFQUFFLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFDakcscUJBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLHFCQUFxQixDQUFDLENBQUMsRUFBQTs7b0JBQWxFLFNBQWtFLENBQUM7Ozs7b0JBRy9ELHFCQUFNLFVBQVUsQ0FBQywyQkFBMkIsRUFBRSxVQUFVLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFBQTs7b0JBQTNGLFNBQTJGLENBQUM7b0JBQzVGLHFCQUFNLFVBQVUsQ0FBQywwQkFBMEIsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLDJFQUEyRSxDQUFDLENBQUMsRUFBQTs7b0JBQTFJLFNBQTBJLENBQUM7Ozs7b0JBRTNJLFFBQU8sS0FBRyxDQUFDLElBQUksRUFBRTt3QkFDYixLQUFLLG9CQUFvQjs0QkFDckIsY0FBYyxDQUFDLDJCQUEyQixFQUFFLCtCQUErQixDQUFDLENBQUE7NEJBQzVFLE1BQU07d0JBQ1Y7NEJBQ0ksTUFBTSxLQUFHLENBQUM7cUJBQ2pCOzs7O29CQUlELHFCQUFNLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUE7O29CQUEvRCxTQUErRCxDQUFDO29CQUNoRSxxQkFBTSxVQUFVLENBQUMsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFBOztvQkFBakUsU0FBaUUsQ0FBQzs7OztvQkFFbEUsUUFBTyxLQUFHLENBQUMsSUFBSSxFQUFFO3dCQUNiLEtBQUssY0FBYzs0QkFDZixjQUFjLENBQUMsaUJBQWlCLEVBQUUseUJBQXlCLENBQUMsQ0FBQzs0QkFDN0QsTUFBTTt3QkFDVjs0QkFDSSxNQUFNLEtBQUcsQ0FBQztxQkFDakI7O3lCQUdMLHFCQUFNLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RSxTQUF1RSxDQUFDO29CQUV4RSxzQkFBTyxFQUFFLEVBQUM7Ozs7Q0FDYjtBQUVELFNBQWUsa0JBQWtCLENBQUMsUUFBZSxFQUFFLFFBQXFCOzs7O3dCQUNwRSxxQkFBTSxVQUFVLENBQUMsc0JBQXNCLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBdkUsU0FBdUUsQ0FBQztvQkFFeEUsc0JBQU8sRUFBRSxFQUFDOzs7O0NBQ2I7QUFFRCxTQUFlLG9CQUFvQixDQUFDLFFBQWUsRUFBRSxRQUFxQjs7Ozs7O29CQUNsRSxVQUFVLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFXLENBQUM7b0JBQy9DLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFXLENBQUM7b0JBQ25FLGFBQWEsR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBVyxDQUFDO29CQUN2RCxZQUFZLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFXLENBQUM7b0JBQ2pELE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQVcsQ0FBQztvQkFFdkMsc0JBQXNCLEdBQUcsVUFBVSxDQUFDLHVCQUF1QixFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7b0JBQzNHLHFCQUFxQixHQUFHLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7b0JBQ2pHLHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLEVBQUE7O29CQUFsRSxTQUFrRSxDQUFDOzs7O29CQUcvRCxxQkFBTSxVQUFVLENBQUMsMkJBQTJCLEVBQUUsVUFBVSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUE7O29CQUEzRixTQUEyRixDQUFDO29CQUM1RixxQkFBTSxVQUFVLENBQUMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQywyRUFBMkUsQ0FBQyxDQUFDLEVBQUE7O29CQUExSSxTQUEwSSxDQUFDOzs7O29CQUUzSSxRQUFPLEtBQUcsQ0FBQyxJQUFJLEVBQUU7d0JBQ2IsS0FBSyxvQkFBb0I7NEJBQ3JCLGNBQWMsQ0FBQywyQkFBMkIsRUFBRSwrQkFBK0IsQ0FBQyxDQUFBOzRCQUM1RSxNQUFNO3dCQUNWOzRCQUNJLE1BQU0sS0FBRyxDQUFDO3FCQUNqQjs7OztvQkFJRCxxQkFBTSxVQUFVLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFBOztvQkFBL0QsU0FBK0QsQ0FBQztvQkFDaEUscUJBQU0sVUFBVSxDQUFDLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBQTs7b0JBQWpFLFNBQWlFLENBQUM7Ozs7b0JBRWxFLFFBQU8sS0FBRyxDQUFDLElBQUksRUFBRTt3QkFDYixLQUFLLGNBQWM7NEJBQ2YsY0FBYyxDQUFDLGlCQUFpQixFQUFFLHlCQUF5QixDQUFDLENBQUM7NEJBQzdELE1BQU07d0JBQ1Y7NEJBQ0ksTUFBTSxLQUFHLENBQUM7cUJBQ2pCOzt5QkFHTCxxQkFBTSxVQUFVLENBQUMsc0JBQXNCLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBdkUsU0FBdUUsQ0FBQztvQkFFeEUsc0JBQU8sRUFBRSxFQUFDOzs7O0NBQ2I7QUFFRCxrQkFBZTtJQUNYLE1BQU0sRUFBRyxlQUFlO0lBQ3hCLE1BQU0sRUFBRyxlQUFlO0lBQ3hCLE1BQU0sRUFBRyxlQUFlO0NBQzNCLENBQUEifQ==