"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultTags = [
    {
        Key: "Application",
        Value: "AbiClerk"
    },
    {
        Key: "ManagedBy",
        Value: "AbiClerk"
    }
];
function dappNameTag(dappName) {
    return {
        Key: "DappName",
        Value: dappName
    };
}
exports.dappNameTag = dappNameTag;
function dappOwnerTag(dappOwner) {
    return {
        Key: "DappOwner",
        Value: dappOwner
    };
}
exports.dappOwnerTag = dappOwnerTag;
/*
Returns a Promise that rejects with reason after msDelay milliseconds
*/
function rejectDelay(reason) {
    var msDelay = 700;
    return new Promise(function (resolve, reject) {
        setTimeout(reject.bind(null, reason), msDelay);
    });
}
exports.rejectDelay = rejectDelay;
/*
Retries a promise returned by promiseGenerator up to maxRetries times as long as the error is retryable
Based on https://stackoverflow.com/questions/38213668/promise-retry-design-patterns
*/
function addAwsPromiseRetries(promiseGenerator, maxRetries) {
    // Ensure we call promiseGenerator on the first iteration
    var p = Promise.reject({ retryable: true });
    /*
    Appends maxRetries number of retry and delay promises to an AWS promise, returning once a retry promise resolves.

    1. As long as promiseGenerator() rejects with a retryable error, we retry and then delay before the next loop iteration
    2. If promiseGenerator() resolves, the rest of the loop will finish without triggering any further catch functions
    3. If promiseGenerator() rejects with a non-retryable error, the rest of the loop will finish without any further
       retries or delays since all catch blocks will simply return Promise.reject(err)
    */
    for (var i = 0; i < maxRetries; i++) {
        // @ts-ignore TS doesn't like that these could technically reject with
        // an error.  Rather than force (* as ReturnType) every place we await
        // this, just have the compiler assume this function succeeds.
        p = p.catch(function (err) { return err.retryable ? promiseGenerator() : Promise.reject(err); })
            .catch(function (err) { return err.retryable ? rejectDelay(err) : Promise.reject(err); });
    }
    return p;
}
exports.addAwsPromiseRetries = addAwsPromiseRetries;
var DappOperations;
(function (DappOperations) {
    DappOperations["create"] = "create";
    DappOperations["update"] = "update";
    DappOperations["delete"] = "delete";
})(DappOperations = exports.DappOperations || (exports.DappOperations = {}));
var DappStates;
(function (DappStates) {
    DappStates["CREATING"] = "CREATING";
    DappStates["BUILDING_DAPP"] = "BUILDING_DAPP";
    DappStates["AVAILABLE"] = "AVAILABLE";
    DappStates["DELETING"] = "DELETING";
    DappStates["FAILED"] = "FAILED";
    DappStates["DEPOSED"] = "DEPOSED";
})(DappStates = exports.DappStates || (exports.DappStates = {}));
var DappTiers;
(function (DappTiers) {
    DappTiers["POC"] = "POC";
    DappTiers["STANDARD"] = "STANDARD";
    DappTiers["PROFESSIONAL"] = "PROFESSIONAL";
    DappTiers["ENTERPRISE"] = "ENTERPRISE";
})(DappTiers = exports.DappTiers || (exports.DappTiers = {}));
exports.default = {
    defaultTags: exports.defaultTags, dappNameTag: dappNameTag, dappOwnerTag: dappOwnerTag, addAwsPromiseRetries: addAwsPromiseRetries
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImNvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUthLFFBQUEsV0FBVyxHQUFpQjtJQUNyQztRQUNJLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLEtBQUssRUFBRSxVQUFVO0tBQ3BCO0lBQ0Q7UUFDSSxHQUFHLEVBQUUsV0FBVztRQUNoQixLQUFLLEVBQUUsVUFBVTtLQUNwQjtDQUNKLENBQUM7QUFFRixTQUFnQixXQUFXLENBQUMsUUFBZTtJQUN2QyxPQUFPO1FBQ0gsR0FBRyxFQUFFLFVBQVU7UUFDZixLQUFLLEVBQUUsUUFBUTtLQUNsQixDQUFBO0FBQ0wsQ0FBQztBQUxELGtDQUtDO0FBRUQsU0FBZ0IsWUFBWSxDQUFDLFNBQWdCO0lBQ3pDLE9BQU87UUFDSCxHQUFHLEVBQUUsV0FBVztRQUNoQixLQUFLLEVBQUUsU0FBUztLQUNuQixDQUFBO0FBQ0wsQ0FBQztBQUxELG9DQUtDO0FBRUQ7O0VBRUU7QUFDRixTQUFnQixXQUFXLENBQUMsTUFBYTtJQUNyQyxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUM7SUFDbEIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFTLE9BQU8sRUFBRSxNQUFNO1FBQ3ZDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNuRCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFMRCxrQ0FLQztBQUVEOzs7RUFHRTtBQUNGLFNBQWdCLG9CQUFvQixDQUFhLGdCQUF3QyxFQUFFLFVBQWlCO0lBQ3hHLHlEQUF5RDtJQUN6RCxJQUFJLENBQUMsR0FBdUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO0lBRTlEOzs7Ozs7O01BT0U7SUFDRixLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsVUFBVSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQzVCLHNFQUFzRTtRQUN0RSxzRUFBc0U7UUFDdEUsOERBQThEO1FBQzlELENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBeEQsQ0FBd0QsQ0FBQzthQUN0RSxLQUFLLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQXRELENBQXNELENBQUMsQ0FBQztLQUM5RTtJQUNELE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQXBCRCxvREFvQkM7QUFPRCxJQUFZLGNBSVg7QUFKRCxXQUFZLGNBQWM7SUFDdEIsbUNBQWlCLENBQUE7SUFDakIsbUNBQWlCLENBQUE7SUFDakIsbUNBQWlCLENBQUE7QUFDckIsQ0FBQyxFQUpXLGNBQWMsR0FBZCxzQkFBYyxLQUFkLHNCQUFjLFFBSXpCO0FBRUQsSUFBWSxVQU9YO0FBUEQsV0FBWSxVQUFVO0lBQ2xCLG1DQUFxQixDQUFBO0lBQ3JCLDZDQUErQixDQUFBO0lBQy9CLHFDQUF1QixDQUFBO0lBQ3ZCLG1DQUFxQixDQUFBO0lBQ3JCLCtCQUFpQixDQUFBO0lBQ2pCLGlDQUFtQixDQUFBO0FBQ3ZCLENBQUMsRUFQVyxVQUFVLEdBQVYsa0JBQVUsS0FBVixrQkFBVSxRQU9yQjtBQUVELElBQVksU0FLWDtBQUxELFdBQVksU0FBUztJQUNqQix3QkFBVyxDQUFBO0lBQ1gsa0NBQXFCLENBQUE7SUFDckIsMENBQTZCLENBQUE7SUFDN0Isc0NBQXlCLENBQUE7QUFDN0IsQ0FBQyxFQUxXLFNBQVMsR0FBVCxpQkFBUyxLQUFULGlCQUFTLFFBS3BCO0FBYUQsa0JBQWU7SUFDWCxXQUFXLHFCQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUUsWUFBWSxjQUFBLEVBQUUsb0JBQW9CLHNCQUFBO0NBQy9ELENBQUMifQ==