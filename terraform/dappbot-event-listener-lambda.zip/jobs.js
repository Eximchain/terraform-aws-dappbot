"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("./common");
var env_1 = require("./env");
var services_1 = __importDefault(require("./services"));
var cognito_1 = __importDefault(require("./services/cognito"));
var cloudfront = services_1.default.cloudfront, dynamoDB = services_1.default.dynamoDB, s3 = services_1.default.s3, sqs = services_1.default.sqs, codepipeline = services_1.default.codepipeline, sendgrid = services_1.default.sendgrid, github = services_1.default.github;
var deleteMethodName = 'delete';
// View a sample JSON event from a CodePipeline here:
//
// https://docs.aws.amazon.com/codepipeline/latest/userguide/actions-invoke-lambda-function.html#actions-invoke-lambda-function-json-event-example
//
// Below function is called by index, it receives the event["CodePipeline.job"] field.
function postPipelineBuildJob(_a) {
    var data = _a.data, id = _a.id;
    return __awaiter(this, void 0, void 0, function () {
        var actionConfiguration, _b, OwnerEmail, DestinationBucket, DappName, err_1;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    actionConfiguration = data.actionConfiguration;
                    _b = JSON.parse(actionConfiguration.configuration.UserParameters), OwnerEmail = _b.OwnerEmail, DestinationBucket = _b.DestinationBucket, DappName = _b.DappName;
                    console.log("Successfully loaded all info to the clean function:");
                    console.log("OwnerEmail: " + OwnerEmail + "; DappName: " + DappName + "; DestinationBucket: " + DestinationBucket);
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 6, , 9]);
                    return [4 /*yield*/, s3.makeObjectNoCache(DestinationBucket, 'index.html')];
                case 2:
                    _c.sent();
                    return [4 /*yield*/, dynamoDB.setDappAvailable(DappName)];
                case 3:
                    _c.sent();
                    return [4 /*yield*/, sendgrid.sendConfirmation(OwnerEmail, DappName, dnsNameFromDappName(DappName))];
                case 4:
                    _c.sent();
                    console.log("Successfully completed all CodePipeline cleanup steps!");
                    return [4 /*yield*/, codepipeline.completeJob(id)];
                case 5: return [2 /*return*/, _c.sent()];
                case 6:
                    err_1 = _c.sent();
                    console.log("Error cleaning up the CodePipeline execution: ", err_1);
                    return [4 /*yield*/, codepipeline.failJob(id, err_1)];
                case 7:
                    _c.sent();
                    return [4 /*yield*/, dynamoDB.setDappFailed(DappName)];
                case 8: return [2 /*return*/, _c.sent()];
                case 9: return [2 /*return*/];
            }
        });
    });
}
function periodicCleanup() {
    return __awaiter(this, void 0, void 0, function () {
        var potentialFailedUsers, splitUsers, failedUsers, activeUsers, _a, _b, _i, i, activeUser, _c, _d, _e, i, failedUser;
        return __generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    console.log('Performing Periodic Cleanup');
                    console.log('Cleaning up CloudFront Distributions');
                    return [4 /*yield*/, cloudfront.cleanupDisabledDistros()];
                case 1:
                    _f.sent();
                    console.log('Cloudfront Distribution Cleanup successful');
                    console.log('Cleaning Up Lapsed Users');
                    return [4 /*yield*/, dynamoDB.getPotentialFailedUsers()];
                case 2:
                    potentialFailedUsers = _f.sent();
                    console.log("Checking Potential Failed Users: ", potentialFailedUsers);
                    return [4 /*yield*/, cognito_1.default.confirmFailedUsers(potentialFailedUsers)];
                case 3:
                    splitUsers = _f.sent();
                    console.log("Users Split by Cognito Status: ", splitUsers);
                    failedUsers = splitUsers.Failed;
                    activeUsers = splitUsers.Active;
                    _a = [];
                    for (_b in activeUsers)
                        _a.push(_b);
                    _i = 0;
                    _f.label = 4;
                case 4:
                    if (!(_i < _a.length)) return [3 /*break*/, 7];
                    i = _a[_i];
                    activeUser = activeUsers[i];
                    console.log('Removing non-failed user from LAPSED list: ', activeUser);
                    return [4 /*yield*/, dynamoDB.deleteLapsedUser(activeUser)];
                case 5:
                    _f.sent();
                    _f.label = 6;
                case 6:
                    _i++;
                    return [3 /*break*/, 4];
                case 7:
                    _c = [];
                    for (_d in failedUsers)
                        _c.push(_d);
                    _e = 0;
                    _f.label = 8;
                case 8:
                    if (!(_e < _c.length)) return [3 /*break*/, 12];
                    i = _c[_e];
                    failedUser = failedUsers[i];
                    return [4 /*yield*/, cleanDappsForUser(failedUser)];
                case 9:
                    _f.sent();
                    return [4 /*yield*/, dynamoDB.deleteLapsedUser(failedUser)];
                case 10:
                    _f.sent();
                    console.log('Successfully Cleaned Dapps for failed user: ', failedUser);
                    _f.label = 11;
                case 11:
                    _e++;
                    return [3 /*break*/, 8];
                case 12:
                    console.log('Periodic Cleanup Successful');
                    return [2 /*return*/, {}];
            }
        });
    });
}
function enterpriseGithubCommitJob(_a) {
    var data = _a.data, id = _a.id;
    return __awaiter(this, void 0, void 0, function () {
        var inputArtifact, artifactLocation, artifactCredentials, actionConfiguration, _b, OwnerEmail, DappName, TargetRepoName, TargetRepoOwner, artifact, err_2;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    console.log("Enterprise Commit Job: ", data);
                    inputArtifact = data.inputArtifacts[0];
                    artifactLocation = inputArtifact.location.s3Location;
                    artifactCredentials = data.artifactCredentials;
                    actionConfiguration = data.actionConfiguration;
                    _b = JSON.parse(actionConfiguration.configuration.UserParameters), OwnerEmail = _b.OwnerEmail, DappName = _b.DappName, TargetRepoName = _b.TargetRepoName, TargetRepoOwner = _b.TargetRepoOwner;
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 5, , 8]);
                    return [4 /*yield*/, s3.downloadArtifact(artifactLocation, artifactCredentials)];
                case 2:
                    artifact = _c.sent();
                    return [4 /*yield*/, github.commitArtifact(artifact, TargetRepoName, TargetRepoOwner)];
                case 3:
                    _c.sent();
                    return [4 /*yield*/, codepipeline.completeJob(id)];
                case 4: return [2 /*return*/, _c.sent()];
                case 5:
                    err_2 = _c.sent();
                    console.log("Error committing to GitHub: ", err_2);
                    return [4 /*yield*/, codepipeline.failJob(id, err_2)];
                case 6:
                    _c.sent();
                    return [4 /*yield*/, dynamoDB.setDappFailed(DappName)];
                case 7: return [2 /*return*/, _c.sent()];
                case 8: return [2 /*return*/];
            }
        });
    });
}
function handlePaymentStatus(userEmail, status) {
    return __awaiter(this, void 0, void 0, function () {
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _a = status;
                    switch (_a) {
                        case common_1.PaymentStatus.LAPSED: return [3 /*break*/, 1];
                        case common_1.PaymentStatus.ACTIVE: return [3 /*break*/, 3];
                        case common_1.PaymentStatus.CANCELLED: return [3 /*break*/, 5];
                    }
                    return [3 /*break*/, 7];
                case 1:
                    console.log("Handling " + status + " payment status for user " + userEmail);
                    return [4 /*yield*/, dynamoDB.putLapsedUser(userEmail)];
                case 2: return [2 /*return*/, _b.sent()];
                case 3:
                    console.log("Handling " + status + " payment status for user " + userEmail);
                    return [4 /*yield*/, dynamoDB.deleteLapsedUser(userEmail)];
                case 4: return [2 /*return*/, _b.sent()];
                case 5:
                    console.log("Handling " + status + " payment status for user " + userEmail);
                    return [4 /*yield*/, handleCancelledUser(userEmail)];
                case 6: return [2 /*return*/, _b.sent()];
                case 7:
                    console.log("No Handler for payment status " + status);
                    _b.label = 8;
                case 8: return [2 /*return*/];
            }
        });
    });
}
function handleCancelledUser(userEmail) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, cleanDappsForUser(userEmail)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, cognito_1.default.markUserCancelled(userEmail)];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function cleanDappsForUser(userEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dappsToClean, _a, _b, _i, j, dappName, sqsMessageBody;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    console.log('Cleaning Dapps for user: ', userEmail);
                    return [4 /*yield*/, dynamoDB.getDappNamesByOwner(userEmail)];
                case 1:
                    dappsToClean = _c.sent();
                    _a = [];
                    for (_b in dappsToClean)
                        _a.push(_b);
                    _i = 0;
                    _c.label = 2;
                case 2:
                    if (!(_i < _a.length)) return [3 /*break*/, 5];
                    j = _a[_i];
                    dappName = dappsToClean[j];
                    sqsMessageBody = {
                        Method: deleteMethodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, sqs.sendMessage(deleteMethodName, JSON.stringify(sqsMessageBody))];
                case 3:
                    _c.sent();
                    _c.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function dnsNameFromDappName(dappName) {
    return dappName.concat(env_1.dnsRoot);
}
exports.default = {
    postPipelineBuild: postPipelineBuildJob,
    enterpriseGithubCommit: enterpriseGithubCommitJob,
    periodicCleanup: periodicCleanup,
    handlePaymentStatus: handlePaymentStatus
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiam9icy5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJqb2JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxtQ0FBeUM7QUFFekMsNkJBQWdDO0FBQ2hDLHdEQUFrQztBQUNsQywrREFBeUM7QUFDakMsSUFBQSwwQ0FBVSxFQUFFLHNDQUFRLEVBQUUsMEJBQUUsRUFBRSw0QkFBRyxFQUFFLDhDQUFZLEVBQUUsc0NBQVEsRUFBRSxrQ0FBTSxDQUFjO0FBRW5GLElBQU0sZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBRWxDLHFEQUFxRDtBQUNyRCxFQUFFO0FBQ0Ysa0pBQWtKO0FBQ2xKLEVBQUU7QUFDRixzRkFBc0Y7QUFFdEYsU0FBZSxvQkFBb0IsQ0FBQyxFQUE0QjtRQUExQixjQUFJLEVBQUUsVUFBRTs7Ozs7O29CQUNwQyxtQkFBbUIsR0FBSyxJQUFJLG9CQUFULENBQVU7b0JBRS9CLEtBQThDLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxFQUF4RyxVQUFVLGdCQUFBLEVBQUUsaUJBQWlCLHVCQUFBLEVBQUUsUUFBUSxjQUFBLENBQWtFO29CQUVqSCxPQUFPLENBQUMsR0FBRyxDQUFDLHFEQUFxRCxDQUFDLENBQUM7b0JBQ25FLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWUsVUFBVSxvQkFBZSxRQUFRLDZCQUF3QixpQkFBbUIsQ0FBQyxDQUFDOzs7O29CQUd2RyxxQkFBTSxFQUFFLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLEVBQUUsWUFBWSxDQUFDLEVBQUE7O29CQUEzRCxTQUEyRCxDQUFDO29CQUM1RCxxQkFBTSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEVBQUE7O29CQUF6QyxTQUF5QyxDQUFDO29CQUMxQyxxQkFBTSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBcEYsU0FBb0YsQ0FBQztvQkFDckYsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO29CQUMvRCxxQkFBTSxZQUFZLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUF6QyxzQkFBTyxTQUFrQyxFQUFDOzs7b0JBRTFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELEVBQUUsS0FBRyxDQUFDLENBQUM7b0JBQ25FLHFCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEtBQUcsQ0FBQyxFQUFBOztvQkFBbkMsU0FBbUMsQ0FBQztvQkFDN0IscUJBQU0sUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsRUFBQTt3QkFBN0Msc0JBQU8sU0FBc0MsRUFBQzs7Ozs7Q0FFakQ7QUFFRCxTQUFlLGVBQWU7Ozs7OztvQkFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO29CQUUzQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7b0JBQ3BELHFCQUFNLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxFQUFBOztvQkFBekMsU0FBeUMsQ0FBQztvQkFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO29CQUV6RCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7b0JBQ2IscUJBQU0sUUFBUSxDQUFDLHVCQUF1QixFQUFFLEVBQUE7O29CQUEvRCxvQkFBb0IsR0FBRyxTQUF3QztvQkFDbkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO29CQUN0RCxxQkFBTSxpQkFBTyxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLEVBQUE7O29CQUFuRSxVQUFVLEdBQUcsU0FBc0Q7b0JBQ3ZFLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQ3ZELFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUNoQyxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQzs7K0JBRXRCLFdBQVc7Ozs7Ozs7b0JBQ25CLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWhDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkNBQTZDLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQ3ZFLHFCQUFNLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFBQTs7b0JBQTNDLFNBQTJDLENBQUM7Ozs7Ozs7K0JBR2hDLFdBQVc7Ozs7Ozs7b0JBQ25CLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLHFCQUFNLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxFQUFBOztvQkFBbkMsU0FBbUMsQ0FBQztvQkFDcEMscUJBQU0sUUFBUSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFBOztvQkFBM0MsU0FBMkMsQ0FBQztvQkFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsRUFBRSxVQUFVLENBQUMsQ0FBQzs7Ozs7O29CQUcxRSxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7b0JBQzNDLHNCQUFPLEVBQUUsRUFBQzs7OztDQUNYO0FBRUQsU0FBZSx5QkFBeUIsQ0FBQyxFQUE0QjtRQUExQixjQUFJLEVBQUUsVUFBRTs7Ozs7O29CQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO29CQUN6QyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkMsZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7b0JBQ3JELG1CQUFtQixHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztvQkFDM0MsbUJBQW1CLEdBQUssSUFBSSxvQkFBVCxDQUFVO29CQUMvQixLQUE0RCxJQUFJLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsRUFBdEgsVUFBVSxnQkFBQSxFQUFFLFFBQVEsY0FBQSxFQUFFLGNBQWMsb0JBQUEsRUFBRSxlQUFlLHFCQUFBLENBQWtFOzs7O29CQUc5RyxxQkFBTSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsRUFBQTs7b0JBQTNFLFFBQVEsR0FBRyxTQUFnRTtvQkFDL0UscUJBQU0sTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxFQUFFLGVBQWUsQ0FBQyxFQUFBOztvQkFBdEUsU0FBc0UsQ0FBQztvQkFDaEUscUJBQU0sWUFBWSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBQTt3QkFBekMsc0JBQU8sU0FBa0MsRUFBQzs7O29CQUUxQyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNqRCxxQkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxLQUFHLENBQUMsRUFBQTs7b0JBQW5DLFNBQW1DLENBQUM7b0JBQzdCLHFCQUFNLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEVBQUE7d0JBQTdDLHNCQUFPLFNBQXNDLEVBQUM7Ozs7O0NBRWpEO0FBRUQsU0FBZSxtQkFBbUIsQ0FBQyxTQUFnQixFQUFFLE1BQW9COzs7Ozs7b0JBQy9ELEtBQUEsTUFBTSxDQUFBOzs2QkFDUCxzQkFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFyQix3QkFBb0I7NkJBR3BCLHNCQUFhLENBQUMsTUFBTSxDQUFDLENBQXJCLHdCQUFvQjs2QkFHcEIsc0JBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBeEIsd0JBQXVCOzs7O29CQUwxQixPQUFPLENBQUMsR0FBRyxDQUFDLGNBQVksTUFBTSxpQ0FBNEIsU0FBVyxDQUFDLENBQUM7b0JBQ2hFLHFCQUFNLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUE7d0JBQTlDLHNCQUFPLFNBQXVDLEVBQUM7O29CQUUvQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQVksTUFBTSxpQ0FBNEIsU0FBVyxDQUFDLENBQUM7b0JBQ2hFLHFCQUFNLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsRUFBQTt3QkFBakQsc0JBQU8sU0FBMEMsRUFBQzs7b0JBRWxELE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBWSxNQUFNLGlDQUE0QixTQUFXLENBQUMsQ0FBQztvQkFDaEUscUJBQU0sbUJBQW1CLENBQUMsU0FBUyxDQUFDLEVBQUE7d0JBQTNDLHNCQUFPLFNBQW9DLEVBQUM7O29CQUU1QyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFpQyxNQUFRLENBQUMsQ0FBQzs7Ozs7O0NBRTVEO0FBRUQsU0FBZSxtQkFBbUIsQ0FBQyxTQUFnQjs7Ozt3QkFDakQscUJBQU0saUJBQWlCLENBQUMsU0FBUyxDQUFDLEVBQUE7O29CQUFsQyxTQUFrQyxDQUFDO29CQUNuQyxxQkFBTSxpQkFBTyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxFQUFBOztvQkFBMUMsU0FBMEMsQ0FBQzs7Ozs7Q0FDNUM7QUFFRCxTQUFlLGlCQUFpQixDQUFDLFNBQWdCOzs7Ozs7b0JBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQy9CLHFCQUFNLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsRUFBQTs7b0JBQTVELFlBQVksR0FBRyxTQUE2Qzs7K0JBRWxELFlBQVk7Ozs7Ozs7b0JBQ3BCLFFBQVEsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzNCLGNBQWMsR0FBRzt3QkFDbkIsTUFBTSxFQUFFLGdCQUFnQjt3QkFDeEIsUUFBUSxFQUFFLFFBQVE7cUJBQ25CLENBQUM7b0JBQ0YscUJBQU0sR0FBRyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RSxTQUF1RSxDQUFDOzs7Ozs7Ozs7Q0FFN0U7QUFFRCxTQUFTLG1CQUFtQixDQUFDLFFBQWU7SUFDMUMsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQU8sQ0FBQyxDQUFDO0FBQ2xDLENBQUM7QUFFRCxrQkFBZTtJQUNiLGlCQUFpQixFQUFHLG9CQUFvQjtJQUN4QyxzQkFBc0IsRUFBRyx5QkFBeUI7SUFDbEQsZUFBZSxFQUFHLGVBQWU7SUFDakMsbUJBQW1CLEVBQUcsbUJBQW1CO0NBQzFDLENBQUEifQ==