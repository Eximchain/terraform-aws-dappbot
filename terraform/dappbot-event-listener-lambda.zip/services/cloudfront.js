"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var uuid_1 = __importDefault(require("uuid"));
var common_1 = require("../common");
var env_1 = require("../env");
var cloudfront = new env_1.AWS.CloudFront({ apiVersion: '2018-11-05' });
function promiseGetCloudfrontDistributionConfig(distroId) {
    // Cleanup function may make a lot of these calls at once and needs a lot of retries
    var maxRetries = 20;
    var params = {
        Id: distroId
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.getDistributionConfig(params).promise(); }, maxRetries);
}
function promiseDeleteCloudfrontDistribution(distroId, etag) {
    // Cleanup function may make a lot of these calls at once and needs a lot of retries
    var maxRetries = 20;
    var params = {
        Id: distroId,
        IfMatch: etag
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.deleteDistribution(params).promise(); }, maxRetries);
}
function deleteCloudfrontDistributionNoEtag(distroId) {
    return __awaiter(this, void 0, void 0, function () {
        var getConfigResult, etag;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetCloudfrontDistributionConfig(distroId)];
                case 1:
                    getConfigResult = _a.sent();
                    etag = getConfigResult.ETag;
                    if (!etag) {
                        return [2 /*return*/, Promise.reject("ETag for " + distroId + " not found")];
                    }
                    return [2 /*return*/, promiseDeleteCloudfrontDistribution(distroId, etag)];
            }
        });
    });
}
function promiseListCloudfrontDistributions(marker) {
    var maxRetries = 5;
    var params = marker ? { Marker: marker } : {};
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listDistributions(params).promise(); }, maxRetries);
}
function promiseListTagsForCloudfrontDistribution(distroArn) {
    // Cleanup function may make a lot of these calls at once and needs a lot of retries
    var maxRetries = 20;
    var params = {
        Resource: distroArn
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listTagsForResource(params).promise(); }, maxRetries);
}
function promiseCreateCloudfrontInvalidation(distroId, pathPrefix) {
    if (pathPrefix === void 0) { pathPrefix = '/'; }
    var maxRetries = 5;
    var params = {
        DistributionId: distroId,
        InvalidationBatch: {
            CallerReference: uuid_1.default(),
            Paths: {
                Quantity: 1,
                Items: [
                    pathPrefix + "*"
                ]
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.createInvalidation(params).promise(); }, maxRetries);
}
function getDisabledDistributions() {
    return __awaiter(this, void 0, void 0, function () {
        var marker, disabledDistros, listDistrosResult, listDistrosPage, disabledDistroPage, disabledDistroPageArns;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    marker = '';
                    disabledDistros = [];
                    _a.label = 1;
                case 1:
                    if (!true) return [3 /*break*/, 3];
                    return [4 /*yield*/, promiseListCloudfrontDistributions(marker)];
                case 2:
                    listDistrosResult = _a.sent();
                    if (!listDistrosResult.DistributionList) {
                        return [3 /*break*/, 3];
                    }
                    listDistrosPage = listDistrosResult.DistributionList;
                    if (!listDistrosPage.Items) {
                        return [3 /*break*/, 3];
                    }
                    disabledDistroPage = listDistrosPage.Items.filter(function (item) { return item.Enabled === false; })
                        .filter(function (item) { return item.Status === 'Deployed'; });
                    disabledDistroPageArns = disabledDistroPage.map(function (item) { return ({ Id: item.Id, ARN: item.ARN }); });
                    disabledDistros = disabledDistros.concat(disabledDistroPageArns);
                    if (listDistrosPage.IsTruncated) {
                        marker = listDistrosPage.Marker;
                    }
                    else {
                        return [3 /*break*/, 3];
                    }
                    return [3 /*break*/, 1];
                case 3: return [2 /*return*/, disabledDistros];
            }
        });
    });
}
function getDistroIdsForCleanup() {
    return __awaiter(this, void 0, void 0, function () {
        var disabledDistroIdentifiers, numDisabledDistros, getTagsPromises, identifiersWithTags, i, identifier, tags, getTagsResult, err_1, identifierWithTags, identifiersForCleanup;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getDisabledDistributions()];
                case 1:
                    disabledDistroIdentifiers = _a.sent();
                    numDisabledDistros = disabledDistroIdentifiers.length;
                    console.log("Found " + numDisabledDistros + " Cloudfront distributions disabled");
                    getTagsPromises = disabledDistroIdentifiers.map(function (identifier) { return (promiseListTagsForCloudfrontDistribution(identifier.ARN)); });
                    identifiersWithTags = [];
                    i = 0;
                    _a.label = 2;
                case 2:
                    if (!(i < numDisabledDistros)) return [3 /*break*/, 8];
                    identifier = disabledDistroIdentifiers[i];
                    tags = void 0;
                    _a.label = 3;
                case 3:
                    _a.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, getTagsPromises[i]];
                case 4:
                    getTagsResult = _a.sent();
                    if (getTagsResult.Tags.Items) {
                        tags = getTagsResult.Tags.Items;
                    }
                    else {
                        tags = null;
                    }
                    return [3 /*break*/, 6];
                case 5:
                    err_1 = _a.sent();
                    tags = null;
                    return [3 /*break*/, 6];
                case 6:
                    identifierWithTags = { Id: identifier.Id, ARN: identifier.ARN, Tags: tags };
                    identifiersWithTags.push(identifierWithTags);
                    _a.label = 7;
                case 7:
                    i++;
                    return [3 /*break*/, 2];
                case 8:
                    identifiersForCleanup = identifiersWithTags.filter(filterIdentifiersForCleanup);
                    return [2 /*return*/, identifiersForCleanup.map(function (identifier) { return identifier.Id; })];
            }
        });
    });
}
function cleanupDisabledDistributions() {
    return __awaiter(this, void 0, void 0, function () {
        var idsForCleanup, deletePromises, errs_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Cleaning up disabled Cloudfront Distributions");
                    return [4 /*yield*/, getDistroIdsForCleanup()];
                case 1:
                    idsForCleanup = _a.sent();
                    console.log("Found " + idsForCleanup.length + " Cloudfront distributions for cleanup");
                    deletePromises = idsForCleanup.map(deleteCloudfrontDistributionNoEtag);
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, Promise.all(deletePromises)];
                case 3:
                    _a.sent();
                    console.log("All distributions cleaned up successfully");
                    return [3 /*break*/, 5];
                case 4:
                    errs_1 = _a.sent();
                    console.log("Error deleting some distributions for cleanup: ", errs_1);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function filterIdentifiersForCleanup(identifier) {
    var tags = identifier.Tags;
    if (!tags) {
        return false;
    }
    var applicationDappBotTags = tags.filter(function (tag) { return tag.Key === 'Application' && tag.Value === 'DappBot'; });
    var managedByDappBotTags = tags.filter(function (tag) { return tag.Key === 'ManagedBy' && tag.Value === 'DappBot'; });
    return applicationDappBotTags.length === 1 && managedByDappBotTags.length === 1;
}
exports.default = {
    getDistroConfig: promiseGetCloudfrontDistributionConfig,
    deleteDistro: promiseDeleteCloudfrontDistribution,
    listTags: promiseListTagsForCloudfrontDistribution,
    cleanupDisabledDistros: cleanupDisabledDistributions,
    invalidateDistroPrefix: promiseCreateCloudfrontInvalidation
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xvdWRmcm9udC5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jbG91ZGZyb250LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSw4Q0FBMEI7QUFDMUIsb0NBQWlEO0FBQ2pELDhCQUE2QjtBQUU3QixJQUFNLFVBQVUsR0FBRyxJQUFJLFNBQUcsQ0FBQyxVQUFVLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUVsRSxTQUFTLHNDQUFzQyxDQUFDLFFBQWU7SUFDM0Qsb0ZBQW9GO0lBQ3BGLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUNwQixJQUFJLE1BQU0sR0FBRztRQUNULEVBQUUsRUFBRSxRQUFRO0tBQ2YsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsU0FBUyxtQ0FBbUMsQ0FBQyxRQUFlLEVBQUUsSUFBVztJQUNyRSxvRkFBb0Y7SUFDcEYsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDO0lBQ3BCLElBQUksTUFBTSxHQUFHO1FBQ1QsRUFBRSxFQUFFLFFBQVE7UUFDWixPQUFPLEVBQUUsSUFBSTtLQUNoQixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsVUFBVSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUEvQyxDQUErQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ25HLENBQUM7QUFFRCxTQUFlLGtDQUFrQyxDQUFDLFFBQWU7Ozs7O3dCQUN2QyxxQkFBTSxzQ0FBc0MsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXhFLGVBQWUsR0FBRyxTQUFzRDtvQkFDeEUsSUFBSSxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxJQUFJLEVBQUU7d0JBQ1Asc0JBQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFZLFFBQVEsZUFBWSxDQUFDLEVBQUM7cUJBQzNEO29CQUNELHNCQUFPLG1DQUFtQyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsRUFBQzs7OztDQUM5RDtBQUVELFNBQVMsa0NBQWtDLENBQUMsTUFBYTtJQUNyRCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQzlDLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBOUMsQ0FBOEMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNsRyxDQUFDO0FBRUQsU0FBUyx3Q0FBd0MsQ0FBQyxTQUFnQjtJQUM5RCxvRkFBb0Y7SUFDcEYsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDO0lBQ3BCLElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFFLFNBQVM7S0FDdEIsQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNwRyxDQUFDO0FBRUQsU0FBUyxtQ0FBbUMsQ0FBQyxRQUFlLEVBQUUsVUFBcUI7SUFBckIsMkJBQUEsRUFBQSxnQkFBcUI7SUFDL0UsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsY0FBYyxFQUFFLFFBQVE7UUFDeEIsaUJBQWlCLEVBQUU7WUFDZixlQUFlLEVBQUUsY0FBTSxFQUFFO1lBQ3pCLEtBQUssRUFBRTtnQkFDSCxRQUFRLEVBQUUsQ0FBQztnQkFDWCxLQUFLLEVBQUU7b0JBQ0EsVUFBVSxNQUFHO2lCQUNuQjthQUNKO1NBQ0o7S0FDSixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsVUFBVSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUEvQyxDQUErQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ25HLENBQUM7QUFFRCxTQUFlLHdCQUF3Qjs7Ozs7O29CQUMvQixNQUFNLEdBQUcsRUFBRSxDQUFDO29CQUNaLGVBQWUsR0FBMEIsRUFBRSxDQUFDOzs7eUJBQ3pDLElBQUk7b0JBQ3lDLHFCQUFNLGtDQUFrQyxDQUFDLE1BQU0sQ0FBQyxFQUFBOztvQkFBNUYsaUJBQWlCLEdBQTJCLFNBQWdEO29CQUNoRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLEVBQUU7d0JBQ3JDLHdCQUFNO3FCQUNUO29CQUNHLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDekQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7d0JBQ3hCLHdCQUFNO3FCQUNUO29CQUVHLGtCQUFrQixHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQXRCLENBQXNCLENBQUM7eUJBQ3RDLE1BQU0sQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUExQixDQUEwQixDQUFDLENBQUM7b0JBRXRGLHNCQUFzQixHQUFHLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLENBQUMsRUFBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQTlCLENBQThCLENBQUMsQ0FBQztvQkFDNUYsZUFBZSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFFakUsSUFBSSxlQUFlLENBQUMsV0FBVyxFQUFFO3dCQUM3QixNQUFNLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQztxQkFDbkM7eUJBQU07d0JBQ0gsd0JBQU07cUJBQ1Q7O3dCQUVMLHNCQUFPLGVBQWUsRUFBQzs7OztDQUMxQjtBQUVELFNBQWUsc0JBQXNCOzs7Ozt3QkFDRCxxQkFBTSx3QkFBd0IsRUFBRSxFQUFBOztvQkFBNUQseUJBQXlCLEdBQUcsU0FBZ0M7b0JBQzVELGtCQUFrQixHQUFHLHlCQUF5QixDQUFDLE1BQU0sQ0FBQztvQkFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFTLGtCQUFrQix1Q0FBb0MsQ0FBQyxDQUFDO29CQUN6RSxlQUFlLEdBQUcseUJBQXlCLENBQUMsR0FBRyxDQUFDLFVBQUEsVUFBVSxJQUFJLE9BQUEsQ0FBQyx3Q0FBd0MsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBMUQsQ0FBMEQsQ0FBQyxDQUFDO29CQUUxSCxtQkFBbUIsR0FBa0MsRUFBRSxDQUFDO29CQUNuRCxDQUFDLEdBQUcsQ0FBQzs7O3lCQUFFLENBQUEsQ0FBQyxHQUFHLGtCQUFrQixDQUFBO29CQUM5QixVQUFVLEdBQUcseUJBQXlCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFDLElBQUksU0FBYSxDQUFDOzs7O29CQUVFLHFCQUFNLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBQTs7b0JBQXhDLGFBQWEsR0FBRyxTQUF3QjtvQkFDNUMsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTt3QkFDMUIsSUFBSSxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO3FCQUNuQzt5QkFBTTt3QkFDSCxJQUFJLEdBQUcsSUFBSSxDQUFDO3FCQUNmOzs7O29CQUVELElBQUksR0FBRyxJQUFJLENBQUM7OztvQkFFWixrQkFBa0IsR0FBRyxFQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsQ0FBQztvQkFDOUUsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7OztvQkFkVCxDQUFDLEVBQUUsQ0FBQTs7O29CQWlCdkMscUJBQXFCLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7b0JBQ3BGLHNCQUFPLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxVQUFBLFVBQVUsSUFBSSxPQUFBLFVBQVUsQ0FBQyxFQUFFLEVBQWIsQ0FBYSxDQUFDLEVBQUM7Ozs7Q0FDakU7QUFFRCxTQUFlLDRCQUE0Qjs7Ozs7O29CQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLCtDQUErQyxDQUFDLENBQUM7b0JBQ3pDLHFCQUFNLHNCQUFzQixFQUFFLEVBQUE7O29CQUE5QyxhQUFhLEdBQUcsU0FBOEI7b0JBQ2xELE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBUyxhQUFhLENBQUMsTUFBTSwwQ0FBdUMsQ0FBQyxDQUFDO29CQUM5RSxjQUFjLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDOzs7O29CQUV2RSxxQkFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFBOztvQkFBakMsU0FBaUMsQ0FBQztvQkFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDOzs7O29CQUV6RCxPQUFPLENBQUMsR0FBRyxDQUFDLGlEQUFpRCxFQUFFLE1BQUksQ0FBQyxDQUFDOzs7Ozs7Q0FFNUU7QUFFRCxTQUFTLDJCQUEyQixDQUFDLFVBQXVDO0lBQ3hFLElBQUksSUFBSSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDM0IsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNQLE9BQU8sS0FBSyxDQUFDO0tBQ2hCO0lBRUQsSUFBSSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLEdBQUcsS0FBSyxhQUFhLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQXBELENBQW9ELENBQUMsQ0FBQztJQUN0RyxJQUFJLG9CQUFvQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxHQUFHLENBQUMsS0FBSyxLQUFLLFNBQVMsRUFBbEQsQ0FBa0QsQ0FBQyxDQUFDO0lBQ2xHLE9BQU8sc0JBQXNCLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxvQkFBb0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO0FBQ3BGLENBQUM7QUFhRCxrQkFBZTtJQUNYLGVBQWUsRUFBRyxzQ0FBc0M7SUFDeEQsWUFBWSxFQUFHLG1DQUFtQztJQUNsRCxRQUFRLEVBQUcsd0NBQXdDO0lBQ25ELHNCQUFzQixFQUFHLDRCQUE0QjtJQUNyRCxzQkFBc0IsRUFBRyxtQ0FBbUM7Q0FDL0QsQ0FBQyJ9