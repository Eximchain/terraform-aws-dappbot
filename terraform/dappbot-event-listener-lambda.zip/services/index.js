"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var cloudfront_1 = __importDefault(require("./cloudfront"));
var codepipeline_1 = __importDefault(require("./codepipeline"));
var dynamoDB_1 = __importDefault(require("./dynamoDB"));
var github_1 = __importDefault(require("./github"));
var s3_1 = __importDefault(require("./s3"));
var sqs_1 = __importDefault(require("./sqs"));
var sendgrid_1 = __importDefault(require("./sendgrid"));
exports.default = { cloudfront: cloudfront_1.default, codepipeline: codepipeline_1.default, dynamoDB: dynamoDB_1.default, github: github_1.default, s3: s3_1.default, sqs: sqs_1.default, sendgrid: sendgrid_1.default };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSw0REFBc0M7QUFDdEMsZ0VBQTBDO0FBQzFDLHdEQUFrQztBQUNsQyxvREFBOEI7QUFDOUIsNENBQXNCO0FBQ3RCLDhDQUF3QjtBQUN4Qix3REFBa0M7QUFFbEMsa0JBQWUsRUFBRSxVQUFVLHNCQUFBLEVBQUUsWUFBWSx3QkFBQSxFQUFFLFFBQVEsb0JBQUEsRUFBRSxNQUFNLGtCQUFBLEVBQUUsRUFBRSxjQUFBLEVBQUUsR0FBRyxlQUFBLEVBQUUsUUFBUSxvQkFBQSxFQUFFLENBQUMifQ==