"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var ddb = new env_1.AWS.DynamoDB({ apiVersion: '2012-08-10' });
function serializeDdbKey(dappName) {
    var keyItem = {
        'DappName': { S: dappName }
    };
    return keyItem;
}
function promiseSetDappAvailable(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbResponse, dbItem;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetDappItem(dappName)];
                case 1:
                    dbResponse = _a.sent();
                    dbItem = dbResponse.Item;
                    dbItem.State.S = common_1.DappStates.AVAILABLE;
                    return [2 /*return*/, promisePutRawDappItem(dbItem)];
            }
        });
    });
}
function promiseSetDappFailed(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbResponse, dbItem;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetDappItem(dappName)];
                case 1:
                    dbResponse = _a.sent();
                    dbItem = dbResponse.Item;
                    dbItem.State.S = common_1.DappStates.FAILED;
                    return [2 /*return*/, promisePutRawDappItem(dbItem)];
            }
        });
    });
}
function promiseSetItemBuilding(dbItem, cloudfrontDistroId, cloudfrontDns) {
    if (cloudfrontDistroId) {
        dbItem.CloudfrontDistributionId = { S: cloudfrontDistroId };
    }
    if (cloudfrontDns) {
        dbItem.CloudfrontDnsName = { S: cloudfrontDns };
    }
    dbItem.State.S = common_1.DappStates.BUILDING_DAPP;
    return promisePutRawDappItem(dbItem);
}
// TODO: Combine with SetDapp method
function promiseSetItemAvailable(dbItem) {
    dbItem.State.S = common_1.DappStates.AVAILABLE;
    return promisePutRawDappItem(dbItem);
}
function promisePutRawDappItem(item) {
    var maxRetries = 5;
    var putItemParams = {
        TableName: env_1.dappTableName,
        Item: item
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promiseGetDappItem(dappName) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.dappTableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.getItem(getItemParams).promise(); }, maxRetries);
}
function promiseDeleteDappItem(dappName) {
    var maxRetries = 5;
    var deleteItemParams = {
        TableName: env_1.dappTableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.deleteItem(deleteItemParams).promise(); }, maxRetries);
}
function promiseGetItemsByOwner(ownerEmail) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.dappTableName,
        IndexName: 'OwnerEmailIndex',
        ExpressionAttributeNames: {
            "#OE": "OwnerEmail"
        },
        ExpressionAttributeValues: {
            ":e": {
                S: ownerEmail
            }
        },
        KeyConditionExpression: "#OE = :e",
        Select: 'ALL_PROJECTED_ATTRIBUTES'
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.query(getItemParams).promise(); }, maxRetries);
}
function getDappNamesByOwner(owner) {
    return __awaiter(this, void 0, void 0, function () {
        var dappList, itemsByOwnerResponse, itemsByOwner, i, item, dappName;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    dappList = [];
                    return [4 /*yield*/, promiseGetItemsByOwner(owner)];
                case 1:
                    itemsByOwnerResponse = _a.sent();
                    itemsByOwner = itemsByOwnerResponse.Items;
                    if (!itemsByOwner) {
                        return [2 /*return*/, dappList];
                    }
                    for (i in itemsByOwner) {
                        item = itemsByOwner[i];
                        dappName = item.DappName.S;
                        dappList.push(dappName);
                    }
                    return [2 /*return*/, dappList];
            }
        });
    });
}
function serializeLapsedUserItem(userEmail) {
    var now = new Date().toISOString();
    // Required Params
    var item = {
        'UserEmail': { S: userEmail },
        'LapsedAt': { S: now }
    };
    return item;
}
function serializeLapsedUserKey(userEmail) {
    var key = {
        'UserEmail': { S: userEmail }
    };
    return key;
}
function promisePutLapsedUser(lapsedUser) {
    var maxRetries = 5;
    var putItemParams = {
        TableName: env_1.lapsedUsersTableName,
        Item: serializeLapsedUserItem(lapsedUser)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promiseDeleteLapsedUser(lapsedUser) {
    var maxRetries = 5;
    var deleteItemParams = {
        TableName: env_1.lapsedUsersTableName,
        Key: serializeLapsedUserKey(lapsedUser)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.deleteItem(deleteItemParams).promise(); }, maxRetries);
}
function promiseScanLapsedUsers() {
    var maxRetries = 5;
    var scanParams = {
        TableName: env_1.lapsedUsersTableName
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.scan(scanParams).promise(); }, maxRetries);
}
function getPotentialFailedUsers() {
    return __awaiter(this, void 0, void 0, function () {
        var response, potentialLapsedUsers, items, i, item, userEmail, lapsedAtIsoString, lapsedAt, now, msSinceLapse, hrsSinceLapse;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseScanLapsedUsers()];
                case 1:
                    response = _a.sent();
                    potentialLapsedUsers = [];
                    items = response.Items;
                    if (!items) {
                        return [2 /*return*/, []];
                    }
                    for (i in items) {
                        item = items[i];
                        userEmail = item.UserEmail.S;
                        lapsedAtIsoString = item.LapsedAt.S;
                        lapsedAt = Date.parse(lapsedAtIsoString);
                        now = Date.now();
                        msSinceLapse = now - lapsedAt;
                        hrsSinceLapse = msToHrs(msSinceLapse);
                        if (hrsSinceLapse > env_1.paymentLapsedGracePeriodHrs) {
                            potentialLapsedUsers.push(userEmail);
                        }
                    }
                    return [2 /*return*/, potentialLapsedUsers];
            }
        });
    });
}
function msToHrs(millis) {
    // 1000 ms / s
    // 60 s / min
    // 60 min / hr
    return millis / (60 * 60 * 1000);
}
exports.default = {
    getItem: promiseGetDappItem,
    deleteItem: promiseDeleteDappItem,
    getByOwner: promiseGetItemsByOwner,
    setDappAvailable: promiseSetDappAvailable,
    setDappFailed: promiseSetDappFailed,
    setItemBuilding: promiseSetItemBuilding,
    setItemAvailable: promiseSetItemAvailable,
    putLapsedUser: promisePutLapsedUser,
    deleteLapsedUser: promiseDeleteLapsedUser,
    getPotentialFailedUsers: getPotentialFailedUsers,
    getDappNamesByOwner: getDappNamesByOwner
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1vREIuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvZHluYW1vREIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLG9DQUE2RDtBQUM3RCw4QkFBK0Y7QUFDL0YsSUFBTSxHQUFHLEdBQUcsSUFBSSxTQUFHLENBQUMsUUFBUSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFekQsU0FBUyxlQUFlLENBQUMsUUFBZTtJQUNwQyxJQUFJLE9BQU8sR0FBRztRQUNWLFVBQVUsRUFBRSxFQUFDLENBQUMsRUFBRSxRQUFRLEVBQUM7S0FDNUIsQ0FBQztJQUNGLE9BQU8sT0FBTyxDQUFDO0FBQ25CLENBQUM7QUFFRCxTQUFlLHVCQUF1QixDQUFDLFFBQWU7Ozs7O3dCQUNqQyxxQkFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFVBQVUsR0FBRyxTQUFrQztvQkFDL0MsTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFvQixDQUFDO29CQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxtQkFBVSxDQUFDLFNBQVMsQ0FBQztvQkFFdEMsc0JBQU8scUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUM7Ozs7Q0FDeEM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLFFBQWU7Ozs7O3dCQUM5QixxQkFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFVBQVUsR0FBRyxTQUFrQztvQkFDL0MsTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFvQixDQUFDO29CQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxtQkFBVSxDQUFDLE1BQU0sQ0FBQztvQkFFbkMsc0JBQU8scUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUM7Ozs7Q0FDeEM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLE1BQStCLEVBQUUsa0JBQTBCLEVBQUUsYUFBcUI7SUFDOUcsSUFBSSxrQkFBa0IsRUFBRTtRQUNwQixNQUFNLENBQUMsd0JBQXdCLEdBQUcsRUFBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUMsQ0FBQztLQUM3RDtJQUNELElBQUksYUFBYSxFQUFFO1FBQ2YsTUFBTSxDQUFDLGlCQUFpQixHQUFHLEVBQUMsQ0FBQyxFQUFFLGFBQWEsRUFBQyxDQUFDO0tBQ2pEO0lBRUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsbUJBQVUsQ0FBQyxhQUFhLENBQUM7SUFFMUMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBRUQsb0NBQW9DO0FBQ3BDLFNBQVMsdUJBQXVCLENBQUMsTUFBK0I7SUFDNUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsbUJBQVUsQ0FBQyxTQUFTLENBQUM7SUFFdEMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxJQUE2QjtJQUN4RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLG1CQUFhO1FBQ3hCLElBQUksRUFBRSxJQUFJO0tBQ2IsQ0FBQztJQUVGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXBDLENBQW9DLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDeEYsQ0FBQztBQUVELFNBQVMsa0JBQWtCLENBQUMsUUFBZTtJQUN2QyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLG1CQUFhO1FBQ3hCLEdBQUcsRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDO0tBQ2pDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHFCQUFxQixDQUFDLFFBQWU7SUFDMUMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksZ0JBQWdCLEdBQUc7UUFDbkIsU0FBUyxFQUFFLG1CQUFhO1FBQ3hCLEdBQUcsRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDO0tBQ2pDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxFQUFFLEVBQTFDLENBQTBDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDOUYsQ0FBQztBQUVELFNBQVMsc0JBQXNCLENBQUMsVUFBaUI7SUFDN0MsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksYUFBYSxHQUFHO1FBQ2hCLFNBQVMsRUFBRSxtQkFBYTtRQUN4QixTQUFTLEVBQUUsaUJBQWlCO1FBQzVCLHdCQUF3QixFQUFFO1lBQ3RCLEtBQUssRUFBRSxZQUFZO1NBQ3RCO1FBQ0QseUJBQXlCLEVBQUU7WUFDdkIsSUFBSSxFQUFFO2dCQUNGLENBQUMsRUFBRSxVQUFVO2FBQ2hCO1NBQ0o7UUFDRCxzQkFBc0IsRUFBRSxVQUFVO1FBQ2xDLE1BQU0sRUFBRSwwQkFBMEI7S0FDckMsQ0FBQztJQUVGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxDLENBQWtDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEYsQ0FBQztBQUVELFNBQWUsbUJBQW1CLENBQUMsS0FBWTs7Ozs7O29CQUN2QyxRQUFRLEdBQVksRUFBRSxDQUFDO29CQUNBLHFCQUFNLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBMUQsb0JBQW9CLEdBQUcsU0FBbUM7b0JBQzFELFlBQVksR0FBRyxvQkFBb0IsQ0FBQyxLQUFLLENBQUM7b0JBQzlDLElBQUksQ0FBQyxZQUFZLEVBQUU7d0JBQ2Ysc0JBQU8sUUFBUSxFQUFDO3FCQUNuQjtvQkFDRCxLQUFTLENBQUMsSUFBSSxZQUFZLEVBQUU7d0JBQ3BCLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZCLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQVcsQ0FBQzt3QkFDekMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDM0I7b0JBQ0Qsc0JBQU8sUUFBUSxFQUFDOzs7O0NBQ25CO0FBRUQsU0FBUyx1QkFBdUIsQ0FBQyxTQUFnQjtJQUM3QyxJQUFJLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ25DLGtCQUFrQjtJQUNsQixJQUFJLElBQUksR0FBNEI7UUFDaEMsV0FBVyxFQUFHLEVBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBQztRQUM1QixVQUFVLEVBQUcsRUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFDO0tBQ3hCLENBQUM7SUFDRixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxTQUFnQjtJQUM1QyxJQUFJLEdBQUcsR0FBNEI7UUFDL0IsV0FBVyxFQUFHLEVBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBQztLQUMvQixDQUFDO0lBQ0YsT0FBTyxHQUFHLENBQUM7QUFDZixDQUFDO0FBRUQsU0FBUyxvQkFBb0IsQ0FBQyxVQUFpQjtJQUMzQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLDBCQUFvQjtRQUMvQixJQUFJLEVBQUUsdUJBQXVCLENBQUMsVUFBVSxDQUFDO0tBQzVDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHVCQUF1QixDQUFDLFVBQWlCO0lBQzlDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGdCQUFnQixHQUFHO1FBQ25CLFNBQVMsRUFBRSwwQkFBb0I7UUFDL0IsR0FBRyxFQUFFLHNCQUFzQixDQUFDLFVBQVUsQ0FBQztLQUMxQyxDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUExQyxDQUEwQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQzlGLENBQUM7QUFFRCxTQUFTLHNCQUFzQjtJQUMzQixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxVQUFVLEdBQUc7UUFDYixTQUFTLEVBQUUsMEJBQW9CO0tBQ2xDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE5QixDQUE4QixFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFFRCxTQUFlLHVCQUF1Qjs7Ozs7d0JBQ25CLHFCQUFNLHNCQUFzQixFQUFFLEVBQUE7O29CQUF6QyxRQUFRLEdBQUcsU0FBOEI7b0JBRXpDLG9CQUFvQixHQUFZLEVBQUUsQ0FBQztvQkFDbkMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxLQUFLLEVBQUU7d0JBQ1Isc0JBQU8sRUFBRSxFQUFDO3FCQUNiO29CQUVELEtBQVMsQ0FBQyxJQUFJLEtBQUssRUFBRTt3QkFDYixJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVoQixTQUFTLEdBQVUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFXLENBQUM7d0JBQzlDLGlCQUFpQixHQUFVLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBVyxDQUFDO3dCQUVyRCxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO3dCQUN6QyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUNqQixZQUFZLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQzt3QkFDOUIsYUFBYSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFFMUMsSUFBSSxhQUFhLEdBQUcsaUNBQTJCLEVBQUU7NEJBQzdDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt5QkFDeEM7cUJBQ0o7b0JBQ0Qsc0JBQU8sb0JBQW9CLEVBQUM7Ozs7Q0FDL0I7QUFFRCxTQUFTLE9BQU8sQ0FBQyxNQUFhO0lBQzFCLGNBQWM7SUFDZCxhQUFhO0lBQ2IsY0FBYztJQUNkLE9BQU8sTUFBTSxHQUFHLENBQUMsRUFBRSxHQUFDLEVBQUUsR0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBRUQsa0JBQWU7SUFDWCxPQUFPLEVBQUcsa0JBQWtCO0lBQzVCLFVBQVUsRUFBRyxxQkFBcUI7SUFDbEMsVUFBVSxFQUFHLHNCQUFzQjtJQUNuQyxnQkFBZ0IsRUFBRyx1QkFBdUI7SUFDMUMsYUFBYSxFQUFHLG9CQUFvQjtJQUNwQyxlQUFlLEVBQUcsc0JBQXNCO0lBQ3hDLGdCQUFnQixFQUFHLHVCQUF1QjtJQUMxQyxhQUFhLEVBQUcsb0JBQW9CO0lBQ3BDLGdCQUFnQixFQUFHLHVCQUF1QjtJQUMxQyx1QkFBdUIsRUFBRyx1QkFBdUI7SUFDakQsbUJBQW1CLEVBQUcsbUJBQW1CO0NBQzVDLENBQUEifQ==