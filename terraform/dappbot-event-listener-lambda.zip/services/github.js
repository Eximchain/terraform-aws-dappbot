"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var rest_1 = __importDefault(require("@octokit/rest"));
var env_1 = require("../env");
var GITHUB_CONFIGURED = false;
var token = "";
if (env_1.githubToken && env_1.githubToken !== "") {
    token = env_1.githubToken;
    GITHUB_CONFIGURED = true;
}
var octokit = new rest_1.default({
    auth: token,
    userAgent: 'DappbotService v1.0'
});
var masterRefName = 'heads/master';
function commitArtifactToGithub(artifact, targetRepoName, targetRepoOwner) {
    return __awaiter(this, void 0, void 0, function () {
        var masterRef, headCommit, blobs, _i, _a, _b, filePath, fileObj, file, fileContent, blob, treeItems, newTree, newCommit;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    if (!GITHUB_CONFIGURED) {
                        console.log("Github Client not configured. Skipping committing artifacts to Github.");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, getMasterRef(targetRepoName, targetRepoOwner)];
                case 1:
                    masterRef = _c.sent();
                    return [4 /*yield*/, getCommit(targetRepoName, targetRepoOwner, masterRef.object.sha)];
                case 2:
                    headCommit = _c.sent();
                    blobs = new Map();
                    _i = 0, _a = Object.entries(artifact.files);
                    _c.label = 3;
                case 3:
                    if (!(_i < _a.length)) return [3 /*break*/, 7];
                    _b = _a[_i], filePath = _b[0], fileObj = _b[1];
                    file = fileObj;
                    fileContent = fileAsBase64(file);
                    return [4 /*yield*/, createBlob(targetRepoName, targetRepoOwner, fileContent)];
                case 4:
                    blob = _c.sent();
                    blobs.set(filePath, blob);
                    // Sleep required to avoid triggering the Github "abuse detection mechanism"
                    return [4 /*yield*/, sleep(250)];
                case 5:
                    // Sleep required to avoid triggering the Github "abuse detection mechanism"
                    _c.sent();
                    _c.label = 6;
                case 6:
                    _i++;
                    return [3 /*break*/, 3];
                case 7:
                    console.log("All blobs created");
                    treeItems = [];
                    blobs.forEach(function (blob, filePath, map) { return (treeItems.push({
                        path: filePath,
                        sha: blob.sha,
                        type: 'blob',
                        mode: '100644'
                    })); });
                    return [4 /*yield*/, createNewTree(targetRepoName, targetRepoOwner, headCommit.tree.sha, treeItems)];
                case 8:
                    newTree = _c.sent();
                    return [4 /*yield*/, createCommit(targetRepoName, targetRepoOwner, newTree.sha, masterRef.object.sha)];
                case 9:
                    newCommit = _c.sent();
                    return [4 /*yield*/, pushCommit(targetRepoName, targetRepoOwner, newCommit.sha)];
                case 10:
                    _c.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function fileAsBase64(file) {
    return file.asNodeBuffer().toString('base64');
}
function createBlob(repoName, repoOwner, base64Content) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        content: base64Content,
                        encoding: 'base64'
                    };
                    return [4 /*yield*/, octokit.git.createBlob(params)];
                case 1:
                    response = _a.sent();
                    console.log("Created blob", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function getMasterRef(repoName, repoOwner) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        ref: masterRefName
                    };
                    return [4 /*yield*/, octokit.git.getRef(params)];
                case 1:
                    response = _a.sent();
                    console.log("Got Reference: ", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function getCommit(repoName, repoOwner, commitSha) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        commit_sha: commitSha
                    };
                    return [4 /*yield*/, octokit.git.getCommit(params)];
                case 1:
                    response = _a.sent();
                    console.log("Got Commit: ", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function createNewTree(repoName, repoOwner, baseTreeSha, treeItems) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        tree: treeItems,
                        base_tree: baseTreeSha
                    };
                    return [4 /*yield*/, octokit.git.createTree(params)];
                case 1:
                    response = _a.sent();
                    console.log("Created new tree: ", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function createCommit(repoName, repoOwner, treeSha, parentSha) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        message: 'Source Commit by DappBot Enterprise',
                        tree: treeSha,
                        parents: [parentSha]
                    };
                    return [4 /*yield*/, octokit.git.createCommit(params)];
                case 1:
                    response = _a.sent();
                    console.log("Created new commit: ", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function pushCommit(repoName, repoOwner, commitSha) {
    return __awaiter(this, void 0, void 0, function () {
        var params, response;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        owner: repoOwner,
                        repo: repoName,
                        ref: masterRefName,
                        sha: commitSha
                    };
                    return [4 /*yield*/, octokit.git.updateRef(params)];
                case 1:
                    response = _a.sent();
                    console.log("Pushed new commit: ", response);
                    return [2 /*return*/, response.data];
            }
        });
    });
}
function sleep(ms) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (resolve) { return setTimeout(resolve, ms); })];
        });
    });
}
exports.default = {
    commitArtifact: commitArtifactToGithub
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2l0aHViLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL2dpdGh1Yi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdURBQW9DO0FBQ3BDLDhCQUFxQztBQUVyQyxJQUFJLGlCQUFpQixHQUFHLEtBQUssQ0FBQztBQUM5QixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7QUFDZixJQUFJLGlCQUFXLElBQUksaUJBQVcsS0FBSyxFQUFFLEVBQUU7SUFDbkMsS0FBSyxHQUFHLGlCQUFXLENBQUM7SUFDcEIsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO0NBQzVCO0FBRUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxjQUFPLENBQUM7SUFDeEIsSUFBSSxFQUFFLEtBQUs7SUFDWCxTQUFTLEVBQUUscUJBQXFCO0NBQ25DLENBQUMsQ0FBQztBQUNILElBQU0sYUFBYSxHQUFHLGNBQWMsQ0FBQztBQUdyQyxTQUFlLHNCQUFzQixDQUFDLFFBQVksRUFBRSxjQUFxQixFQUFFLGVBQXNCOzs7Ozs7b0JBQzdGLElBQUksQ0FBQyxpQkFBaUIsRUFBRTt3QkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3RUFBd0UsQ0FBQyxDQUFDO3dCQUN0RixzQkFBTztxQkFDVjtvQkFFZSxxQkFBTSxZQUFZLENBQUMsY0FBYyxFQUFFLGVBQWUsQ0FBQyxFQUFBOztvQkFBL0QsU0FBUyxHQUFHLFNBQW1EO29CQUNsRCxxQkFBTSxTQUFTLENBQUMsY0FBYyxFQUFFLGVBQWUsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFBOztvQkFBbkYsVUFBVSxHQUFHLFNBQXNFO29CQUVuRixLQUFLLEdBQTJCLElBQUksR0FBRyxFQUFFLENBQUM7MEJBQ2dCLEVBQTlCLEtBQUEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDOzs7eUJBQTlCLENBQUEsY0FBOEIsQ0FBQTtvQkFBckQsV0FBbUIsRUFBbEIsUUFBUSxRQUFBLEVBQUUsT0FBTyxRQUFBO29CQUNuQixJQUFJLEdBQUcsT0FBc0IsQ0FBQztvQkFDOUIsV0FBVyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFMUIscUJBQU0sVUFBVSxDQUFDLGNBQWMsRUFBRSxlQUFlLEVBQUUsV0FBVyxDQUFDLEVBQUE7O29CQUFyRSxJQUFJLEdBQUcsU0FBOEQ7b0JBQ3pFLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMxQiw0RUFBNEU7b0JBQzVFLHFCQUFNLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQTs7b0JBRGhCLDRFQUE0RTtvQkFDNUUsU0FBZ0IsQ0FBQzs7O29CQVBXLElBQThCLENBQUE7OztvQkFTOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO29CQUU3QixTQUFTLEdBQWMsRUFBRSxDQUFDO29CQUM5QixLQUFLLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLElBQUssT0FBQSxDQUNuQyxTQUFTLENBQUMsSUFBSSxDQUFDO3dCQUNYLElBQUksRUFBRSxRQUFRO3dCQUNkLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRzt3QkFDYixJQUFJLEVBQUUsTUFBTTt3QkFDWixJQUFJLEVBQUUsUUFBUTtxQkFDakIsQ0FBQyxDQUNMLEVBUHNDLENBT3RDLENBQUMsQ0FBQztvQkFFVyxxQkFBTSxhQUFhLENBQUMsY0FBYyxFQUFFLGVBQWUsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsRUFBQTs7b0JBQTlGLE9BQU8sR0FBRyxTQUFvRjtvQkFDbEYscUJBQU0sWUFBWSxDQUFDLGNBQWMsRUFBRSxlQUFlLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFBOztvQkFBbEcsU0FBUyxHQUFHLFNBQXNGO29CQUN0RyxxQkFBTSxVQUFVLENBQUMsY0FBYyxFQUFFLGVBQWUsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUE7O29CQUFoRSxTQUFnRSxDQUFDOzs7OztDQUNwRTtBQUVELFNBQVMsWUFBWSxDQUFDLElBQWdCO0lBQ2xDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNsRCxDQUFDO0FBRUQsU0FBZSxVQUFVLENBQUMsUUFBZSxFQUFFLFNBQWdCLEVBQUUsYUFBb0I7Ozs7OztvQkFDekUsTUFBTSxHQUFHO3dCQUNULEtBQUssRUFBRSxTQUFTO3dCQUNoQixJQUFJLEVBQUUsUUFBUTt3QkFDZCxPQUFPLEVBQUUsYUFBYTt3QkFDdEIsUUFBUSxFQUFFLFFBQVE7cUJBQ3JCLENBQUM7b0JBRWEscUJBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUE7O29CQUEvQyxRQUFRLEdBQUcsU0FBb0M7b0JBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO29CQUN0QyxzQkFBTyxRQUFRLENBQUMsSUFBSSxFQUFDOzs7O0NBQ3hCO0FBRUQsU0FBZSxZQUFZLENBQUMsUUFBZSxFQUFFLFNBQWdCOzs7Ozs7b0JBQ3JELE1BQU0sR0FBRzt3QkFDVCxLQUFLLEVBQUUsU0FBUzt3QkFDaEIsSUFBSSxFQUFFLFFBQVE7d0JBQ2QsR0FBRyxFQUFFLGFBQWE7cUJBQ3JCLENBQUM7b0JBRWEscUJBQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUE7O29CQUEzQyxRQUFRLEdBQUcsU0FBZ0M7b0JBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBQ3pDLHNCQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUM7Ozs7Q0FDeEI7QUFFRCxTQUFlLFNBQVMsQ0FBQyxRQUFlLEVBQUUsU0FBZ0IsRUFBRSxTQUFnQjs7Ozs7O29CQUNwRSxNQUFNLEdBQUc7d0JBQ1QsS0FBSyxFQUFFLFNBQVM7d0JBQ2hCLElBQUksRUFBRSxRQUFRO3dCQUNkLFVBQVUsRUFBRSxTQUFTO3FCQUN4QixDQUFDO29CQUVhLHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFBOztvQkFBOUMsUUFBUSxHQUFHLFNBQW1DO29CQUNsRCxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDdEMsc0JBQU8sUUFBUSxDQUFDLElBQUksRUFBQzs7OztDQUN4QjtBQUVELFNBQWUsYUFBYSxDQUFDLFFBQWUsRUFBRSxTQUFnQixFQUFFLFdBQWtCLEVBQUUsU0FBb0I7Ozs7OztvQkFDaEcsTUFBTSxHQUFHO3dCQUNULEtBQUssRUFBRSxTQUFTO3dCQUNoQixJQUFJLEVBQUUsUUFBUTt3QkFDZCxJQUFJLEVBQUUsU0FBUzt3QkFDZixTQUFTLEVBQUUsV0FBVztxQkFDekIsQ0FBQztvQkFFYSxxQkFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBQTs7b0JBQS9DLFFBQVEsR0FBRyxTQUFvQztvQkFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDNUMsc0JBQU8sUUFBUSxDQUFDLElBQUksRUFBQzs7OztDQUN4QjtBQUVELFNBQWUsWUFBWSxDQUFDLFFBQWUsRUFBRSxTQUFnQixFQUFFLE9BQWMsRUFBRSxTQUFnQjs7Ozs7O29CQUN2RixNQUFNLEdBQUc7d0JBQ1QsS0FBSyxFQUFFLFNBQVM7d0JBQ2hCLElBQUksRUFBRSxRQUFRO3dCQUNkLE9BQU8sRUFBRSxxQ0FBcUM7d0JBQzlDLElBQUksRUFBRSxPQUFPO3dCQUNiLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQztxQkFDdkIsQ0FBQztvQkFFYSxxQkFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBQTs7b0JBQWpELFFBQVEsR0FBRyxTQUFzQztvQkFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDOUMsc0JBQU8sUUFBUSxDQUFDLElBQUksRUFBQzs7OztDQUN4QjtBQUVELFNBQWUsVUFBVSxDQUFDLFFBQWUsRUFBRSxTQUFnQixFQUFFLFNBQWdCOzs7Ozs7b0JBQ3JFLE1BQU0sR0FBRzt3QkFDVCxLQUFLLEVBQUUsU0FBUzt3QkFDaEIsSUFBSSxFQUFFLFFBQVE7d0JBQ2QsR0FBRyxFQUFFLGFBQWE7d0JBQ2xCLEdBQUcsRUFBRSxTQUFTO3FCQUNqQixDQUFDO29CQUVhLHFCQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFBOztvQkFBOUMsUUFBUSxHQUFHLFNBQW1DO29CQUNsRCxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxDQUFDO29CQUM3QyxzQkFBTyxRQUFRLENBQUMsSUFBSSxFQUFDOzs7O0NBQ3hCO0FBbUJELFNBQWUsS0FBSyxDQUFDLEVBQVM7OztZQUMxQixzQkFBTyxJQUFJLE9BQU8sQ0FBQyxVQUFBLE9BQU8sSUFBSSxPQUFBLFVBQVUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLEVBQXZCLENBQXVCLENBQUMsRUFBQzs7O0NBQzFEO0FBRUQsa0JBQWU7SUFDWCxjQUFjLEVBQUcsc0JBQXNCO0NBQzFDLENBQUEifQ==