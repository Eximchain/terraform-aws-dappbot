"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
var paymentStatusAttrName = 'custom:payment_status';
var dappLimitAttrNames = [
    'custom:num_dapps',
    'custom:standard_limit',
    'custom:professional_limit',
    'custom:enterprise_limit'
];
function promiseAdminGetUser(cognitoUsername) {
    var maxRetries = 5;
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); }, maxRetries);
}
function promiseAdminUpdateUserAttributes(cognitoUsername, userAttributes) {
    var maxRetries = 5;
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername,
        UserAttributes: userAttributes
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminUpdateUserAttributes(params).promise(); }, maxRetries);
}
function markUserActive(cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, setPaymentStatus(cognitoUsername, common_1.PaymentStatus.ACTIVE)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function markUserFailed(cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, zeroLimitsAndSetPaymentStatus(cognitoUsername, common_1.PaymentStatus.FAILED)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function markUserCancelled(cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, zeroLimitsAndSetPaymentStatus(cognitoUsername, common_1.PaymentStatus.CANCELLED)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function markUserLapsed(cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, setPaymentStatus(cognitoUsername, common_1.PaymentStatus.LAPSED)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function setPaymentStatus(cognitoUsername, paymentStatus) {
    return __awaiter(this, void 0, void 0, function () {
        var userAttributes;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    userAttributes = [{
                            Name: paymentStatusAttrName,
                            Value: paymentStatus
                        }];
                    return [4 /*yield*/, promiseAdminUpdateUserAttributes(cognitoUsername, userAttributes)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function zeroLimitsAndSetPaymentStatus(cognitoUsername, paymentStatus) {
    return __awaiter(this, void 0, void 0, function () {
        var userAttributes, updatedPaymentStatusAttr;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    userAttributes = [];
                    dappLimitAttrNames.forEach(function (attrName) { return userAttributes.push({ Name: attrName, Value: '0' }); });
                    updatedPaymentStatusAttr = {
                        Name: paymentStatusAttrName,
                        Value: paymentStatus
                    };
                    userAttributes.push(updatedPaymentStatusAttr);
                    console.log("Marking user '" + cognitoUsername + "' " + paymentStatus + " in cognito and setting limits to 0");
                    return [4 /*yield*/, promiseAdminUpdateUserAttributes(cognitoUsername, userAttributes)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function confirmFailedUsers(potentialFailedUsers) {
    return __awaiter(this, void 0, void 0, function () {
        var splitUsers, failedUsers;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, splitPotentialFailedUsers(potentialFailedUsers)];
                case 1:
                    splitUsers = _a.sent();
                    failedUsers = splitUsers.Failed;
                    return [4 /*yield*/, markFailedUsers(failedUsers)];
                case 2:
                    _a.sent();
                    return [2 /*return*/, splitUsers];
            }
        });
    });
}
function splitPotentialFailedUsers(potentialFailedUsers) {
    return __awaiter(this, void 0, void 0, function () {
        var activeUsers, failedUsers, _a, _b, _i, i, potentialFailedUser, response, userAttrs, filteredAttrs, paymentStatus;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    activeUsers = [];
                    failedUsers = [];
                    _a = [];
                    for (_b in potentialFailedUsers)
                        _a.push(_b);
                    _i = 0;
                    _c.label = 1;
                case 1:
                    if (!(_i < _a.length)) return [3 /*break*/, 4];
                    i = _a[_i];
                    potentialFailedUser = potentialFailedUsers[i];
                    return [4 /*yield*/, promiseAdminGetUser(potentialFailedUser)];
                case 2:
                    response = _c.sent();
                    userAttrs = void 0;
                    if (response.UserAttributes) {
                        userAttrs = response.UserAttributes;
                    }
                    else {
                        userAttrs = [];
                    }
                    filteredAttrs = userAttrs.filter(function (item) { return item.Name === paymentStatusAttrName; });
                    if (filteredAttrs.length === 0) {
                        console.log("No payment_status attribute found for user " + potentialFailedUser);
                        return [3 /*break*/, 3];
                    }
                    else if (filteredAttrs.length > 1) {
                        console.log("Multiple payment_status attributes found for user " + potentialFailedUser, filteredAttrs);
                        return [3 /*break*/, 3];
                    }
                    paymentStatus = filteredAttrs[0].Value;
                    switch (paymentStatus) {
                        case common_1.PaymentStatus.LAPSED:
                        case common_1.PaymentStatus.FAILED:
                        case common_1.PaymentStatus.CANCELLED:
                            failedUsers.push(potentialFailedUser);
                            break;
                        case common_1.PaymentStatus.ACTIVE:
                            activeUsers.push(potentialFailedUser);
                            break;
                        default:
                            console.log("Unrecognized Payment Status: " + paymentStatus);
                            break;
                    }
                    _c.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/, { Failed: failedUsers, Active: activeUsers }];
            }
        });
    });
}
function markFailedUsers(failedUsers) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, _b, _i, i, user;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = [];
                    for (_b in failedUsers)
                        _a.push(_b);
                    _i = 0;
                    _c.label = 1;
                case 1:
                    if (!(_i < _a.length)) return [3 /*break*/, 4];
                    i = _a[_i];
                    user = failedUsers[i];
                    return [4 /*yield*/, markUserFailed(user)];
                case 2:
                    _c.sent();
                    _c.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/];
            }
        });
    });
}
exports.default = {
    confirmFailedUsers: confirmFailedUsers, markUserCancelled: markUserCancelled, markUserLapsed: markUserLapsed, markUserActive: markUserActive
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw4QkFBZ0Q7QUFDaEQsb0NBQWdFO0FBRWhFLElBQU0sT0FBTyxHQUFHLElBQUksU0FBRyxDQUFDLDhCQUE4QixDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFbkYsSUFBTSxxQkFBcUIsR0FBRyx1QkFBdUIsQ0FBQztBQUN0RCxJQUFNLGtCQUFrQixHQUFHO0lBQ3ZCLGtCQUFrQjtJQUNsQix1QkFBdUI7SUFDdkIsMkJBQTJCO0lBQzNCLHlCQUF5QjtDQUM1QixDQUFDO0FBRUYsU0FBUyxtQkFBbUIsQ0FBQyxlQUFzQjtJQUMvQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxVQUFVLEVBQUUsdUJBQWlCO1FBQzdCLFFBQVEsRUFBRSxlQUFlO0tBQzVCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQzFGLENBQUM7QUFFRCxTQUFTLGdDQUFnQyxDQUFDLGVBQXNCLEVBQUUsY0FBK0I7SUFDN0YsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsVUFBVSxFQUFFLHVCQUFpQjtRQUM3QixRQUFRLEVBQUUsZUFBZTtRQUN6QixjQUFjLEVBQUUsY0FBYztLQUNqQyxDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFuRCxDQUFtRCxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3ZHLENBQUM7QUFFRCxTQUFlLGNBQWMsQ0FBQyxlQUFzQjs7Ozt3QkFDekMscUJBQU0sZ0JBQWdCLENBQUMsZUFBZSxFQUFFLHNCQUFhLENBQUMsTUFBTSxDQUFDLEVBQUE7d0JBQXBFLHNCQUFPLFNBQTZELEVBQUM7Ozs7Q0FDeEU7QUFFRCxTQUFlLGNBQWMsQ0FBQyxlQUFzQjs7Ozt3QkFDekMscUJBQU0sNkJBQTZCLENBQUMsZUFBZSxFQUFFLHNCQUFhLENBQUMsTUFBTSxDQUFDLEVBQUE7d0JBQWpGLHNCQUFPLFNBQTBFLEVBQUM7Ozs7Q0FDckY7QUFFRCxTQUFlLGlCQUFpQixDQUFDLGVBQXNCOzs7O3dCQUM1QyxxQkFBTSw2QkFBNkIsQ0FBQyxlQUFlLEVBQUUsc0JBQWEsQ0FBQyxTQUFTLENBQUMsRUFBQTt3QkFBcEYsc0JBQU8sU0FBNkUsRUFBQzs7OztDQUN4RjtBQUVELFNBQWUsY0FBYyxDQUFDLGVBQXNCOzs7O3dCQUN6QyxxQkFBTSxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsc0JBQWEsQ0FBQyxNQUFNLENBQUMsRUFBQTt3QkFBcEUsc0JBQU8sU0FBNkQsRUFBQzs7OztDQUN4RTtBQUVELFNBQWUsZ0JBQWdCLENBQUMsZUFBc0IsRUFBRSxhQUEyQjs7Ozs7O29CQUMzRSxjQUFjLEdBQW1CLENBQUM7NEJBQ2xDLElBQUksRUFBRyxxQkFBcUI7NEJBQzVCLEtBQUssRUFBRyxhQUFhO3lCQUN4QixDQUFDLENBQUE7b0JBQ0sscUJBQU0sZ0NBQWdDLENBQUMsZUFBZSxFQUFFLGNBQWMsQ0FBQyxFQUFBO3dCQUE5RSxzQkFBTyxTQUF1RSxFQUFDOzs7O0NBQ2xGO0FBRUQsU0FBZSw2QkFBNkIsQ0FBQyxlQUFzQixFQUFFLGFBQTJCOzs7Ozs7b0JBQ3hGLGNBQWMsR0FBbUIsRUFBRSxDQUFDO29CQUN4QyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFDLENBQUMsRUFBakQsQ0FBaUQsQ0FBQyxDQUFDO29CQUV0Rix3QkFBd0IsR0FBaUI7d0JBQ3pDLElBQUksRUFBRSxxQkFBcUI7d0JBQzNCLEtBQUssRUFBRSxhQUFhO3FCQUN2QixDQUFBO29CQUNELGNBQWMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQztvQkFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBaUIsZUFBZSxVQUFLLGFBQWEsd0NBQXFDLENBQUMsQ0FBQztvQkFDOUYscUJBQU0sZ0NBQWdDLENBQUMsZUFBZSxFQUFFLGNBQWMsQ0FBQyxFQUFBO3dCQUE5RSxzQkFBTyxTQUF1RSxFQUFDOzs7O0NBQ2xGO0FBRUQsU0FBZSxrQkFBa0IsQ0FBQyxvQkFBNkI7Ozs7O3dCQUMxQyxxQkFBTSx5QkFBeUIsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFBOztvQkFBbEUsVUFBVSxHQUFHLFNBQXFEO29CQUNsRSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDcEMscUJBQU0sZUFBZSxDQUFDLFdBQVcsQ0FBQyxFQUFBOztvQkFBbEMsU0FBa0MsQ0FBQztvQkFDbkMsc0JBQU8sVUFBVSxFQUFDOzs7O0NBQ3JCO0FBRUQsU0FBZSx5QkFBeUIsQ0FBQyxvQkFBNkI7Ozs7OztvQkFDOUQsV0FBVyxHQUFZLEVBQUUsQ0FBQztvQkFDMUIsV0FBVyxHQUFZLEVBQUUsQ0FBQzs7K0JBQ2hCLG9CQUFvQjs7Ozs7OztvQkFDMUIsbUJBQW1CLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRW5DLHFCQUFNLG1CQUFtQixDQUFDLG1CQUFtQixDQUFDLEVBQUE7O29CQUF6RCxRQUFRLEdBQUcsU0FBOEM7b0JBQ3pELFNBQVMsU0FBZ0IsQ0FBQztvQkFDOUIsSUFBSSxRQUFRLENBQUMsY0FBYyxFQUFFO3dCQUN6QixTQUFTLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQztxQkFDdkM7eUJBQU07d0JBQ0gsU0FBUyxHQUFHLEVBQUUsQ0FBQztxQkFDbEI7b0JBQ0csYUFBYSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBQyxJQUFJLElBQUssT0FBQSxJQUFJLENBQUMsSUFBSSxLQUFLLHFCQUFxQixFQUFuQyxDQUFtQyxDQUFDLENBQUM7b0JBRXBGLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQzVCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQThDLG1CQUFxQixDQUFDLENBQUM7d0JBQ2pGLHdCQUFTO3FCQUNaO3lCQUFNLElBQUksYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdURBQXFELG1CQUFxQixFQUFFLGFBQWEsQ0FBQyxDQUFDO3dCQUN2Ryx3QkFBUztxQkFDWjtvQkFFRyxhQUFhLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztvQkFDM0MsUUFBUSxhQUFhLEVBQUU7d0JBQ25CLEtBQUssc0JBQWEsQ0FBQyxNQUFNLENBQUM7d0JBQzFCLEtBQUssc0JBQWEsQ0FBQyxNQUFNLENBQUM7d0JBQzFCLEtBQUssc0JBQWEsQ0FBQyxTQUFTOzRCQUN4QixXQUFXLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7NEJBQ3RDLE1BQU07d0JBQ1YsS0FBSyxzQkFBYSxDQUFDLE1BQU07NEJBQ3JCLFdBQVcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQzs0QkFDdEMsTUFBTTt3QkFDVjs0QkFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFnQyxhQUFlLENBQUMsQ0FBQzs0QkFDN0QsTUFBTTtxQkFDYjs7Ozs7d0JBRUwsc0JBQU8sRUFBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUMsRUFBQzs7OztDQUNyRDtBQUVELFNBQWUsZUFBZSxDQUFDLFdBQW9COzs7Ozs7OytCQUNqQyxXQUFXOzs7Ozs7O29CQUNqQixJQUFJLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxQixxQkFBTSxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUE7O29CQUExQixTQUEwQixDQUFBOzs7Ozs7Ozs7Q0FFakM7QUFPRCxrQkFBZTtJQUNYLGtCQUFrQixvQkFBQSxFQUFFLGlCQUFpQixtQkFBQSxFQUFFLGNBQWMsZ0JBQUEsRUFBRSxjQUFjLGdCQUFBO0NBQ3hFLENBQUEifQ==