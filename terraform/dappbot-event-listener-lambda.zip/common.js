"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultTags = [
    {
        Key: "Application",
        Value: "DappBot"
    },
    {
        Key: "ManagedBy",
        Value: "DappBot"
    }
];
var DappStates;
(function (DappStates) {
    DappStates["CREATING"] = "CREATING";
    DappStates["BUILDING_DAPP"] = "BUILDING_DAPP";
    DappStates["AVAILABLE"] = "AVAILABLE";
    DappStates["DELETING"] = "DELETING";
    DappStates["FAILED"] = "FAILED";
    DappStates["DEPOSED"] = "DEPOSED";
})(DappStates = exports.DappStates || (exports.DappStates = {}));
var PaymentStatus;
(function (PaymentStatus) {
    PaymentStatus["ACTIVE"] = "ACTIVE";
    PaymentStatus["LAPSED"] = "LAPSED";
    PaymentStatus["FAILED"] = "FAILED";
    PaymentStatus["CANCELLED"] = "CANCELLED";
})(PaymentStatus = exports.PaymentStatus || (exports.PaymentStatus = {}));
/*
Returns a Promise that rejects with reason after msDelay milliseconds
*/
function rejectDelay(reason) {
    var msDelay = 700;
    return new Promise(function (resolve, reject) {
        setTimeout(reject.bind(null, reason), msDelay);
    });
}
exports.rejectDelay = rejectDelay;
/*
Retries a promise returned by promiseGenerator up to maxRetries times as long as the error is retryable
Based on https://stackoverflow.com/questions/38213668/promise-retry-design-patterns
*/
function addAwsPromiseRetries(promiseGenerator, maxRetries) {
    // Ensure we call promiseGenerator on the first iteration
    var p = Promise.reject({ retryable: true });
    /*
    Appends maxRetries number of retry and delay promises to an AWS promise, returning once a retry promise resolves.

    1. As long as promiseGenerator() rejects with a retryable error, we retry and then delay before the next loop iteration
    2. If promiseGenerator() resolves, the rest of the loop will finish without triggering any further catch functions
    3. If promiseGenerator() rejects with a non-retryable error, the rest of the loop will finish without any further
       retries or delays since all catch blocks will simply return Promise.reject(err)
    */
    for (var i = 0; i < maxRetries; i++) {
        // @ts-ignore TS doesn't like that these could technically reject with
        // an error.  Rather than force (* as ReturnType) every place we await
        // this, just have the compiler assume this function succeeds.
        p = p.catch(function (err) { return err.retryable ? promiseGenerator() : Promise.reject(err); })
            .catch(function (err) { return err.retryable ? rejectDelay(err) : Promise.reject(err); });
    }
    return p;
}
exports.addAwsPromiseRetries = addAwsPromiseRetries;
exports.default = {
    defaultTags: exports.defaultTags, addAwsPromiseRetries: addAwsPromiseRetries
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImNvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUthLFFBQUEsV0FBVyxHQUFpQjtJQUNyQztRQUNJLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLEtBQUssRUFBRSxTQUFTO0tBQ25CO0lBQ0Q7UUFDSSxHQUFHLEVBQUUsV0FBVztRQUNoQixLQUFLLEVBQUUsU0FBUztLQUNuQjtDQUNKLENBQUM7QUFFRixJQUFZLFVBT1g7QUFQRCxXQUFZLFVBQVU7SUFDbEIsbUNBQXFCLENBQUE7SUFDckIsNkNBQStCLENBQUE7SUFDL0IscUNBQXVCLENBQUE7SUFDdkIsbUNBQXFCLENBQUE7SUFDckIsK0JBQWlCLENBQUE7SUFDakIsaUNBQW1CLENBQUE7QUFDdkIsQ0FBQyxFQVBXLFVBQVUsR0FBVixrQkFBVSxLQUFWLGtCQUFVLFFBT3JCO0FBRUQsSUFBWSxhQUtYO0FBTEQsV0FBWSxhQUFhO0lBQ3JCLGtDQUFpQixDQUFBO0lBQ2pCLGtDQUFpQixDQUFBO0lBQ2pCLGtDQUFpQixDQUFBO0lBQ2pCLHdDQUF1QixDQUFBO0FBQzNCLENBQUMsRUFMVyxhQUFhLEdBQWIscUJBQWEsS0FBYixxQkFBYSxRQUt4QjtBQUVEOztFQUVFO0FBQ0YsU0FBZ0IsV0FBVyxDQUFDLE1BQWE7SUFDckMsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDO0lBQ2xCLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBUyxPQUFPLEVBQUUsTUFBTTtRQUN2QyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDbkQsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBTEQsa0NBS0M7QUFFRDs7O0VBR0U7QUFDRixTQUFnQixvQkFBb0IsQ0FBYSxnQkFBd0MsRUFBRSxVQUFpQjtJQUN4Ryx5REFBeUQ7SUFDekQsSUFBSSxDQUFDLEdBQXVCLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBQyxTQUFTLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztJQUU5RDs7Ozs7OztNQU9FO0lBQ0YsS0FBSSxJQUFJLENBQUMsR0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUM1QixzRUFBc0U7UUFDdEUsc0VBQXNFO1FBQ3RFLDhEQUE4RDtRQUM5RCxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQXhELENBQXdELENBQUM7YUFDdEUsS0FBSyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUF0RCxDQUFzRCxDQUFDLENBQUM7S0FDOUU7SUFDRCxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUM7QUFwQkQsb0RBb0JDO0FBRUQsa0JBQWU7SUFDWCxXQUFXLHFCQUFBLEVBQUUsb0JBQW9CLHNCQUFBO0NBQ3BDLENBQUMifQ==