"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var shelljs_1 = __importDefault(require("shelljs"));
var fs_1 = __importDefault(require("fs"));
// @ts-ignore Alas, there are no published bindings for node-zip.
var node_zip_1 = __importDefault(require("node-zip"));
var common_1 = require("../common");
var env_1 = require("../env");
var loadingPageHtml_1 = require("./loadingPageHtml");
var s3 = new env_1.AWS.S3({ apiVersion: '2006-03-01' });
function promiseCreateS3Bucket(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        ACL: 'public-read'
    };
    return common_1.addAwsPromiseRetries(function () { return s3.createBucket(params).promise(); }, maxRetries);
}
function promiseDeleteS3Bucket(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.deleteBucket(params).promise(); }, maxRetries);
}
function promiseListS3Objects(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.listObjects(params).promise(); }, maxRetries);
}
function promiseEmptyS3Bucket(bucketName) {
    var maxDeleteRetries = 5;
    console.log("Emptying S3 bucket ", bucketName);
    // TODO: Does this have issues with the limit of list objects?
    return promiseListS3Objects(bucketName).then(function (result) {
        console.log("List S3 Objects Success", result);
        // Contents can be undefined, ensure there's always an array to map over
        result.Contents = result.Contents || [];
        var deletePromises = result.Contents.map(function (obj) {
            var params = {
                Bucket: bucketName,
                Key: obj.Key
            };
            return common_1.addAwsPromiseRetries(function () { return s3.deleteObject(params).promise(); }, maxDeleteRetries);
        });
        var retPromise = Promise.all(deletePromises);
        console.log("Returning promise", retPromise, "With deletePromises", deletePromises);
        return retPromise;
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseSetS3BucketPublicReadable(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Policy: JSON.stringify({
            "Version": "2012-10-17",
            "Statement": [{
                    "Sid": "PublicReadGetObject",
                    "Effect": "Allow",
                    "Principal": "*",
                    "Action": ["s3:GetObject"],
                    "Resource": ["arn:aws:s3:::" + bucketName + "/*"]
                }
            ]
        })
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketPolicy(params).promise(); }, maxRetries);
}
function promiseConfigureS3BucketStaticWebsite(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        WebsiteConfiguration: {
            ErrorDocument: {
                Key: 'index.html'
            },
            IndexDocument: {
                Suffix: 'index.html'
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketWebsite(params).promise(); }, maxRetries);
}
function promiseEnableS3BucketCORS(bucketName, dappDNS) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        CORSConfiguration: {
            CORSRules: [
                {
                    "AllowedHeaders": ["Authorization"],
                    "AllowedOrigins": ["https://" + dappDNS],
                    "AllowedMethods": ["GET"],
                    MaxAgeSeconds: 3000
                }
            ]
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketCors(params).promise(); }, maxRetries);
}
function promiseGetS3BucketWebsiteConfig(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.getBucketWebsite(params).promise(); }, maxRetries);
}
function promisePutDappseed(_a) {
    var dappName = _a.dappName, web3URL = _a.web3URL, guardianURL = _a.guardianURL, abi = _a.abi, addr = _a.addr, cdnURL = _a.cdnURL;
    shelljs_1.default.cd('/tmp');
    var dappZip = new node_zip_1.default();
    var abiObj = typeof abi === 'string' ? JSON.parse(abi) : abi;
    dappZip.file('Contract.json', JSON.stringify(abiObj, undefined, 2));
    dappZip.file('config.json', JSON.stringify({
        contract_name: dappName,
        contract_addr: addr,
        contract_path: './Contract.json',
        web3URL: web3URL, guardianURL: guardianURL, cdnURL: "https://" + cdnURL
    }, undefined, 2));
    fs_1.default.writeFileSync('./dappseed.zip', dappZip.generate({ base64: false, compression: 'DEFLATE' }), 'binary');
    var zipData = fs_1.default.readFileSync('./dappseed.zip');
    var maxRetries = 5;
    var params = {
        Bucket: env_1.dappseedBucket,
        ACL: 'private',
        Key: dappName + "/dappseed.zip",
        Body: zipData
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putObject(params).promise(); }, maxRetries);
}
function promisePutS3LoadingPage(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        ACL: 'public-read',
        ContentType: 'text/html',
        Key: 'index.html',
        Body: loadingPageHtml_1.loadingPageHtml,
        CacheControl: 'max-age=0'
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putObject(params).promise(); }, maxRetries);
}
function promiseMakeObjectNoCache(bucketName, objectKey) {
    return __awaiter(this, void 0, void 0, function () {
        var maxRetries, indexObject, putParams;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    maxRetries = 5;
                    return [4 /*yield*/, promiseGetS3Object(bucketName, objectKey)];
                case 1:
                    indexObject = _a.sent();
                    putParams = {
                        Bucket: bucketName,
                        ACL: 'public-read',
                        ContentType: indexObject.ContentType,
                        Key: objectKey,
                        Body: indexObject.Body,
                        CacheControl: 'max-age=0'
                    };
                    return [2 /*return*/, common_1.addAwsPromiseRetries(function () { return s3.putObject(putParams).promise(); }, maxRetries)];
            }
        });
    });
}
function promisePutBucketTags(bucketName, tags) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Tagging: {
            TagSet: tags
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketTagging(params).promise(); }, maxRetries);
}
function promiseCreateS3BucketWithTags(bucketName, dappName, dappOwner) {
    console.log("Creating S3 bucket ", bucketName);
    return promiseCreateS3Bucket(bucketName).then(function (result) {
        console.log("Create S3 Bucket Success", result);
        var extraTags = [common_1.dappNameTag(dappName), common_1.dappOwnerTag(dappOwner)];
        var bucketTags = common_1.defaultTags.concat(extraTags);
        console.log("Applying Default Bucket Tags", common_1.defaultTags);
        return promisePutBucketTags(bucketName, bucketTags);
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseGetS3Object(bucketName, objectKey) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Key: objectKey
    };
    return common_1.addAwsPromiseRetries(function () { return s3.getObject(params).promise(); }, maxRetries);
}
function getS3BucketEndpoint(bucketName) {
    return bucketName.concat(".s3.").concat(env_1.awsRegion).concat(".amazonaws.com");
}
exports.default = {
    getBucketWebsite: promiseGetS3BucketWebsiteConfig,
    configureBucketWebsite: promiseConfigureS3BucketStaticWebsite,
    setBucketPublic: promiseSetS3BucketPublicReadable,
    putLoadingPage: promisePutS3LoadingPage,
    putDappseed: promisePutDappseed,
    createBucketWithTags: promiseCreateS3BucketWithTags,
    deleteBucket: promiseDeleteS3Bucket,
    emptyBucket: promiseEmptyS3Bucket,
    listObjects: promiseListS3Objects,
    getObject: promiseGetS3Object,
    makeObjectNoCache: promiseMakeObjectNoCache,
    enableBucketCors: promiseEnableS3BucketCORS,
    bucketEndpoint: getS3BucketEndpoint
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiczMuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvczMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9EQUE0QjtBQUM1QiwwQ0FBb0I7QUFDcEIsaUVBQWlFO0FBQ2pFLHNEQUEyQjtBQUUzQixvQ0FHbUI7QUFDbkIsOEJBQXdEO0FBQ3hELHFEQUFvRDtBQUVwRCxJQUFNLEVBQUUsR0FBRyxJQUFJLFNBQUcsQ0FBQyxFQUFFLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUVsRCxTQUFTLHFCQUFxQixDQUFDLFVBQWlCO0lBQzVDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO1FBQ2xCLEdBQUcsRUFBRSxhQUFhO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFqQyxDQUFpQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3JGLENBQUM7QUFFRCxTQUFTLHFCQUFxQixDQUFDLFVBQWlCO0lBQzVDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFqQyxDQUFpQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3JGLENBQUM7QUFFRCxTQUFTLG9CQUFvQixDQUFDLFVBQWlCO0lBQzNDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoQyxDQUFnQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3BGLENBQUM7QUFFRCxTQUFTLG9CQUFvQixDQUFDLFVBQWlCO0lBQzNDLElBQUksZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsVUFBVSxDQUFDLENBQUE7SUFDOUMsOERBQThEO0lBQzlELE9BQU8sb0JBQW9CLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVMsTUFBTTtRQUN4RCxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQy9DLHdFQUF3RTtRQUN4RSxNQUFNLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDO1FBQ3hDLElBQUksY0FBYyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQUMsR0FBRztZQUN6QyxJQUFJLE1BQU0sR0FBRztnQkFDVCxNQUFNLEVBQUUsVUFBVTtnQkFDbEIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFnQjthQUM1QixDQUFDO1lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBakMsQ0FBaUMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFBO1FBQzFGLENBQUMsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUM3QyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFLFVBQVUsRUFBRSxxQkFBcUIsRUFBRSxjQUFjLENBQUMsQ0FBQTtRQUNuRixPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDLENBQUM7U0FDRCxLQUFLLENBQUMsVUFBUyxHQUFHO1FBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDMUIsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUVELFNBQVMsZ0NBQWdDLENBQUMsVUFBaUI7SUFDdkQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsTUFBTSxFQUFFLFVBQVU7UUFDbEIsTUFBTSxFQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDcEIsU0FBUyxFQUFDLFlBQVk7WUFDdEIsV0FBVyxFQUFDLENBQUM7b0JBQ2IsS0FBSyxFQUFDLHFCQUFxQjtvQkFDckIsUUFBUSxFQUFDLE9BQU87b0JBQ3BCLFdBQVcsRUFBRSxHQUFHO29CQUNkLFFBQVEsRUFBQyxDQUFDLGNBQWMsQ0FBQztvQkFDekIsVUFBVSxFQUFDLENBQUMsa0JBQWdCLFVBQVUsT0FBSSxDQUFDO2lCQUM1QzthQUNGO1NBQ0osQ0FBQztLQUNMLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFHRCxTQUFTLHFDQUFxQyxDQUFDLFVBQWlCO0lBQzVELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO1FBQ2xCLG9CQUFvQixFQUFFO1lBQ2xCLGFBQWEsRUFBRTtnQkFDWCxHQUFHLEVBQUUsWUFBWTthQUNwQjtZQUNELGFBQWEsRUFBRTtnQkFDWCxNQUFNLEVBQUUsWUFBWTthQUN2QjtTQUNKO0tBQ0osQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBckMsQ0FBcUMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN6RixDQUFDO0FBRUQsU0FBUyx5QkFBeUIsQ0FBQyxVQUFpQixFQUFFLE9BQWM7SUFDaEUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsTUFBTSxFQUFHLFVBQVU7UUFDbkIsaUJBQWlCLEVBQUc7WUFDaEIsU0FBUyxFQUFHO2dCQUNSO29CQUNJLGdCQUFnQixFQUFFLENBQUMsZUFBZSxDQUFDO29CQUNuQyxnQkFBZ0IsRUFBRSxDQUFDLGFBQVcsT0FBUyxDQUFDO29CQUN4QyxnQkFBZ0IsRUFBRSxDQUFDLEtBQUssQ0FBQztvQkFDekIsYUFBYSxFQUFLLElBQUk7aUJBQ3pCO2FBQ0o7U0FDSjtLQUNKLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFsQyxDQUFrQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3RGLENBQUM7QUFFRCxTQUFTLCtCQUErQixDQUFDLFVBQWlCO0lBQ3RELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO0tBQ3JCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXJDLENBQXFDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDekYsQ0FBQztBQUVELFNBQVMsa0JBQWtCLENBQUMsRUFBa0U7UUFBaEUsc0JBQVEsRUFBRSxvQkFBTyxFQUFFLDRCQUFXLEVBQUUsWUFBRyxFQUFFLGNBQUksRUFBRSxrQkFBTTtJQUMzRSxpQkFBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqQixJQUFNLE9BQU8sR0FBRyxJQUFJLGtCQUFHLEVBQUUsQ0FBQztJQUMxQixJQUFNLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztJQUMvRCxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwRSxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3ZDLGFBQWEsRUFBRyxRQUFRO1FBQ3hCLGFBQWEsRUFBRyxJQUFJO1FBQ3BCLGFBQWEsRUFBRyxpQkFBaUI7UUFDakMsT0FBTyxTQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUUsTUFBTSxFQUFDLGFBQVcsTUFBUTtLQUNuRCxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xCLFlBQUUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFDLE1BQU0sRUFBQyxLQUFLLEVBQUMsV0FBVyxFQUFDLFNBQVMsRUFBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUE7SUFDcEcsSUFBTSxPQUFPLEdBQUcsWUFBRSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBRWxELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRyxvQkFBYztRQUN2QixHQUFHLEVBQUUsU0FBUztRQUNkLEdBQUcsRUFBSyxRQUFRLGtCQUFlO1FBQy9CLElBQUksRUFBRSxPQUFPO0tBQ2hCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE5QixDQUE4QixFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFFRCxTQUFTLHVCQUF1QixDQUFDLFVBQWlCO0lBQzlDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO1FBQ2xCLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLFdBQVcsRUFBRSxXQUFXO1FBQ3hCLEdBQUcsRUFBRSxZQUFZO1FBQ2pCLElBQUksRUFBRSxpQ0FBZTtRQUNyQixZQUFZLEVBQUUsV0FBVztLQUM1QixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBOUIsQ0FBOEIsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNsRixDQUFDO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxVQUFpQixFQUFFLFNBQWdCOzs7Ozs7b0JBQ25FLFVBQVUsR0FBRyxDQUFDLENBQUM7b0JBQ0MscUJBQU0sa0JBQWtCLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxFQUFBOztvQkFBN0QsV0FBVyxHQUFHLFNBQStDO29CQUM3RCxTQUFTLEdBQUc7d0JBQ2QsTUFBTSxFQUFHLFVBQVU7d0JBQ25CLEdBQUcsRUFBRyxhQUFhO3dCQUNuQixXQUFXLEVBQUUsV0FBVyxDQUFDLFdBQVc7d0JBQ3BDLEdBQUcsRUFBRyxTQUFTO3dCQUNmLElBQUksRUFBRyxXQUFXLENBQUMsSUFBSTt3QkFDdkIsWUFBWSxFQUFFLFdBQVc7cUJBQzVCLENBQUE7b0JBQ0Qsc0JBQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLEVBQUUsVUFBVSxDQUFDLEVBQUM7Ozs7Q0FDcEY7QUFFRCxTQUFTLG9CQUFvQixDQUFDLFVBQWlCLEVBQUUsSUFBa0I7SUFDL0QsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsTUFBTSxFQUFFLFVBQVU7UUFDbEIsT0FBTyxFQUFFO1lBQ0wsTUFBTSxFQUFFLElBQUk7U0FDZjtLQUNKLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXJDLENBQXFDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDekYsQ0FBQztBQUVELFNBQVMsNkJBQTZCLENBQUMsVUFBaUIsRUFBRSxRQUFlLEVBQUUsU0FBZ0I7SUFDdkYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUMsQ0FBQTtJQUM5QyxPQUFPLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFTLE1BQU07UUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNoRCxJQUFJLFNBQVMsR0FBRyxDQUFDLG9CQUFXLENBQUMsUUFBUSxDQUFDLEVBQUUscUJBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQ2pFLElBQUksVUFBVSxHQUFHLG9CQUFXLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEVBQUUsb0JBQVcsQ0FBQyxDQUFBO1FBQ3hELE9BQU8sb0JBQW9CLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ3hELENBQUMsQ0FBQztTQUNELEtBQUssQ0FBQyxVQUFTLEdBQUc7UUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMxQixPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxVQUFpQixFQUFFLFNBQWdCO0lBQzNELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFNLE1BQU0sR0FBRztRQUNYLE1BQU0sRUFBRyxVQUFVO1FBQ25CLEdBQUcsRUFBRyxTQUFTO0tBQ2xCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE5QixDQUE4QixFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLFVBQWlCO0lBQzFDLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBUyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDaEYsQ0FBQztBQUVELGtCQUFlO0lBQ1gsZ0JBQWdCLEVBQUcsK0JBQStCO0lBQ2xELHNCQUFzQixFQUFHLHFDQUFxQztJQUM5RCxlQUFlLEVBQUcsZ0NBQWdDO0lBQ2xELGNBQWMsRUFBRyx1QkFBdUI7SUFDeEMsV0FBVyxFQUFHLGtCQUFrQjtJQUNoQyxvQkFBb0IsRUFBRyw2QkFBNkI7SUFDcEQsWUFBWSxFQUFHLHFCQUFxQjtJQUNwQyxXQUFXLEVBQUcsb0JBQW9CO0lBQ2xDLFdBQVcsRUFBRyxvQkFBb0I7SUFDbEMsU0FBUyxFQUFHLGtCQUFrQjtJQUM5QixpQkFBaUIsRUFBRyx3QkFBd0I7SUFDNUMsZ0JBQWdCLEVBQUcseUJBQXlCO0lBQzVDLGNBQWMsRUFBRyxtQkFBbUI7Q0FDdkMsQ0FBQSJ9