"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var assert_1 = __importDefault(require("assert"));
var uuid_1 = __importDefault(require("uuid"));
var common_1 = require("../common");
var env_1 = require("../env");
var cloudfront = new env_1.AWS.CloudFront({ apiVersion: '2018-11-05' });
function promiseCreateCloudfrontDistribution(appName, dappOwner, s3Origin, dappDNS) {
    // TODO: Origin Access Identity
    // TODO: Verify that we want these args
    var maxRetries = 5;
    var extraTags = [common_1.dappNameTag(appName), common_1.dappOwnerTag(dappOwner)];
    var params = {
        DistributionConfigWithTags: {
            DistributionConfig: {
                CallerReference: uuid_1.default(),
                DefaultRootObject: 'index.html',
                Aliases: {
                    Quantity: 1,
                    Items: [dappDNS]
                },
                ViewerCertificate: {
                    ACMCertificateArn: env_1.wildcardCertArn,
                    SSLSupportMethod: 'sni-only',
                },
                Origins: {
                    Quantity: 1,
                    Items: [{
                            Id: 's3-origin',
                            DomainName: s3Origin,
                            S3OriginConfig: {
                                OriginAccessIdentity: ''
                            }
                        }],
                },
                DefaultCacheBehavior: {
                    TargetOriginId: 's3-origin',
                    ForwardedValues: {
                        QueryString: false,
                        Cookies: {
                            Forward: 'none'
                        },
                        Headers: {
                            Quantity: 0
                        }
                    },
                    TrustedSigners: {
                        Quantity: 0,
                        Enabled: false
                    },
                    ViewerProtocolPolicy: 'redirect-to-https',
                    MinTTL: 0,
                    AllowedMethods: {
                        Quantity: 7,
                        Items: ['GET', 'HEAD', 'OPTIONS', 'PUT', 'PATCH', 'POST', 'DELETE']
                    }
                },
                Enabled: true,
                Comment: "Cloudfront distribution for ".concat(appName)
            },
            Tags: {
                Items: common_1.defaultTags.concat(extraTags)
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.createDistributionWithTags(params).promise(); }, maxRetries);
}
function promiseGetCloudfrontDistributionConfig(distroId) {
    var maxRetries = 5;
    var params = {
        Id: distroId
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.getDistributionConfig(params).promise(); }, maxRetries);
}
function promiseDisableCloudfrontDistribution(distroId) {
    var maxUpdateRetries = 5;
    return promiseGetCloudfrontDistributionConfig(distroId).then(function (result) {
        console.log("Get Cloudfront Distro Config Success", result);
        var config = result.DistributionConfig;
        config.Enabled = false;
        var params = {
            Id: distroId,
            IfMatch: result.ETag,
            DistributionConfig: config
        };
        return common_1.addAwsPromiseRetries(function () { return cloudfront.updateDistribution(params).promise(); }, maxUpdateRetries);
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseUpdateCloudfrontDistributionOriginAndEnable(distroId, s3Origin) {
    var maxUpdateRetries = 5;
    return promiseGetCloudfrontDistributionConfig(distroId).then(function (result) {
        console.log("Get Cloudfront Distro Config Success", result);
        var config = result.DistributionConfig;
        console.log("Origin", config.Origins.Items[0]);
        var originItem = {
            Id: 's3-origin',
            DomainName: s3Origin,
            OriginPath: '',
            S3OriginConfig: {
                OriginAccessIdentity: ''
            },
            CustomHeaders: {
                Quantity: 0
            }
        };
        config.Origins.Items[0] = originItem;
        config.Enabled = true;
        var params = {
            Id: distroId,
            IfMatch: result.ETag,
            DistributionConfig: config
        };
        return common_1.addAwsPromiseRetries(function () { return cloudfront.updateDistribution(params).promise(); }, maxUpdateRetries);
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseDeleteCloudfrontDistribution(distroId) {
    var maxRetries = 5;
    var params = {
        Id: distroId
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.deleteDistribution(params).promise(); }, maxRetries);
}
function promiseListCloudfrontDistributions(marker) {
    var maxRetries = 5;
    var params = marker ? { Marker: marker } : {};
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listDistributions(params).promise(); }, maxRetries);
}
function promiseListTagsForCloudfrontDistribution(distroArn) {
    var maxRetries = 5;
    var params = {
        Resource: distroArn
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.listTagsForResource(params).promise(); }, maxRetries);
}
function promiseCreateCloudfrontInvalidation(distroId, pathPrefix) {
    if (pathPrefix === void 0) { pathPrefix = '/'; }
    var maxRetries = 5;
    var params = {
        DistributionId: distroId,
        InvalidationBatch: {
            CallerReference: uuid_1.default(),
            Paths: {
                Quantity: 1,
                Items: [
                    pathPrefix + "*"
                ]
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cloudfront.createInvalidation(params).promise(); }, maxRetries);
}
function getConflictingDistribution(dappDNS) {
    return __awaiter(this, void 0, void 0, function () {
        var conflictingAlias, marker, existingDistroResult, existingDistroPage, existingDistrosMatchingAlias;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    conflictingAlias = dappDNS;
                    marker = '';
                    _a.label = 1;
                case 1:
                    if (!true) return [3 /*break*/, 3];
                    return [4 /*yield*/, promiseListCloudfrontDistributions(marker)];
                case 2:
                    existingDistroResult = _a.sent();
                    if (!existingDistroResult.DistributionList) {
                        return [2 /*return*/, null];
                    }
                    existingDistroPage = existingDistroResult.DistributionList;
                    if (!existingDistroPage.Items) {
                        return [2 /*return*/, null];
                    }
                    existingDistrosMatchingAlias = existingDistroPage.Items.filter(function (item) { return item.Aliases.Quantity === 1; })
                        .filter(function (item) { return item.Aliases.Items[0] === conflictingAlias; });
                    assert_1.default(existingDistrosMatchingAlias.length <= 1, "Found " + existingDistrosMatchingAlias.length + " distribution with matching CNAME instead of at most 1. This must be a bug!");
                    if (existingDistrosMatchingAlias.length == 1) {
                        return [2 /*return*/, existingDistrosMatchingAlias[0]];
                    }
                    if (existingDistroPage.IsTruncated) {
                        marker = existingDistroPage.Marker;
                    }
                    else {
                        return [2 /*return*/, null];
                    }
                    return [3 /*break*/, 1];
                case 3: return [2 /*return*/];
            }
        });
    });
}
function getDistributionOwner(distroArn) {
    return __awaiter(this, void 0, void 0, function () {
        var listTagsResponse, distroTags, dappOwnerTagList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseListTagsForCloudfrontDistribution(distroArn)];
                case 1:
                    listTagsResponse = _a.sent();
                    distroTags = listTagsResponse.Tags.Items || [];
                    dappOwnerTagList = distroTags.filter(function (tag) { return tag.Key === 'DappOwner'; });
                    assert_1.default(dappOwnerTagList.length == 1, "Found " + dappOwnerTagList.length + " tags with Key 'DappOwner' instead of exactly 1. This must be a bug!");
                    return [2 /*return*/, dappOwnerTagList[0].Value];
            }
        });
    });
}
exports.default = {
    createDistro: promiseCreateCloudfrontDistribution,
    getDistroConfig: promiseGetCloudfrontDistributionConfig,
    disableDistro: promiseDisableCloudfrontDistribution,
    deleteDistro: promiseDeleteCloudfrontDistribution,
    listTags: promiseListTagsForCloudfrontDistribution,
    updateOriginAndEnable: promiseUpdateCloudfrontDistributionOriginAndEnable,
    getConflictingDistro: getConflictingDistribution,
    getDistroOwner: getDistributionOwner,
    invalidateDistroPrefix: promiseCreateCloudfrontInvalidation
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xvdWRmcm9udC5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jbG91ZGZyb250LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxrREFBNEI7QUFDNUIsOENBQTBCO0FBQzFCLG9DQUF5RjtBQUN6Riw4QkFBOEM7QUFFOUMsSUFBTSxVQUFVLEdBQUcsSUFBSSxTQUFHLENBQUMsVUFBVSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFbEUsU0FBUyxtQ0FBbUMsQ0FBQyxPQUFjLEVBQUUsU0FBZ0IsRUFBRSxRQUFlLEVBQUUsT0FBYztJQUMxRywrQkFBK0I7SUFDL0IsdUNBQXVDO0lBRXZDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLFNBQVMsR0FBRyxDQUFDLG9CQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUscUJBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBRWhFLElBQUksTUFBTSxHQUFHO1FBQ1QsMEJBQTBCLEVBQUU7WUFDeEIsa0JBQWtCLEVBQUU7Z0JBQ2hCLGVBQWUsRUFBRSxjQUFNLEVBQUU7Z0JBQ3pCLGlCQUFpQixFQUFFLFlBQVk7Z0JBQy9CLE9BQU8sRUFBRTtvQkFDTCxRQUFRLEVBQUUsQ0FBQztvQkFDWCxLQUFLLEVBQUUsQ0FBQyxPQUFPLENBQUM7aUJBQ25CO2dCQUNELGlCQUFpQixFQUFHO29CQUNoQixpQkFBaUIsRUFBRyxxQkFBZTtvQkFDbkMsZ0JBQWdCLEVBQUcsVUFBVTtpQkFDaEM7Z0JBQ0QsT0FBTyxFQUFFO29CQUNMLFFBQVEsRUFBRSxDQUFDO29CQUNYLEtBQUssRUFBRSxDQUFDOzRCQUNKLEVBQUUsRUFBRSxXQUFXOzRCQUNmLFVBQVUsRUFBRSxRQUFROzRCQUNwQixjQUFjLEVBQUU7Z0NBQ1osb0JBQW9CLEVBQUUsRUFBRTs2QkFDM0I7eUJBQ0osQ0FBQztpQkFDTDtnQkFDRCxvQkFBb0IsRUFBRTtvQkFDbEIsY0FBYyxFQUFFLFdBQVc7b0JBQzNCLGVBQWUsRUFBRTt3QkFDYixXQUFXLEVBQUUsS0FBSzt3QkFDbEIsT0FBTyxFQUFFOzRCQUNMLE9BQU8sRUFBRSxNQUFNO3lCQUNsQjt3QkFDRCxPQUFPLEVBQUU7NEJBQ0wsUUFBUSxFQUFFLENBQUM7eUJBQ2Q7cUJBQ0o7b0JBQ0QsY0FBYyxFQUFFO3dCQUNaLFFBQVEsRUFBRSxDQUFDO3dCQUNYLE9BQU8sRUFBRSxLQUFLO3FCQUNqQjtvQkFDRCxvQkFBb0IsRUFBRSxtQkFBbUI7b0JBQ3pDLE1BQU0sRUFBRSxDQUFDO29CQUNULGNBQWMsRUFBRTt3QkFDWixRQUFRLEVBQUUsQ0FBQzt3QkFDWCxLQUFLLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUM7cUJBQ3RFO2lCQUNKO2dCQUNELE9BQU8sRUFBRSxJQUFJO2dCQUNiLE9BQU8sRUFBRSw4QkFBOEIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2FBQzFEO1lBQ0QsSUFBSSxFQUFFO2dCQUNGLEtBQUssRUFBRSxvQkFBVyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7YUFDdkM7U0FDSjtLQUNKLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXZELENBQXVELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDM0csQ0FBQztBQUVELFNBQVMsc0NBQXNDLENBQUMsUUFBZTtJQUMzRCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxFQUFFLEVBQUUsUUFBUTtLQUNmLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxELENBQWtELEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEcsQ0FBQztBQUVELFNBQVMsb0NBQW9DLENBQUMsUUFBZTtJQUN6RCxJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQztJQUN6QixPQUFPLHNDQUFzQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFTLE1BQU07UUFDeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsa0JBQXdDLENBQUM7UUFDN0QsTUFBTSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFFdkIsSUFBSSxNQUFNLEdBQUc7WUFDVCxFQUFFLEVBQUUsUUFBUTtZQUNaLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNwQixrQkFBa0IsRUFBRSxNQUFNO1NBQzdCLENBQUM7UUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQS9DLENBQStDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUN6RyxDQUFDLENBQUM7U0FDRCxLQUFLLENBQUMsVUFBUyxHQUFHO1FBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDMUIsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUVELFNBQVMsa0RBQWtELENBQUMsUUFBZSxFQUFFLFFBQWU7SUFDeEYsSUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7SUFDekIsT0FBTyxzQ0FBc0MsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBUyxNQUFNO1FBQ3hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDNUQsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLGtCQUF3QyxDQUFDO1FBQzdELE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0MsSUFBSSxVQUFVLEdBQUc7WUFDYixFQUFFLEVBQUUsV0FBVztZQUNmLFVBQVUsRUFBRSxRQUFRO1lBQ3BCLFVBQVUsRUFBRSxFQUFFO1lBQ2QsY0FBYyxFQUFFO2dCQUNaLG9CQUFvQixFQUFFLEVBQUU7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ1gsUUFBUSxFQUFFLENBQUM7YUFDZDtTQUNKLENBQUM7UUFDRixNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7UUFDckMsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFdEIsSUFBSSxNQUFNLEdBQUc7WUFDVCxFQUFFLEVBQUUsUUFBUTtZQUNaLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNwQixrQkFBa0IsRUFBRSxNQUFNO1NBQzdCLENBQUM7UUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQS9DLENBQStDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUN6RyxDQUFDLENBQUM7U0FDRCxLQUFLLENBQUMsVUFBUyxHQUFHO1FBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDMUIsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUVELFNBQVMsbUNBQW1DLENBQUMsUUFBZTtJQUN4RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxFQUFFLEVBQUUsUUFBUTtLQUNmLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQS9DLENBQStDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDbkcsQ0FBQztBQUVELFNBQVMsa0NBQWtDLENBQUMsTUFBYTtJQUNyRCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQzlDLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBOUMsQ0FBOEMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNsRyxDQUFDO0FBRUQsU0FBUyx3Q0FBd0MsQ0FBQyxTQUFnQjtJQUM5RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUUsU0FBUztLQUN0QixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsVUFBVSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoRCxDQUFnRCxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3BHLENBQUM7QUFFRCxTQUFTLG1DQUFtQyxDQUFDLFFBQWUsRUFBRSxVQUFxQjtJQUFyQiwyQkFBQSxFQUFBLGdCQUFxQjtJQUMvRSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxjQUFjLEVBQUUsUUFBUTtRQUN4QixpQkFBaUIsRUFBRTtZQUNmLGVBQWUsRUFBRSxjQUFNLEVBQUU7WUFDekIsS0FBSyxFQUFFO2dCQUNILFFBQVEsRUFBRSxDQUFDO2dCQUNYLEtBQUssRUFBRTtvQkFDQSxVQUFVLE1BQUc7aUJBQ25CO2FBQ0o7U0FDSjtLQUNKLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxVQUFVLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQS9DLENBQStDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDbkcsQ0FBQztBQUVELFNBQWUsMEJBQTBCLENBQUMsT0FBYzs7Ozs7O29CQUNoRCxnQkFBZ0IsR0FBRyxPQUFPLENBQUM7b0JBQzNCLE1BQU0sR0FBRyxFQUFFLENBQUM7Ozt5QkFDVCxJQUFJO29CQUM0QyxxQkFBTSxrQ0FBa0MsQ0FBQyxNQUFNLENBQUMsRUFBQTs7b0JBQS9GLG9CQUFvQixHQUEyQixTQUFnRDtvQkFDbkcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGdCQUFnQixFQUFDO3dCQUN2QyxzQkFBTyxJQUFJLEVBQUM7cUJBQ2Y7b0JBQ0csa0JBQWtCLEdBQUcsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUM7b0JBQy9ELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUM7d0JBQzFCLHNCQUFPLElBQUksRUFBQztxQkFDZjtvQkFDRyw0QkFBNEIsR0FBRyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUFDO3lCQUMzQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQW1CLENBQUMsQ0FBQyxDQUFDLEtBQUssZ0JBQWdCLEVBQXpELENBQXlELENBQUMsQ0FBQztvQkFDdEksZ0JBQU0sQ0FBQyw0QkFBNEIsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFLFdBQVMsNEJBQTRCLENBQUMsTUFBTSxnRkFBNkUsQ0FBQyxDQUFDO29CQUU1SyxJQUFJLDRCQUE0QixDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQzFDLHNCQUFPLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxFQUFDO3FCQUMxQztvQkFFRCxJQUFJLGtCQUFrQixDQUFDLFdBQVcsRUFBRTt3QkFDaEMsTUFBTSxHQUFHLGtCQUFrQixDQUFDLE1BQU0sQ0FBQztxQkFDdEM7eUJBQU07d0JBQ0gsc0JBQU8sSUFBSSxFQUFDO3FCQUNmOzs7Ozs7Q0FFUjtBQUVELFNBQWUsb0JBQW9CLENBQUMsU0FBZ0I7Ozs7O3dCQUN6QixxQkFBTSx3Q0FBd0MsQ0FBQyxTQUFTLENBQUMsRUFBQTs7b0JBQTVFLGdCQUFnQixHQUFHLFNBQXlEO29CQUM1RSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7b0JBQy9DLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBdkIsQ0FBdUIsQ0FBQyxDQUFDO29CQUN6RSxnQkFBTSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsV0FBUyxnQkFBZ0IsQ0FBQyxNQUFNLHlFQUFzRSxDQUFDLENBQUM7b0JBQzdJLHNCQUFPLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQzs7OztDQUNwQztBQUVELGtCQUFlO0lBQ1gsWUFBWSxFQUFHLG1DQUFtQztJQUNsRCxlQUFlLEVBQUcsc0NBQXNDO0lBQ3hELGFBQWEsRUFBRyxvQ0FBb0M7SUFDcEQsWUFBWSxFQUFHLG1DQUFtQztJQUNsRCxRQUFRLEVBQUcsd0NBQXdDO0lBQ25ELHFCQUFxQixFQUFHLGtEQUFrRDtJQUMxRSxvQkFBb0IsRUFBRywwQkFBMEI7SUFDakQsY0FBYyxFQUFHLG9CQUFvQjtJQUNyQyxzQkFBc0IsRUFBRyxtQ0FBbUM7Q0FDL0QsQ0FBQyJ9