"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var ddb = new env_1.AWS.DynamoDB({ apiVersion: '2012-08-10' });
function serializeDdbKey(dappName) {
    var keyItem = {
        'DappName': { S: dappName }
    };
    return keyItem;
}
function promiseSetDappAvailable(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbResponse, dbItem;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetDappItem(dappName)];
                case 1:
                    dbResponse = _a.sent();
                    dbItem = dbResponse.Item;
                    dbItem.State.S = common_1.DappStates.AVAILABLE;
                    return [2 /*return*/, promisePutRawDappItem(dbItem)];
            }
        });
    });
}
function promiseSetDappFailed(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbResponse, dbItem;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetDappItem(dappName)];
                case 1:
                    dbResponse = _a.sent();
                    dbItem = dbResponse.Item;
                    dbItem.State.S = common_1.DappStates.FAILED;
                    return [2 /*return*/, promisePutRawDappItem(dbItem)];
            }
        });
    });
}
function promiseSetDappDeposed(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dbResponse, dbItem;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetDappItem(dappName)];
                case 1:
                    dbResponse = _a.sent();
                    dbItem = dbResponse.Item;
                    dbItem.State.S = common_1.DappStates.DEPOSED;
                    return [2 /*return*/, promisePutRawDappItem(dbItem)];
            }
        });
    });
}
function promiseSetItemBuilding(dbItem, cloudfrontDistroId, cloudfrontDns) {
    if (cloudfrontDistroId) {
        dbItem.CloudfrontDistributionId = { S: cloudfrontDistroId };
    }
    if (cloudfrontDns) {
        dbItem.CloudfrontDnsName = { S: cloudfrontDns };
    }
    dbItem.State.S = common_1.DappStates.BUILDING_DAPP;
    return promisePutRawDappItem(dbItem);
}
// TODO: Combine with SetDapp method
function promiseSetItemAvailable(dbItem) {
    dbItem.State.S = common_1.DappStates.AVAILABLE;
    return promisePutRawDappItem(dbItem);
}
function promisePutRawDappItem(item) {
    var maxRetries = 5;
    var putItemParams = {
        TableName: env_1.tableName,
        Item: item
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promiseGetDappItem(dappName) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.getItem(getItemParams).promise(); }, maxRetries);
}
function promiseDeleteDappItem(dappName) {
    var maxRetries = 5;
    var deleteItemParams = {
        TableName: env_1.tableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.deleteItem(deleteItemParams).promise(); }, maxRetries);
}
function promiseGetItemsByOwner(ownerEmail) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        IndexName: 'OwnerEmailIndex',
        ExpressionAttributeNames: {
            "#OE": "OwnerEmail"
        },
        ExpressionAttributeValues: {
            ":e": {
                S: ownerEmail
            }
        },
        KeyConditionExpression: "#OE = :e",
        Select: 'ALL_PROJECTED_ATTRIBUTES'
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.query(getItemParams).promise(); }, maxRetries);
}
exports.default = {
    getItem: promiseGetDappItem,
    deleteItem: promiseDeleteDappItem,
    getByOwner: promiseGetItemsByOwner,
    setDappAvailable: promiseSetDappAvailable,
    setDappFailed: promiseSetDappFailed,
    setDappDeposed: promiseSetDappDeposed,
    setItemBuilding: promiseSetItemBuilding,
    setItemAvailable: promiseSetItemAvailable
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1vREIuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvZHluYW1vREIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLG9DQUE2RDtBQUM3RCw4QkFBd0M7QUFDeEMsSUFBTSxHQUFHLEdBQUcsSUFBSSxTQUFHLENBQUMsUUFBUSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFekQsU0FBUyxlQUFlLENBQUMsUUFBZTtJQUNwQyxJQUFJLE9BQU8sR0FBRztRQUNWLFVBQVUsRUFBRSxFQUFDLENBQUMsRUFBRSxRQUFRLEVBQUM7S0FDNUIsQ0FBQztJQUNGLE9BQU8sT0FBTyxDQUFDO0FBQ25CLENBQUM7QUFFRCxTQUFlLHVCQUF1QixDQUFDLFFBQWU7Ozs7O3dCQUNqQyxxQkFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFVBQVUsR0FBRyxTQUFrQztvQkFDL0MsTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFvQixDQUFDO29CQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxtQkFBVSxDQUFDLFNBQVMsQ0FBQztvQkFFdEMsc0JBQU8scUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUM7Ozs7Q0FDeEM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLFFBQWU7Ozs7O3dCQUM5QixxQkFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFVBQVUsR0FBRyxTQUFrQztvQkFDL0MsTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFvQixDQUFDO29CQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxtQkFBVSxDQUFDLE1BQU0sQ0FBQztvQkFFbkMsc0JBQU8scUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUM7Ozs7Q0FDeEM7QUFFRCxTQUFlLHFCQUFxQixDQUFDLFFBQWU7Ozs7O3dCQUMvQixxQkFBTSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFVBQVUsR0FBRyxTQUFrQztvQkFDL0MsTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFvQixDQUFDO29CQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxtQkFBVSxDQUFDLE9BQU8sQ0FBQztvQkFFcEMsc0JBQU8scUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUM7Ozs7Q0FDeEM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLE1BQStCLEVBQUUsa0JBQTBCLEVBQUUsYUFBcUI7SUFDOUcsSUFBSSxrQkFBa0IsRUFBRTtRQUNwQixNQUFNLENBQUMsd0JBQXdCLEdBQUcsRUFBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUMsQ0FBQztLQUM3RDtJQUNELElBQUksYUFBYSxFQUFFO1FBQ2YsTUFBTSxDQUFDLGlCQUFpQixHQUFHLEVBQUMsQ0FBQyxFQUFFLGFBQWEsRUFBQyxDQUFDO0tBQ2pEO0lBRUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsbUJBQVUsQ0FBQyxhQUFhLENBQUM7SUFFMUMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBRUQsb0NBQW9DO0FBQ3BDLFNBQVMsdUJBQXVCLENBQUMsTUFBK0I7SUFDNUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsbUJBQVUsQ0FBQyxTQUFTLENBQUM7SUFFdEMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxJQUE2QjtJQUN4RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLGVBQVM7UUFDcEIsSUFBSSxFQUFFLElBQUk7S0FDYixDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxRQUFlO0lBQ3ZDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGFBQWEsR0FBRztRQUNoQixTQUFTLEVBQUUsZUFBUztRQUNwQixHQUFHLEVBQUUsZUFBZSxDQUFDLFFBQVEsQ0FBQztLQUNqQyxDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxRQUFlO0lBQzFDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGdCQUFnQixHQUFHO1FBQ25CLFNBQVMsRUFBRSxlQUFTO1FBQ3BCLEdBQUcsRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDO0tBQ2pDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxFQUFFLEVBQTFDLENBQTBDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDOUYsQ0FBQztBQUVELFNBQVMsc0JBQXNCLENBQUMsVUFBaUI7SUFDN0MsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksYUFBYSxHQUFHO1FBQ2hCLFNBQVMsRUFBRSxlQUFTO1FBQ3BCLFNBQVMsRUFBRSxpQkFBaUI7UUFDNUIsd0JBQXdCLEVBQUU7WUFDdEIsS0FBSyxFQUFFLFlBQVk7U0FDdEI7UUFDRCx5QkFBeUIsRUFBRTtZQUN2QixJQUFJLEVBQUU7Z0JBQ0YsQ0FBQyxFQUFFLFVBQVU7YUFDaEI7U0FDSjtRQUNELHNCQUFzQixFQUFFLFVBQVU7UUFDbEMsTUFBTSxFQUFFLDBCQUEwQjtLQUNyQyxDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEMsQ0FBa0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RixDQUFDO0FBRUQsa0JBQWU7SUFDWCxPQUFPLEVBQUcsa0JBQWtCO0lBQzVCLFVBQVUsRUFBRyxxQkFBcUI7SUFDbEMsVUFBVSxFQUFHLHNCQUFzQjtJQUNuQyxnQkFBZ0IsRUFBRyx1QkFBdUI7SUFDMUMsYUFBYSxFQUFHLG9CQUFvQjtJQUNwQyxjQUFjLEVBQUcscUJBQXFCO0lBQ3RDLGVBQWUsRUFBRyxzQkFBc0I7SUFDeEMsZ0JBQWdCLEVBQUcsdUJBQXVCO0NBQzdDLENBQUEifQ==