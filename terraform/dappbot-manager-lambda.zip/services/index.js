"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var cloudfront_1 = __importDefault(require("./cloudfront"));
var codepipeline_1 = __importDefault(require("./codepipeline"));
var cognito_1 = __importDefault(require("./cognito"));
var dynamoDB_1 = __importDefault(require("./dynamoDB"));
var route53_1 = __importDefault(require("./route53"));
var s3_1 = __importDefault(require("./s3"));
exports.default = { cloudfront: cloudfront_1.default, codepipeline: codepipeline_1.default, cognito: cognito_1.default, dynamoDB: dynamoDB_1.default, route53: route53_1.default, s3: s3_1.default };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSw0REFBc0M7QUFDdEMsZ0VBQTBDO0FBQzFDLHNEQUFnQztBQUNoQyx3REFBa0M7QUFDbEMsc0RBQWdDO0FBQ2hDLDRDQUFzQjtBQUV0QixrQkFBZSxFQUFFLFVBQVUsc0JBQUEsRUFBRSxZQUFZLHdCQUFBLEVBQUUsT0FBTyxtQkFBQSxFQUFFLFFBQVEsb0JBQUEsRUFBRSxPQUFPLG1CQUFBLEVBQUUsRUFBRSxjQUFBLEVBQUUsQ0FBQyJ9