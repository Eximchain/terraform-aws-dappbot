"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
exports.lambdaFxnName = process.env.AWS_LAMBDA_FUNCTION_NAME;
// Provided to us via Terraform
exports.tableName = process.env.DDB_TABLE;
exports.r53HostedZoneId = process.env.R53_HOSTED_ZONE_ID;
exports.dnsRoot = process.env.DNS_ROOT;
exports.codebuildId = process.env.CODEBUILD_ID;
exports.pipelineRoleArn = process.env.PIPELINE_ROLE_ARN;
exports.kmsKeyName = process.env.KMS_KEY_NAME;
exports.artifactBucket = process.env.ARTIFACT_BUCKET;
exports.dappseedBucket = process.env.DAPPSEED_BUCKET;
exports.wildcardCertArn = process.env.WILDCARD_CERT_ARN;
exports.cognitoUserPoolId = process.env.COGNITO_USER_POOL;
exports.sendgridApiKey = process.env.SENDGRID_API_KEY;
var aws_sdk_1 = __importDefault(require("aws-sdk"));
exports.AWS = aws_sdk_1.default;
exports.AWS.config.update({ region: exports.awsRegion });
exports.default = {
    AWS: exports.AWS, awsRegion: exports.awsRegion, tableName: exports.tableName, r53HostedZoneId: exports.r53HostedZoneId, dnsRoot: exports.dnsRoot, codebuildId: exports.codebuildId,
    lambdaFxnName: exports.lambdaFxnName, pipelineRoleArn: exports.pipelineRoleArn, kmsKeyName: exports.kmsKeyName, artifactBucket: exports.artifactBucket,
    dappseedBucket: exports.dappseedBucket, wildcardCertArn: exports.wildcardCertArn, cognitoUserPoolId: exports.cognitoUserPoolId, sendgridApiKey: exports.sendgridApiKey
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLGdDQUFnQztBQUNuQixRQUFBLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQW9CLENBQUM7QUFDN0MsUUFBQSxhQUFhLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBa0MsQ0FBQztBQUU1RSwrQkFBK0I7QUFDbEIsUUFBQSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFtQixDQUFDO0FBQzVDLFFBQUEsZUFBZSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQTRCLENBQUM7QUFDM0QsUUFBQSxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFrQixDQUFDO0FBQ3pDLFFBQUEsV0FBVyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBc0IsQ0FBQztBQUNqRCxRQUFBLGVBQWUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUEyQixDQUFDO0FBQzFELFFBQUEsVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBc0IsQ0FBQztBQUNoRCxRQUFBLGNBQWMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQXlCLENBQUM7QUFDdkQsUUFBQSxjQUFjLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUF5QixDQUFDO0FBQ3ZELFFBQUEsZUFBZSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQTJCLENBQUM7QUFDMUQsUUFBQSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUEyQixDQUFDO0FBQzVELFFBQUEsY0FBYyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQTBCLENBQUM7QUFFckUsb0RBQXNDO0FBQ3pCLFFBQUEsR0FBRyxHQUFHLGlCQUFlLENBQUM7QUFDbkMsV0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxNQUFNLEVBQUUsaUJBQVMsRUFBQyxDQUFDLENBQUM7QUFFdkMsa0JBQWU7SUFDWCxHQUFHLGFBQUEsRUFBRSxTQUFTLG1CQUFBLEVBQUUsU0FBUyxtQkFBQSxFQUFFLGVBQWUseUJBQUEsRUFBRSxPQUFPLGlCQUFBLEVBQUUsV0FBVyxxQkFBQTtJQUNoRSxhQUFhLHVCQUFBLEVBQUUsZUFBZSx5QkFBQSxFQUFFLFVBQVUsb0JBQUEsRUFBRSxjQUFjLHdCQUFBO0lBQzFELGNBQWMsd0JBQUEsRUFBRSxlQUFlLHlCQUFBLEVBQUUsaUJBQWlCLDJCQUFBLEVBQUUsY0FBYyx3QkFBQTtDQUNyRSxDQUFDIn0=