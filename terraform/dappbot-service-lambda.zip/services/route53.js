"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var addAwsPromiseRetries = require('../common').addAwsPromiseRetries;
var _a = require('../env'), AWS = _a.AWS, r53HostedZoneId = _a.r53HostedZoneId, dnsRoot = _a.dnsRoot;
var route53 = new AWS.Route53({ apiVersion: '2013-04-01' });
function promiseCreateDnsRecord(dnsName, cloudfrontDns) {
    var maxRetries = 5;
    var params = {
        HostedZoneId: r53HostedZoneId,
        ChangeBatch: {
            Changes: [{
                    Action: 'CREATE',
                    ResourceRecordSet: {
                        AliasTarget: {
                            DNSName: cloudfrontDns,
                            EvaluateTargetHealth: false,
                            HostedZoneId: "Z2FDTNDATAQYW2"
                        },
                        Name: dnsName,
                        Type: "A"
                    }
                }]
        }
    };
    return addAwsPromiseRetries(function () { return route53.changeResourceRecordSets(params).promise(); }, maxRetries);
}
function promiseDeleteDnsRecord(dnsName, cloudfrontDns) {
    var maxRetries = 5;
    var params = {
        HostedZoneId: r53HostedZoneId,
        ChangeBatch: {
            Changes: [{
                    Action: 'DELETE',
                    ResourceRecordSet: {
                        AliasTarget: {
                            DNSName: cloudfrontDns,
                            EvaluateTargetHealth: false,
                            HostedZoneId: "Z2FDTNDATAQYW2"
                        },
                        Name: dnsName,
                        Type: "A"
                    }
                }]
        }
    };
    return addAwsPromiseRetries(function () { return route53.changeResourceRecordSets(params).promise(); }, maxRetries);
}
exports.default = {
    createRecord: promiseCreateDnsRecord,
    deleteRecord: promiseDeleteDnsRecord
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGU1My5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9yb3V0ZTUzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQVEsSUFBQSxnRUFBb0IsQ0FBMEI7QUFDaEQsSUFBQSxzQkFBcUQsRUFBbkQsWUFBRyxFQUFFLG9DQUFlLEVBQUUsb0JBQTZCLENBQUM7QUFDNUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFNUQsU0FBUyxzQkFBc0IsQ0FBQyxPQUFjLEVBQUUsYUFBb0I7SUFDaEUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsWUFBWSxFQUFFLGVBQWU7UUFDN0IsV0FBVyxFQUFFO1lBQ1QsT0FBTyxFQUFFLENBQUM7b0JBQ04sTUFBTSxFQUFFLFFBQVE7b0JBQ2hCLGlCQUFpQixFQUFFO3dCQUNmLFdBQVcsRUFBRTs0QkFDVCxPQUFPLEVBQUUsYUFBYTs0QkFDdEIsb0JBQW9CLEVBQUUsS0FBSzs0QkFDM0IsWUFBWSxFQUFFLGdCQUFnQjt5QkFDakM7d0JBQ0QsSUFBSSxFQUFFLE9BQU87d0JBQ2IsSUFBSSxFQUFFLEdBQUc7cUJBQ1o7aUJBQ0osQ0FBQztTQUNMO0tBQ0osQ0FBQTtJQUNELE9BQU8sb0JBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxPQUFjLEVBQUUsYUFBb0I7SUFDaEUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsWUFBWSxFQUFFLGVBQWU7UUFDN0IsV0FBVyxFQUFFO1lBQ1QsT0FBTyxFQUFFLENBQUM7b0JBQ04sTUFBTSxFQUFFLFFBQVE7b0JBQ2hCLGlCQUFpQixFQUFFO3dCQUNmLFdBQVcsRUFBRTs0QkFDVCxPQUFPLEVBQUUsYUFBYTs0QkFDdEIsb0JBQW9CLEVBQUUsS0FBSzs0QkFDM0IsWUFBWSxFQUFFLGdCQUFnQjt5QkFDakM7d0JBQ0QsSUFBSSxFQUFFLE9BQU87d0JBQ2IsSUFBSSxFQUFFLEdBQUc7cUJBQ1o7aUJBQ0osQ0FBQztTQUNMO0tBQ0osQ0FBQTtJQUNELE9BQU8sb0JBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEQsQ0FBa0QsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RyxDQUFDO0FBRUQsa0JBQWU7SUFDWCxZQUFZLEVBQUcsc0JBQXNCO0lBQ3JDLFlBQVksRUFBRyxzQkFBc0I7Q0FDeEMsQ0FBQSJ9