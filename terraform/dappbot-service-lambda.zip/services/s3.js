"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var env_1 = require("../env");
var s3 = new env_1.AWS.S3({ apiVersion: '2006-03-01' });
function promiseDeleteS3Bucket(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.deleteBucket(params).promise(); }, maxRetries);
}
function promiseListS3Objects(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.listObjects(params).promise(); }, maxRetries);
}
function promiseEmptyS3Bucket(bucketName) {
    var maxDeleteRetries = 5;
    console.log("Emptying S3 bucket ", bucketName);
    // TODO: Does this have issues with the limit of list objects?
    return promiseListS3Objects(bucketName).then(function (result) {
        console.log("List S3 Objects Success", result);
        // Contents can be undefined, ensure there's always an array to map over
        result.Contents = result.Contents || [];
        var deletePromises = result.Contents.map(function (obj) {
            var params = {
                Bucket: bucketName,
                Key: obj.Key
            };
            return common_1.addAwsPromiseRetries(function () { return s3.deleteObject(params).promise(); }, maxDeleteRetries);
        });
        var retPromise = Promise.all(deletePromises);
        console.log("Returning promise", retPromise, "With deletePromises", deletePromises);
        return retPromise;
    })
        .catch(function (err) {
        console.log("Error", err);
        return Promise.reject(err);
    });
}
function promiseSetS3BucketPublicReadable(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Policy: JSON.stringify({
            "Version": "2012-10-17",
            "Statement": [{
                    "Sid": "PublicReadGetObject",
                    "Effect": "Allow",
                    "Principal": "*",
                    "Action": ["s3:GetObject"],
                    "Resource": ["arn:aws:s3:::" + bucketName + "/*"]
                }
            ]
        })
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketPolicy(params).promise(); }, maxRetries);
}
function promiseConfigureS3BucketStaticWebsite(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        WebsiteConfiguration: {
            ErrorDocument: {
                Key: 'index.html'
            },
            IndexDocument: {
                Suffix: 'index.html'
            }
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketWebsite(params).promise(); }, maxRetries);
}
function promiseEnableS3BucketCORS(bucketName, dappDNS) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        CORSConfiguration: {
            CORSRules: [
                {
                    "AllowedHeaders": ["Authorization"],
                    "AllowedOrigins": ["https://" + dappDNS],
                    "AllowedMethods": ["GET"],
                    MaxAgeSeconds: 3000
                }
            ]
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketCors(params).promise(); }, maxRetries);
}
function promiseGetS3BucketWebsiteConfig(bucketName) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName
    };
    return common_1.addAwsPromiseRetries(function () { return s3.getBucketWebsite(params).promise(); }, maxRetries);
}
function promiseMakeObjectNoCache(bucketName, objectKey) {
    return __awaiter(this, void 0, void 0, function () {
        var maxRetries, indexObject, putParams;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    maxRetries = 5;
                    return [4 /*yield*/, promiseGetS3Object(bucketName, objectKey)];
                case 1:
                    indexObject = _a.sent();
                    putParams = {
                        Bucket: bucketName,
                        ACL: 'public-read',
                        ContentType: indexObject.ContentType,
                        Key: objectKey,
                        Body: indexObject.Body,
                        CacheControl: 'max-age=0'
                    };
                    return [2 /*return*/, common_1.addAwsPromiseRetries(function () { return s3.putObject(putParams).promise(); }, maxRetries)];
            }
        });
    });
}
function promisePutBucketTags(bucketName, tags) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Tagging: {
            TagSet: tags
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketTagging(params).promise(); }, maxRetries);
}
function promiseGetS3Object(bucketName, objectKey) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Key: objectKey
    };
    return common_1.addAwsPromiseRetries(function () { return s3.getObject(params).promise(); }, maxRetries);
}
function getS3BucketEndpoint(bucketName) {
    return bucketName.concat(".s3.").concat(env_1.awsRegion).concat(".amazonaws.com");
}
exports.default = {
    getBucketWebsite: promiseGetS3BucketWebsiteConfig,
    configureBucketWebsite: promiseConfigureS3BucketStaticWebsite,
    setBucketPublic: promiseSetS3BucketPublicReadable,
    deleteBucket: promiseDeleteS3Bucket,
    emptyBucket: promiseEmptyS3Bucket,
    listObjects: promiseListS3Objects,
    getObject: promiseGetS3Object,
    makeObjectNoCache: promiseMakeObjectNoCache,
    enableBucketCors: promiseEnableS3BucketCORS,
    bucketEndpoint: getS3BucketEndpoint
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiczMuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvczMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9DQUE4RDtBQUM5RCw4QkFBd0M7QUFFeEMsSUFBTSxFQUFFLEdBQUcsSUFBSSxTQUFHLENBQUMsRUFBRSxDQUFDLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7QUFFbEQsU0FBUyxxQkFBcUIsQ0FBQyxVQUFpQjtJQUM1QyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUUsVUFBVTtLQUNyQixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBakMsQ0FBaUMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNyRixDQUFDO0FBRUQsU0FBUyxvQkFBb0IsQ0FBQyxVQUFpQjtJQUMzQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUUsVUFBVTtLQUNyQixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEMsQ0FBZ0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNwRixDQUFDO0FBRUQsU0FBUyxvQkFBb0IsQ0FBQyxVQUFpQjtJQUMzQyxJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQztJQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLFVBQVUsQ0FBQyxDQUFBO0lBQzlDLDhEQUE4RDtJQUM5RCxPQUFPLG9CQUFvQixDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFTLE1BQU07UUFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMvQyx3RUFBd0U7UUFDeEUsTUFBTSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztRQUN4QyxJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEdBQUc7WUFDekMsSUFBSSxNQUFNLEdBQUc7Z0JBQ1QsTUFBTSxFQUFFLFVBQVU7Z0JBQ2xCLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBZ0I7YUFDNUIsQ0FBQztZQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQTtRQUMxRixDQUFDLENBQUMsQ0FBQTtRQUNGLElBQUksVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxVQUFVLEVBQUUscUJBQXFCLEVBQUUsY0FBYyxDQUFDLENBQUE7UUFDbkYsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQyxDQUFDO1NBQ0QsS0FBSyxDQUFDLFVBQVMsR0FBRztRQUNmLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUMvQixDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFFRCxTQUFTLGdDQUFnQyxDQUFDLFVBQWlCO0lBQ3ZELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRSxVQUFVO1FBQ2xCLE1BQU0sRUFBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ3BCLFNBQVMsRUFBQyxZQUFZO1lBQ3RCLFdBQVcsRUFBQyxDQUFDO29CQUNiLEtBQUssRUFBQyxxQkFBcUI7b0JBQ3JCLFFBQVEsRUFBQyxPQUFPO29CQUNwQixXQUFXLEVBQUUsR0FBRztvQkFDZCxRQUFRLEVBQUMsQ0FBQyxjQUFjLENBQUM7b0JBQ3pCLFVBQVUsRUFBQyxDQUFDLGtCQUFnQixVQUFVLE9BQUksQ0FBQztpQkFDNUM7YUFDRjtTQUNKLENBQUM7S0FDTCxDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBR0QsU0FBUyxxQ0FBcUMsQ0FBQyxVQUFpQjtJQUM1RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUUsVUFBVTtRQUNsQixvQkFBb0IsRUFBRTtZQUNsQixhQUFhLEVBQUU7Z0JBQ1gsR0FBRyxFQUFFLFlBQVk7YUFDcEI7WUFDRCxhQUFhLEVBQUU7Z0JBQ1gsTUFBTSxFQUFFLFlBQVk7YUFDdkI7U0FDSjtLQUNKLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXJDLENBQXFDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDekYsQ0FBQztBQUVELFNBQVMseUJBQXlCLENBQUMsVUFBaUIsRUFBRSxPQUFjO0lBQ2hFLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBRztRQUNULE1BQU0sRUFBRyxVQUFVO1FBQ25CLGlCQUFpQixFQUFHO1lBQ2hCLFNBQVMsRUFBRztnQkFDUjtvQkFDSSxnQkFBZ0IsRUFBRSxDQUFDLGVBQWUsQ0FBQztvQkFDbkMsZ0JBQWdCLEVBQUUsQ0FBQyxhQUFXLE9BQVMsQ0FBQztvQkFDeEMsZ0JBQWdCLEVBQUUsQ0FBQyxLQUFLLENBQUM7b0JBQ3pCLGFBQWEsRUFBSyxJQUFJO2lCQUN6QjthQUNKO1NBQ0o7S0FDSixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBbEMsQ0FBa0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RixDQUFDO0FBRUQsU0FBUywrQkFBK0IsQ0FBQyxVQUFpQjtJQUN0RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUUsVUFBVTtLQUNyQixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFyQyxDQUFxQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3pGLENBQUM7QUFFRCxTQUFlLHdCQUF3QixDQUFDLFVBQWlCLEVBQUUsU0FBZ0I7Ozs7OztvQkFDbkUsVUFBVSxHQUFHLENBQUMsQ0FBQztvQkFDQyxxQkFBTSxrQkFBa0IsQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLEVBQUE7O29CQUE3RCxXQUFXLEdBQUcsU0FBK0M7b0JBQzdELFNBQVMsR0FBRzt3QkFDZCxNQUFNLEVBQUcsVUFBVTt3QkFDbkIsR0FBRyxFQUFHLGFBQWE7d0JBQ25CLFdBQVcsRUFBRSxXQUFXLENBQUMsV0FBVzt3QkFDcEMsR0FBRyxFQUFHLFNBQVM7d0JBQ2YsSUFBSSxFQUFHLFdBQVcsQ0FBQyxJQUFJO3dCQUN2QixZQUFZLEVBQUUsV0FBVztxQkFDNUIsQ0FBQTtvQkFDRCxzQkFBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBakMsQ0FBaUMsRUFBRSxVQUFVLENBQUMsRUFBQzs7OztDQUNwRjtBQUVELFNBQVMsb0JBQW9CLENBQUMsVUFBaUIsRUFBRSxJQUFrQjtJQUMvRCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUUsVUFBVTtRQUNsQixPQUFPLEVBQUU7WUFDTCxNQUFNLEVBQUUsSUFBSTtTQUNmO0tBQ0osQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBckMsQ0FBcUMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN6RixDQUFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxVQUFpQixFQUFFLFNBQWdCO0lBQzNELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFNLE1BQU0sR0FBRztRQUNYLE1BQU0sRUFBRyxVQUFVO1FBQ25CLEdBQUcsRUFBRyxTQUFTO0tBQ2xCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE5QixDQUE4QixFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLFVBQWlCO0lBQzFDLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBUyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDaEYsQ0FBQztBQUVELGtCQUFlO0lBQ1gsZ0JBQWdCLEVBQUcsK0JBQStCO0lBQ2xELHNCQUFzQixFQUFHLHFDQUFxQztJQUM5RCxlQUFlLEVBQUcsZ0NBQWdDO0lBQ2xELFlBQVksRUFBRyxxQkFBcUI7SUFDcEMsV0FBVyxFQUFHLG9CQUFvQjtJQUNsQyxXQUFXLEVBQUcsb0JBQW9CO0lBQ2xDLFNBQVMsRUFBRyxrQkFBa0I7SUFDOUIsaUJBQWlCLEVBQUcsd0JBQXdCO0lBQzVDLGdCQUFnQixFQUFHLHlCQUF5QjtJQUM1QyxjQUFjLEVBQUcsbUJBQW1CO0NBQ3ZDLENBQUEifQ==