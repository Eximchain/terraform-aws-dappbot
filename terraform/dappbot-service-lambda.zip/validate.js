"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var errors_1 = require("./errors");
var common_1 = require("./common");
var cloudfront_1 = __importDefault(require("./services/cloudfront"));
var OPERATION_HANDLING_BY_STATE = {
    CREATING: {
        'create': 'process',
        'update': 'retry',
        'delete': 'process'
    },
    BUILDING_DAPP: {
        'create': 'ignore',
        'update': 'process',
        'delete': 'process'
    },
    AVAILABLE: {
        'create': 'ignore',
        'update': 'process',
        'delete': 'process'
    },
    DELETING: {
        'create': 'ignore',
        'update': 'ignore',
        'delete': 'process'
    },
    FAILED: {
        'create': 'ignore',
        'update': 'ignore',
        'delete': 'process'
    },
    DEPOSED: {
        'create': 'ignore',
        'update': 'ignore',
        'delete': 'process'
    }
};
/*
- This function throws an error if processing should be delayed but retried
- Returns true if the operation should be processed
- Returns false otherwise
*/
function processOpFromState(operation, state) {
    var directive = OPERATION_HANDLING_BY_STATE[state][operation];
    errors_1.assertPermission(directive !== 'retry', "'" + operation + "' operation prohibited from state '" + state + "'. Failing processing and retrying after visibility timeout.");
    return directive == 'process';
}
function validateStateCreate(dbResponse) {
    var operation = common_1.DappOperations.create;
    var dbItem = dbResponse.Item;
    // Use a direct check so the TS compiler understands that beyond this line,
    // dbItem is definitely defined.  Same in fxns below.
    if (!dbItem)
        throw new Error("Dapp Not Found for " + operation + " operation");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DappName'), "dbItem: required attribute 'DappName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('OwnerEmail'), "dbItem: required attribute 'OwnerEmail' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DnsName'), "dbItem: required attribute 'DnsName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('PipelineName'), "dbItem: required attribute 'PipelineName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Abi'), "dbItem: required attribute 'Abi' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('ContractAddr'), "dbItem: required attribute 'ContractAddr' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Web3URL'), "dbItem: required attribute 'Web3URL' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('GuardianURL'), "dbItem: required attribute 'GuardianURL' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('State'), "dbItem: required attribute 'State' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Tier'), "dbItem: required attribute 'Tier' not found");
    errors_1.assertStateValid(dbItem.DappName.hasOwnProperty('S'), "dbItem: required attribute 'DappName' has wrong shape");
    errors_1.assertStateValid(dbItem.OwnerEmail.hasOwnProperty('S'), "dbItem: required attribute 'OwnerEmail' has wrong shape");
    errors_1.assertStateValid(dbItem.DnsName.hasOwnProperty('S'), "dbItem: required attribute 'DnsName' has wrong shape");
    errors_1.assertStateValid(dbItem.PipelineName.hasOwnProperty('S'), "dbItem: required attribute 'PipelineName' has wrong shape");
    errors_1.assertStateValid(dbItem.Abi.hasOwnProperty('S'), "dbItem: required attribute 'Abi' has wrong shape");
    errors_1.assertStateValid(dbItem.ContractAddr.hasOwnProperty('S'), "dbItem: required attribute 'ContractAddr' has wrong shape");
    errors_1.assertStateValid(dbItem.Web3URL.hasOwnProperty('S'), "dbItem: required attribute 'Web3URL' has wrong shape");
    errors_1.assertStateValid(dbItem.GuardianURL.hasOwnProperty('S'), "dbItem: required attribute 'GuardianURL' has wrong shape");
    errors_1.assertStateValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'State' has wrong shape");
    errors_1.assertStateValid(dbItem.Tier.hasOwnProperty('S'), "dbItem: required attribute 'Tier' has wrong shape");
    var state = dbItem.State.S;
    return processOpFromState(operation, state);
}
function validateStateUpdate(dbResponse) {
    var operation = common_1.DappOperations.update;
    var dbItem = dbResponse.Item;
    if (!dbItem)
        throw new Error("Dapp Not Found for " + operation + " operation");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DappName'), "dbItem: required attribute 'DappName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('OwnerEmail'), "dbItem: required attribute 'OwnerEmail' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DnsName'), "dbItem: required attribute 'DnsName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('PipelineName'), "dbItem: required attribute 'PipelineName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Abi'), "dbItem: required attribute 'Abi' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('ContractAddr'), "dbItem: required attribute 'ContractAddr' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Web3URL'), "dbItem: required attribute 'Web3URL' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('GuardianURL'), "dbItem: required attribute 'GuardianURL' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('State'), "dbItem: required attribute 'State' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Tier'), "dbItem: required attribute 'Tier' not found");
    errors_1.assertStateValid(dbItem.DappName.hasOwnProperty('S'), "dbItem: required attribute 'DappName' has wrong shape");
    errors_1.assertStateValid(dbItem.OwnerEmail.hasOwnProperty('S'), "dbItem: required attribute 'OwnerEmail' has wrong shape");
    errors_1.assertStateValid(dbItem.DnsName.hasOwnProperty('S'), "dbItem: required attribute 'DnsName' has wrong shape");
    errors_1.assertStateValid(dbItem.PipelineName.hasOwnProperty('S'), "dbItem: required attribute 'PipelineName' has wrong shape");
    errors_1.assertStateValid(dbItem.Abi.hasOwnProperty('S'), "dbItem: required attribute 'Abi' has wrong shape");
    errors_1.assertStateValid(dbItem.ContractAddr.hasOwnProperty('S'), "dbItem: required attribute 'ContractAddr' has wrong shape");
    errors_1.assertStateValid(dbItem.Web3URL.hasOwnProperty('S'), "dbItem: required attribute 'Web3URL' has wrong shape");
    errors_1.assertStateValid(dbItem.GuardianURL.hasOwnProperty('S'), "dbItem: required attribute 'GuardianURL' has wrong shape");
    errors_1.assertStateValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'State' has wrong shape");
    errors_1.assertStateValid(dbItem.Tier.hasOwnProperty('S'), "dbItem: required attribute 'Tier' has wrong shape");
    var state = dbItem.State.S;
    return processOpFromState(operation, state);
}
function validateStateDelete(dbResponse) {
    var operation = common_1.DappOperations.delete;
    var dbItem = dbResponse.Item;
    if (!dbItem)
        throw new Error("Dapp Not Found for " + operation + " operation");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DappName'), "dbItem: required attribute 'DappName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('OwnerEmail'), "dbItem: required attribute 'OwnerEmail' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('DnsName'), "dbItem: required attribute 'DnsName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('PipelineName'), "dbItem: required attribute 'PipelineName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('S3BucketName'), "dbItem: required attribute 'S3BucketName' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('State'), "dbItem: required attribute 'State' not found");
    errors_1.assertStateValid(dbItem.hasOwnProperty('Tier'), "dbItem: required attribute 'Tier' not found");
    errors_1.assertStateValid(dbItem.DappName.hasOwnProperty('S'), "dbItem: required attribute 'DappName' has wrong shape");
    errors_1.assertStateValid(dbItem.OwnerEmail.hasOwnProperty('S'), "dbItem: required attribute 'OwnerEmail' has wrong shape");
    errors_1.assertStateValid(dbItem.DnsName.hasOwnProperty('S'), "dbItem: required attribute 'DnsName' has wrong shape");
    errors_1.assertStateValid(dbItem.PipelineName.hasOwnProperty('S'), "dbItem: required attribute 'PipelineName' has wrong shape");
    errors_1.assertStateValid(dbItem.S3BucketName.hasOwnProperty('S'), "dbItem: required attribute 'S3BucketName' has wrong shape");
    errors_1.assertStateValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'State' has wrong shape");
    errors_1.assertStateValid(dbItem.Tier.hasOwnProperty('S'), "dbItem: required attribute 'Tier' has wrong shape");
    var state = dbItem.State.S;
    return processOpFromState(operation, state);
}
function validateConflictingDistributionRepurposable(conflictingDistro, owner) {
    return __awaiter(this, void 0, void 0, function () {
        var conflictingDistroArn, existingDappOwner, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!conflictingDistro) {
                        console.log("UNEXPECTED ERROR: Conflicting distro not found despite 'CNAMEAlreadyExists' error");
                        errors_1.throwInternalValidationError();
                    }
                    conflictingDistroArn = conflictingDistro.ARN;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, cloudfront_1.default.getDistroOwner(conflictingDistroArn)];
                case 2:
                    existingDappOwner = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    err_1 = _a.sent();
                    console.log("UNEXPECTED ERROR: Conuld not retrieve owner of existing Dapp");
                    errors_1.throwInternalValidationError();
                    return [3 /*break*/, 4];
                case 4:
                    // Don't let the caller take someone else's distribution
                    errors_1.assertPermission(owner === existingDappOwner, "Cannot repurpose distribution that belongs to another user");
                    return [2 /*return*/];
            }
        });
    });
}
exports.default = {
    stateCreate: validateStateCreate,
    stateUpdate: validateStateUpdate,
    stateDelete: validateStateDelete,
    conflictingDistroRepurposable: validateConflictingDistributionRepurposable
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG1DQUE0RjtBQUM1RixtQ0FBcUY7QUFDckYscUVBQStDO0FBWS9DLElBQU0sMkJBQTJCLEdBQXVCO0lBQ3BELFFBQVEsRUFBRTtRQUNOLFFBQVEsRUFBRSxTQUFTO1FBQ25CLFFBQVEsRUFBRSxPQUFPO1FBQ2pCLFFBQVEsRUFBRSxTQUFTO0tBQ3RCO0lBQ0QsYUFBYSxFQUFFO1FBQ1gsUUFBUSxFQUFFLFFBQVE7UUFDbEIsUUFBUSxFQUFFLFNBQVM7UUFDbkIsUUFBUSxFQUFFLFNBQVM7S0FDdEI7SUFDRCxTQUFTLEVBQUU7UUFDUCxRQUFRLEVBQUUsUUFBUTtRQUNsQixRQUFRLEVBQUUsU0FBUztRQUNuQixRQUFRLEVBQUUsU0FBUztLQUN0QjtJQUNELFFBQVEsRUFBRTtRQUNOLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLFFBQVEsRUFBRSxTQUFTO0tBQ3RCO0lBQ0QsTUFBTSxFQUFFO1FBQ0osUUFBUSxFQUFFLFFBQVE7UUFDbEIsUUFBUSxFQUFFLFFBQVE7UUFDbEIsUUFBUSxFQUFFLFNBQVM7S0FDdEI7SUFDRCxPQUFPLEVBQUU7UUFDTCxRQUFRLEVBQUUsUUFBUTtRQUNsQixRQUFRLEVBQUUsUUFBUTtRQUNsQixRQUFRLEVBQUUsU0FBUztLQUN0QjtDQUNKLENBQUM7QUFFRjs7OztFQUlFO0FBQ0YsU0FBUyxrQkFBa0IsQ0FBQyxTQUFpQixFQUFFLEtBQWdCO0lBQzNELElBQUksU0FBUyxHQUFHLDJCQUEyQixDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzlELHlCQUFnQixDQUFDLFNBQVMsS0FBSyxPQUFPLEVBQUUsTUFBSSxTQUFTLDJDQUFzQyxLQUFLLGlFQUE4RCxDQUFDLENBQUM7SUFDaEssT0FBTyxTQUFTLElBQUksU0FBUyxDQUFDO0FBQ2xDLENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLFVBQXdCO0lBQ2pELElBQU0sU0FBUyxHQUFHLHVCQUFPLENBQUMsTUFBTSxDQUFDO0lBRWpDLElBQUksTUFBTSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUM7SUFDN0IsMkVBQTJFO0lBQzNFLHFEQUFxRDtJQUNyRCxJQUFJLENBQUMsTUFBTTtRQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXNCLFNBQVMsZUFBWSxDQUFDLENBQUE7SUFFekUseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxpREFBaUQsQ0FBQyxDQUFDO0lBQ3ZHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsbURBQW1ELENBQUMsQ0FBQztJQUMzRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDckcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxxREFBcUQsQ0FBQyxDQUFDO0lBQy9HLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQUUsNENBQTRDLENBQUMsQ0FBQztJQUM3Rix5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxFQUFFLHFEQUFxRCxDQUFDLENBQUM7SUFDL0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRSxnREFBZ0QsQ0FBQyxDQUFDO0lBQ3JHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUM3Ryx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLDhDQUE4QyxDQUFDLENBQUM7SUFDakcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSw2Q0FBNkMsQ0FBQyxDQUFDO0lBRS9GLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHVEQUF1RCxDQUFDLENBQUM7SUFDL0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUseURBQXlELENBQUMsQ0FBQztJQUNuSCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO0lBQzdHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDJEQUEyRCxDQUFDLENBQUM7SUFDdkgseUJBQWdCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsa0RBQWtELENBQUMsQ0FBQztJQUNyRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSwyREFBMkQsQ0FBQyxDQUFDO0lBQ3ZILHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHNEQUFzRCxDQUFDLENBQUM7SUFDN0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsMERBQTBELENBQUMsQ0FBQztJQUNySCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxvREFBb0QsQ0FBQyxDQUFDO0lBQ3pHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLG1EQUFtRCxDQUFDLENBQUM7SUFFdkcsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFlLENBQUM7SUFDekMsT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDaEQsQ0FBQztBQUVELFNBQVMsbUJBQW1CLENBQUMsVUFBd0I7SUFDakQsSUFBTSxTQUFTLEdBQUcsdUJBQU8sQ0FBQyxNQUFNLENBQUM7SUFFakMsSUFBSSxNQUFNLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQztJQUM3QixJQUFJLENBQUMsTUFBTTtRQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXNCLFNBQVMsZUFBWSxDQUFDLENBQUE7SUFFekUseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxpREFBaUQsQ0FBQyxDQUFDO0lBQ3ZHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsbURBQW1ELENBQUMsQ0FBQztJQUMzRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDckcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxxREFBcUQsQ0FBQyxDQUFDO0lBQy9HLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQUUsNENBQTRDLENBQUMsQ0FBQztJQUM3Rix5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxFQUFFLHFEQUFxRCxDQUFDLENBQUM7SUFDL0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRSxnREFBZ0QsQ0FBQyxDQUFDO0lBQ3JHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUM3Ryx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLDhDQUE4QyxDQUFDLENBQUM7SUFDakcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSw2Q0FBNkMsQ0FBQyxDQUFDO0lBRS9GLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHVEQUF1RCxDQUFDLENBQUM7SUFDL0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUseURBQXlELENBQUMsQ0FBQztJQUNuSCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO0lBQzdHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDJEQUEyRCxDQUFDLENBQUM7SUFDdkgseUJBQWdCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsa0RBQWtELENBQUMsQ0FBQztJQUNyRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSwyREFBMkQsQ0FBQyxDQUFDO0lBQ3ZILHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHNEQUFzRCxDQUFDLENBQUM7SUFDN0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsMERBQTBELENBQUMsQ0FBQztJQUNySCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxvREFBb0QsQ0FBQyxDQUFDO0lBQ3pHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLG1EQUFtRCxDQUFDLENBQUM7SUFFdkcsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFlLENBQUM7SUFDekMsT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDaEQsQ0FBQztBQUVELFNBQVMsbUJBQW1CLENBQUMsVUFBd0I7SUFDakQsSUFBTSxTQUFTLEdBQUcsdUJBQU8sQ0FBQyxNQUFNLENBQUM7SUFFakMsSUFBSSxNQUFNLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQztJQUM3QixJQUFJLENBQUMsTUFBTTtRQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXNCLFNBQVMsZUFBWSxDQUFDLENBQUE7SUFFekUseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxpREFBaUQsQ0FBQyxDQUFDO0lBQ3ZHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsbURBQW1ELENBQUMsQ0FBQztJQUMzRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDckcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxxREFBcUQsQ0FBQyxDQUFDO0lBQy9HLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEVBQUUscURBQXFELENBQUMsQ0FBQztJQUMvRyx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLDhDQUE4QyxDQUFDLENBQUM7SUFDakcseUJBQWdCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSw2Q0FBNkMsQ0FBQyxDQUFDO0lBRS9GLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHVEQUF1RCxDQUFDLENBQUM7SUFDL0cseUJBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUseURBQXlELENBQUMsQ0FBQztJQUNuSCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO0lBQzdHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDJEQUEyRCxDQUFDLENBQUM7SUFDdkgseUJBQWdCLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsMkRBQTJELENBQUMsQ0FBQztJQUN2SCx5QkFBZ0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxvREFBb0QsQ0FBQyxDQUFDO0lBQ3pHLHlCQUFnQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLG1EQUFtRCxDQUFDLENBQUM7SUFFdkcsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFlLENBQUM7SUFDekMsT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDaEQsQ0FBQztBQUdELFNBQWUsMkNBQTJDLENBQUMsaUJBQTZCLEVBQUUsS0FBWTs7Ozs7O29CQUNsRyxJQUFJLENBQUMsaUJBQWlCLEVBQUU7d0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUZBQW1GLENBQUMsQ0FBQzt3QkFDakcscUNBQTRCLEVBQUUsQ0FBQztxQkFDbEM7b0JBS0csb0JBQW9CLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDOzs7O29CQUd6QixxQkFBTSxvQkFBVSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFBOztvQkFBekUsaUJBQWlCLEdBQUcsU0FBcUQsQ0FBQzs7OztvQkFFMUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4REFBOEQsQ0FBQyxDQUFDO29CQUM1RSxxQ0FBNEIsRUFBRSxDQUFDOzs7b0JBR25DLHdEQUF3RDtvQkFDeEQseUJBQWdCLENBQUMsS0FBSyxLQUFLLGlCQUFpQixFQUFFLDREQUE0RCxDQUFDLENBQUM7Ozs7O0NBQy9HO0FBRUQsa0JBQWU7SUFDWCxXQUFXLEVBQUcsbUJBQW1CO0lBQ2pDLFdBQVcsRUFBRyxtQkFBbUI7SUFDakMsV0FBVyxFQUFHLG1CQUFtQjtJQUNqQyw2QkFBNkIsRUFBRywyQ0FBMkM7Q0FDOUUsQ0FBQSJ9