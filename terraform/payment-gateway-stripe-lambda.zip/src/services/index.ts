import cognito from './cognito';
import stripe from './stripe';
import sns from './sns';

export default {
  cognito, sns, stripe
}