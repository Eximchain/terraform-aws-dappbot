"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __importDefault(require("./services"));
var stripe_1 = require("./services/stripe");
var cognito = services_1.default.cognito, stripe = services_1.default.stripe, sns = services_1.default.sns;
var validate_1 = require("./validate");
function response(body) {
    var responseHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Authorization,Content-Type',
    };
    return {
        statusCode: 200,
        headers: responseHeaders,
        body: JSON.stringify(body)
    };
}
exports.response = response;
function apiRead(email) {
    return __awaiter(this, void 0, void 0, function () {
        var user, stripeData, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    console.log("Reading user data for " + email);
                    return [4 /*yield*/, cognito.getUser(email)];
                case 1:
                    user = _b.sent();
                    if (!user) return [3 /*break*/, 3];
                    return [4 /*yield*/, stripe.read(email)];
                case 2:
                    _a = _b.sent();
                    return [3 /*break*/, 4];
                case 3:
                    _a = {};
                    _b.label = 4;
                case 4:
                    stripeData = _a;
                    return [2 /*return*/, response(__assign({ user: user }, stripeData))];
            }
        });
    });
}
function apiUpdateDapps(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var plans, updatedSub, updateDappResult, newUser;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    plans = JSON.parse(body).plans;
                    console.log("Updating dapp counts for " + email);
                    return [4 /*yield*/, stripe.updateSubscription(email, plans)];
                case 1:
                    updatedSub = _a.sent();
                    return [4 /*yield*/, cognito.updateDapps(email, plans)];
                case 2:
                    updateDappResult = _a.sent();
                    return [4 /*yield*/, cognito.getUser(email)];
                case 3:
                    newUser = _a.sent();
                    return [2 /*return*/, response({
                            success: true,
                            updatedSubscription: updatedSub,
                            updatedUser: newUser
                        })];
            }
        });
    });
}
function apiUpdatePayment(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var token, validToken, customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    token = JSON.parse(body).token;
                    console.log("Updating payment source for " + email);
                    return [4 /*yield*/, stripe.isTokenValid(token)];
                case 1:
                    validToken = _a.sent();
                    if (!validToken) return [3 /*break*/, 3];
                    return [4 /*yield*/, stripe.updatePayment(email, token)];
                case 2:
                    customer = _a.sent();
                    return [2 /*return*/, response({
                            success: true,
                            updatedCustomer: customer
                        })];
                case 3: return [2 /*return*/, response({
                        success: false,
                        err: new Error("Provided Stripe token was not valid.")
                    })];
            }
        });
    });
}
function apiCancel(email) {
    return __awaiter(this, void 0, void 0, function () {
        var cancelledSub, cancelledNotification;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Cancelling " + email + "'s subscription");
                    return [4 /*yield*/, stripe.cancel(email)];
                case 1:
                    cancelledSub = _a.sent();
                    return [4 /*yield*/, sns.publishCancellation(email)];
                case 2:
                    cancelledNotification = _a.sent();
                    return [2 /*return*/, response({
                            success: true,
                            cancelledSub: cancelledSub,
                            cancelledNotification: cancelledNotification
                        })];
            }
        });
    });
}
function apiCreate(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, email, plans, name, coupon, token, validToken, allowedPlan, _b, customer, subscription, newUser;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = JSON.parse(body), email = _a.email, plans = _a.plans, name = _a.name, coupon = _a.coupon, token = _a.token;
                    console.log("Creating customer, subscription, & Cognito acct for " + email);
                    return [4 /*yield*/, stripe.isTokenValid(token)];
                case 1:
                    validToken = _c.sent();
                    allowedPlan = validToken ? plans : { standard: 1 };
                    return [4 /*yield*/, stripe.create({
                            name: name, email: email, token: token, coupon: coupon,
                            plans: allowedPlan
                        })];
                case 2:
                    _b = _c.sent(), customer = _b.customer, subscription = _b.subscription;
                    if (!stripe_1.ValidSubscriptionStates.includes(subscription.status)) {
                        throw Error("Subscription failed because subscription status is " + subscription.status);
                    }
                    return [4 /*yield*/, cognito.createUser(email, allowedPlan)];
                case 3:
                    newUser = _c.sent();
                    return [2 /*return*/, response({
                            success: true,
                            user: newUser,
                            stripeId: customer.id,
                            subscriptionId: subscription.id
                        })];
            }
        });
    });
}
function apiUpdate(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, err_1;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 7, , 8]);
                    _a = validate_1.matchUpdateBody(body);
                    switch (_a) {
                        case validate_1.UpdateUserActions.UpdatePlan: return [3 /*break*/, 1];
                        case validate_1.UpdateUserActions.UpdatePayment: return [3 /*break*/, 3];
                    }
                    return [3 /*break*/, 5];
                case 1: return [4 /*yield*/, apiUpdateDapps(email, body)];
                case 2: return [2 /*return*/, _b.sent()];
                case 3: return [4 /*yield*/, apiUpdatePayment(email, body)];
                case 4: return [2 /*return*/, _b.sent()];
                case 5: return [2 /*return*/, response({
                        success: false,
                        err: { message: "PUT body did not match shape for updating dapp allotments or payment source." }
                    })];
                case 6: return [3 /*break*/, 8];
                case 7:
                    err_1 = _b.sent();
                    return [2 /*return*/, response({
                            success: false,
                            err: err_1
                        })];
                case 8: return [2 /*return*/];
            }
        });
    });
}
exports.default = {
    read: apiRead,
    update: apiUpdate,
    create: apiCreate,
    cancel: apiCancel
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx3REFBa0M7QUFDbEMsNENBQTBGO0FBQ2pGLElBQUEsb0NBQU8sRUFBRSxrQ0FBTSxFQUFFLDRCQUFHLENBQWM7QUFFM0MsdUNBQTZEO0FBRzdELFNBQWdCLFFBQVEsQ0FBQyxJQUFXO0lBQ2hDLElBQUksZUFBZSxHQUFHO1FBQ2xCLGNBQWMsRUFBRSxrQkFBa0I7UUFDbEMsNkJBQTZCLEVBQUUsR0FBRztRQUNsQyw4QkFBOEIsRUFBRSw0QkFBNEI7S0FDL0QsQ0FBQTtJQUNELE9BQU87UUFDSCxVQUFVLEVBQUUsR0FBRztRQUNmLE9BQU8sRUFBRSxlQUFlO1FBQ3hCLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztLQUM3QixDQUFBO0FBQ0wsQ0FBQztBQVhELDRCQVdDO0FBRUQsU0FBZSxPQUFPLENBQUMsS0FBWTs7Ozs7O29CQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUF5QixLQUFPLENBQUMsQ0FBQztvQkFDakMscUJBQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQW5DLElBQUksR0FBRyxTQUE0Qjt5QkFDdEIsSUFBSSxFQUFKLHdCQUFJO29CQUFHLHFCQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF4QixLQUFBLFNBQXdCLENBQUE7OztvQkFBRyxLQUFBLEVBQUUsQ0FBQTs7O29CQUFqRCxVQUFVLEtBQXVDO29CQUN2RCxzQkFBTyxRQUFRLFlBQUcsSUFBSSxNQUFBLElBQUssVUFBVSxFQUFHLEVBQUE7Ozs7Q0FDM0M7QUFFRCxTQUFlLGNBQWMsQ0FBQyxLQUFZLEVBQUUsSUFBVzs7Ozs7O29CQUMzQyxLQUFLLEdBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBckIsQ0FBc0I7b0JBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQTRCLEtBQU8sQ0FBQyxDQUFBO29CQUM3QixxQkFBTSxNQUFNLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxFQUFBOztvQkFBMUQsVUFBVSxHQUFHLFNBQTZDO29CQUN2QyxxQkFBTSxPQUFPLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBQTs7b0JBQTFELGdCQUFnQixHQUFHLFNBQXVDO29CQUNoRCxxQkFBTSxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBdEMsT0FBTyxHQUFHLFNBQTRCO29CQUU1QyxzQkFBTyxRQUFRLENBQUM7NEJBQ1osT0FBTyxFQUFFLElBQUk7NEJBQ2IsbUJBQW1CLEVBQUcsVUFBVTs0QkFDaEMsV0FBVyxFQUFHLE9BQU87eUJBQ3hCLENBQUMsRUFBQTs7OztDQUNMO0FBRUQsU0FBZSxnQkFBZ0IsQ0FBQyxLQUFhLEVBQUUsSUFBWTs7Ozs7O29CQUNoRCxLQUFLLEdBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBcEIsQ0FBcUI7b0JBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQStCLEtBQU8sQ0FBQyxDQUFBO29CQUNoQyxxQkFBTSxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBN0MsVUFBVSxHQUFHLFNBQWdDO3lCQUMvQyxVQUFVLEVBQVYsd0JBQVU7b0JBQ08scUJBQU0sTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUE7O29CQUFuRCxRQUFRLEdBQUcsU0FBd0M7b0JBQ3pELHNCQUFPLFFBQVEsQ0FBQzs0QkFDWixPQUFPLEVBQUUsSUFBSTs0QkFDYixlQUFlLEVBQUUsUUFBUTt5QkFDNUIsQ0FBQyxFQUFBO3dCQUVGLHNCQUFPLFFBQVEsQ0FBQzt3QkFDWixPQUFPLEVBQUUsS0FBSzt3QkFDZCxHQUFHLEVBQUcsSUFBSSxLQUFLLENBQUMsc0NBQXNDLENBQUM7cUJBQzFELENBQUMsRUFBQTs7OztDQUVUO0FBRUQsU0FBZSxTQUFTLENBQUMsS0FBWTs7Ozs7O29CQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFjLEtBQUssb0JBQWlCLENBQUMsQ0FBQztvQkFDN0IscUJBQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXpDLFlBQVksR0FBRyxTQUEwQjtvQkFDakIscUJBQU0sR0FBRyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBNUQscUJBQXFCLEdBQUcsU0FBb0M7b0JBQ2xFLHNCQUFPLFFBQVEsQ0FBQzs0QkFDWixPQUFPLEVBQUUsSUFBSTs0QkFDYixZQUFZLGNBQUE7NEJBQ1oscUJBQXFCLHVCQUFBO3lCQUN4QixDQUFDLEVBQUE7Ozs7Q0FDTDtBQUdELFNBQWUsU0FBUyxDQUFDLElBQVc7Ozs7OztvQkFDMUIsS0FBd0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBdEQsS0FBSyxXQUFBLEVBQUUsS0FBSyxXQUFBLEVBQUUsSUFBSSxVQUFBLEVBQUUsTUFBTSxZQUFBLEVBQUUsS0FBSyxXQUFBLENBQXFCO29CQUU5RCxPQUFPLENBQUMsR0FBRyxDQUFDLHlEQUF1RCxLQUFPLENBQUMsQ0FBQTtvQkFJeEQscUJBQU0sTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQTdDLFVBQVUsR0FBRyxTQUFnQztvQkFDN0MsV0FBVyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRyxDQUFDLEVBQUUsQ0FBQztvQkFDdkIscUJBQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQzs0QkFDbkQsSUFBSSxNQUFBLEVBQUUsS0FBSyxPQUFBLEVBQUUsS0FBSyxPQUFBLEVBQUUsTUFBTSxRQUFBOzRCQUMxQixLQUFLLEVBQUcsV0FBVzt5QkFDdEIsQ0FBQyxFQUFBOztvQkFISSxLQUE2QixTQUdqQyxFQUhNLFFBQVEsY0FBQSxFQUFFLFlBQVksa0JBQUE7b0JBSzlCLElBQUksQ0FBQyxnQ0FBdUIsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUN4RCxNQUFNLEtBQUssQ0FBQyx3REFBc0QsWUFBWSxDQUFDLE1BQVEsQ0FBQyxDQUFBO3FCQUMzRjtvQkFFYSxxQkFBTSxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsRUFBQTs7b0JBQXRELE9BQU8sR0FBRyxTQUE0QztvQkFFMUQsc0JBQU8sUUFBUSxDQUFDOzRCQUNaLE9BQU8sRUFBRSxJQUFJOzRCQUNiLElBQUksRUFBRyxPQUFPOzRCQUNkLFFBQVEsRUFBRSxRQUFRLENBQUMsRUFBRTs0QkFDckIsY0FBYyxFQUFFLFlBQVksQ0FBQyxFQUFFO3lCQUNsQyxDQUFDLEVBQUE7Ozs7Q0FDTDtBQUVELFNBQWUsU0FBUyxDQUFDLEtBQWEsRUFBRSxJQUFXOzs7Ozs7O29CQUVuQyxLQUFBLDBCQUFlLENBQUMsSUFBSSxDQUFDLENBQUE7OzZCQUNwQiw0QkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBN0Isd0JBQTRCOzZCQUU1Qiw0QkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBaEMsd0JBQStCOzs7d0JBRHpCLHFCQUFNLGNBQWMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUE7d0JBQXhDLHNCQUFPLFNBQWlDLEVBQUE7d0JBRWpDLHFCQUFNLGdCQUFnQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBQTt3QkFBMUMsc0JBQU8sU0FBbUMsRUFBQTt3QkFHMUMsc0JBQU8sUUFBUSxDQUFDO3dCQUNaLE9BQU8sRUFBQyxLQUFLO3dCQUNiLEdBQUcsRUFBQyxFQUFDLE9BQU8sRUFBRSw4RUFBOEUsRUFBQztxQkFDaEcsQ0FBQyxFQUFBOzs7O29CQUdWLHNCQUFPLFFBQVEsQ0FBQzs0QkFDWixPQUFPLEVBQUMsS0FBSzs0QkFDYixHQUFHLEVBQUMsS0FBRzt5QkFDVixDQUFDLEVBQUE7Ozs7O0NBSVQ7QUFDRCxrQkFBZTtJQUNYLElBQUksRUFBRSxPQUFPO0lBQ2IsTUFBTSxFQUFFLFNBQVM7SUFDakIsTUFBTSxFQUFFLFNBQVM7SUFDakIsTUFBTSxFQUFFLFNBQVM7Q0FDcEIsQ0FBQSJ9