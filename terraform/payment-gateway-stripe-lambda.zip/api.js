"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __importDefault(require("./services"));
var stripe_1 = require("./services/stripe");
var cognito = services_1.default.cognito, stripe = services_1.default.stripe, sns = services_1.default.sns;
var validate_1 = require("./validate");
var responses_1 = require("./responses");
function apiCreate(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, email, plans, name, coupon, token, validToken, allowedPlan, _b, customer, subscription, newUser, err_1;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = JSON.parse(body), email = _a.email, plans = _a.plans, name = _a.name, coupon = _a.coupon, token = _a.token;
                    console.log("Creating customer, subscription, & Cognito acct for " + email);
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 5, , 6]);
                    return [4 /*yield*/, stripe.isTokenValid(token)];
                case 2:
                    validToken = _c.sent();
                    allowedPlan = validToken ? plans : { standard: 1 };
                    return [4 /*yield*/, stripe.create({
                            name: name, email: email, token: token, coupon: coupon,
                            plans: allowedPlan
                        })];
                case 3:
                    _b = _c.sent(), customer = _b.customer, subscription = _b.subscription;
                    if (!stripe_1.ValidSubscriptionStates.includes(subscription.status)) {
                        throw Error("Subscription failed because subscription status is " + subscription.status);
                    }
                    return [4 /*yield*/, cognito.createUser(email, allowedPlan)];
                case 4:
                    newUser = _c.sent();
                    return [2 /*return*/, responses_1.successResponse({
                            user: newUser,
                            stripeId: customer.id,
                            subscriptionId: subscription.id
                        })];
                case 5:
                    err_1 = _c.sent();
                    return [2 /*return*/, responses_1.unexpectedErrorResponse({ message: err_1.message })];
                case 6: return [2 /*return*/];
            }
        });
    });
}
function apiRead(email) {
    return __awaiter(this, void 0, void 0, function () {
        var user, stripeData, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    console.log("Reading user data for " + email);
                    return [4 /*yield*/, cognito.getUser(email)];
                case 1:
                    user = _b.sent();
                    if (!user) return [3 /*break*/, 3];
                    return [4 /*yield*/, stripe.read(email)];
                case 2:
                    _a = _b.sent();
                    return [3 /*break*/, 4];
                case 3:
                    _a = {};
                    _b.label = 4;
                case 4:
                    stripeData = _a;
                    return [2 /*return*/, responses_1.successResponse(__assign({ user: user }, stripeData))];
            }
        });
    });
}
function apiCancel(email) {
    return __awaiter(this, void 0, void 0, function () {
        var cancelledSub, cancelledNotification;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Cancelling " + email + "'s subscription");
                    return [4 /*yield*/, stripe.cancel(email)];
                case 1:
                    cancelledSub = _a.sent();
                    return [4 /*yield*/, sns.publishCancellation(email)];
                case 2:
                    cancelledNotification = _a.sent();
                    return [2 /*return*/, responses_1.successResponse({
                            cancelledSub: cancelledSub,
                            cancelledNotification: cancelledNotification
                        })];
            }
        });
    });
}
function apiUpdate(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, err_2;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 7, , 8]);
                    _a = validate_1.matchUpdateBody(body);
                    switch (_a) {
                        case validate_1.UpdateUserActions.UpdatePlan: return [3 /*break*/, 1];
                        case validate_1.UpdateUserActions.UpdatePayment: return [3 /*break*/, 3];
                    }
                    return [3 /*break*/, 5];
                case 1: return [4 /*yield*/, apiUpdateDapps(email, body)];
                case 2: return [2 /*return*/, _b.sent()];
                case 3: return [4 /*yield*/, apiUpdatePayment(email, body)];
                case 4: return [2 /*return*/, _b.sent()];
                case 5: return [2 /*return*/, responses_1.userErrorResponse({
                        message: "PUT body did not match shape for updating dapp allotments or payment source."
                    })];
                case 6: return [3 /*break*/, 8];
                case 7:
                    err_2 = _b.sent();
                    return [2 /*return*/, responses_1.unexpectedErrorResponse(err_2)];
                case 8: return [2 /*return*/];
            }
        });
    });
}
function apiUpdateDapps(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var plans, updatedSub, updateDappResult, newUser;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    plans = JSON.parse(body).plans;
                    console.log("Updating dapp counts for " + email);
                    return [4 /*yield*/, stripe.updateSubscription(email, plans)];
                case 1:
                    updatedSub = _a.sent();
                    return [4 /*yield*/, cognito.updateDapps(email, plans)];
                case 2:
                    updateDappResult = _a.sent();
                    return [4 /*yield*/, cognito.getUser(email)];
                case 3:
                    newUser = _a.sent();
                    return [2 /*return*/, responses_1.successResponse({
                            updatedSubscription: updatedSub,
                            updatedUser: newUser
                        })];
            }
        });
    });
}
function apiUpdatePayment(email, body) {
    return __awaiter(this, void 0, void 0, function () {
        var token, validToken, customer, responseData, invoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    token = JSON.parse(body).token;
                    console.log("Updating payment source for " + email);
                    return [4 /*yield*/, stripe.isTokenValid(token)];
                case 1:
                    validToken = _a.sent();
                    if (!validToken) return [3 /*break*/, 4];
                    return [4 /*yield*/, stripe.updatePayment(email, token)];
                case 2:
                    customer = _a.sent();
                    responseData = {
                        updatedCustomer: customer
                    };
                    return [4 /*yield*/, stripe.retryLatestUnpaid(email)];
                case 3:
                    invoice = _a.sent();
                    if (invoice) {
                        responseData.retriedInvoice = invoice;
                        console.log("Found a past_due invoice and recharged it with new payment source.");
                    }
                    return [2 /*return*/, responses_1.successResponse(responseData)];
                case 4: return [2 /*return*/, responses_1.userErrorResponse({ message: 'Provided Stripe token was not valid.' })];
            }
        });
    });
}
exports.default = {
    read: apiRead,
    update: apiUpdate,
    create: apiCreate,
    cancel: apiCancel
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx3REFBa0M7QUFDbEMsNENBQStFO0FBQ3ZFLElBQUEsb0NBQU8sRUFBRSxrQ0FBTSxFQUFFLDRCQUFHLENBQWM7QUFDMUMsdUNBQStEO0FBQy9ELHlDQUEwRjtBQUUxRixTQUFlLFNBQVMsQ0FBQyxJQUFZOzs7Ozs7b0JBQzNCLEtBQXdDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQXRELEtBQUssV0FBQSxFQUFFLEtBQUssV0FBQSxFQUFFLElBQUksVUFBQSxFQUFFLE1BQU0sWUFBQSxFQUFFLEtBQUssV0FBQSxDQUFxQjtvQkFFOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5REFBdUQsS0FBTyxDQUFDLENBQUE7Ozs7b0JBS3BELHFCQUFNLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUE3QyxVQUFVLEdBQUcsU0FBZ0M7b0JBQzdDLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUM7b0JBQ3RCLHFCQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUM7NEJBQ25ELElBQUksTUFBQSxFQUFFLEtBQUssT0FBQSxFQUFFLEtBQUssT0FBQSxFQUFFLE1BQU0sUUFBQTs0QkFDMUIsS0FBSyxFQUFFLFdBQVc7eUJBQ3JCLENBQUMsRUFBQTs7b0JBSEksS0FBNkIsU0FHakMsRUFITSxRQUFRLGNBQUEsRUFBRSxZQUFZLGtCQUFBO29CQUs5QixJQUFJLENBQUMsZ0NBQXVCLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDeEQsTUFBTSxLQUFLLENBQUMsd0RBQXNELFlBQVksQ0FBQyxNQUFRLENBQUMsQ0FBQTtxQkFDM0Y7b0JBRWEscUJBQU0sT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLEVBQUE7O29CQUF0RCxPQUFPLEdBQUcsU0FBNEM7b0JBRTFELHNCQUFPLDJCQUFlLENBQUM7NEJBQ25CLElBQUksRUFBRSxPQUFPOzRCQUNiLFFBQVEsRUFBRSxRQUFRLENBQUMsRUFBRTs0QkFDckIsY0FBYyxFQUFFLFlBQVksQ0FBQyxFQUFFO3lCQUNsQyxDQUFDLEVBQUE7OztvQkFFRixzQkFBTyxtQ0FBdUIsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBQTs7Ozs7Q0FFL0Q7QUFFRCxTQUFlLE9BQU8sQ0FBQyxLQUFhOzs7Ozs7b0JBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQXlCLEtBQU8sQ0FBQyxDQUFDO29CQUNqQyxxQkFBTSxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBbkMsSUFBSSxHQUFHLFNBQTRCO3lCQUN0QixJQUFJLEVBQUosd0JBQUk7b0JBQUcscUJBQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXhCLEtBQUEsU0FBd0IsQ0FBQTs7O29CQUFHLEtBQUEsRUFBRSxDQUFBOzs7b0JBQWpELFVBQVUsS0FBdUM7b0JBQ3ZELHNCQUFPLDJCQUFlLFlBQUcsSUFBSSxNQUFBLElBQUssVUFBVSxFQUFHLEVBQUE7Ozs7Q0FDbEQ7QUFFRCxTQUFlLFNBQVMsQ0FBQyxLQUFhOzs7Ozs7b0JBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWMsS0FBSyxvQkFBaUIsQ0FBQyxDQUFDO29CQUM3QixxQkFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsWUFBWSxHQUFHLFNBQTBCO29CQUNqQixxQkFBTSxHQUFHLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUE1RCxxQkFBcUIsR0FBRyxTQUFvQztvQkFDbEUsc0JBQU8sMkJBQWUsQ0FBQzs0QkFDbkIsWUFBWSxjQUFBOzRCQUNaLHFCQUFxQix1QkFBQTt5QkFDeEIsQ0FBQyxFQUFBOzs7O0NBQ0w7QUFFRCxTQUFlLFNBQVMsQ0FBQyxLQUFhLEVBQUUsSUFBWTs7Ozs7OztvQkFFcEMsS0FBQSwwQkFBZSxDQUFDLElBQUksQ0FBQyxDQUFBOzs2QkFDcEIsNEJBQWlCLENBQUMsVUFBVSxDQUFDLENBQTdCLHdCQUE0Qjs2QkFFNUIsNEJBQWlCLENBQUMsYUFBYSxDQUFDLENBQWhDLHdCQUErQjs7O3dCQUR6QixxQkFBTSxjQUFjLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFBO3dCQUF4QyxzQkFBTyxTQUFpQyxFQUFBO3dCQUVqQyxxQkFBTSxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUE7d0JBQTFDLHNCQUFPLFNBQW1DLEVBQUE7d0JBRzFDLHNCQUFPLDZCQUFpQixDQUFDO3dCQUNyQixPQUFPLEVBQUUsOEVBQThFO3FCQUMxRixDQUFDLEVBQUE7Ozs7b0JBR1Ysc0JBQU8sbUNBQXVCLENBQUMsS0FBRyxDQUFDLEVBQUE7Ozs7O0NBRTFDO0FBR0QsU0FBZSxjQUFjLENBQUMsS0FBYSxFQUFFLElBQVk7Ozs7OztvQkFDN0MsS0FBSyxHQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQXJCLENBQXNCO29CQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE0QixLQUFPLENBQUMsQ0FBQTtvQkFDN0IscUJBQU0sTUFBTSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBQTs7b0JBQTFELFVBQVUsR0FBRyxTQUE2QztvQkFDdkMscUJBQU0sT0FBTyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUE7O29CQUExRCxnQkFBZ0IsR0FBRyxTQUF1QztvQkFDaEQscUJBQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXRDLE9BQU8sR0FBRyxTQUE0QjtvQkFFNUMsc0JBQU8sMkJBQWUsQ0FBQzs0QkFDbkIsbUJBQW1CLEVBQUUsVUFBVTs0QkFDL0IsV0FBVyxFQUFFLE9BQU87eUJBQ3ZCLENBQUMsRUFBQTs7OztDQUNMO0FBT0QsU0FBZSxnQkFBZ0IsQ0FBQyxLQUFhLEVBQUUsSUFBWTs7Ozs7O29CQUMvQyxLQUFLLEdBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBckIsQ0FBc0I7b0JBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQStCLEtBQU8sQ0FBQyxDQUFBO29CQUNoQyxxQkFBTSxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBN0MsVUFBVSxHQUFHLFNBQWdDO3lCQUMvQyxVQUFVLEVBQVYsd0JBQVU7b0JBQ08scUJBQU0sTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUE7O29CQUFuRCxRQUFRLEdBQUcsU0FBd0M7b0JBQ3JELFlBQVksR0FBOEI7d0JBQzFDLGVBQWUsRUFBRSxRQUFRO3FCQUM1QixDQUFBO29CQUNlLHFCQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQS9DLE9BQU8sR0FBRyxTQUFxQztvQkFDckQsSUFBSSxPQUFPLEVBQUU7d0JBQ1QsWUFBWSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7d0JBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0VBQW9FLENBQUMsQ0FBQztxQkFDckY7b0JBQ0Qsc0JBQU8sMkJBQWUsQ0FBQyxZQUFZLENBQUMsRUFBQzt3QkFFckMsc0JBQU8sNkJBQWlCLENBQUMsRUFBRSxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsQ0FBQyxFQUFBOzs7O0NBRXBGO0FBRUQsa0JBQWU7SUFDWCxJQUFJLEVBQUUsT0FBTztJQUNiLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0NBQ3BCLENBQUEifQ==