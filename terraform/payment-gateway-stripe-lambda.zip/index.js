'use strict';
const api, { response } = require('./api');
const webhooks = require('./webhooks');

exports.managementHandler = async (event) => {

    // Auto-return success for CORS pre-flight OPTIONS requests
    if (event.httpMethod.toLowerCase() == 'options'){
        // Note the empty body, no actual response data required
        return response({});
    }
    
    if (event.pathParameters == null){
        throw new Error("malformed path proxy");
    }

    let method = event.pathParameters.proxy;
    let callerEmail = event.requestContext.authorizer.claims.email;
    let body = {};
    if (event.body) body = JSON.parse(event.body);
    let responsePromise = (function(method) {
        switch(method) {
            case 'read':
                return api.read(callerEmail);
            case 'update':
                return api.update(callerEmail, body);
            case 'cancel':
                return api.cancel(callerEmail);
            default:
                throw new Error("Unrecognized method name ".concat(method));
        }
    })(method);

    let response = await responsePromise;
    return response;
};

exports.webhookHandler = async (event) => {
    // Auto-return success for CORS pre-flight OPTIONS requests
    if (event.httpMethod.toLowerCase() == 'options'){
        // Note the empty body, no actual response data required
        return response({});
    }
    return await webhooks.failedPayment(event);
}

exports.signupHandler = async (event) => {
    // Auto-return success for CORS pre-flight OPTIONS requests
    if (event.httpMethod.toLowerCase() == 'options'){
        // Note the empty body, no actual response data required
        return response({});
    }
    return await api.create(event.body);
}