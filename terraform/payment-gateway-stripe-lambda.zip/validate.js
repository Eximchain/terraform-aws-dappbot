"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function bodyHas(body, propertyNames) {
    return propertyNames.every(function (name) { return body.hasOwnProperty(name); });
}
var HTTPMethods;
(function (HTTPMethods) {
    HTTPMethods["GET"] = "GET";
    HTTPMethods["OPTIONS"] = "OPTIONS";
    HTTPMethods["PUT"] = "PUT";
    HTTPMethods["POST"] = "POST";
    HTTPMethods["DELETE"] = "DELETE";
})(HTTPMethods = exports.HTTPMethods || (exports.HTTPMethods = {}));
function isHTTPMethod(method, HTTPMethod) {
    return method.toUpperCase() === HTTPMethod;
}
exports.isHTTPMethod = isHTTPMethod;
var UpdateParamNames;
(function (UpdateParamNames) {
    UpdateParamNames["Plans"] = "plans";
    UpdateParamNames["Token"] = "token";
})(UpdateParamNames = exports.UpdateParamNames || (exports.UpdateParamNames = {}));
exports.UpdateUserParams = {
    UpdatePlan: [UpdateParamNames.Plans],
    UpdatePayment: [UpdateParamNames.Token]
};
var UpdateUserActions;
(function (UpdateUserActions) {
    UpdateUserActions["UpdatePlan"] = "UPDATE_PLAN";
    UpdateUserActions["UpdatePayment"] = "UPDATE_PAYMENT";
})(UpdateUserActions = exports.UpdateUserActions || (exports.UpdateUserActions = {}));
function matchUpdateBody(body) {
    var bodyParsed = JSON.parse(body);
    if (bodyHas(bodyParsed, exports.UpdateUserParams.UpdatePlan)) {
        return UpdateUserActions.UpdatePlan;
    }
    else if (bodyHas(bodyParsed, exports.UpdateUserParams.UpdatePayment)) {
        return UpdateUserActions.UpdatePayment;
    }
    else {
        return false;
    }
}
exports.matchUpdateBody = matchUpdateBody;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLE9BQU8sQ0FBQyxJQUFXLEVBQUUsYUFBc0I7SUFDbEQsT0FBTyxhQUFhLENBQUMsS0FBSyxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBekIsQ0FBeUIsQ0FBQyxDQUFBO0FBQy9ELENBQUM7QUFFRCxJQUFZLFdBTVg7QUFORCxXQUFZLFdBQVc7SUFDckIsMEJBQVcsQ0FBQTtJQUNYLGtDQUFtQixDQUFBO0lBQ25CLDBCQUFXLENBQUE7SUFDWCw0QkFBYSxDQUFBO0lBQ2IsZ0NBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQU5XLFdBQVcsR0FBWCxtQkFBVyxLQUFYLG1CQUFXLFFBTXRCO0FBRUQsU0FBZ0IsWUFBWSxDQUFDLE1BQWEsRUFBRSxVQUFzQjtJQUNoRSxPQUFPLE1BQU0sQ0FBQyxXQUFXLEVBQUUsS0FBSyxVQUFVLENBQUM7QUFDN0MsQ0FBQztBQUZELG9DQUVDO0FBRUQsSUFBWSxnQkFHWDtBQUhELFdBQVksZ0JBQWdCO0lBQzFCLG1DQUFlLENBQUE7SUFDZixtQ0FBZSxDQUFBO0FBQ2pCLENBQUMsRUFIVyxnQkFBZ0IsR0FBaEIsd0JBQWdCLEtBQWhCLHdCQUFnQixRQUczQjtBQUVZLFFBQUEsZ0JBQWdCLEdBQUc7SUFDOUIsVUFBVSxFQUFHLENBQUUsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0lBQ3RDLGFBQWEsRUFBRSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQztDQUN4QyxDQUFBO0FBRUQsSUFBWSxpQkFHWDtBQUhELFdBQVksaUJBQWlCO0lBQzNCLCtDQUEwQixDQUFBO0lBQzFCLHFEQUFnQyxDQUFBO0FBQ2xDLENBQUMsRUFIVyxpQkFBaUIsR0FBakIseUJBQWlCLEtBQWpCLHlCQUFpQixRQUc1QjtBQUNELFNBQWdCLGVBQWUsQ0FBQyxJQUFXO0lBQ3pDLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDbkMsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFLHdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFDO1FBQ25ELE9BQU8saUJBQWlCLENBQUMsVUFBVSxDQUFBO0tBQ3BDO1NBQU0sSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFLHdCQUFnQixDQUFDLGFBQWEsQ0FBQyxFQUFDO1FBQzdELE9BQU8saUJBQWlCLENBQUMsYUFBYSxDQUFBO0tBQ3ZDO1NBQU07UUFDTCxPQUFPLEtBQUssQ0FBQztLQUNkO0FBQ0gsQ0FBQztBQVRELDBDQVNDIn0=