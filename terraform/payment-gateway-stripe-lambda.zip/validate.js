"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function bodyHas(body, propertyNames) {
    return propertyNames.every(function (name) { return body.hasOwnProperty(name); });
}
var UpdateParamNames;
(function (UpdateParamNames) {
    UpdateParamNames["Plans"] = "plans";
    UpdateParamNames["Token"] = "token";
})(UpdateParamNames = exports.UpdateParamNames || (exports.UpdateParamNames = {}));
exports.UpdateUserParams = {
    UpdatePlan: [UpdateParamNames.Plans],
    UpdatePayment: [UpdateParamNames.Token]
};
var UpdateUserActions;
(function (UpdateUserActions) {
    UpdateUserActions["UpdatePlan"] = "UPDATE_PLAN";
    UpdateUserActions["UpdatePayment"] = "UPDATE_PAYMENT";
})(UpdateUserActions = exports.UpdateUserActions || (exports.UpdateUserActions = {}));
function matchUpdateBody(body) {
    var bodyParsed = JSON.parse(body);
    if (bodyHas(bodyParsed, exports.UpdateUserParams.UpdatePlan)) {
        return UpdateUserActions.UpdatePlan;
    }
    else if (bodyHas(bodyParsed, exports.UpdateUserParams.UpdatePayment)) {
        return UpdateUserActions.UpdatePayment;
    }
    else {
        return false;
    }
}
exports.matchUpdateBody = matchUpdateBody;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLE9BQU8sQ0FBQyxJQUFXLEVBQUUsYUFBc0I7SUFDbEQsT0FBTyxhQUFhLENBQUMsS0FBSyxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBekIsQ0FBeUIsQ0FBQyxDQUFBO0FBQy9ELENBQUM7QUFFRCxJQUFZLGdCQUdYO0FBSEQsV0FBWSxnQkFBZ0I7SUFDMUIsbUNBQWUsQ0FBQTtJQUNmLG1DQUFlLENBQUE7QUFDakIsQ0FBQyxFQUhXLGdCQUFnQixHQUFoQix3QkFBZ0IsS0FBaEIsd0JBQWdCLFFBRzNCO0FBRVksUUFBQSxnQkFBZ0IsR0FBRztJQUM5QixVQUFVLEVBQUcsQ0FBRSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7SUFDdEMsYUFBYSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0NBQ3hDLENBQUE7QUFFRCxJQUFZLGlCQUdYO0FBSEQsV0FBWSxpQkFBaUI7SUFDM0IsK0NBQTBCLENBQUE7SUFDMUIscURBQWdDLENBQUE7QUFDbEMsQ0FBQyxFQUhXLGlCQUFpQixHQUFqQix5QkFBaUIsS0FBakIseUJBQWlCLFFBRzVCO0FBQ0QsU0FBZ0IsZUFBZSxDQUFDLElBQVc7SUFDekMsSUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUNuQyxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUUsd0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUM7UUFDbkQsT0FBTyxpQkFBaUIsQ0FBQyxVQUFVLENBQUE7S0FDcEM7U0FBTSxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUUsd0JBQWdCLENBQUMsYUFBYSxDQUFDLEVBQUM7UUFDN0QsT0FBTyxpQkFBaUIsQ0FBQyxhQUFhLENBQUE7S0FDdkM7U0FBTTtRQUNMLE9BQU8sS0FBSyxDQUFDO0tBQ2Q7QUFDSCxDQUFDO0FBVEQsMENBU0MifQ==