
const AWS = require('aws-sdk');
const awsRegion = "us-east-1";
const _cognitoUserPoolId = "us-east-1_VwUpL0eus"


AWS.config.update({region: awsRegion});
const userPoolId = _cognitoUserPoolId;

module.exports = { 
    AWS, awsRegion, userPoolId
};