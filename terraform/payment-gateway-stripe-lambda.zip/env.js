
const AWS = require('aws-sdk');

// Provided automagically by AWS
const awsRegion = process.env.AWS_REGION;

// Provided by Terraform
const cognitoUserPoolId = process.env.COGNITO_USER_POOL;
const stripeKey = process.env.STRIPE_API_KEY;
const targetSnsARN = process.env.TARGET_SNS_ARN;

const PLAN_IDS = {
    ENTHUSIAST : '',
    PROJECT : '',
    STARTUP : ''
}

AWS.config.update({region: awsRegion});

const failedPaymentWebhookId = 'whsec_Mp28CyzpSKBsdeeetcSFHu4QViwYngY4';

module.exports = { 
    AWS, awsRegion, cognitoUserPoolId, stripeKey, PLAN_IDS,
    failedPaymentWebhookId, targetSnsARN
};