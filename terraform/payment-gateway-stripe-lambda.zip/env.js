"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var aws_sdk_1 = __importDefault(require("aws-sdk"));
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
// Provided by Terraform
exports.cognitoUserPoolId = process.env.COGNITO_USER_POOL;
exports.stripeKey = process.env.STRIPE_API_KEY;
exports.stripeWebhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
exports.snsTopicARN = process.env.SNS_TOPIC_ARN;
exports.sendgridKey = process.env.SENDGRID_API_KEY;
exports.managerDNS = process.env.MANAGER_SPA_DNS;
exports.eximchainAccountsOnly = process.env.EXIMCHAIN_ACCOUNTS_ONLY === 'true' ? true : false;
aws_sdk_1.default.config.update({ region: exports.awsRegion });
exports.AWS = aws_sdk_1.default;
exports.default = {
    AWS: exports.AWS, awsRegion: exports.awsRegion, cognitoUserPoolId: exports.cognitoUserPoolId, stripeKey: exports.stripeKey,
    stripeWebhookSecret: exports.stripeWebhookSecret, snsTopicARN: exports.snsTopicARN
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLG9EQUFzQztBQUV0QyxnQ0FBZ0M7QUFDbkIsUUFBQSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFFaEQsd0JBQXdCO0FBQ1gsUUFBQSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUEyQixDQUFDO0FBQzVELFFBQUEsU0FBUyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBd0IsQ0FBQztBQUNqRCxRQUFBLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQStCLENBQUM7QUFDbEUsUUFBQSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUF1QixDQUFDO0FBQ2xELFFBQUEsV0FBVyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQTBCLENBQUM7QUFDckQsUUFBQSxVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUF5QixDQUFDO0FBQ25ELFFBQUEscUJBQXFCLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBRW5HLGlCQUFlLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLE1BQU0sRUFBRSxpQkFBUyxFQUFDLENBQUMsQ0FBQztBQUN0QyxRQUFBLEdBQUcsR0FBRyxpQkFBZSxDQUFDO0FBR25DLGtCQUFlO0lBQ1gsR0FBRyxhQUFBLEVBQUUsU0FBUyxtQkFBQSxFQUFFLGlCQUFpQiwyQkFBQSxFQUFFLFNBQVMsbUJBQUE7SUFDNUMsbUJBQW1CLDZCQUFBLEVBQUUsV0FBVyxxQkFBQTtDQUNuQyxDQUFDIn0=