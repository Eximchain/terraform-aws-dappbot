"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
// FUNCTIONS FOR MARSHALLING RESPONSES
var HTTPMethods;
(function (HTTPMethods) {
    HTTPMethods["GET"] = "GET";
    HTTPMethods["OPTIONS"] = "OPTIONS";
    HTTPMethods["PUT"] = "PUT";
    HTTPMethods["POST"] = "POST";
    HTTPMethods["DELETE"] = "DELETE";
})(HTTPMethods = exports.HTTPMethods || (exports.HTTPMethods = {}));
function response(body, opts) {
    var responseCode = 200;
    // Override response code based on opts
    if (opts.isErr) {
        if (opts.errorResponseCode) {
            responseCode = opts.errorResponseCode;
        }
        else {
            responseCode = 500;
        }
    }
    else if (opts.isCreate) {
        responseCode = 201;
    }
    else if (opts.isRead) {
        if (body.hasOwnProperty("exists") && !body.exists) {
            // Dapp Not Found
            // This looks like a success response but uses error code 404
            responseCode = 404;
        }
    }
    var responseHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Authorization,Content-Type'
    };
    var dataField = opts.isErr ? {} : body;
    var errField = opts.isErr ? body : null;
    var responseBody = {
        data: dataField,
        err: errField
    };
    return {
        statusCode: responseCode,
        headers: responseHeaders,
        body: JSON.stringify(responseBody)
    };
}
function successResponse(body, opts) {
    if (opts === void 0) { opts = { isCreate: false }; }
    var successOpt = { isErr: false };
    var callOpts = __assign({}, opts, successOpt);
    return response(body, callOpts);
}
exports.successResponse = successResponse;
function errorResponse(body, opts) {
    if (opts === void 0) { opts = { isCreate: false }; }
    var errorOpt = { isErr: true };
    var callOpts = __assign({}, opts, errorOpt);
    return response(body, callOpts);
}
exports.errorResponse = errorResponse;
function userErrorResponse(body, opts) {
    if (opts === void 0) { opts = { isCreate: false }; }
    var errorOpt = { isErr: true, errorResponseCode: 400 };
    var callOpts = __assign({}, opts, errorOpt);
    return response(body, callOpts);
}
exports.userErrorResponse = userErrorResponse;
function unexpectedErrorResponse(body, opts) {
    if (opts === void 0) { opts = { isCreate: false }; }
    var errorOpt = { isErr: true, errorResponseCode: 500 };
    var callOpts = __assign({}, opts, errorOpt);
    return response(body, callOpts);
}
exports.unexpectedErrorResponse = unexpectedErrorResponse;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzcG9uc2VzLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInJlc3BvbnNlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUEsc0NBQXNDO0FBQ3RDLElBQVksV0FNWDtBQU5ELFdBQVksV0FBVztJQUNyQiwwQkFBVyxDQUFBO0lBQ1gsa0NBQW1CLENBQUE7SUFDbkIsMEJBQVcsQ0FBQTtJQUNYLDRCQUFhLENBQUE7SUFDYixnQ0FBaUIsQ0FBQTtBQUNuQixDQUFDLEVBTlcsV0FBVyxHQUFYLG1CQUFXLEtBQVgsbUJBQVcsUUFNdEI7QUFTRCxTQUFTLFFBQVEsQ0FBQyxJQUFRLEVBQUUsSUFBb0I7SUFDOUMsSUFBSSxZQUFZLEdBQUcsR0FBRyxDQUFDO0lBQ3ZCLHVDQUF1QztJQUN2QyxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7UUFDWixJQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtZQUN4QixZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1NBQ3pDO2FBQU07WUFDSCxZQUFZLEdBQUcsR0FBRyxDQUFDO1NBQ3RCO0tBQ0o7U0FBTSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7UUFDdEIsWUFBWSxHQUFHLEdBQUcsQ0FBQztLQUN0QjtTQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNwQixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQy9DLGlCQUFpQjtZQUNqQiw2REFBNkQ7WUFDN0QsWUFBWSxHQUFHLEdBQUcsQ0FBQztTQUN0QjtLQUNKO0lBRUQsSUFBSSxlQUFlLEdBQUc7UUFDbEIsY0FBYyxFQUFFLGtCQUFrQjtRQUNsQyw2QkFBNkIsRUFBRSxHQUFHO1FBQ2xDLDhCQUE4QixFQUFFLDRCQUE0QjtLQUMvRCxDQUFDO0lBR0YsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDdkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDeEMsSUFBSSxZQUFZLEdBQUc7UUFDZixJQUFJLEVBQUUsU0FBUztRQUNmLEdBQUcsRUFBRSxRQUFRO0tBQ2hCLENBQUM7SUFDRixPQUFPO1FBQ0gsVUFBVSxFQUFFLFlBQVk7UUFDeEIsT0FBTyxFQUFFLGVBQWU7UUFDeEIsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO0tBQ3JDLENBQUE7QUFDSCxDQUFDO0FBRUQsU0FBZ0IsZUFBZSxDQUFDLElBQVEsRUFBRSxJQUFzQztJQUF0QyxxQkFBQSxFQUFBLFNBQXNCLFFBQVEsRUFBRSxLQUFLLEVBQUM7SUFDOUUsSUFBSSxVQUFVLEdBQUcsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUM7SUFDaEMsSUFBSSxRQUFRLGdCQUFPLElBQUksRUFBSyxVQUFVLENBQUMsQ0FBQztJQUN4QyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDbEMsQ0FBQztBQUpELDBDQUlDO0FBRUQsU0FBZ0IsYUFBYSxDQUFDLElBQVEsRUFBRSxJQUFzQztJQUF0QyxxQkFBQSxFQUFBLFNBQXNCLFFBQVEsRUFBRSxLQUFLLEVBQUM7SUFDNUUsSUFBSSxRQUFRLEdBQUcsRUFBQyxLQUFLLEVBQUUsSUFBSSxFQUFDLENBQUM7SUFDN0IsSUFBSSxRQUFRLGdCQUFPLElBQUksRUFBSyxRQUFRLENBQUMsQ0FBQztJQUN0QyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDbEMsQ0FBQztBQUpELHNDQUlDO0FBRUQsU0FBZ0IsaUJBQWlCLENBQUMsSUFBUSxFQUFFLElBQXNDO0lBQXRDLHFCQUFBLEVBQUEsU0FBc0IsUUFBUSxFQUFFLEtBQUssRUFBQztJQUNoRixJQUFJLFFBQVEsR0FBRyxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUcsR0FBRyxFQUFFLENBQUM7SUFDdkQsSUFBSSxRQUFRLGdCQUFPLElBQUksRUFBSyxRQUFRLENBQUMsQ0FBQztJQUN0QyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDbEMsQ0FBQztBQUpELDhDQUlDO0FBRUQsU0FBZ0IsdUJBQXVCLENBQUMsSUFBUSxFQUFFLElBQXNDO0lBQXRDLHFCQUFBLEVBQUEsU0FBc0IsUUFBUSxFQUFFLEtBQUssRUFBQztJQUN0RixJQUFJLFFBQVEsR0FBRyxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUcsR0FBRyxFQUFFLENBQUM7SUFDdkQsSUFBSSxRQUFRLGdCQUFPLElBQUksRUFBSyxRQUFRLENBQUMsQ0FBQztJQUN0QyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDbEMsQ0FBQztBQUpELDBEQUlDIn0=