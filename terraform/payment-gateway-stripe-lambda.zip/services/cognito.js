"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var sns_1 = require("./sns");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function formatUser(user) {
    if (!user)
        return false;
    var Attributes = user.Attributes || user.UserAttributes || [];
    var PreferredMfaSetting = user.PreferredMfaSetting, UserMFASettingList = user.UserMFASettingList, MFAOptions = user.MFAOptions;
    var emailAttr = Attributes.find(function (_a) {
        var Name = _a.Name;
        return Name === 'email';
    });
    return {
        Username: user.Username,
        Email: emailAttr.Value,
        UserAttributes: Attributes.reduce(function (attrObj, attr) {
            attrObj[attr.Name] = attr.Value || '';
            return attrObj;
        }, {}),
        PreferredMfaSetting: PreferredMfaSetting, UserMFASettingList: UserMFASettingList, MFAOptions: MFAOptions
    };
}
function promiseAdminGetUser(cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        var params, user;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        UserPoolId: env_1.cognitoUserPoolId,
                        Username: cognitoUsername
                    };
                    return [4 /*yield*/, cognito.adminGetUser(params).promise()];
                case 1:
                    user = _a.sent();
                    return [2 /*return*/, formatUser(user)];
            }
        });
    });
}
function numDapps(plans, typeOfPlan) {
    var planName = "custom:" + typeOfPlan + "_limit";
    return {
        Name: planName,
        Value: (plans[typeOfPlan] || 0).toString()
    };
}
function promiseUpdateDapps(email, plans) {
    return __awaiter(this, void 0, void 0, function () {
        var params;
        return __generator(this, function (_a) {
            params = {
                "UserAttributes": [
                    numDapps(plans, "standard"),
                    numDapps(plans, "enterprise"),
                    numDapps(plans, "professional")
                ],
                "Username": email,
                "UserPoolId": env_1.cognitoUserPoolId
            };
            return [2 /*return*/, cognito.adminUpdateUserAttributes(params).promise()];
        });
    });
}
exports.promiseUpdateDapps = promiseUpdateDapps;
function generatePassword(length) {
    var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
}
function promiseAdminCreateUser(email, plans) {
    return __awaiter(this, void 0, void 0, function () {
        var params, createResult;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    params = {
                        UserPoolId: env_1.cognitoUserPoolId,
                        Username: email,
                        DesiredDeliveryMediums: [
                            "EMAIL"
                        ],
                        ForceAliasCreation: false,
                        TemporaryPassword: generatePassword(10),
                        UserAttributes: [
                            {
                                Name: 'email',
                                Value: email
                            },
                            {
                                Name: 'email_verified',
                                Value: 'true'
                            },
                            numDapps(plans, "standard"),
                            numDapps(plans, "enterprise"),
                            numDapps(plans, "professional"),
                            {
                                Name: 'custom:payment_status',
                                Value: sns_1.PaymentStatus.ACTIVE
                            }
                        ]
                    };
                    return [4 /*yield*/, cognito.adminCreateUser(params).promise()];
                case 1:
                    createResult = _a.sent();
                    return [2 /*return*/, formatUser(createResult.User)];
            }
        });
    });
}
exports.promiseAdminCreateUser = promiseAdminCreateUser;
exports.default = {
    createUser: promiseAdminCreateUser,
    updateDapps: promiseUpdateDapps,
    getUser: promiseAdminGetUser
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw4QkFBZ0Q7QUFFaEQsNkJBQXNDO0FBR3RDLElBQU0sT0FBTyxHQUFHLElBQUksU0FBRyxDQUFDLDhCQUE4QixDQUFDLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7QUFzQnJGLFNBQVMsVUFBVSxDQUFDLElBQThFO0lBQzlGLElBQUksQ0FBQyxJQUFJO1FBQUUsT0FBTyxLQUFLLENBQUM7SUFDeEIsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQztJQUN0RCxJQUFBLDhDQUFtQixFQUFFLDRDQUFrQixFQUFFLDRCQUFVLENBQVU7SUFDckUsSUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFDLEVBQVE7WUFBTixjQUFJO1FBQU8sT0FBQSxJQUFJLEtBQUssT0FBTztJQUFoQixDQUFnQixDQUErQixDQUFDO0lBQ2hHLE9BQU87UUFDSCxRQUFRLEVBQUcsSUFBSSxDQUFDLFFBQWtCO1FBQ2xDLEtBQUssRUFBRyxTQUFTLENBQUMsS0FBZTtRQUNqQyxjQUFjLEVBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFDLE9BQU8sRUFBRSxJQUFJO1lBQzdDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDdEMsT0FBTyxPQUFPLENBQUE7UUFDbEIsQ0FBQyxFQUFFLEVBQXNCLENBQUM7UUFDMUIsbUJBQW1CLHFCQUFBLEVBQUUsa0JBQWtCLG9CQUFBLEVBQUUsVUFBVSxZQUFBO0tBQ3ZDLENBQUE7QUFDcEIsQ0FBQztBQUVELFNBQWUsbUJBQW1CLENBQUMsZUFBdUI7Ozs7OztvQkFDbEQsTUFBTSxHQUFHO3dCQUNULFVBQVUsRUFBRSx1QkFBaUI7d0JBQzdCLFFBQVEsRUFBRSxlQUFlO3FCQUM1QixDQUFDO29CQUNXLHFCQUFNLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUE7O29CQUFuRCxJQUFJLEdBQUcsU0FBNEM7b0JBQ3pELHNCQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQzs7OztDQUMzQjtBQUVELFNBQVMsUUFBUSxDQUFDLEtBQWtCLEVBQUUsVUFBMkI7SUFDN0QsSUFBSSxRQUFRLEdBQUcsWUFBVSxVQUFVLFdBQVEsQ0FBQTtJQUMzQyxPQUFPO1FBQ0gsSUFBSSxFQUFFLFFBQVE7UUFDZCxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO0tBQzdDLENBQUE7QUFDTCxDQUFDO0FBRUQsU0FBc0Isa0JBQWtCLENBQUMsS0FBYSxFQUFFLEtBQWtCOzs7O1lBQ2xFLE1BQU0sR0FBRztnQkFDVCxnQkFBZ0IsRUFBRTtvQkFDZCxRQUFRLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQztvQkFDM0IsUUFBUSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUM7b0JBQzdCLFFBQVEsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDO2lCQUNsQztnQkFDRCxVQUFVLEVBQUUsS0FBSztnQkFDakIsWUFBWSxFQUFFLHVCQUFpQjthQUNsQyxDQUFBO1lBQ0Qsc0JBQU8sT0FBTyxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFDOzs7Q0FDOUQ7QUFYRCxnREFXQztBQUVELFNBQVMsZ0JBQWdCLENBQUMsTUFBYztJQUNwQyxJQUFJLE9BQU8sR0FBRyxnRUFBZ0UsRUFDMUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztJQUNoQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1FBQ2pELE1BQU0sSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDM0Q7SUFDRCxPQUFPLE1BQU0sQ0FBQztBQUNsQixDQUFDO0FBRUQsU0FBc0Isc0JBQXNCLENBQUMsS0FBYSxFQUFFLEtBQWtCOzs7Ozs7b0JBQ3RFLE1BQU0sR0FBRzt3QkFDVCxVQUFVLEVBQUUsdUJBQWlCO3dCQUM3QixRQUFRLEVBQUUsS0FBSzt3QkFDZixzQkFBc0IsRUFBRTs0QkFDcEIsT0FBTzt5QkFDVjt3QkFDRCxrQkFBa0IsRUFBRSxLQUFLO3dCQUN6QixpQkFBaUIsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUM7d0JBQ3ZDLGNBQWMsRUFBRTs0QkFDWjtnQ0FDSSxJQUFJLEVBQUUsT0FBTztnQ0FDYixLQUFLLEVBQUUsS0FBSzs2QkFDZjs0QkFDRDtnQ0FDSSxJQUFJLEVBQUUsZ0JBQWdCO2dDQUN0QixLQUFLLEVBQUUsTUFBTTs2QkFDaEI7NEJBQ0QsUUFBUSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUM7NEJBQzNCLFFBQVEsQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDOzRCQUM3QixRQUFRLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQzs0QkFDL0I7Z0NBQ0ksSUFBSSxFQUFFLHVCQUF1QjtnQ0FDN0IsS0FBSyxFQUFFLG1CQUFhLENBQUMsTUFBTTs2QkFDOUI7eUJBQ0o7cUJBQ0osQ0FBQTtvQkFFb0IscUJBQU0sT0FBTyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBQTs7b0JBQTlELFlBQVksR0FBRyxTQUErQztvQkFDcEUsc0JBQU8sVUFBVSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBQTs7OztDQUN2QztBQTlCRCx3REE4QkM7QUFLRCxrQkFBZTtJQUNYLFVBQVUsRUFBRSxzQkFBc0I7SUFDbEMsV0FBVyxFQUFFLGtCQUFrQjtJQUMvQixPQUFPLEVBQUUsbUJBQW1CO0NBQy9CLENBQUEifQ==