"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var mail_1 = __importDefault(require("@sendgrid/mail"));
var emails_1 = require("../emails");
var env_1 = require("../env");
var USING_SENDGRID = false;
if (env_1.sendgridKey && env_1.sendgridKey !== "") {
    mail_1.default.setApiKey(env_1.sendgridKey);
    USING_SENDGRID = true;
}
var FROM_ADDRESS = 'dappbot@eximchain.com';
function sendTrialEndEmail(email) {
    return __awaiter(this, void 0, void 0, function () {
        var emailHtml, confirmationParam;
        return __generator(this, function (_a) {
            emailHtml = emails_1.trialEndEmail(env_1.managerDNS);
            confirmationParam = {
                from: FROM_ADDRESS,
                to: email,
                subject: "Your DappBot Trial is Ending Soon, Unless...",
                html: emailHtml
            };
            if (USING_SENDGRID) {
                return [2 /*return*/, mail_1.default.send(confirmationParam)];
            }
            else {
                console.log("No Sendgrid API key loaded, not sending a Trial Ending Soon email to " + email + ".");
                return [2 /*return*/, confirmationParam];
            }
            return [2 /*return*/];
        });
    });
}
exports.sendTrialEndEmail = sendTrialEndEmail;
exports.default = {
    sendTrialEndEmail: sendTrialEndEmail
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZGdyaWQuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvc2VuZGdyaWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHdEQUFvQztBQUNwQyxvQ0FBeUM7QUFDekMsOEJBQWlEO0FBRWpELElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQztBQUUzQixJQUFJLGlCQUFXLElBQUksaUJBQVcsS0FBSyxFQUFFLEVBQUM7SUFDcEMsY0FBTSxDQUFDLFNBQVMsQ0FBQyxpQkFBVyxDQUFDLENBQUM7SUFDOUIsY0FBYyxHQUFHLElBQUksQ0FBQztDQUN2QjtBQUVELElBQU0sWUFBWSxHQUFHLHVCQUF1QixDQUFDO0FBRTdDLFNBQXNCLGlCQUFpQixDQUFDLEtBQVk7Ozs7WUFDOUMsU0FBUyxHQUFHLHNCQUFhLENBQUMsZ0JBQVUsQ0FBQyxDQUFBO1lBQ3JDLGlCQUFpQixHQUFHO2dCQUN0QixJQUFJLEVBQUcsWUFBWTtnQkFDbkIsRUFBRSxFQUFHLEtBQUs7Z0JBQ1YsT0FBTyxFQUFHLDhDQUE4QztnQkFDeEQsSUFBSSxFQUFHLFNBQVM7YUFDakIsQ0FBQTtZQUNELElBQUksY0FBYyxFQUFDO2dCQUNqQixzQkFBTyxjQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUM7YUFDdkM7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQywwRUFBd0UsS0FBSyxNQUFHLENBQUMsQ0FBQztnQkFDOUYsc0JBQU8saUJBQWlCLEVBQUE7YUFDekI7Ozs7Q0FDRjtBQWRELDhDQWNDO0FBRUQsa0JBQWU7SUFDYixpQkFBaUIsbUJBQUE7Q0FDbEIsQ0FBQSJ9