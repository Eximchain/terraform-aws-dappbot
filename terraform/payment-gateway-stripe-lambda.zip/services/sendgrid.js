"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var mail_1 = __importDefault(require("@sendgrid/mail"));
var env_1 = require("../env");
var USING_SENDGRID = false;
if (env_1.sendgridKey && env_1.sendgridKey !== "") {
    mail_1.default.setApiKey(env_1.sendgridKey);
    USING_SENDGRID = true;
}
var FROM_ADDRESS = 'dappbot@eximchain.com';
// The template is on one line so that it doesn't clutter up
// the file.  The only variable inside the template
// is the `managerDNS` so that links are always pointed
// to the correct URL.  If you want to edit this file:
// 
// 1: Copy the string to a new HTML file
// 2: Select all text and use cmd+k+f to reformat
// 3: Make your changes
// 4: Go to Chrome & put the string in a variable*,
//    like let template = `<!DOCTYPE>...`
// 5: Remove all newlines using the regex below:
//    template.replace(/\r?\n|\r/g, '')
// 6: Replace the string below with the new output.
//
// * If you have variables in your template (e.g. ${varName}),
// then before saving in the console, remove the $
// so that Chrome doesn't try to resolve them here. Just
// add the $ back after you remove the newlines.
var trialEndEmail = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"  <html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns=\"http://www.w3.org/1999/xhtml\"><head>  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />  <title>The Eximchain Team</title></head><body  style=\"-webkit-text-size-adjust: none; box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; height: 100%; line-height: 1.4; margin: 0; width: 100% !important;\"  bgcolor=\"#f7f8f9\">  <style type=\"text/css\">    body {      width: 100% !important;      height: 100%;      margin: 0;      line-height: 1.4;      background-color: #fff;      color: #626b76;      -webkit-text-size-adjust: none;    }    @media only screen and (max-width: 600px) {      .email-body_inner {        width: 100% !important;      }      .email-footer {        width: 100% !important;      }    }    @media only screen and (max-width: 500px) {      .button {        width: 100% !important;      }    }  </style> <span class=\"preheader\"    style=\"box-sizing: border-box; display: none !important; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 1px; line-height: 1px; max-height: 0; max-width: 0; mso-hide: all; opacity: 0; overflow: hidden; visibility: hidden;\">Eximchain    - Token Verification</span>  <table class=\"email-wrapper\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"    style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin: 0; padding: 0; width: 100%;\"    bgcolor=\"#f7f8f9\">    <tr>      <td align=\"center\"        style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; word-break: break-word;\">        <table class=\"email-content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"          style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin: 0; padding: 0; width: 100%;\">          <tr style=\"background: #fff;\">            <td height=\"40\" class=\"em_height\">&nbsp;</td>          </tr>          <!-- HEADER 1 -->          <tr style=\"background: #fff;\">            <td align=\"center\"> <a href=\"#\" target=\"_blank\" style=\"text-decoration:none;\"><img                  src=\"https://eximchain.com/token-verification.png\" width=\"230\" height=\"auto\"                  style=\"display:block; margin-bottom: 25px;\" border=\"0\" alt=\"Eximchain\" /></a>              <h2                style=\"font-size: 1.2em; font-weight: normal; margin-top: -10px; margin-bottom: 0.809em; color: #515762;\">                DappBot Trial Update</h2>            </td>          </tr>          <tr style=\"background: #fff;\">            <td height=\"30\" class=\"em_height\">&nbsp;</td>          </tr>          <tr>            <td class=\"email-body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"              style=\"-premailer-cellpadding: 0; -premailer-cellspacing: 0; border-bottom-color: #EDEFF2; border-bottom-style: solid; border-bottom-width: 1px; border-top-color: #EDEFF2; border-top-style: solid; border-top-width: 1px; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin: 0; padding: 0; width: 100%; word-break: break-word; border-top: 4px solid #267edc;\"              bgcolor=\"#FFFFFF\">              <table class=\"email-body_inner\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\"                style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin: 0 auto; padding: 0; width: 570px;\"                bgcolor=\"#FFFFFF\">                <tr>                  <td class=\"content-cell\"                    style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; padding: 35px; word-break: break-word;\">                    <!-- ACTUAL CONTENT BEGINS HERE -->                    <!-- HEADER 2 -->                    <h1                      style=\"box-sizing: border-box; color: #2b333f; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 19px; font-weight: bold; margin-top: 0;\"                      align=\"left\">Thank you for trying out DappBot!</h1>                    <!-- BODY -->                    <p style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 16px; line-height: 1.5em; margin-top: 0;\"                      align=\"left\">                      We hope you have been enjoying DappBot.  Your 7 day free trial                      is expiring in 3 days.                      </p>                    <p style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 16px; line-height: 1.5em; margin-top: 0;\"                      align=\"left\">                      You can finish activating your subscription now by entering                      credit card information into your <a href=\"" + env_1.managerDNS + "/home/user-settings\"                      style=\"box-sizing: border-box; color: #3869D4; font-family: 'Helvetica Neue', Helvetica, sans-serif;\">                      User Settings</a>.                    </p>                    <p style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 16px; line-height: 1.5em; margin-top: 0;\"                      align=\"left\">                      Alternately, if you would like to extend your trial by two                       more weeks, please <a href=\"https://imgflip.com/i/37koyd\"                      style=\"box-sizing: border-box; color: #3869D4; font-family: 'Helvetica Neue', Helvetica, sans-serif;\">                      fill out this survey</a> and provide your email.  We're                       eager to learn more about how we can make this product                      better for you!                    </p>                    <!-- SIGNATURE -->                    <p style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 16px; line-height: 1.5em; margin-top: 0;\"                      align=\"left\">Thank you, <br />Eximchain Team</p>                    <p style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 16px; line-height: 1.5em; margin-top: 0;\"                      align=\"left\"><strong                        style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif;\">P.S.</strong>                      Please do not reply to this email. This email is generated automatically, and is not monitored for                      responses. We will never ask you to send sensitive information via email or via a link in an                      email.</p>                    <table class=\"body-sub\"                      style=\"border-top-color: #EDEFF2; border-top-style: solid; border-top-width: 1px; box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin-top: 25px; padding-top: 25px;\">                      <tr>                        <td                          style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; word-break: break-word;\">                          <p class=\"sub\"                            style=\"box-sizing: border-box; color: #626b76; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 12px; line-height: 1.5em; margin-top: 0;\"                            align=\"left\">If any issues arise, please reach out for support at our <a                              href=\"https://eximchain.zendesk.com/\"                              style=\"box-sizing: border-box; color: #3869D4; font-family: 'Helvetica Neue', Helvetica, sans-serif;\">help                              center.</a></p>                        </td>                      </tr>                    </table>                  </td>                </tr>              </table>            </td>          </tr>          <!-- FOOTER -->          <tr>            <td              style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; word-break: break-word; background: white;\">              <table class=\"email-footer\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\"                style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; margin: 0 auto; padding: 0; text-align: center; width: 570px;\">                <tr>                  <td class=\"content-cell\" align=\"center\"                    style=\"box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, sans-serif; padding: 35px; word-break: break-word;\">                    <p class=\"sub align-center\"                      style=\"box-sizing: border-box; color: #AEAEAE; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 12px; line-height: 1.5em; margin-top: 0;\"                      align=\"center\">\u00A9 2018 Eximchain. All rights reserved.</p>                    <p class=\"sub align-center\"                      style=\"box-sizing: border-box; color: #AEAEAE; font-family: 'Helvetica Neue', Helvetica, sans-serif; font-size: 12px; line-height: 1.5em; margin-top: 0;\"                      align=\"center\"> Eximchain <br />#02-00, 22 North Canal Road <br />Singapore 048834 </p>                  </td>                </tr>              </table>            </td>          </tr>        </table>      </td>    </tr>  </table></body></html>";
function sendTrialEndEmail(email) {
    return __awaiter(this, void 0, void 0, function () {
        var confirmationParam, msg;
        return __generator(this, function (_a) {
            confirmationParam = {
                from: FROM_ADDRESS,
                to: email,
                subject: "Your DappBot Trial is Ending Soon, Unless...",
                html: trialEndEmail
            };
            if (USING_SENDGRID) {
                return [2 /*return*/, mail_1.default.send(confirmationParam)];
            }
            else {
                msg = "No Sendgrid API key loaded, not sending following email: " + JSON.stringify(confirmationParam, undefined, 2);
                return [2 /*return*/, msg];
            }
            return [2 /*return*/];
        });
    });
}
exports.sendTrialEndEmail = sendTrialEndEmail;
exports.default = {
    sendTrialEndEmail: sendTrialEndEmail
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZGdyaWQuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvc2VuZGdyaWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHdEQUFvQztBQUNwQyw4QkFBaUQ7QUFFakQsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDO0FBRTNCLElBQUksaUJBQVcsSUFBSSxpQkFBVyxLQUFLLEVBQUUsRUFBQztJQUNwQyxjQUFNLENBQUMsU0FBUyxDQUFDLGlCQUFXLENBQUMsQ0FBQztJQUM5QixjQUFjLEdBQUcsSUFBSSxDQUFDO0NBQ3ZCO0FBRUQsSUFBTSxZQUFZLEdBQUcsdUJBQXVCLENBQUM7QUFFN0MsNERBQTREO0FBQzVELG1EQUFtRDtBQUNuRCx1REFBdUQ7QUFDdkQsc0RBQXNEO0FBQ3RELEdBQUc7QUFDSCx3Q0FBd0M7QUFDeEMsaURBQWlEO0FBQ2pELHVCQUF1QjtBQUN2QixtREFBbUQ7QUFDbkQseUNBQXlDO0FBQ3pDLGdEQUFnRDtBQUNoRCx1Q0FBdUM7QUFDdkMsbURBQW1EO0FBQ25ELEVBQUU7QUFDRiw4REFBOEQ7QUFDOUQsa0RBQWtEO0FBQ2xELHdEQUF3RDtBQUN4RCxnREFBZ0Q7QUFDaEQsSUFBTSxhQUFhLEdBQUcsaTlKQUE0MEosZ0JBQVUsbzlJQUF1NEksQ0FBQTtBQUVudlMsU0FBc0IsaUJBQWlCLENBQUMsS0FBWTs7OztZQUM5QyxpQkFBaUIsR0FBRztnQkFDdEIsSUFBSSxFQUFHLFlBQVk7Z0JBQ25CLEVBQUUsRUFBRyxLQUFLO2dCQUNWLE9BQU8sRUFBRyw4Q0FBOEM7Z0JBQ3hELElBQUksRUFBRyxhQUFhO2FBQ3JCLENBQUE7WUFDRCxJQUFJLGNBQWMsRUFBQztnQkFDakIsc0JBQU8sY0FBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFDO2FBQ3ZDO2lCQUFNO2dCQUNELEdBQUcsR0FBRyw4REFBNEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFHLENBQUM7Z0JBQ3hILHNCQUFPLEdBQUcsRUFBQTthQUNYOzs7O0NBQ0Y7QUFiRCw4Q0FhQztBQUVELGtCQUFlO0lBQ2IsaUJBQWlCLG1CQUFBO0NBQ2xCLENBQUEifQ==