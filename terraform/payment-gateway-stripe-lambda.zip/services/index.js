module.exports = {
  cognito: require('./cognito')
}