"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var validate_1 = require("../validate");
var stripe_1 = __importDefault(require("stripe"));
var lodash_keyby_1 = __importDefault(require("lodash.keyby"));
exports.stripe = new stripe_1.default(env_1.stripeKey);
var SubscriptionStates;
(function (SubscriptionStates) {
    SubscriptionStates["trial"] = "trialing";
    SubscriptionStates["active"] = "active";
    SubscriptionStates["canceled"] = "canceled";
    SubscriptionStates["unpaid"] = "unpaid";
    SubscriptionStates["incomplete"] = "incomplete";
    SubscriptionStates["incompleteExpired"] = "incomplete_expired";
    SubscriptionStates["pastDue"] = "past_due";
})(SubscriptionStates = exports.SubscriptionStates || (exports.SubscriptionStates = {}));
exports.ValidSubscriptionStates = [SubscriptionStates.trial, SubscriptionStates.active];
///////////////////////////////////////////////////
////                 KEY METHODS
///////////////////////////////////////////////////
function createCustomerAndSubscription(_a) {
    var name = _a.name, email = _a.email, token = _a.token, plans = _a.plans, coupon = _a.coupon;
    return __awaiter(this, void 0, void 0, function () {
        var newCustomer, subItems, newSub;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.create({
                        name: name, email: email,
                        description: "Customer for " + email,
                        source: token
                    })];
                case 1:
                    newCustomer = _b.sent();
                    subItems = [];
                    Object.keys(plans).forEach(function (plan) {
                        var quantity = plans[plan];
                        if (quantity > 0) {
                            subItems.push({ plan: plan, quantity: quantity });
                        }
                    });
                    return [4 /*yield*/, exports.stripe.subscriptions.create({
                            customer: newCustomer.id,
                            items: subItems,
                            trial_period_days: 14
                        })];
                case 2:
                    newSub = _b.sent();
                    return [2 /*return*/, {
                            customer: newCustomer,
                            subscription: newSub
                        }];
            }
        });
    });
}
function getStripeData(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer, subscription, invoice, failedInvoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) return [3 /*break*/, 6];
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2:
                    subscription = _a.sent();
                    return [4 /*yield*/, getUnpaidInvoice(customer.id)];
                case 3:
                    failedInvoice = _a.sent();
                    if (!failedInvoice) return [3 /*break*/, 4];
                    invoice = failedInvoice;
                    return [3 /*break*/, 6];
                case 4: return [4 /*yield*/, getUpcomingInvoice(customer.id)];
                case 5:
                    invoice = _a.sent();
                    _a.label = 6;
                case 6: return [2 /*return*/, { customer: customer, subscription: subscription, invoice: invoice }];
            }
        });
    });
}
///////////////////////////////////////////////////
////                 CUSTOMERS
///////////////////////////////////////////////////
function getStripeCustomer(email) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList, customerId;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.list({ email: email })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Two customers listed for " + email + ", must be an error!");
                    }
                    customerId = matchingList.data[0].id;
                    return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                            expand: ['default_source']
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeCustomerById(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                        expand: ['default_source']
                    })];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
exports.getStripeCustomerById = getStripeCustomerById;
function updateCustomerPayment(email, paymentToken) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (customer === null) {
                        throw new Error("A customer does not exist for email " + email + " in stripe");
                    }
                    return [4 /*yield*/, exports.stripe.customers.update(customer.id, { source: paymentToken })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
///////////////////////////////////////////////////
////               SUBSCRIPTIONS
///////////////////////////////////////////////////
function getStripeSubscriptionByCustomerId(stripeCustomerId) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.subscriptions.list({
                        customer: stripeCustomerId
                    })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Multiple subscriptions listed for Stripe Customer " + stripeCustomerId + ", must be an error!.");
                    }
                    return [2 /*return*/, matchingList.data[0]];
            }
        });
    });
}
function getStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) {
                        return [2 /*return*/, null];
                    }
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function cancelStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscription(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to cancel subscription for " + email + ", no subscription exists.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.del(subscription.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function updateStripeSubscription(email, newPlans) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, customer, subscription, currentItems, items, currentByPlan;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, getStripeData(email)];
                case 1:
                    _a = _b.sent(), customer = _a.customer, subscription = _a.subscription;
                    if (!customer) {
                        throw new Error("Unable to update subscription for " + email + ", no customer exist.");
                    }
                    if (!subscription) {
                        throw new Error("Unable to update subscription for " + email + ", no subscription exist.");
                    }
                    if (subscription.status === 'trialing' && customer.default_source === null) {
                        throw new validate_1.UserError("You cannot modify your dapp count without a saved payment method.");
                    }
                    currentItems = subscription.items.data.slice();
                    items = [];
                    currentByPlan = lodash_keyby_1.default(currentItems, function (item) { return item.plan.id; });
                    Object.keys(newPlans).forEach(function (planId) {
                        var newQuantity = newPlans[planId];
                        var currentItem = currentByPlan[planId];
                        if (newQuantity === 0) {
                            if (currentItem)
                                items.push({
                                    id: currentItem.id,
                                    deleted: true
                                });
                        }
                        else {
                            var newItem = {
                                plan: planId,
                                quantity: newQuantity
                            };
                            if (currentItem)
                                newItem.id = currentItem.id;
                            items.push(newItem);
                        }
                    });
                    return [4 /*yield*/, exports.stripe.subscriptions.update(subscription.id, { items: items })
                            .then(function (updatedSubscription) {
                            // If they've already added a card but are still trialing,
                            // updating their dapp count immediately ends their trial.
                            // Doing it in this then ensures that the update is complete
                            // before we end their trial and they get invoiced.
                            if (updatedSubscription.status === 'trialing') {
                                return exports.stripe.subscriptions.update(subscription.id, {
                                    trial_end: 'now'
                                });
                            }
                            else {
                                return updatedSubscription;
                            }
                        })];
                case 2: return [2 /*return*/, _b.sent()];
            }
        });
    });
}
///////////////////////////////////////////////////
////                  INVOICES
///////////////////////////////////////////////////
/**
 * Given a customerId, uses getUnpaidInvoice to
 * attempt payment on a failed invoice, returning
 * the invoice after the updating.  If there is
 * no unpaid invoice, returns null.
 *
 * @param customerId
 */
function retryLatestUnpaid(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        var latestInvoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getUnpaidInvoice(customerId)];
                case 1:
                    latestInvoice = _a.sent();
                    if (!latestInvoice) return [3 /*break*/, 3];
                    return [4 /*yield*/, exports.stripe.invoices.pay(latestInvoice.id)];
                case 2: return [2 /*return*/, _a.sent()];
                case 3: return [2 /*return*/, null];
            }
        });
    });
}
/**
 * Given a customerId, returns their unpaid invoice.
 * If they do not have an invoice which has been
 * attempted but not paid, it returns null.
 *
 * @param customerId
 */
function getUnpaidInvoice(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        var invoices, latestInvoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.invoices.list({
                        customer: customerId
                    })];
                case 1:
                    invoices = _a.sent();
                    if (invoices.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    latestInvoice = invoices.data[0];
                    if (latestInvoice.attempted && !latestInvoice.paid) {
                        return [2 /*return*/, latestInvoice];
                    }
                    else {
                        console.log('Latest invoice does not hit requirements of attempted but not paid.');
                        return [2 /*return*/, null];
                    }
                    return [2 /*return*/];
            }
        });
    });
}
/**
 * Given a customerId, return their upcoming invoice.
 * Automatically includes up to 100 of the underlying
 * line items.
 *
 * TODO: What does this do when they have been moved
 * to not making anymore invoices?
 *
 * @param customerId
 */
function getUpcomingInvoice(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        var upcomingInvoice, fullLineItems;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.invoices.retrieveUpcoming(customerId)];
                case 1:
                    upcomingInvoice = _a.sent();
                    return [4 /*yield*/, exports.stripe.invoices.listUpcomingLineItems({
                            customer: customerId,
                            limit: 100
                        })];
                case 2:
                    fullLineItems = _a.sent();
                    upcomingInvoice.lines.data = fullLineItems.data;
                    return [2 /*return*/, upcomingInvoice];
            }
        });
    });
}
///////////////////////////////////////////////////
////                  HELPERS
///////////////////////////////////////////////////
function isTokenValid(tokenId) {
    return __awaiter(this, void 0, void 0, function () {
        var tokenData, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (typeof tokenId !== 'string')
                        return [2 /*return*/, false];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, exports.stripe.tokens.retrieve(tokenId)];
                case 2:
                    tokenData = _a.sent();
                    return [2 /*return*/, !tokenData.used];
                case 3:
                    err_1 = _a.sent();
                    // Retrieve throws if this isn't a valid token.
                    return [2 /*return*/, false];
                case 4: return [2 /*return*/];
            }
        });
    });
}
function decodeWebhook(webhookBody, signature) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.webhooks.constructEvent(webhookBody, signature, env_1.stripeWebhookSecret)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
var WebhookEventTypes;
(function (WebhookEventTypes) {
    WebhookEventTypes["failedPayment"] = "invoice.payment_failed";
    WebhookEventTypes["successfulPayment"] = "invoice.payment_succeeded";
    WebhookEventTypes["trialEnding"] = "customer.subscription.trial_will_end";
})(WebhookEventTypes = exports.WebhookEventTypes || (exports.WebhookEventTypes = {}));
exports.default = {
    create: createCustomerAndSubscription,
    updateSubscription: updateStripeSubscription,
    updatePayment: updateCustomerPayment,
    cancel: cancelStripeSubscription,
    read: getStripeData,
    isTokenValid: isTokenValid, stripe: exports.stripe, decodeWebhook: decodeWebhook,
    retryLatestUnpaid: retryLatestUnpaid
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RyaXBlLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL3N0cmlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOEJBQXdEO0FBQ3hELHdDQUF3QztBQUN4QyxrREFBNEI7QUFDNUIsOERBQWlDO0FBQ3BCLFFBQUEsTUFBTSxHQUFHLElBQUksZ0JBQU0sQ0FBQyxlQUFTLENBQUMsQ0FBQztBQWE1QyxJQUFZLGtCQVFYO0FBUkQsV0FBWSxrQkFBa0I7SUFDNUIsd0NBQWtCLENBQUE7SUFDbEIsdUNBQWlCLENBQUE7SUFDakIsMkNBQXFCLENBQUE7SUFDckIsdUNBQWlCLENBQUE7SUFDakIsK0NBQXlCLENBQUE7SUFDekIsOERBQXdDLENBQUE7SUFDeEMsMENBQW9CLENBQUE7QUFDdEIsQ0FBQyxFQVJXLGtCQUFrQixHQUFsQiwwQkFBa0IsS0FBbEIsMEJBQWtCLFFBUTdCO0FBQ1ksUUFBQSx1QkFBdUIsR0FBMkIsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7QUF1QnJILG1EQUFtRDtBQUNuRCxnQ0FBZ0M7QUFDaEMsbURBQW1EO0FBRW5ELFNBQWUsNkJBQTZCLENBQUMsRUFBc0Q7UUFBcEQsY0FBSSxFQUFFLGdCQUFLLEVBQUUsZ0JBQUssRUFBRSxnQkFBSyxFQUFFLGtCQUFNOzs7Ozt3QkFDMUQscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7d0JBQ2hELElBQUksTUFBQSxFQUFFLEtBQUssT0FBQTt3QkFDWCxXQUFXLEVBQUUsa0JBQWdCLEtBQU87d0JBQ3BDLE1BQU0sRUFBRSxLQUFLO3FCQUNkLENBQUMsRUFBQTs7b0JBSkksV0FBVyxHQUFHLFNBSWxCO29CQUNJLFFBQVEsR0FBNEIsRUFBRSxDQUFDO29CQUM3QyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7d0JBQzdCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUF1QixDQUFDLENBQUM7d0JBQzlDLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksTUFBQSxFQUFFLFFBQVEsVUFBQSxFQUFFLENBQUMsQ0FBQTt5QkFDbEM7b0JBQ0gsQ0FBQyxDQUFDLENBQUE7b0JBQ2EscUJBQU0sY0FBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7NEJBQy9DLFFBQVEsRUFBRSxXQUFXLENBQUMsRUFBRTs0QkFDeEIsS0FBSyxFQUFFLFFBQVE7NEJBQ2YsaUJBQWlCLEVBQUUsRUFBRTt5QkFDdEIsQ0FBQyxFQUFBOztvQkFKSSxNQUFNLEdBQUcsU0FJYjtvQkFDRixzQkFBTzs0QkFDTCxRQUFRLEVBQUUsV0FBVzs0QkFDckIsWUFBWSxFQUFFLE1BQU07eUJBQ3JCLEVBQUE7Ozs7Q0FDRjtBQUVELFNBQWUsYUFBYSxDQUFDLEtBQVk7Ozs7O3dCQUU1QixxQkFBTSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXpDLFFBQVEsR0FBRyxTQUE4QixDQUFDO3lCQUN0QyxRQUFRLEVBQVIsd0JBQVE7b0JBQ0sscUJBQU0saUNBQWlDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFBOztvQkFBbkUsWUFBWSxHQUFHLFNBQW9ELENBQUM7b0JBQzlDLHFCQUFNLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBQTs7b0JBQW5ELGFBQWEsR0FBRyxTQUFtQzt5QkFDckQsYUFBYSxFQUFiLHdCQUFhO29CQUNmLE9BQU8sR0FBRyxhQUFhLENBQUM7O3dCQUVkLHFCQUFNLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBQTs7b0JBQS9DLE9BQU8sR0FBRyxTQUFxQyxDQUFDOzt3QkFHcEQsc0JBQU8sRUFBRSxRQUFRLFVBQUEsRUFBRSxZQUFZLGNBQUEsRUFBRSxPQUFPLFNBQUEsRUFBRSxFQUFDOzs7O0NBQzVDO0FBRUQsbURBQW1EO0FBQ25ELDhCQUE4QjtBQUM5QixtREFBbUQ7QUFFbkQsU0FBZSxpQkFBaUIsQ0FBQyxLQUFZOzs7Ozt3QkFDdEIscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQUEsRUFBRSxDQUFDLEVBQUE7O29CQUFyRCxZQUFZLEdBQUcsU0FBc0M7b0JBRTNELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO3dCQUNsQyxzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7eUJBQU0sSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ3ZDLE1BQU0sSUFBSSxLQUFLLENBQUMsOEJBQTRCLEtBQUssd0JBQXFCLENBQUMsQ0FBQztxQkFDekU7b0JBSUssVUFBVSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUNwQyxxQkFBTSxjQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUU7NEJBQ2pELE1BQU0sRUFBRyxDQUFDLGdCQUFnQixDQUFDO3lCQUM1QixDQUFDLEVBQUE7d0JBRkYsc0JBQU8sU0FFTCxFQUFBOzs7O0NBQ0g7QUFFRCxTQUFzQixxQkFBcUIsQ0FBQyxVQUFpQjs7Ozt3QkFDcEQscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO3dCQUNqRCxNQUFNLEVBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztxQkFDNUIsQ0FBQyxFQUFBO3dCQUZGLHNCQUFPLFNBRUwsRUFBQTs7OztDQUNIO0FBSkQsc0RBSUM7QUFFRCxTQUFlLHFCQUFxQixDQUFDLEtBQWEsRUFBRSxZQUFtQjs7Ozs7d0JBQ3BELHFCQUFNLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsUUFBUSxHQUFHLFNBQThCO29CQUMvQyxJQUFHLFFBQVEsS0FBSyxJQUFJLEVBQUM7d0JBQ25CLE1BQU0sSUFBSSxLQUFLLENBQUUseUNBQXVDLEtBQUssZUFBWSxDQUFDLENBQUE7cUJBQzNFO29CQUNNLHFCQUFNLGNBQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBQyxNQUFNLEVBQUMsWUFBWSxFQUFDLENBQUMsRUFBQTt3QkFBeEUsc0JBQU8sU0FBaUUsRUFBQTs7OztDQUV6RTtBQUVELG1EQUFtRDtBQUNuRCxnQ0FBZ0M7QUFDaEMsbURBQW1EO0FBRW5ELFNBQWUsaUNBQWlDLENBQUMsZ0JBQXVCOzs7Ozt3QkFDakQscUJBQU0sY0FBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7d0JBQ25ELFFBQVEsRUFBRSxnQkFBZ0I7cUJBQzNCLENBQUMsRUFBQTs7b0JBRkksWUFBWSxHQUFHLFNBRW5CO29CQUVGLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO3dCQUNsQyxzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7eUJBQU0sSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ3ZDLE1BQU0sSUFBSSxLQUFLLENBQUMsdURBQXFELGdCQUFnQix5QkFBc0IsQ0FBQyxDQUFDO3FCQUM5RztvQkFFRCxzQkFBTyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDOzs7O0NBQzdCO0FBRUQsU0FBZSxxQkFBcUIsQ0FBQyxLQUFZOzs7Ozt3QkFDOUIscUJBQU0saUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF6QyxRQUFRLEdBQUcsU0FBOEI7b0JBQy9DLElBQUksQ0FBQyxRQUFRLEVBQUM7d0JBQ1osc0JBQU8sSUFBSSxFQUFDO3FCQUNiO29CQUNNLHFCQUFNLGlDQUFpQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBQTt3QkFBM0Qsc0JBQU8sU0FBb0QsRUFBQzs7OztDQUM3RDtBQUVELFNBQWUsd0JBQXdCLENBQUMsS0FBWTs7Ozs7d0JBQzdCLHFCQUFNLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBakQsWUFBWSxHQUFHLFNBQWtDO29CQUN2RCxJQUFJLENBQUMsWUFBWSxFQUFDO3dCQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLHVDQUFxQyxLQUFLLDhCQUEyQixDQUFDLENBQUE7cUJBQ3ZGO29CQUNNLHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBQTt3QkFBdEQsc0JBQU8sU0FBK0MsRUFBQTs7OztDQUN2RDtBQUVELFNBQWUsd0JBQXdCLENBQUMsS0FBWSxFQUFFLFFBQW9COzs7Ozt3QkFDdEMscUJBQU0sYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBdEQsS0FBNEIsU0FBMEIsRUFBcEQsUUFBUSxjQUFBLEVBQUUsWUFBWSxrQkFBQTtvQkFDOUIsSUFBSSxDQUFDLFFBQVEsRUFBQzt3QkFDWixNQUFNLElBQUksS0FBSyxDQUFDLHVDQUFxQyxLQUFLLHlCQUFzQixDQUFDLENBQUM7cUJBQ25GO29CQUNELElBQUksQ0FBQyxZQUFZLEVBQUM7d0JBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXFDLEtBQUssNkJBQTBCLENBQUMsQ0FBQztxQkFDdkY7b0JBQ0QsSUFBSSxZQUFZLENBQUMsTUFBTSxLQUFLLFVBQVUsSUFBSSxRQUFRLENBQUMsY0FBYyxLQUFLLElBQUksRUFBQzt3QkFDekUsTUFBTSxJQUFJLG9CQUFTLENBQUMsbUVBQW1FLENBQUMsQ0FBQztxQkFDMUY7b0JBQ0ssWUFBWSxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUMvQyxLQUFLLEdBQTRCLEVBQUUsQ0FBQztvQkFDcEMsYUFBYSxHQUFHLHNCQUFLLENBQUMsWUFBWSxFQUFFLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQVosQ0FBWSxDQUFDLENBQUE7b0JBQy9ELE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUMsTUFBTTt3QkFDbkMsSUFBSSxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQXlCLENBQUMsQ0FBQzt3QkFDdEQsSUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN4QyxJQUFJLFdBQVcsS0FBSyxDQUFDLEVBQUU7NEJBQ3JCLElBQUksV0FBVztnQ0FBRSxLQUFLLENBQUMsSUFBSSxDQUFDO29DQUMxQixFQUFFLEVBQUcsV0FBVyxDQUFDLEVBQUU7b0NBQ25CLE9BQU8sRUFBRyxJQUFJO2lDQUNmLENBQUMsQ0FBQTt5QkFDSDs2QkFBTTs0QkFDTCxJQUFJLE9BQU8sR0FBMEI7Z0NBQ25DLElBQUksRUFBRyxNQUFNO2dDQUNiLFFBQVEsRUFBRyxXQUFXOzZCQUN2QixDQUFBOzRCQUNELElBQUksV0FBVztnQ0FBRSxPQUFPLENBQUMsRUFBRSxHQUFHLFdBQVcsQ0FBQyxFQUFFLENBQUM7NEJBQzdDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7eUJBQ3BCO29CQUNILENBQUMsQ0FBQyxDQUFBO29CQUNLLHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxLQUFLLE9BQUEsRUFBRSxDQUFDOzZCQUNqRSxJQUFJLENBQUMsVUFBQyxtQkFBbUI7NEJBQ3hCLDBEQUEwRDs0QkFDMUQsMERBQTBEOzRCQUMxRCw0REFBNEQ7NEJBQzVELG1EQUFtRDs0QkFDbkQsSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFO2dDQUM3QyxPQUFPLGNBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUU7b0NBQ2xELFNBQVMsRUFBRSxLQUFLO2lDQUNqQixDQUFDLENBQUE7NkJBQ0g7aUNBQU07Z0NBQ0wsT0FBTyxtQkFBbUIsQ0FBQzs2QkFDNUI7d0JBQ0wsQ0FBQyxDQUFDLEVBQUE7d0JBYkYsc0JBQU8sU0FhTCxFQUFBOzs7O0NBQ0g7QUFFRCxtREFBbUQ7QUFDbkQsOEJBQThCO0FBQzlCLG1EQUFtRDtBQUVuRDs7Ozs7OztHQU9HO0FBQ0gsU0FBZSxpQkFBaUIsQ0FBQyxVQUFpQjs7Ozs7d0JBQzFCLHFCQUFNLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFBOztvQkFBbEQsYUFBYSxHQUFHLFNBQWtDO3lCQUNwRCxhQUFhLEVBQWIsd0JBQWE7b0JBQ1IscUJBQU0sY0FBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUFsRCxzQkFBTyxTQUEyQyxFQUFDO3dCQUVuRCxzQkFBTyxJQUFJLEVBQUM7Ozs7Q0FFZjtBQUVEOzs7Ozs7R0FNRztBQUNILFNBQWUsZ0JBQWdCLENBQUMsVUFBaUI7Ozs7O3dCQUM5QixxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzt3QkFDMUMsUUFBUSxFQUFHLFVBQVU7cUJBQ3RCLENBQUMsRUFBQTs7b0JBRkksUUFBUSxHQUFHLFNBRWY7b0JBQ0YsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQzlCLHNCQUFPLElBQUksRUFBQztxQkFDYjtvQkFDSyxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxhQUFhLENBQUMsU0FBUyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRTt3QkFDbEQsc0JBQU8sYUFBYSxFQUFDO3FCQUN0Qjt5QkFBTTt3QkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHFFQUFxRSxDQUFDLENBQUM7d0JBQ25GLHNCQUFPLElBQUksRUFBQztxQkFDYjs7Ozs7Q0FDRjtBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILFNBQWUsa0JBQWtCLENBQUMsVUFBaUI7Ozs7O3dCQUN6QixxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxFQUFBOztvQkFBcEUsZUFBZSxHQUFHLFNBQWtEO29CQUNwRCxxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDOzRCQUNoRSxRQUFRLEVBQUcsVUFBVTs0QkFDckIsS0FBSyxFQUFHLEdBQUc7eUJBQ1osQ0FBQyxFQUFBOztvQkFISSxhQUFhLEdBQUcsU0FHcEI7b0JBQ0YsZUFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQztvQkFDaEQsc0JBQU8sZUFBZSxFQUFDOzs7O0NBQ3hCO0FBRUQsbURBQW1EO0FBQ25ELDZCQUE2QjtBQUM3QixtREFBbUQ7QUFFbkQsU0FBZSxZQUFZLENBQUMsT0FBMEI7Ozs7OztvQkFDcEQsSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRO3dCQUFFLHNCQUFPLEtBQUssRUFBQzs7OztvQkFFMUIscUJBQU0sY0FBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUE7O29CQUFqRCxTQUFTLEdBQUcsU0FBcUM7b0JBQ3ZELHNCQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQzs7O29CQUV2QiwrQ0FBK0M7b0JBQy9DLHNCQUFPLEtBQUssRUFBQzs7Ozs7Q0FFaEI7QUFFRCxTQUFlLGFBQWEsQ0FBQyxXQUFrQixFQUFFLFNBQXlCOzs7O3dCQUNqRSxxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLHlCQUFtQixDQUFDLEVBQUE7d0JBQXhGLHNCQUFPLFNBQWlGLEVBQUM7Ozs7Q0FDMUY7QUFFRCxJQUFZLGlCQUlYO0FBSkQsV0FBWSxpQkFBaUI7SUFDM0IsNkRBQXdDLENBQUE7SUFDeEMsb0VBQStDLENBQUE7SUFDL0MseUVBQW9ELENBQUE7QUFDdEQsQ0FBQyxFQUpXLGlCQUFpQixHQUFqQix5QkFBaUIsS0FBakIseUJBQWlCLFFBSTVCO0FBRUQsa0JBQWU7SUFDYixNQUFNLEVBQUUsNkJBQTZCO0lBQ3JDLGtCQUFrQixFQUFFLHdCQUF3QjtJQUM1QyxhQUFhLEVBQUUscUJBQXFCO0lBQ3BDLE1BQU0sRUFBRSx3QkFBd0I7SUFDaEMsSUFBSSxFQUFFLGFBQWE7SUFDbkIsWUFBWSxjQUFBLEVBQUUsTUFBTSxnQkFBQSxFQUFFLGFBQWEsZUFBQTtJQUNuQyxpQkFBaUIsbUJBQUE7Q0FDbEIsQ0FBQSJ9