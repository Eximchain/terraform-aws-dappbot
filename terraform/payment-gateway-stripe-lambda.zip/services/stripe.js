"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var stripe_1 = __importDefault(require("stripe"));
exports.stripe = new stripe_1.default(env_1.stripeKey);
var SubscriptionStates;
(function (SubscriptionStates) {
    SubscriptionStates["trial"] = "trialing";
    SubscriptionStates["active"] = "active";
    SubscriptionStates["canceled"] = "canceled";
    SubscriptionStates["unpaid"] = "unpaid";
    SubscriptionStates["incomplete"] = "incomplete";
    SubscriptionStates["incompleteExpired"] = "incomplete_expired";
    SubscriptionStates["pastDue"] = "past_due";
})(SubscriptionStates = exports.SubscriptionStates || (exports.SubscriptionStates = {}));
exports.ValidSubscriptionStates = [SubscriptionStates.trial, SubscriptionStates.active];
function buildSubscriptionItems(plans) {
    var items = [];
    if (plans.standard > 0) {
        items.push({ plan: 'standard', quantity: plans.standard });
    }
    if (plans.professional > 0) {
        items.push({ plan: 'professional', quantity: plans.professional });
    }
    if (plans.enterprise > 0) {
        items.push({ plan: 'enterprise', quantity: plans.enterprise });
    }
    return items;
}
function createCustomerAndSubscription(_a) {
    var name = _a.name, email = _a.email, token = _a.token, plans = _a.plans, coupon = _a.coupon;
    return __awaiter(this, void 0, void 0, function () {
        var newCustomer, newSub;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.create({
                        name: name, email: email,
                        description: "Customer for " + email,
                        source: token
                    })];
                case 1:
                    newCustomer = _b.sent();
                    return [4 /*yield*/, exports.stripe.subscriptions.create({
                            customer: newCustomer.id,
                            items: buildSubscriptionItems(plans),
                            trial_period_days: 7
                        })];
                case 2:
                    newSub = _b.sent();
                    return [2 /*return*/, {
                            customer: newCustomer,
                            subscription: newSub
                        }];
            }
        });
    });
}
function getStripeCustomerById(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                        expand: ['default_source']
                    })];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
exports.getStripeCustomerById = getStripeCustomerById;
function updateCustomerPayment(email, paymentToken) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (customer === null) {
                        throw new Error("A customer does not exist for email " + email + " in stripe");
                    }
                    return [4 /*yield*/, exports.stripe.customers.update(customer.id, { source: paymentToken })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeCustomer(email) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList, customerId;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.list({ email: email })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Two customers listed for " + email + ", must be an error!");
                    }
                    customerId = matchingList.data[0].id;
                    return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                            expand: ['default_source']
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeSubscriptionByCustomerId(stripeCustomerId) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.subscriptions.list({
                        customer: stripeCustomerId
                    })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Multiple subscriptions listed for Stripe Customer " + stripeCustomerId + ", must be an error!.");
                    }
                    return [2 /*return*/, matchingList.data[0]];
            }
        });
    });
}
function getStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) {
                        return [2 /*return*/, null];
                    }
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function cancelStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscription(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to cancel subscription for " + email + ", no subscription exists.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.del(subscription.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function updateStripeSubscription(email, newPlans) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscription(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to update subscription for email " + email + ", no subscriptions exist.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.update(subscription.id, {
                            items: buildSubscriptionItems(newPlans)
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeData(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer, subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) return [3 /*break*/, 3];
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2:
                    subscription = _a.sent();
                    _a.label = 3;
                case 3: return [2 /*return*/, { customer: customer, subscription: subscription }];
            }
        });
    });
}
function isTokenValid(tokenId) {
    return __awaiter(this, void 0, void 0, function () {
        var tokenData, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (typeof tokenId !== 'string')
                        return [2 /*return*/, false];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, exports.stripe.tokens.retrieve(tokenId)];
                case 2:
                    tokenData = _a.sent();
                    return [2 /*return*/, !tokenData.used];
                case 3:
                    err_1 = _a.sent();
                    // Retrieve throws if this isn't a valid token.
                    return [2 /*return*/, false];
                case 4: return [2 /*return*/];
            }
        });
    });
}
function decodeWebhook(webhookBody, signature) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.webhooks.constructEvent(webhookBody, signature, env_1.stripeWebhookSecret)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
var WebhookEventTypes;
(function (WebhookEventTypes) {
    WebhookEventTypes["failedPayment"] = "invoice.payment_failed";
    WebhookEventTypes["successfulPayment"] = "invoice.payment_succeeded";
    WebhookEventTypes["trialEnding"] = "customer.subscription.trial_will_end";
})(WebhookEventTypes = exports.WebhookEventTypes || (exports.WebhookEventTypes = {}));
exports.default = {
    create: createCustomerAndSubscription,
    updateSubscription: updateStripeSubscription,
    updatePayment: updateCustomerPayment,
    cancel: cancelStripeSubscription,
    read: getStripeData,
    isTokenValid: isTokenValid, stripe: exports.stripe, decodeWebhook: decodeWebhook
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RyaXBlLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL3N0cmlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOEJBQXdEO0FBQ3hELGtEQUE0QjtBQUNmLFFBQUEsTUFBTSxHQUFHLElBQUksZ0JBQU0sQ0FBQyxlQUFTLENBQUMsQ0FBQztBQVU1QyxJQUFZLGtCQVFYO0FBUkQsV0FBWSxrQkFBa0I7SUFDNUIsd0NBQWtCLENBQUE7SUFDbEIsdUNBQWlCLENBQUE7SUFDakIsMkNBQXFCLENBQUE7SUFDckIsdUNBQWlCLENBQUE7SUFDakIsK0NBQXlCLENBQUE7SUFDekIsOERBQXdDLENBQUE7SUFDeEMsMENBQW9CLENBQUE7QUFDdEIsQ0FBQyxFQVJXLGtCQUFrQixHQUFsQiwwQkFBa0IsS0FBbEIsMEJBQWtCLFFBUTdCO0FBQ1ksUUFBQSx1QkFBdUIsR0FBMkIsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7QUF1QnJILFNBQVMsc0JBQXNCLENBQUMsS0FBaUI7SUFDL0MsSUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDO0lBQ2pCLElBQUksS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUU7UUFDdEIsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRyxVQUFVLEVBQUUsUUFBUSxFQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFBO0tBQzdEO0lBQ0QsSUFBSSxLQUFLLENBQUMsWUFBWSxHQUFHLENBQUMsRUFBRTtRQUMxQixLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFHLGNBQWMsRUFBRSxRQUFRLEVBQUcsS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUE7S0FDckU7SUFDRCxJQUFJLEtBQUssQ0FBQyxVQUFVLEdBQUcsQ0FBQyxFQUFFO1FBQ3hCLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUcsWUFBWSxFQUFFLFFBQVEsRUFBRyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQTtLQUNqRTtJQUNELE9BQU8sS0FBSyxDQUFDO0FBQ2YsQ0FBQztBQUVELFNBQWUsNkJBQTZCLENBQUMsRUFBc0Q7UUFBcEQsY0FBSSxFQUFFLGdCQUFLLEVBQUUsZ0JBQUssRUFBRSxnQkFBSyxFQUFFLGtCQUFNOzs7Ozt3QkFDMUQscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7d0JBQ2hELElBQUksTUFBQSxFQUFFLEtBQUssT0FBQTt3QkFDWCxXQUFXLEVBQUUsa0JBQWdCLEtBQU87d0JBQ3BDLE1BQU0sRUFBRSxLQUFLO3FCQUNkLENBQUMsRUFBQTs7b0JBSkksV0FBVyxHQUFHLFNBSWxCO29CQUVhLHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDOzRCQUMvQyxRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUU7NEJBQ3hCLEtBQUssRUFBRSxzQkFBc0IsQ0FBQyxLQUFLLENBQUM7NEJBQ3BDLGlCQUFpQixFQUFFLENBQUM7eUJBQ3JCLENBQUMsRUFBQTs7b0JBSkksTUFBTSxHQUFHLFNBSWI7b0JBQ0Ysc0JBQU87NEJBQ0wsUUFBUSxFQUFFLFdBQVc7NEJBQ3JCLFlBQVksRUFBRSxNQUFNO3lCQUNyQixFQUFBOzs7O0NBQ0Y7QUFFRCxTQUFzQixxQkFBcUIsQ0FBQyxVQUFpQjs7Ozt3QkFDcEQscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO3dCQUNqRCxNQUFNLEVBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztxQkFDNUIsQ0FBQyxFQUFBO3dCQUZGLHNCQUFPLFNBRUwsRUFBQTs7OztDQUNIO0FBSkQsc0RBSUM7QUFFRCxTQUFlLHFCQUFxQixDQUFDLEtBQWEsRUFBRSxZQUFtQjs7Ozs7d0JBQ3BELHFCQUFNLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsUUFBUSxHQUFHLFNBQThCO29CQUMvQyxJQUFHLFFBQVEsS0FBSyxJQUFJLEVBQUM7d0JBQ25CLE1BQU0sSUFBSSxLQUFLLENBQUUseUNBQXVDLEtBQUssZUFBWSxDQUFDLENBQUE7cUJBQzNFO29CQUNNLHFCQUFNLGNBQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBQyxNQUFNLEVBQUMsWUFBWSxFQUFDLENBQUMsRUFBQTt3QkFBeEUsc0JBQU8sU0FBaUUsRUFBQTs7OztDQUV6RTtBQUVELFNBQWUsaUJBQWlCLENBQUMsS0FBWTs7Ozs7d0JBQ3RCLHFCQUFNLGNBQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFBLEVBQUUsQ0FBQyxFQUFBOztvQkFBckQsWUFBWSxHQUFHLFNBQXNDO29CQUUzRCxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDbEMsc0JBQU8sSUFBSSxFQUFDO3FCQUNiO3lCQUFNLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE0QixLQUFLLHdCQUFxQixDQUFDLENBQUM7cUJBQ3pFO29CQUlLLFVBQVUsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztvQkFDcEMscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFOzRCQUNqRCxNQUFNLEVBQUcsQ0FBQyxnQkFBZ0IsQ0FBQzt5QkFDNUIsQ0FBQyxFQUFBO3dCQUZGLHNCQUFPLFNBRUwsRUFBQTs7OztDQUNIO0FBRUQsU0FBZSxpQ0FBaUMsQ0FBQyxnQkFBdUI7Ozs7O3dCQUNqRCxxQkFBTSxjQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQzt3QkFDbkQsUUFBUSxFQUFFLGdCQUFnQjtxQkFDM0IsQ0FBQyxFQUFBOztvQkFGSSxZQUFZLEdBQUcsU0FFbkI7b0JBRUYsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ2xDLHNCQUFPLElBQUksRUFBQztxQkFDYjt5QkFBTSxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDdkMsTUFBTSxJQUFJLEtBQUssQ0FBQyx1REFBcUQsZ0JBQWdCLHlCQUFzQixDQUFDLENBQUM7cUJBQzlHO29CQUVELHNCQUFPLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUM7Ozs7Q0FDN0I7QUFFRCxTQUFlLHFCQUFxQixDQUFDLEtBQVk7Ozs7O3dCQUM5QixxQkFBTSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQXpDLFFBQVEsR0FBRyxTQUE4QjtvQkFDL0MsSUFBSSxDQUFDLFFBQVEsRUFBQzt3QkFDWixzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7b0JBQ00scUJBQU0saUNBQWlDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUEzRCxzQkFBTyxTQUFvRCxFQUFDOzs7O0NBQzdEO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxLQUFZOzs7Ozt3QkFDN0IscUJBQU0scUJBQXFCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUFqRCxZQUFZLEdBQUcsU0FBa0M7b0JBQ3ZELElBQUksQ0FBQyxZQUFZLEVBQUM7d0JBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXFDLEtBQUssOEJBQTJCLENBQUMsQ0FBQTtxQkFDdkY7b0JBQ00scUJBQU0sY0FBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUF0RCxzQkFBTyxTQUErQyxFQUFBOzs7O0NBQ3ZEO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxLQUFZLEVBQUUsUUFBb0I7Ozs7O3dCQUNuRCxxQkFBTSxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQWpELFlBQVksR0FBRyxTQUFrQztvQkFDdkQsSUFBSSxDQUFDLFlBQVksRUFBQzt3QkFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2Q0FBMkMsS0FBSyw4QkFBMkIsQ0FBQyxDQUFDO3FCQUM5RjtvQkFDTSxxQkFBTSxjQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFOzRCQUN4RCxLQUFLLEVBQUUsc0JBQXNCLENBQUMsUUFBUSxDQUFDO3lCQUN4QyxDQUFDLEVBQUE7d0JBRkYsc0JBQU8sU0FFTCxFQUFBOzs7O0NBQ0g7QUFFRCxTQUFlLGFBQWEsQ0FBQyxLQUFZOzs7Ozt3QkFFNUIscUJBQU0saUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF6QyxRQUFRLEdBQUcsU0FBOEIsQ0FBQzt5QkFDdEMsUUFBUSxFQUFSLHdCQUFRO29CQUNLLHFCQUFNLGlDQUFpQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBQTs7b0JBQW5FLFlBQVksR0FBRyxTQUFvRCxDQUFDOzt3QkFFdEUsc0JBQU8sRUFBRSxRQUFRLFVBQUEsRUFBRSxZQUFZLGNBQUEsRUFBRSxFQUFDOzs7O0NBQ25DO0FBRUQsU0FBZSxZQUFZLENBQUMsT0FBMEI7Ozs7OztvQkFDcEQsSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRO3dCQUFFLHNCQUFPLEtBQUssRUFBQzs7OztvQkFFMUIscUJBQU0sY0FBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUE7O29CQUFqRCxTQUFTLEdBQUcsU0FBcUM7b0JBQ3ZELHNCQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQzs7O29CQUV2QiwrQ0FBK0M7b0JBQy9DLHNCQUFPLEtBQUssRUFBQzs7Ozs7Q0FFaEI7QUFFRCxTQUFlLGFBQWEsQ0FBQyxXQUFrQixFQUFFLFNBQXlCOzs7O3dCQUNqRSxxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLHlCQUFtQixDQUFDLEVBQUE7d0JBQXhGLHNCQUFPLFNBQWlGLEVBQUM7Ozs7Q0FDMUY7QUFFRCxJQUFZLGlCQUlYO0FBSkQsV0FBWSxpQkFBaUI7SUFDM0IsNkRBQXdDLENBQUE7SUFDeEMsb0VBQStDLENBQUE7SUFDL0MseUVBQW9ELENBQUE7QUFDdEQsQ0FBQyxFQUpXLGlCQUFpQixHQUFqQix5QkFBaUIsS0FBakIseUJBQWlCLFFBSTVCO0FBRUQsa0JBQWU7SUFDYixNQUFNLEVBQUUsNkJBQTZCO0lBQ3JDLGtCQUFrQixFQUFFLHdCQUF3QjtJQUM1QyxhQUFhLEVBQUUscUJBQXFCO0lBQ3BDLE1BQU0sRUFBRSx3QkFBd0I7SUFDaEMsSUFBSSxFQUFFLGFBQWE7SUFDbkIsWUFBWSxjQUFBLEVBQUUsTUFBTSxnQkFBQSxFQUFFLGFBQWEsZUFBQTtDQUNwQyxDQUFBIn0=