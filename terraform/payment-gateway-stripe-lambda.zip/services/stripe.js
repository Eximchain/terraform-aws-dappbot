"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var stripe_1 = __importDefault(require("stripe"));
var lodash_keyby_1 = __importDefault(require("lodash.keyby"));
exports.stripe = new stripe_1.default(env_1.stripeKey);
var SubscriptionStates;
(function (SubscriptionStates) {
    SubscriptionStates["trial"] = "trialing";
    SubscriptionStates["active"] = "active";
    SubscriptionStates["canceled"] = "canceled";
    SubscriptionStates["unpaid"] = "unpaid";
    SubscriptionStates["incomplete"] = "incomplete";
    SubscriptionStates["incompleteExpired"] = "incomplete_expired";
    SubscriptionStates["pastDue"] = "past_due";
})(SubscriptionStates = exports.SubscriptionStates || (exports.SubscriptionStates = {}));
exports.ValidSubscriptionStates = [SubscriptionStates.trial, SubscriptionStates.active];
///////////////////////////////////////////////////
////                 KEY METHODS
///////////////////////////////////////////////////
function createCustomerAndSubscription(_a) {
    var name = _a.name, email = _a.email, token = _a.token, plans = _a.plans, coupon = _a.coupon;
    return __awaiter(this, void 0, void 0, function () {
        var newCustomer, subItems, newSub;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.create({
                        name: name, email: email,
                        description: "Customer for " + email,
                        source: token
                    })];
                case 1:
                    newCustomer = _b.sent();
                    subItems = [];
                    Object.keys(plans).forEach(function (plan) {
                        var quantity = plans[plan];
                        if (quantity > 0) {
                            subItems.push({ plan: plan, quantity: quantity });
                        }
                    });
                    return [4 /*yield*/, exports.stripe.subscriptions.create({
                            customer: newCustomer.id,
                            items: subItems,
                            trial_period_days: 7
                        })];
                case 2:
                    newSub = _b.sent();
                    return [2 /*return*/, {
                            customer: newCustomer,
                            subscription: newSub
                        }];
            }
        });
    });
}
function getStripeData(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer, subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) return [3 /*break*/, 3];
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2:
                    subscription = _a.sent();
                    _a.label = 3;
                case 3: return [2 /*return*/, { customer: customer, subscription: subscription }];
            }
        });
    });
}
///////////////////////////////////////////////////
////                 CUSTOMERS
///////////////////////////////////////////////////
function getStripeCustomerById(customerId) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                        expand: ['default_source']
                    })];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
exports.getStripeCustomerById = getStripeCustomerById;
function updateCustomerPayment(email, paymentToken) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (customer === null) {
                        throw new Error("A customer does not exist for email " + email + " in stripe");
                    }
                    return [4 /*yield*/, exports.stripe.customers.update(customer.id, { source: paymentToken })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getStripeCustomer(email) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList, customerId;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.customers.list({ email: email })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Two customers listed for " + email + ", must be an error!");
                    }
                    customerId = matchingList.data[0].id;
                    return [4 /*yield*/, exports.stripe.customers.retrieve(customerId, {
                            expand: ['default_source']
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
///////////////////////////////////////////////////
////               SUBSCRIPTIONS
///////////////////////////////////////////////////
function getStripeSubscriptionByCustomerId(stripeCustomerId) {
    return __awaiter(this, void 0, void 0, function () {
        var matchingList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.subscriptions.list({
                        customer: stripeCustomerId
                    })];
                case 1:
                    matchingList = _a.sent();
                    if (matchingList.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    else if (matchingList.data.length > 1) {
                        throw new Error("Multiple subscriptions listed for Stripe Customer " + stripeCustomerId + ", must be an error!.");
                    }
                    return [2 /*return*/, matchingList.data[0]];
            }
        });
    });
}
function getStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer) {
                        return [2 /*return*/, null];
                    }
                    return [4 /*yield*/, getStripeSubscriptionByCustomerId(customer.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function cancelStripeSubscription(email) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscription(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to cancel subscription for " + email + ", no subscription exists.");
                    }
                    return [4 /*yield*/, exports.stripe.subscriptions.del(subscription.id)];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function updateStripeSubscription(email, newPlans) {
    return __awaiter(this, void 0, void 0, function () {
        var subscription, currentItems, items, currentByPlan;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeSubscription(email)];
                case 1:
                    subscription = _a.sent();
                    if (!subscription) {
                        throw new Error("Unable to update subscription for email " + email + ", no subscriptions exist.");
                    }
                    currentItems = subscription.items.data.slice();
                    items = [];
                    currentByPlan = lodash_keyby_1.default(currentItems, function (item) { return item.plan.id; });
                    Object.keys(newPlans).forEach(function (planId) {
                        var newQuantity = newPlans[planId];
                        var currentItem = currentByPlan[planId];
                        if (newQuantity === 0) {
                            if (currentItem)
                                items.push({
                                    id: currentItem.id,
                                    deleted: true
                                });
                        }
                        else {
                            items.push(currentItem ? {
                                id: currentItem.id,
                                plan: planId,
                                quantity: newQuantity
                            } : {
                                plan: planId,
                                quantity: newQuantity
                            });
                        }
                    });
                    return [4 /*yield*/, exports.stripe.subscriptions.update(subscription.id, {
                            items: items
                        })];
                case 2: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
///////////////////////////////////////////////////
////                  INVOICES
///////////////////////////////////////////////////
function retryLatestUnpaid(email) {
    return __awaiter(this, void 0, void 0, function () {
        var latestInvoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getUnpaidInvoiceIfExists(email)];
                case 1:
                    latestInvoice = _a.sent();
                    if (!latestInvoice) return [3 /*break*/, 3];
                    return [4 /*yield*/, retryInvoiceById(latestInvoice.id)];
                case 2: return [2 /*return*/, _a.sent()];
                case 3: return [2 /*return*/, null];
            }
        });
    });
}
function retryInvoiceById(invoiceId) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.invoices.pay(invoiceId)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
function getUnpaidInvoiceIfExists(email) {
    return __awaiter(this, void 0, void 0, function () {
        var customer, invoices, latestInvoice;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getStripeCustomer(email)];
                case 1:
                    customer = _a.sent();
                    if (!customer)
                        return [2 /*return*/, null];
                    return [4 /*yield*/, exports.stripe.invoices.list({
                            customer: customer.id
                        })];
                case 2:
                    invoices = _a.sent();
                    if (invoices.data.length === 0) {
                        return [2 /*return*/, null];
                    }
                    latestInvoice = invoices.data[0];
                    if (latestInvoice.attempted && !latestInvoice.paid) {
                        return [2 /*return*/, latestInvoice];
                    }
                    else {
                        console.log('Latest invoice does not hit requirements of attempted but not paid.');
                        return [2 /*return*/, null];
                    }
                    return [2 /*return*/];
            }
        });
    });
}
///////////////////////////////////////////////////
////                  HELPERS
///////////////////////////////////////////////////
function isTokenValid(tokenId) {
    return __awaiter(this, void 0, void 0, function () {
        var tokenData, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (typeof tokenId !== 'string')
                        return [2 /*return*/, false];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, exports.stripe.tokens.retrieve(tokenId)];
                case 2:
                    tokenData = _a.sent();
                    return [2 /*return*/, !tokenData.used];
                case 3:
                    err_1 = _a.sent();
                    // Retrieve throws if this isn't a valid token.
                    return [2 /*return*/, false];
                case 4: return [2 /*return*/];
            }
        });
    });
}
function decodeWebhook(webhookBody, signature) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.stripe.webhooks.constructEvent(webhookBody, signature, env_1.stripeWebhookSecret)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
var WebhookEventTypes;
(function (WebhookEventTypes) {
    WebhookEventTypes["failedPayment"] = "invoice.payment_failed";
    WebhookEventTypes["successfulPayment"] = "invoice.payment_succeeded";
    WebhookEventTypes["trialEnding"] = "customer.subscription.trial_will_end";
})(WebhookEventTypes = exports.WebhookEventTypes || (exports.WebhookEventTypes = {}));
exports.default = {
    create: createCustomerAndSubscription,
    updateSubscription: updateStripeSubscription,
    updatePayment: updateCustomerPayment,
    cancel: cancelStripeSubscription,
    read: getStripeData,
    isTokenValid: isTokenValid, stripe: exports.stripe, decodeWebhook: decodeWebhook,
    retryLatestUnpaid: retryLatestUnpaid
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RyaXBlLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL3N0cmlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOEJBQXdEO0FBQ3hELGtEQUE0QjtBQUM1Qiw4REFBaUM7QUFDcEIsUUFBQSxNQUFNLEdBQUcsSUFBSSxnQkFBTSxDQUFDLGVBQVMsQ0FBQyxDQUFDO0FBYTVDLElBQVksa0JBUVg7QUFSRCxXQUFZLGtCQUFrQjtJQUM1Qix3Q0FBa0IsQ0FBQTtJQUNsQix1Q0FBaUIsQ0FBQTtJQUNqQiwyQ0FBcUIsQ0FBQTtJQUNyQix1Q0FBaUIsQ0FBQTtJQUNqQiwrQ0FBeUIsQ0FBQTtJQUN6Qiw4REFBd0MsQ0FBQTtJQUN4QywwQ0FBb0IsQ0FBQTtBQUN0QixDQUFDLEVBUlcsa0JBQWtCLEdBQWxCLDBCQUFrQixLQUFsQiwwQkFBa0IsUUFRN0I7QUFDWSxRQUFBLHVCQUF1QixHQUEyQixDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQXVCckgsbURBQW1EO0FBQ25ELGdDQUFnQztBQUNoQyxtREFBbUQ7QUFFbkQsU0FBZSw2QkFBNkIsQ0FBQyxFQUFzRDtRQUFwRCxjQUFJLEVBQUUsZ0JBQUssRUFBRSxnQkFBSyxFQUFFLGdCQUFLLEVBQUUsa0JBQU07Ozs7O3dCQUMxRCxxQkFBTSxjQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzt3QkFDaEQsSUFBSSxNQUFBLEVBQUUsS0FBSyxPQUFBO3dCQUNYLFdBQVcsRUFBRSxrQkFBZ0IsS0FBTzt3QkFDcEMsTUFBTSxFQUFFLEtBQUs7cUJBQ2QsQ0FBQyxFQUFBOztvQkFKSSxXQUFXLEdBQUcsU0FJbEI7b0JBQ0ksUUFBUSxHQUE0QixFQUFFLENBQUM7b0JBQzdDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSTt3QkFDN0IsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQXVCLENBQUMsQ0FBQzt3QkFDOUMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFOzRCQUNoQixRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxNQUFBLEVBQUUsUUFBUSxVQUFBLEVBQUUsQ0FBQyxDQUFBO3lCQUNsQztvQkFDSCxDQUFDLENBQUMsQ0FBQTtvQkFDYSxxQkFBTSxjQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQzs0QkFDL0MsUUFBUSxFQUFFLFdBQVcsQ0FBQyxFQUFFOzRCQUN4QixLQUFLLEVBQUUsUUFBUTs0QkFDZixpQkFBaUIsRUFBRSxDQUFDO3lCQUNyQixDQUFDLEVBQUE7O29CQUpJLE1BQU0sR0FBRyxTQUliO29CQUNGLHNCQUFPOzRCQUNMLFFBQVEsRUFBRSxXQUFXOzRCQUNyQixZQUFZLEVBQUUsTUFBTTt5QkFDckIsRUFBQTs7OztDQUNGO0FBRUQsU0FBZSxhQUFhLENBQUMsS0FBWTs7Ozs7d0JBRTVCLHFCQUFNLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsUUFBUSxHQUFHLFNBQThCLENBQUM7eUJBQ3RDLFFBQVEsRUFBUix3QkFBUTtvQkFDSyxxQkFBTSxpQ0FBaUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUE7O29CQUFuRSxZQUFZLEdBQUcsU0FBb0QsQ0FBQzs7d0JBRXRFLHNCQUFPLEVBQUUsUUFBUSxVQUFBLEVBQUUsWUFBWSxjQUFBLEVBQUUsRUFBQzs7OztDQUNuQztBQUVELG1EQUFtRDtBQUNuRCw4QkFBOEI7QUFDOUIsbURBQW1EO0FBRW5ELFNBQXNCLHFCQUFxQixDQUFDLFVBQWlCOzs7O3dCQUNwRCxxQkFBTSxjQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUU7d0JBQ2pELE1BQU0sRUFBRyxDQUFDLGdCQUFnQixDQUFDO3FCQUM1QixDQUFDLEVBQUE7d0JBRkYsc0JBQU8sU0FFTCxFQUFBOzs7O0NBQ0g7QUFKRCxzREFJQztBQUVELFNBQWUscUJBQXFCLENBQUMsS0FBYSxFQUFFLFlBQW1COzs7Ozt3QkFDcEQscUJBQU0saUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF6QyxRQUFRLEdBQUcsU0FBOEI7b0JBQy9DLElBQUcsUUFBUSxLQUFLLElBQUksRUFBQzt3QkFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBRSx5Q0FBdUMsS0FBSyxlQUFZLENBQUMsQ0FBQTtxQkFDM0U7b0JBQ00scUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFDLE1BQU0sRUFBQyxZQUFZLEVBQUMsQ0FBQyxFQUFBO3dCQUF4RSxzQkFBTyxTQUFpRSxFQUFBOzs7O0NBRXpFO0FBRUQsU0FBZSxpQkFBaUIsQ0FBQyxLQUFZOzs7Ozt3QkFDdEIscUJBQU0sY0FBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQUEsRUFBRSxDQUFDLEVBQUE7O29CQUFyRCxZQUFZLEdBQUcsU0FBc0M7b0JBRTNELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO3dCQUNsQyxzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7eUJBQU0sSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ3ZDLE1BQU0sSUFBSSxLQUFLLENBQUMsOEJBQTRCLEtBQUssd0JBQXFCLENBQUMsQ0FBQztxQkFDekU7b0JBSUssVUFBVSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUNwQyxxQkFBTSxjQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUU7NEJBQ2pELE1BQU0sRUFBRyxDQUFDLGdCQUFnQixDQUFDO3lCQUM1QixDQUFDLEVBQUE7d0JBRkYsc0JBQU8sU0FFTCxFQUFBOzs7O0NBQ0g7QUFFRCxtREFBbUQ7QUFDbkQsZ0NBQWdDO0FBQ2hDLG1EQUFtRDtBQUVuRCxTQUFlLGlDQUFpQyxDQUFDLGdCQUF1Qjs7Ozs7d0JBQ2pELHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO3dCQUNuRCxRQUFRLEVBQUUsZ0JBQWdCO3FCQUMzQixDQUFDLEVBQUE7O29CQUZJLFlBQVksR0FBRyxTQUVuQjtvQkFFRixJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDbEMsc0JBQU8sSUFBSSxFQUFDO3FCQUNiO3lCQUFNLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO3dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLHVEQUFxRCxnQkFBZ0IseUJBQXNCLENBQUMsQ0FBQztxQkFDOUc7b0JBRUQsc0JBQU8sWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQzs7OztDQUM3QjtBQUVELFNBQWUscUJBQXFCLENBQUMsS0FBWTs7Ozs7d0JBQzlCLHFCQUFNLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBekMsUUFBUSxHQUFHLFNBQThCO29CQUMvQyxJQUFJLENBQUMsUUFBUSxFQUFDO3dCQUNaLHNCQUFPLElBQUksRUFBQztxQkFDYjtvQkFDTSxxQkFBTSxpQ0FBaUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUE7d0JBQTNELHNCQUFPLFNBQW9ELEVBQUM7Ozs7Q0FDN0Q7QUFFRCxTQUFlLHdCQUF3QixDQUFDLEtBQVk7Ozs7O3dCQUM3QixxQkFBTSxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsRUFBQTs7b0JBQWpELFlBQVksR0FBRyxTQUFrQztvQkFDdkQsSUFBSSxDQUFDLFlBQVksRUFBQzt3QkFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyx1Q0FBcUMsS0FBSyw4QkFBMkIsQ0FBQyxDQUFBO3FCQUN2RjtvQkFDTSxxQkFBTSxjQUFNLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEVBQUE7d0JBQXRELHNCQUFPLFNBQStDLEVBQUE7Ozs7Q0FDdkQ7QUFFRCxTQUFlLHdCQUF3QixDQUFDLEtBQVksRUFBRSxRQUFvQjs7Ozs7d0JBQ25ELHFCQUFNLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBakQsWUFBWSxHQUFHLFNBQWtDO29CQUN2RCxJQUFJLENBQUMsWUFBWSxFQUFDO3dCQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLDZDQUEyQyxLQUFLLDhCQUEyQixDQUFDLENBQUM7cUJBQzlGO29CQUNLLFlBQVksR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDL0MsS0FBSyxHQUE0QixFQUFFLENBQUM7b0JBQ3BDLGFBQWEsR0FBRyxzQkFBSyxDQUFDLFlBQVksRUFBRSxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFaLENBQVksQ0FBQyxDQUFBO29CQUMvRCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFDLE1BQU07d0JBQ25DLElBQUksV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUF5QixDQUFDLENBQUM7d0JBQ3RELElBQUksV0FBVyxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDeEMsSUFBSSxXQUFXLEtBQUssQ0FBQyxFQUFFOzRCQUNyQixJQUFJLFdBQVc7Z0NBQUUsS0FBSyxDQUFDLElBQUksQ0FBQztvQ0FDMUIsRUFBRSxFQUFHLFdBQVcsQ0FBQyxFQUFFO29DQUNuQixPQUFPLEVBQUcsSUFBSTtpQ0FDZixDQUFDLENBQUE7eUJBQ0g7NkJBQU07NEJBQ0wsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dDQUN2QixFQUFFLEVBQUcsV0FBVyxDQUFDLEVBQUU7Z0NBQ25CLElBQUksRUFBRyxNQUFNO2dDQUNiLFFBQVEsRUFBRyxXQUFXOzZCQUN2QixDQUFDLENBQUMsQ0FBQztnQ0FDRixJQUFJLEVBQUcsTUFBTTtnQ0FDYixRQUFRLEVBQUcsV0FBVzs2QkFDdkIsQ0FBQyxDQUFBO3lCQUNIO29CQUNILENBQUMsQ0FBQyxDQUFBO29CQUNLLHFCQUFNLGNBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUU7NEJBQ3hELEtBQUssRUFBRSxLQUFLO3lCQUNiLENBQUMsRUFBQTt3QkFGRixzQkFBTyxTQUVMLEVBQUE7Ozs7Q0FDSDtBQUdELG1EQUFtRDtBQUNuRCw4QkFBOEI7QUFDOUIsbURBQW1EO0FBQ25ELFNBQWUsaUJBQWlCLENBQUMsS0FBWTs7Ozs7d0JBQ3JCLHFCQUFNLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxFQUFBOztvQkFBckQsYUFBYSxHQUFHLFNBQXFDO3lCQUN2RCxhQUFhLEVBQWIsd0JBQWE7b0JBQ1IscUJBQU0sZ0JBQWdCLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxFQUFBO3dCQUEvQyxzQkFBTyxTQUF3QyxFQUFDO3dCQUVoRCxzQkFBTyxJQUFJLEVBQUM7Ozs7Q0FFZjtBQUVELFNBQWUsZ0JBQWdCLENBQUMsU0FBZ0I7Ozs7d0JBQ3ZDLHFCQUFNLGNBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxFQUFBO3dCQUEzQyxzQkFBTyxTQUFvQyxFQUFDOzs7O0NBQzdDO0FBRUQsU0FBZSx3QkFBd0IsQ0FBQyxLQUFZOzs7Ozt3QkFDakMscUJBQU0saUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUE7O29CQUF6QyxRQUFRLEdBQUcsU0FBOEI7b0JBQy9DLElBQUksQ0FBQyxRQUFRO3dCQUFFLHNCQUFPLElBQUksRUFBQztvQkFDVixxQkFBTSxjQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDMUMsUUFBUSxFQUFHLFFBQVEsQ0FBQyxFQUFFO3lCQUN2QixDQUFDLEVBQUE7O29CQUZJLFFBQVEsR0FBRyxTQUVmO29CQUNGLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO3dCQUM5QixzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7b0JBQ0ssYUFBYSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLElBQUksYUFBYSxDQUFDLFNBQVMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUU7d0JBQ2xELHNCQUFPLGFBQWEsRUFBQztxQkFDdEI7eUJBQU07d0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxRUFBcUUsQ0FBQyxDQUFDO3dCQUNuRixzQkFBTyxJQUFJLEVBQUM7cUJBQ2I7Ozs7O0NBQ0Y7QUFFRCxtREFBbUQ7QUFDbkQsNkJBQTZCO0FBQzdCLG1EQUFtRDtBQUVuRCxTQUFlLFlBQVksQ0FBQyxPQUEwQjs7Ozs7O29CQUNwRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFFBQVE7d0JBQUUsc0JBQU8sS0FBSyxFQUFDOzs7O29CQUUxQixxQkFBTSxjQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQTs7b0JBQWpELFNBQVMsR0FBRyxTQUFxQztvQkFDdkQsc0JBQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFDOzs7b0JBRXZCLCtDQUErQztvQkFDL0Msc0JBQU8sS0FBSyxFQUFDOzs7OztDQUVoQjtBQUVELFNBQWUsYUFBYSxDQUFDLFdBQWtCLEVBQUUsU0FBeUI7Ozs7d0JBQ2pFLHFCQUFNLGNBQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUseUJBQW1CLENBQUMsRUFBQTt3QkFBeEYsc0JBQU8sU0FBaUYsRUFBQzs7OztDQUMxRjtBQUVELElBQVksaUJBSVg7QUFKRCxXQUFZLGlCQUFpQjtJQUMzQiw2REFBd0MsQ0FBQTtJQUN4QyxvRUFBK0MsQ0FBQTtJQUMvQyx5RUFBb0QsQ0FBQTtBQUN0RCxDQUFDLEVBSlcsaUJBQWlCLEdBQWpCLHlCQUFpQixLQUFqQix5QkFBaUIsUUFJNUI7QUFFRCxrQkFBZTtJQUNiLE1BQU0sRUFBRSw2QkFBNkI7SUFDckMsa0JBQWtCLEVBQUUsd0JBQXdCO0lBQzVDLGFBQWEsRUFBRSxxQkFBcUI7SUFDcEMsTUFBTSxFQUFFLHdCQUF3QjtJQUNoQyxJQUFJLEVBQUUsYUFBYTtJQUNuQixZQUFZLGNBQUEsRUFBRSxNQUFNLGdCQUFBLEVBQUUsYUFBYSxlQUFBO0lBQ25DLGlCQUFpQixtQkFBQTtDQUNsQixDQUFBIn0=