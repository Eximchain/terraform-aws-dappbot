"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
Returns a Promise that rejects with reason after msDelay milliseconds
*/
function rejectDelay(reason) {
    var msDelay = 700;
    return new Promise(function (resolve, reject) {
        setTimeout(reject.bind(null, reason), msDelay);
    });
}
exports.rejectDelay = rejectDelay;
/*
Retries a promise returned by promiseGenerator up to maxRetries times as long as the error is retryable
Based on https://stackoverflow.com/questions/38213668/promise-retry-design-patterns
*/
function addAwsPromiseRetries(promiseGenerator, maxRetries) {
    // Ensure we call promiseGenerator on the first iteration
    var p = Promise.reject({ retryable: true });
    /*
    Appends maxRetries number of retry and delay promises to an AWS promise, returning once a retry promise resolves.

    1. As long as promiseGenerator() rejects with a retryable error, we retry and then delay before the next loop iteration
    2. If promiseGenerator() resolves, the rest of the loop will finish without triggering any further catch functions
    3. If promiseGenerator() rejects with a non-retryable error, the rest of the loop will finish without any further
       retries or delays since all catch blocks will simply return Promise.reject(err)
    */
    for (var i = 0; i < maxRetries; i++) {
        p = p.catch(function (err) { return err.retryable ? promiseGenerator() : Promise.reject(err); })
            .catch(function (err) { return err.retryable ? rejectDelay(err) : Promise.reject(err); });
    }
    return p;
}
exports.addAwsPromiseRetries = addAwsPromiseRetries;
var DappTiers;
(function (DappTiers) {
    DappTiers["POC"] = "POC";
    DappTiers["STANDARD"] = "STANDARD";
    DappTiers["PROFESSIONAL"] = "PROFESSIONAL";
    DappTiers["ENTERPRISE"] = "ENTERPRISE";
})(DappTiers = exports.DappTiers || (exports.DappTiers = {}));
var HttpMethods;
(function (HttpMethods) {
    HttpMethods["OPTIONS"] = "OPTIONS";
    HttpMethods["GET"] = "GET";
    HttpMethods["POST"] = "POST";
    HttpMethods["PUT"] = "PUT";
    HttpMethods["DELETE"] = "DELETE";
})(HttpMethods = exports.HttpMethods || (exports.HttpMethods = {}));
var ApiMethods;
(function (ApiMethods) {
    ApiMethods["read"] = "read";
    ApiMethods["view"] = "view";
    ApiMethods["list"] = "list";
    ApiMethods["create"] = "create";
    ApiMethods["update"] = "update";
    ApiMethods["delete"] = "delete";
})(ApiMethods = exports.ApiMethods || (exports.ApiMethods = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImNvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBOztFQUVFO0FBQ0YsU0FBZ0IsV0FBVyxDQUFDLE1BQWE7SUFDckMsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDO0lBQ2xCLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBUyxPQUFPLEVBQUUsTUFBTTtRQUN2QyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDbkQsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBTEQsa0NBS0M7QUFFRDs7O0VBR0U7QUFDRixTQUFnQixvQkFBb0IsQ0FBQyxnQkFBaUMsRUFBRSxVQUFpQjtJQUNyRix5REFBeUQ7SUFDekQsSUFBSSxDQUFDLEdBQWdCLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBQyxTQUFTLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztJQUV2RDs7Ozs7OztNQU9FO0lBQ0YsS0FBSSxJQUFJLENBQUMsR0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUM1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQXhELENBQXdELENBQUM7YUFDdEUsS0FBSyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUF0RCxDQUFzRCxDQUFDLENBQUM7S0FDOUU7SUFDRCxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUM7QUFqQkQsb0RBaUJDO0FBMkJELElBQVksU0FLWDtBQUxELFdBQVksU0FBUztJQUNqQix3QkFBVyxDQUFBO0lBQ1gsa0NBQXFCLENBQUE7SUFDckIsMENBQTZCLENBQUE7SUFDN0Isc0NBQXlCLENBQUE7QUFDN0IsQ0FBQyxFQUxXLFNBQVMsR0FBVCxpQkFBUyxLQUFULGlCQUFTLFFBS3BCO0FBRUQsSUFBWSxXQU1YO0FBTkQsV0FBWSxXQUFXO0lBQ25CLGtDQUFtQixDQUFBO0lBQ25CLDBCQUFXLENBQUE7SUFDWCw0QkFBYSxDQUFBO0lBQ2IsMEJBQVcsQ0FBQTtJQUNYLGdDQUFpQixDQUFBO0FBQ3JCLENBQUMsRUFOVyxXQUFXLEdBQVgsbUJBQVcsS0FBWCxtQkFBVyxRQU10QjtBQUVELElBQVksVUFRWDtBQVJELFdBQVksVUFBVTtJQUNsQiwyQkFBYSxDQUFBO0lBQ2IsMkJBQWEsQ0FBQTtJQUNiLDJCQUFhLENBQUE7SUFDYiwrQkFBaUIsQ0FBQTtJQUNqQiwrQkFBaUIsQ0FBQTtJQUNqQiwrQkFBaUIsQ0FBQTtBQUVyQixDQUFDLEVBUlcsVUFBVSxHQUFWLGtCQUFVLEtBQVYsa0JBQVUsUUFRckIifQ==