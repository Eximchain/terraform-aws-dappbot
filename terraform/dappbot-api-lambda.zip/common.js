"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
Returns a Promise that rejects with reason after msDelay milliseconds
*/
function rejectDelay(reason) {
    var msDelay = 700;
    return new Promise(function (resolve, reject) {
        setTimeout(reject.bind(null, reason), msDelay);
    });
}
exports.rejectDelay = rejectDelay;
/*
Retries a promise returned by promiseGenerator up to maxRetries times
as long as the error is retryable. Defaults to 5 retries.

Based on https://stackoverflow.com/questions/38213668/promise-retry-design-patterns
*/
function addAwsPromiseRetries(promiseGenerator, maxRetries) {
    if (maxRetries === void 0) { maxRetries = 5; }
    // Ensure we call promiseGenerator on the first iteration
    var p = Promise.reject({ retryable: true });
    /*
    Appends maxRetries number of retry and delay promises to an AWS promise, returning once a retry promise resolves.

    1. As long as promiseGenerator() rejects with a retryable error, we retry and then delay before the next loop iteration
    2. If promiseGenerator() resolves, the rest of the loop will finish without triggering any further catch functions
    3. If promiseGenerator() rejects with a non-retryable error, the rest of the loop will finish without any further
       retries or delays since all catch blocks will simply return Promise.reject(err)
    */
    for (var i = 0; i < maxRetries; i++) {
        p = p.catch(function (err) { return err.retryable ? promiseGenerator() : Promise.reject(err); })
            .catch(function (err) { return err.retryable ? rejectDelay(err) : Promise.reject(err); });
    }
    return p;
}
exports.addAwsPromiseRetries = addAwsPromiseRetries;
var logSuccess = function (stage, res) { console.log("Successfully completed " + stage + "; result: ", res); };
var logErr = function (stage, err) { console.log("Error on " + stage + ": ", err); };
function callAndLog(stage, promise) {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, promise];
                case 1:
                    res = _a.sent();
                    logSuccess(stage, res);
                    return [2 /*return*/, res];
                case 2:
                    err_1 = _a.sent();
                    logErr(stage, err_1);
                    throw err_1;
                case 3: return [2 /*return*/];
            }
        });
    });
}
exports.callAndLog = callAndLog;
var DappTiers;
(function (DappTiers) {
    DappTiers["POC"] = "POC";
    DappTiers["STANDARD"] = "STANDARD";
    DappTiers["PROFESSIONAL"] = "PROFESSIONAL";
    DappTiers["ENTERPRISE"] = "ENTERPRISE";
})(DappTiers = exports.DappTiers || (exports.DappTiers = {}));
var HttpMethods;
(function (HttpMethods) {
    HttpMethods["OPTIONS"] = "OPTIONS";
    HttpMethods["GET"] = "GET";
    HttpMethods["POST"] = "POST";
    HttpMethods["PUT"] = "PUT";
    HttpMethods["DELETE"] = "DELETE";
})(HttpMethods = exports.HttpMethods || (exports.HttpMethods = {}));
var ApiMethods;
(function (ApiMethods) {
    ApiMethods["read"] = "read";
    ApiMethods["view"] = "view";
    ApiMethods["list"] = "list";
    ApiMethods["create"] = "create";
    ApiMethods["update"] = "update";
    ApiMethods["delete"] = "delete";
    ApiMethods["login"] = "login";
    ApiMethods["passwordReset"] = "password-reset";
})(ApiMethods = exports.ApiMethods || (exports.ApiMethods = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImNvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0VBRUU7QUFDRixTQUFnQixXQUFXLENBQWMsTUFBYTtJQUNsRCxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUM7SUFDbEIsT0FBTyxJQUFJLE9BQU8sQ0FBYyxVQUFTLE9BQU8sRUFBRSxNQUFNO1FBQ3BELFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNuRCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFMRCxrQ0FLQztBQUVEOzs7OztFQUtFO0FBQ0YsU0FBZ0Isb0JBQW9CLENBQW1CLGdCQUF3QyxFQUFFLFVBQXFCO0lBQXJCLDJCQUFBLEVBQUEsY0FBcUI7SUFDbEgseURBQXlEO0lBQ3pELElBQUksQ0FBQyxHQUF1QixPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsU0FBUyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7SUFFOUQ7Ozs7Ozs7TUFPRTtJQUNGLEtBQUksSUFBSSxDQUFDLEdBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDNUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUF4RCxDQUF3RCxDQUFDO2FBQ3RFLEtBQUssQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBbEUsQ0FBa0UsQ0FBQyxDQUFDO0tBQzFGO0lBQ0QsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDO0FBakJELG9EQWlCQztBQUVELElBQU0sVUFBVSxHQUFHLFVBQUMsS0FBWSxFQUFFLEdBQU8sSUFBTyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUEwQixLQUFLLGVBQVksRUFBRSxHQUFHLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQTtBQUMvRyxJQUFNLE1BQU0sR0FBRyxVQUFDLEtBQVksRUFBRSxHQUFPLElBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFZLEtBQUssT0FBSSxFQUFFLEdBQUcsQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFBO0FBRXJGLFNBQXNCLFVBQVUsQ0FBbUIsS0FBWSxFQUFFLE9BQTJCOzs7Ozs7O29CQUUxRSxxQkFBTSxPQUFPLEVBQUE7O29CQUFuQixHQUFHLEdBQUcsU0FBYTtvQkFDdkIsVUFBVSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDdkIsc0JBQU8sR0FBRyxFQUFDOzs7b0JBRVgsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDbkIsTUFBTSxLQUFHLENBQUM7Ozs7O0NBRWpCO0FBVEQsZ0NBU0M7QUEyQkQsSUFBWSxTQUtYO0FBTEQsV0FBWSxTQUFTO0lBQ2pCLHdCQUFXLENBQUE7SUFDWCxrQ0FBcUIsQ0FBQTtJQUNyQiwwQ0FBNkIsQ0FBQTtJQUM3QixzQ0FBeUIsQ0FBQTtBQUM3QixDQUFDLEVBTFcsU0FBUyxHQUFULGlCQUFTLEtBQVQsaUJBQVMsUUFLcEI7QUFFRCxJQUFZLFdBTVg7QUFORCxXQUFZLFdBQVc7SUFDbkIsa0NBQW1CLENBQUE7SUFDbkIsMEJBQVcsQ0FBQTtJQUNYLDRCQUFhLENBQUE7SUFDYiwwQkFBVyxDQUFBO0lBQ1gsZ0NBQWlCLENBQUE7QUFDckIsQ0FBQyxFQU5XLFdBQVcsR0FBWCxtQkFBVyxLQUFYLG1CQUFXLFFBTXRCO0FBRUQsSUFBWSxVQVNYO0FBVEQsV0FBWSxVQUFVO0lBQ2xCLDJCQUFhLENBQUE7SUFDYiwyQkFBYSxDQUFBO0lBQ2IsMkJBQWEsQ0FBQTtJQUNiLCtCQUFpQixDQUFBO0lBQ2pCLCtCQUFpQixDQUFBO0lBQ2pCLCtCQUFpQixDQUFBO0lBQ2pCLDZCQUFnQixDQUFBO0lBQ2hCLDhDQUFnQyxDQUFBO0FBQ3BDLENBQUMsRUFUVyxVQUFVLEdBQVYsa0JBQVUsS0FBVixrQkFBVSxRQVNyQiJ9