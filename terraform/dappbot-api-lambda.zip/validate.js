"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var common_1 = require("./common");
var services_1 = __importDefault(require("./services"));
var cognito = services_1.default.cognito, dynamoDB = services_1.default.dynamoDB;
var errors_1 = require("./errors");
var dappTierToLimitAttr = (_a = {},
    _a[common_1.DappTiers.POC] = 'custom:num_dapps',
    _a[common_1.DappTiers.STANDARD] = 'custom:standard_limit',
    _a[common_1.DappTiers.PROFESSIONAL] = 'custom:professional_limit',
    _a[common_1.DappTiers.ENTERPRISE] = 'custom:enterprise_limit',
    _a);
// Names that should be disallowed for DappName values
var reservedDappNames = new Set([
    'abi',
    'abiclerk',
    'abi-clerk',
    'admin',
    'administrator',
    'api',
    'app',
    'automate',
    'blockvote',
    'blockvoting',
    'community',
    'conference',
    'console',
    'dashboard',
    'dapp',
    'dappbot',
    'dapp-bot',
    'dapperator',
    'dappname',
    'dapp-name',
    'dappsmith',
    'dapp-smith',
    'deploy',
    'directory',
    'exim',
    'eximchain',
    'forum',
    'guard',
    'guardian',
    'help',
    'home',
    'hub',
    'marketplace',
    'quadraticvote',
    'quadraticvoting',
    'root',
    'support',
    'vault',
    'wallet',
    'weyl',
    'weylgov',
    'weylgovern',
    'weylgovernance'
]);
var validDappTiers = new Set(Object.keys(common_1.DappTiers));
// CREATE VALIDATION
function validateBodyCreate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "create: required argument 'DappName' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Abi'), "create: required argument 'Abi' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('ContractAddr'), "create: required argument 'ContractAddr' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Web3URL'), "create: required argument 'Web3URL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('GuardianURL'), "create: required argument 'GuardianURL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Tier'), "create: required argument 'Tier' not found");
    var createBody = body;
    if (createBody.Tier === common_1.DappTiers.ENTERPRISE) {
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoName'), "create: enterprise version required argument 'TargetRepoName' not found");
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoOwner'), "create: enterprise version required argument 'TargetRepoName' not found");
    }
}
function validateLimitsCreate(cognitoUsername, ownerEmail, tier) {
    return __awaiter(this, void 0, void 0, function () {
        var user, attrList, dappLimitAttr, dappLimit, dappItems, numDappsOwned, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Validating Limits for User", cognitoUsername);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, cognito.getUser(cognitoUsername)];
                case 2:
                    user = _a.sent();
                    console.log("Found Cognito User", user);
                    attrList = user.UserAttributes;
                    dappLimitAttr = attrList.filter(function (attr) { return attr.Name === dappTierToLimitAttr[tier]; });
                    dappLimit = void 0;
                    if (dappLimitAttr.length === 0) {
                        dappLimit = 0;
                    }
                    else {
                        errors_1.assertInternal(dappLimitAttr.length === 1);
                        dappLimit = parseInt(dappLimitAttr[0].Value);
                    }
                    return [4 /*yield*/, dynamoDB.getByOwnerAndTier(ownerEmail, tier)];
                case 3:
                    dappItems = _a.sent();
                    console.log("Queried DynamoDB Table", dappItems);
                    numDappsOwned = dappItems.length;
                    errors_1.assertOperationAllowed(numDappsOwned + 1 <= dappLimit, "User " + ownerEmail + " already at dapp limit: " + dappLimit);
                    return [2 /*return*/, true];
                case 4:
                    err_1 = _a.sent();
                    console.log("Error Validating Limit", err_1);
                    errors_1.throwInternalValidationError();
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function validateAllowedDappName(dappName, email) {
    // Admins can use reserved names
    if (isAdmin(email)) {
        return true;
    }
    errors_1.assertOperationAllowed(!reservedDappNames.has(dappName), "Specified DappName " + dappName + " is not an allowed name");
    return true;
}
function validateTier(dappTier) {
    errors_1.assertOperationAllowed(validDappTiers.has(dappTier), "Invalid Tier '" + dappTier + "' specified");
}
function validateNameNotTaken(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var existingItem, err_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    existingItem = null;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 2:
                    existingItem = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    err_2 = _a.sent();
                    console.log("Error retrieving DB Item for create validation", err_2);
                    throw err_2;
                case 4:
                    errors_1.assertOperationAllowed(!existingItem.Item, "DappName " + dappName + " is already taken. Please choose another name.");
                    return [2 /*return*/];
            }
        });
    });
}
function validateCreateAllowed(dappName, cognitoUsername, callerEmail, dappTier) {
    return __awaiter(this, void 0, void 0, function () {
        var limitCheck, nameTakenCheck;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    validateAllowedDappName(dappName, callerEmail);
                    validateTier(dappTier);
                    limitCheck = validateLimitsCreate(cognitoUsername, callerEmail, dappTier);
                    nameTakenCheck = validateNameNotTaken(dappName);
                    return [4 /*yield*/, limitCheck];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, nameTakenCheck];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
// READ VALIDATION
function validateBodyRead(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "read: required argument 'DappName' not found");
}
function validateReadAllowed(dbItem, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbOwner;
        return __generator(this, function (_a) {
            if (isAdmin(callerEmail)) {
                return [2 /*return*/];
            }
            dbOwner = dbItem.Item.OwnerEmail.S;
            errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to read the specified Dapp.");
            return [2 /*return*/];
        });
    });
}
// UPDATE VALIDATION
function validateBodyUpdate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "update: required argument 'DappName' not found");
}
function validateUpdateAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertOperationAllowed(dbItem.Item, "Dapp Not Found");
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to update the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// DELETE VALIDATION
function validateBodyDelete(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "delete: required argument 'DappName' not found");
}
function validateDeleteAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertOperationAllowed(dbItem.Item, "Dapp Not Found");
                    if (isAdmin(callerEmail)) {
                        return [2 /*return*/, dbItem.Item];
                    }
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to delete the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// HELPER FUNCTIONS
/*
Returns whether an email has Admin rights
Admins can bypass certain restrictions

- Admins can delete other users' Dapps
- Admins can read other users' Dapps
- Admins can create Dapps using a reserved name
*/
function isAdmin(email) {
    var adminEmail = 'louis@eximchain.com';
    return email === adminEmail;
}
function cleanDappName(name) {
    return name.toLowerCase()
        .replace(/\s/g, '-') // Convert spaces to hyphens
        .replace(/[^A-Za-z0-9-]/g, '') // Remove non-alphanumerics
        .replace(/-*$|^-*/g, ''); // Trim hyphens off the front & back
}
exports.default = {
    createBody: validateBodyCreate,
    createAllowed: validateCreateAllowed,
    readBody: validateBodyRead,
    readAllowed: validateReadAllowed,
    updateBody: validateBodyUpdate,
    updateAllowed: validateUpdateAllowed,
    deleteBody: validateBodyDelete,
    deleteAllowed: validateDeleteAllowed,
    cleanName: cleanDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxtQ0FBc0Q7QUFDdEQsd0RBQWtDO0FBQzFCLElBQUEsb0NBQU8sRUFBRSxzQ0FBUSxDQUFjO0FBQ3ZDLG1DQUFzSDtBQUd0SCxJQUFNLG1CQUFtQjtJQUNyQixHQUFDLGtCQUFTLENBQUMsR0FBRyxJQUFHLGtCQUFrQjtJQUNuQyxHQUFDLGtCQUFTLENBQUMsUUFBUSxJQUFHLHVCQUF1QjtJQUM3QyxHQUFDLGtCQUFTLENBQUMsWUFBWSxJQUFHLDJCQUEyQjtJQUNyRCxHQUFDLGtCQUFTLENBQUMsVUFBVSxJQUFHLHlCQUF5QjtPQUNwRCxDQUFDO0FBRUYsc0RBQXNEO0FBQ3RELElBQU0saUJBQWlCLEdBQUcsSUFBSSxHQUFHLENBQUM7SUFDOUIsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsT0FBTztJQUNQLGVBQWU7SUFDZixLQUFLO0lBQ0wsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsYUFBYTtJQUNiLFdBQVc7SUFDWCxZQUFZO0lBQ1osU0FBUztJQUNULFdBQVc7SUFDWCxNQUFNO0lBQ04sU0FBUztJQUNULFVBQVU7SUFDVixZQUFZO0lBQ1osVUFBVTtJQUNWLFdBQVc7SUFDWCxXQUFXO0lBQ1gsWUFBWTtJQUNaLFFBQVE7SUFDUixXQUFXO0lBQ1gsTUFBTTtJQUNOLFdBQVc7SUFDWCxPQUFPO0lBQ1AsT0FBTztJQUNQLFVBQVU7SUFDVixNQUFNO0lBQ04sTUFBTTtJQUNOLEtBQUs7SUFDTCxhQUFhO0lBQ2IsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixNQUFNO0lBQ04sU0FBUztJQUNULE9BQU87SUFDUCxRQUFRO0lBQ1IsTUFBTTtJQUNOLFNBQVM7SUFDVCxZQUFZO0lBQ1osZ0JBQWdCO0NBQ25CLENBQUMsQ0FBQztBQUVILElBQU0sY0FBYyxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0JBQVMsQ0FBQyxDQUFDLENBQUM7QUFFdkQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDeEcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSwyQ0FBMkMsQ0FBQyxDQUFDO0lBQzlGLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUNoSCw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLCtDQUErQyxDQUFDLENBQUM7SUFDdEcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsRUFBRSxtREFBbUQsQ0FBQyxDQUFDO0lBQzlHLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUUsNENBQTRDLENBQUMsQ0FBQztJQUVoRyxJQUFJLFVBQVUsR0FBRyxJQUF1QixDQUFDO0lBQ3pDLElBQUksVUFBVSxDQUFDLElBQUksS0FBSyxrQkFBUyxDQUFDLFVBQVUsRUFBRTtRQUMxQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLEVBQUUseUVBQXlFLENBQUMsQ0FBQztRQUN2SSw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDLEVBQUUseUVBQXlFLENBQUMsQ0FBQztLQUMzSTtBQUNMLENBQUM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLGVBQXNCLEVBQUUsVUFBaUIsRUFBRSxJQUFjOzs7Ozs7b0JBQ3pGLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsZUFBZSxDQUFDLENBQUM7Ozs7b0JBRzVDLHFCQUFNLE9BQU8sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQUE7O29CQUE3QyxJQUFJLEdBQUcsU0FBc0M7b0JBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRXBDLFFBQVEsR0FBcUIsSUFBSSxDQUFDLGNBQWMsQ0FBQztvQkFDakQsYUFBYSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxJQUFJLENBQUMsSUFBSSxLQUFLLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUF2QyxDQUF1QyxDQUFDLENBQUM7b0JBQ2pGLFNBQVMsU0FBQSxDQUFDO29CQUNkLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQzVCLFNBQVMsR0FBRyxDQUFDLENBQUM7cUJBQ2pCO3lCQUFNO3dCQUNILHVCQUFjLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDM0MsU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBZSxDQUFDLENBQUM7cUJBQzFEO29CQUVlLHFCQUFNLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLEVBQUE7O29CQUE5RCxTQUFTLEdBQUcsU0FBa0Q7b0JBQ2xFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBRTdDLGFBQWEsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDO29CQUNyQywrQkFBc0IsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLFNBQVMsRUFBRSxPQUFPLEdBQUcsVUFBVSxHQUFHLDBCQUEwQixHQUFHLFNBQVMsQ0FBQyxDQUFDO29CQUN0SCxzQkFBTyxJQUFJLEVBQUM7OztvQkFFWixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUMzQyxxQ0FBNEIsRUFBRSxDQUFDOzs7Ozs7Q0FFdEM7QUFFRCxTQUFTLHVCQUF1QixDQUFDLFFBQWUsRUFBRSxLQUFZO0lBQzFELGdDQUFnQztJQUNoQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNoQixPQUFPLElBQUksQ0FBQztLQUNmO0lBQ0QsK0JBQXNCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsd0JBQXNCLFFBQVEsNEJBQXlCLENBQUMsQ0FBQztJQUNsSCxPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUMsUUFBZTtJQUNqQywrQkFBc0IsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLG1CQUFpQixRQUFRLGdCQUFhLENBQUMsQ0FBQztBQUNqRyxDQUFDO0FBRUQsU0FBZSxvQkFBb0IsQ0FBQyxRQUFlOzs7Ozs7b0JBQzNDLFlBQVksR0FBRyxJQUFJLENBQUM7Ozs7b0JBRUwscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFlBQVksR0FBRyxTQUFnQyxDQUFDOzs7O29CQUVoRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNuRSxNQUFNLEtBQUcsQ0FBQzs7b0JBRWQsK0JBQXNCLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLGNBQVksUUFBUSxtREFBZ0QsQ0FBQyxDQUFDOzs7OztDQUNwSDtBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLGVBQXNCLEVBQUUsV0FBa0IsRUFBRSxRQUFrQjs7Ozs7O29CQUNoSCx1QkFBdUIsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7b0JBQy9DLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDbkIsVUFBVSxHQUFHLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBQzFFLGNBQWMsR0FBRyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEQscUJBQU0sVUFBVSxFQUFBOztvQkFBaEIsU0FBZ0IsQ0FBQztvQkFDakIscUJBQU0sY0FBYyxFQUFBOztvQkFBcEIsU0FBb0IsQ0FBQzs7Ozs7Q0FDeEI7QUFFRCxrQkFBa0I7QUFFbEIsU0FBUyxnQkFBZ0IsQ0FBQyxJQUFXO0lBQ2pDLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUUsOENBQThDLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBRUQsU0FBZSxtQkFBbUIsQ0FBQyxNQUFVLEVBQUUsV0FBa0I7Ozs7WUFDN0QsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQUUsc0JBQU87YUFBRTtZQUVqQyxPQUFPLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLCtCQUFzQixDQUFDLFdBQVcsS0FBSyxPQUFPLEVBQUUsd0RBQXdELENBQUMsQ0FBQzs7OztDQUM3RztBQUVELG9CQUFvQjtBQUVwQixTQUFTLGtCQUFrQixDQUFDLElBQVc7SUFDbkMsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxnREFBZ0QsQ0FBQyxDQUFDO0FBQzVHLENBQUM7QUFFRCxTQUFlLHFCQUFxQixDQUFDLFFBQWUsRUFBRSxXQUFrQjs7Ozs7d0JBQ3ZELHFCQUFNLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUE7O29CQUF6QyxNQUFNLEdBQUcsU0FBZ0M7b0JBQzdDLCtCQUFzQixDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztvQkFFbEQsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztvQkFDdkMsK0JBQXNCLENBQUMsV0FBVyxLQUFLLE9BQU8sRUFBRSwwREFBMEQsQ0FBQyxDQUFDO29CQUU1RyxzQkFBTyxNQUFNLENBQUMsSUFBSSxFQUFDOzs7O0NBQ3RCO0FBRUQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7QUFDNUcsQ0FBQztBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLFdBQWtCOzs7Ozt3QkFDdkQscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXpDLE1BQU0sR0FBRyxTQUFnQztvQkFDN0MsK0JBQXNCLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO29CQUV0RCxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTt3QkFDdEIsc0JBQU8sTUFBTSxDQUFDLElBQUksRUFBQztxQkFDdEI7b0JBRUcsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztvQkFDdkMsK0JBQXNCLENBQUMsV0FBVyxLQUFLLE9BQU8sRUFBRSwwREFBMEQsQ0FBQyxDQUFDO29CQUU1RyxzQkFBTyxNQUFNLENBQUMsSUFBSSxFQUFDOzs7O0NBQ3RCO0FBRUQsbUJBQW1CO0FBRW5COzs7Ozs7O0VBT0U7QUFDRixTQUFTLE9BQU8sQ0FBQyxLQUFZO0lBQ3pCLElBQUksVUFBVSxHQUFHLHFCQUFxQixDQUFDO0lBQ3ZDLE9BQU8sS0FBSyxLQUFLLFVBQVUsQ0FBQztBQUNoQyxDQUFDO0FBRUQsU0FBUyxhQUFhLENBQUMsSUFBVztJQUM5QixPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUU7U0FDcEIsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyw0QkFBNEI7U0FDaEQsT0FBTyxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxDQUFDLDJCQUEyQjtTQUN6RCxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFBLENBQUMsb0NBQW9DO0FBQ3JFLENBQUM7QUFFRCxrQkFBZTtJQUNYLFVBQVUsRUFBRyxrQkFBa0I7SUFDL0IsYUFBYSxFQUFHLHFCQUFxQjtJQUNyQyxRQUFRLEVBQUcsZ0JBQWdCO0lBQzNCLFdBQVcsRUFBRyxtQkFBbUI7SUFDakMsVUFBVSxFQUFHLGtCQUFrQjtJQUMvQixhQUFhLEVBQUcscUJBQXFCO0lBQ3JDLFVBQVUsRUFBRyxrQkFBa0I7SUFDL0IsYUFBYSxFQUFHLHFCQUFxQjtJQUNyQyxTQUFTLEVBQUcsYUFBYTtDQUM1QixDQUFBIn0=