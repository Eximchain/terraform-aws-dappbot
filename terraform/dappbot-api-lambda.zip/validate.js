"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("./common");
var services_1 = __importDefault(require("./services"));
var cognito = services_1.default.cognito, dynamoDB = services_1.default.dynamoDB;
var errors_1 = require("./errors");
var dappLimitAttrName = 'custom:num_dapps';
// Names that should be disallowed for DappName values
var reservedDappNames = new Set([
    'abi',
    'abiclerk',
    'abi-clerk',
    'admin',
    'administrator',
    'api',
    'app',
    'automate',
    'blockvote',
    'blockvoting',
    'community',
    'conference',
    'console',
    'dashboard',
    'dapp',
    'dappbot',
    'dapp-bot',
    'dapperator',
    'dappname',
    'dapp-name',
    'dappsmith',
    'dapp-smith',
    'deploy',
    'directory',
    'exim',
    'eximchain',
    'forum',
    'guard',
    'guardian',
    'help',
    'home',
    'hub',
    'marketplace',
    'quadraticvote',
    'quadraticvoting',
    'root',
    'support',
    'vault',
    'wallet',
    'weyl',
    'weylgov',
    'weylgovern',
    'weylgovernance'
]);
var validDappTiers = new Set(Object.keys(common_1.DappTiers));
// CREATE VALIDATION
function validateBodyCreate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "create: required argument 'DappName' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Abi'), "create: required argument 'Abi' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('ContractAddr'), "create: required argument 'ContractAddr' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Web3URL'), "create: required argument 'Web3URL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('GuardianURL'), "create: required argument 'GuardianURL' not found");
}
function validateLimitsCreate(cognitoUsername, ownerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var user, attrList, dappLimitAttr, dappLimit, dappItems, numDappsOwned, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Validating Limits for User", cognitoUsername);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, cognito.getUser(cognitoUsername)];
                case 2:
                    user = _a.sent();
                    console.log("Found Cognito User", user);
                    attrList = user.UserAttributes;
                    dappLimitAttr = attrList.filter(function (attr) { return attr.Name === dappLimitAttrName; });
                    errors_1.assertInternal(dappLimitAttr.length === 1);
                    dappLimit = dappLimitAttr[0].Value;
                    return [4 /*yield*/, dynamoDB.getByOwner(ownerEmail)];
                case 3:
                    dappItems = _a.sent();
                    console.log("Queried DynamoDB Table", dappItems);
                    numDappsOwned = dappItems.Items.length;
                    errors_1.assertOperationAllowed(numDappsOwned + 1 <= dappLimit, "User " + ownerEmail + " already at dapp limit: " + dappLimit);
                    return [2 /*return*/, true];
                case 4:
                    err_1 = _a.sent();
                    console.log("Error Validating Limit", err_1);
                    errors_1.throwInternalValidationError();
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function validateAllowedDappName(dappName, email) {
    // Admins can use reserved names
    if (isAdmin(email)) {
        return true;
    }
    errors_1.assertOperationAllowed(!reservedDappNames.has(dappName), "Specified DappName " + dappName + " is not an allowed name");
    return true;
}
function validateTier(dappTier) {
    errors_1.assertOperationAllowed(validDappTiers.has(dappTier), "Invalid Tier '" + dappTier + "' specified");
}
function validateNameNotTaken(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var existingItem, err_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    existingItem = null;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 2:
                    existingItem = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    err_2 = _a.sent();
                    console.log("Error retrieving DB Item for create validation", err_2);
                    throw err_2;
                case 4:
                    errors_1.assertOperationAllowed(!existingItem.Item, "DappName " + dappName + " is already taken. Please choose another name.");
                    return [2 /*return*/];
            }
        });
    });
}
function validateCreateAllowed(dappName, cognitoUsername, callerEmail, dappTier) {
    return __awaiter(this, void 0, void 0, function () {
        var limitCheck, nameTakenCheck;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    validateAllowedDappName(dappName, callerEmail);
                    validateTier(dappTier);
                    limitCheck = validateLimitsCreate(cognitoUsername, callerEmail);
                    nameTakenCheck = validateNameNotTaken(dappName);
                    return [4 /*yield*/, limitCheck];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, nameTakenCheck];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
// READ VALIDATION
function validateBodyRead(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "read: required argument 'DappName' not found");
}
function validateReadAllowed(dbItem, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbOwner;
        return __generator(this, function (_a) {
            if (isAdmin(callerEmail)) {
                return [2 /*return*/];
            }
            dbOwner = dbItem.Item.OwnerEmail.S;
            errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to read the specified Dapp.");
            return [2 /*return*/];
        });
    });
}
// UPDATE VALIDATION
function validateBodyUpdate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "update: required argument 'DappName' not found");
}
function validateUpdateAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertOperationAllowed(dbItem.Item, "Dapp Not Found");
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to update the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// DELETE VALIDATION
function validateBodyDelete(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('DappName'), "delete: required argument 'DappName' not found");
}
function validateDeleteAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertOperationAllowed(dbItem.Item, "Dapp Not Found");
                    if (isAdmin(callerEmail)) {
                        return [2 /*return*/, dbItem.Item];
                    }
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to delete the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// HELPER FUNCTIONS
/*
Returns whether an email has Admin rights
Admins can bypass certain restrictions

- Admins can delete other users' Dapps
- Admins can read other users' Dapps
- Admins can create Dapps using a reserved name
*/
function isAdmin(email) {
    var adminEmail = 'louis@eximchain.com';
    return email === adminEmail;
}
function cleanDappName(name) {
    return name.toLowerCase()
        .replace(/\s/g, '-') // Convert spaces to hyphens
        .replace(/[^A-Za-z0-9-]/g, '') // Remove non-alphanumerics
        .replace(/-*$|^-*/g, ''); // Trim hyphens off the front & back
}
exports.default = {
    createBody: validateBodyCreate,
    createAllowed: validateCreateAllowed,
    readBody: validateBodyRead,
    readAllowed: validateReadAllowed,
    updateBody: validateBodyUpdate,
    updateAllowed: validateUpdateAllowed,
    deleteBody: validateBodyDelete,
    deleteAllowed: validateDeleteAllowed,
    cleanName: cleanDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLG1DQUFxQztBQUNyQyx3REFBa0M7QUFDMUIsSUFBQSxvQ0FBTyxFQUFFLHNDQUFRLENBQWM7QUFDdkMsbUNBQXNIO0FBR3RILElBQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBQUM7QUFFN0Msc0RBQXNEO0FBQ3RELElBQU0saUJBQWlCLEdBQUcsSUFBSSxHQUFHLENBQUM7SUFDOUIsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsT0FBTztJQUNQLGVBQWU7SUFDZixLQUFLO0lBQ0wsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsYUFBYTtJQUNiLFdBQVc7SUFDWCxZQUFZO0lBQ1osU0FBUztJQUNULFdBQVc7SUFDWCxNQUFNO0lBQ04sU0FBUztJQUNULFVBQVU7SUFDVixZQUFZO0lBQ1osVUFBVTtJQUNWLFdBQVc7SUFDWCxXQUFXO0lBQ1gsWUFBWTtJQUNaLFFBQVE7SUFDUixXQUFXO0lBQ1gsTUFBTTtJQUNOLFdBQVc7SUFDWCxPQUFPO0lBQ1AsT0FBTztJQUNQLFVBQVU7SUFDVixNQUFNO0lBQ04sTUFBTTtJQUNOLEtBQUs7SUFDTCxhQUFhO0lBQ2IsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixNQUFNO0lBQ04sU0FBUztJQUNULE9BQU87SUFDUCxRQUFRO0lBQ1IsTUFBTTtJQUNOLFNBQVM7SUFDVCxZQUFZO0lBQ1osZ0JBQWdCO0NBQ25CLENBQUMsQ0FBQztBQUVILElBQU0sY0FBYyxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0JBQVMsQ0FBQyxDQUFDLENBQUM7QUFFdkQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDeEcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSwyQ0FBMkMsQ0FBQyxDQUFDO0lBQzlGLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUNoSCw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLCtDQUErQyxDQUFDLENBQUM7SUFDdEcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsRUFBRSxtREFBbUQsQ0FBQyxDQUFDO0FBQ2xILENBQUM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLGVBQXNCLEVBQUUsVUFBaUI7Ozs7OztvQkFDekUsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxlQUFlLENBQUMsQ0FBQzs7OztvQkFHNUMscUJBQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBQTs7b0JBQTdDLElBQUksR0FBRyxTQUFzQztvQkFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFFcEMsUUFBUSxHQUFxQixJQUFJLENBQUMsY0FBYyxDQUFDO29CQUNqRCxhQUFhLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxJQUFJLEtBQUssaUJBQWlCLEVBQS9CLENBQStCLENBQUMsQ0FBQztvQkFDN0UsdUJBQWMsQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUN2QyxTQUFTLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQWUsQ0FBQztvQkFFakMscUJBQU0sUUFBUSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBQTs7b0JBQWpELFNBQVMsR0FBRyxTQUFxQztvQkFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFFN0MsYUFBYSxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO29CQUMzQywrQkFBc0IsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLFNBQVMsRUFBRSxPQUFPLEdBQUcsVUFBVSxHQUFHLDBCQUEwQixHQUFHLFNBQVMsQ0FBQyxDQUFDO29CQUN0SCxzQkFBTyxJQUFJLEVBQUM7OztvQkFFWixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUMzQyxxQ0FBNEIsRUFBRSxDQUFDOzs7Ozs7Q0FFdEM7QUFFRCxTQUFTLHVCQUF1QixDQUFDLFFBQWUsRUFBRSxLQUFZO0lBQzFELGdDQUFnQztJQUNoQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNoQixPQUFPLElBQUksQ0FBQztLQUNmO0lBQ0QsK0JBQXNCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsd0JBQXNCLFFBQVEsNEJBQXlCLENBQUMsQ0FBQztJQUNsSCxPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUMsUUFBZTtJQUNqQywrQkFBc0IsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLG1CQUFpQixRQUFRLGdCQUFhLENBQUMsQ0FBQztBQUNqRyxDQUFDO0FBRUQsU0FBZSxvQkFBb0IsQ0FBQyxRQUFlOzs7Ozs7b0JBQzNDLFlBQVksR0FBRyxJQUFJLENBQUM7Ozs7b0JBRUwscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFlBQVksR0FBRyxTQUFnQyxDQUFDOzs7O29CQUVoRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNuRSxNQUFNLEtBQUcsQ0FBQzs7b0JBRWQsK0JBQXNCLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLGNBQVksUUFBUSxtREFBZ0QsQ0FBQyxDQUFDOzs7OztDQUNwSDtBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLGVBQXNCLEVBQUUsV0FBa0IsRUFBRSxRQUFlOzs7Ozs7b0JBQzdHLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztvQkFDL0MsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUVuQixVQUFVLEdBQUcsb0JBQW9CLENBQUMsZUFBZSxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUNoRSxjQUFjLEdBQUcsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3BELHFCQUFNLFVBQVUsRUFBQTs7b0JBQWhCLFNBQWdCLENBQUM7b0JBQ2pCLHFCQUFNLGNBQWMsRUFBQTs7b0JBQXBCLFNBQW9CLENBQUM7Ozs7O0NBQ3hCO0FBRUQsa0JBQWtCO0FBRWxCLFNBQVMsZ0JBQWdCLENBQUMsSUFBVztJQUNqQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFLDhDQUE4QyxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUVELFNBQWUsbUJBQW1CLENBQUMsTUFBVSxFQUFFLFdBQWtCOzs7O1lBQzdELElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUFFLHNCQUFPO2FBQUU7WUFFakMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUN2QywrQkFBc0IsQ0FBQyxXQUFXLEtBQUssT0FBTyxFQUFFLHdEQUF3RCxDQUFDLENBQUM7Ozs7Q0FDN0c7QUFFRCxvQkFBb0I7QUFFcEIsU0FBUyxrQkFBa0IsQ0FBQyxJQUFXO0lBQ25DLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUUsZ0RBQWdELENBQUMsQ0FBQztBQUM1RyxDQUFDO0FBRUQsU0FBZSxxQkFBcUIsQ0FBQyxRQUFlLEVBQUUsV0FBa0I7Ozs7O3dCQUN2RCxxQkFBTSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBekMsTUFBTSxHQUFHLFNBQWdDO29CQUM3QywrQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBRWxELE9BQU8sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLCtCQUFzQixDQUFDLFdBQVcsS0FBSyxPQUFPLEVBQUUsMERBQTBELENBQUMsQ0FBQztvQkFFNUcsc0JBQU8sTUFBTSxDQUFDLElBQUksRUFBQzs7OztDQUN0QjtBQUVELG9CQUFvQjtBQUVwQixTQUFTLGtCQUFrQixDQUFDLElBQVc7SUFDbkMsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxnREFBZ0QsQ0FBQyxDQUFDO0FBQzVHLENBQUM7QUFFRCxTQUFlLHFCQUFxQixDQUFDLFFBQWUsRUFBRSxXQUFrQjs7Ozs7d0JBQ3ZELHFCQUFNLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUE7O29CQUF6QyxNQUFNLEdBQUcsU0FBZ0M7b0JBQzdDLCtCQUFzQixDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztvQkFFdEQsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3RCLHNCQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUM7cUJBQ3RCO29CQUVHLE9BQU8sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLCtCQUFzQixDQUFDLFdBQVcsS0FBSyxPQUFPLEVBQUUsMERBQTBELENBQUMsQ0FBQztvQkFFNUcsc0JBQU8sTUFBTSxDQUFDLElBQUksRUFBQzs7OztDQUN0QjtBQUVELG1CQUFtQjtBQUVuQjs7Ozs7OztFQU9FO0FBQ0YsU0FBUyxPQUFPLENBQUMsS0FBWTtJQUN6QixJQUFJLFVBQVUsR0FBRyxxQkFBcUIsQ0FBQztJQUN2QyxPQUFPLEtBQUssS0FBSyxVQUFVLENBQUM7QUFDaEMsQ0FBQztBQUVELFNBQVMsYUFBYSxDQUFDLElBQVc7SUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFO1NBQ3BCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsNEJBQTRCO1NBQ2hELE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQywyQkFBMkI7U0FDekQsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQSxDQUFDLG9DQUFvQztBQUNyRSxDQUFDO0FBRUQsa0JBQWU7SUFDWCxVQUFVLEVBQUcsa0JBQWtCO0lBQy9CLGFBQWEsRUFBRyxxQkFBcUI7SUFDckMsUUFBUSxFQUFHLGdCQUFnQjtJQUMzQixXQUFXLEVBQUcsbUJBQW1CO0lBQ2pDLFVBQVUsRUFBRyxrQkFBa0I7SUFDL0IsYUFBYSxFQUFHLHFCQUFxQjtJQUNyQyxVQUFVLEVBQUcsa0JBQWtCO0lBQy9CLGFBQWEsRUFBRyxxQkFBcUI7SUFDckMsU0FBUyxFQUFHLGFBQWE7Q0FDNUIsQ0FBQSJ9