"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var common_1 = require("./common");
var services_1 = __importDefault(require("./services"));
var cognito = services_1.default.cognito, dynamoDB = services_1.default.dynamoDB;
var errors_1 = require("./errors");
var auth_1 = require("./api/auth");
var dappTierToLimitAttr = (_a = {},
    _a[common_1.DappTiers.POC] = 'custom:num_dapps',
    _a[common_1.DappTiers.STANDARD] = 'custom:standard_limit',
    _a[common_1.DappTiers.PROFESSIONAL] = 'custom:professional_limit',
    _a[common_1.DappTiers.ENTERPRISE] = 'custom:enterprise_limit',
    _a);
// Names that should be disallowed for DappName values
var reservedDappNames = new Set([
    'abi',
    'abiclerk',
    'abi-clerk',
    'admin',
    'administrator',
    'api',
    'app',
    'automate',
    'blockvote',
    'blockvoting',
    'community',
    'conference',
    'console',
    'dashboard',
    'dapp',
    'dappbot',
    'dapp-bot',
    'dapperator',
    'dappname',
    'dapp-name',
    'dappsmith',
    'dapp-smith',
    'deploy',
    'directory',
    'exim',
    'eximchain',
    'forum',
    'guard',
    'guardian',
    'help',
    'home',
    'hub',
    'marketplace',
    'quadraticvote',
    'quadraticvoting',
    'root',
    'support',
    'vault',
    'wallet',
    'weyl',
    'weylgov',
    'weylgovern',
    'weylgovernance'
]);
var validDappTiers = new Set(Object.keys(common_1.DappTiers));
// CREATE VALIDATION
function validateBodyCreate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('Abi'), "create: required argument 'Abi' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('ContractAddr'), "create: required argument 'ContractAddr' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Web3URL'), "create: required argument 'Web3URL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('GuardianURL'), "create: required argument 'GuardianURL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Tier'), "create: required argument 'Tier' not found");
    var createBody = body;
    if (createBody.Tier === common_1.DappTiers.ENTERPRISE) {
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoName'), "create: enterprise version required argument 'TargetRepoName' not found");
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoOwner'), "create: enterprise version required argument 'TargetRepoName' not found");
    }
}
function validateLimitsCreate(cognitoUsername, ownerEmail, tier) {
    return __awaiter(this, void 0, void 0, function () {
        var user, attrList, dappLimitAttr, dappLimit, dappItems, numDappsOwned, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Validating Limits for User", cognitoUsername);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, cognito.getUser(cognitoUsername)];
                case 2:
                    user = _a.sent();
                    console.log("Found Cognito User", user);
                    attrList = user.UserAttributes;
                    dappLimitAttr = attrList.filter(function (attr) { return attr.Name === dappTierToLimitAttr[tier]; });
                    dappLimit = void 0;
                    if (dappLimitAttr.length === 0) {
                        dappLimit = 0;
                    }
                    else {
                        errors_1.assertInternal(dappLimitAttr.length === 1);
                        dappLimit = parseInt(dappLimitAttr[0].Value);
                    }
                    return [4 /*yield*/, dynamoDB.getByOwnerAndTier(ownerEmail, tier)];
                case 3:
                    dappItems = _a.sent();
                    console.log("Queried DynamoDB Table", dappItems);
                    numDappsOwned = dappItems.length;
                    errors_1.assertOperationAllowed(numDappsOwned + 1 <= dappLimit, "User " + ownerEmail + " already at dapp limit: " + dappLimit);
                    return [2 /*return*/, true];
                case 4:
                    err_1 = _a.sent();
                    console.log("Error Validating Limit", err_1);
                    errors_1.throwInternalValidationError();
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function validateAllowedDappName(dappName, email) {
    // Admins can use reserved names
    if (isAdmin(email)) {
        return true;
    }
    errors_1.assertOperationAllowed(!reservedDappNames.has(dappName), "Specified DappName " + dappName + " is not an allowed name");
    return true;
}
function validateTier(dappTier) {
    errors_1.assertOperationAllowed(validDappTiers.has(dappTier), "Invalid Tier '" + dappTier + "' specified");
}
function validateNameNotTaken(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var existingItem, err_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    existingItem = null;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 2:
                    existingItem = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    err_2 = _a.sent();
                    console.log("Error retrieving DB Item for create validation", err_2);
                    throw err_2;
                case 4:
                    errors_1.assertDappNameNotTaken(!existingItem.Item, "DappName " + dappName + " is already taken. Please choose another name.");
                    return [2 /*return*/];
            }
        });
    });
}
function validateCreateAllowed(dappName, cognitoUsername, callerEmail, dappTier) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    validateAllowedDappName(dappName, callerEmail);
                    validateTier(dappTier);
                    return [4 /*yield*/, validateNameNotTaken(dappName)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, validateLimitsCreate(cognitoUsername, callerEmail, dappTier)];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
// READ VALIDATION
function validateReadAllowed(dbItem, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbOwner;
        return __generator(this, function (_a) {
            if (isAdmin(callerEmail)) {
                return [2 /*return*/];
            }
            dbOwner = dbItem.Item.OwnerEmail.S;
            errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to read the specified Dapp.");
            return [2 /*return*/];
        });
    });
}
// UPDATE VALIDATION
function validateBodyUpdate(body) {
    console.log("Nothing to validate for 'update' body");
}
function validateUpdateAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, item, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertDappFound(dbItem.Item, "Dapp Not Found");
                    item = dbItem.Item;
                    dbOwner = item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to update the specified Dapp.");
                    return [2 /*return*/, item];
            }
        });
    });
}
// DELETE VALIDATION
function validateBodyDelete(body) {
    console.log("Nothing to validate for 'delete' body");
}
function validateDeleteAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, item, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertDappFound(dbItem.Item, "Dapp Not Found");
                    item = dbItem.Item;
                    if (isAdmin(callerEmail)) {
                        return [2 /*return*/, item];
                    }
                    dbOwner = item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to delete the specified Dapp.");
                    return [2 /*return*/, item];
            }
        });
    });
}
// LOGIN VALIDATION
function bodyHas(body, propertyNames) {
    return propertyNames.every(function (name) { return body.hasOwnProperty(name); });
}
function matchLoginBody(body) {
    if (bodyHas(body, auth_1.LoginParams.Login)) {
        return auth_1.LoginActions.Login;
    }
    else if (bodyHas(body, auth_1.LoginParams.ConfirmNewPassword)) {
        return auth_1.LoginActions.ConfirmNewPassword;
    }
    else if (bodyHas(body, auth_1.LoginParams.ConfirmMFALogin)) {
        return auth_1.LoginActions.ConfirmMFALogin;
    }
    else if (bodyHas(body, auth_1.LoginParams.ConfirmMFASetup)) {
        return auth_1.LoginActions.ConfirmMFASetup;
    }
    else {
        return false;
    }
}
function matchPasswordResetBody(body) {
    // Confirm must go first b/c Begin args are a subset
    if (bodyHas(body, auth_1.PasswordResetParams.Confirm)) {
        return auth_1.PasswordResetActions.Confirm;
    }
    else if (bodyHas(body, auth_1.PasswordResetParams.Begin)) {
        return auth_1.PasswordResetActions.Begin;
    }
    else {
        return false;
    }
}
// HELPER FUNCTIONS
/*
Returns whether an email has Admin rights
Admins can bypass certain restrictions

- Admins can delete other users' Dapps
- Admins can read other users' Dapps
- Admins can create Dapps using a reserved name
*/
function isAdmin(email) {
    var adminEmail = 'louis@eximchain.com';
    return email === adminEmail;
}
function cleanDappName(name) {
    return name.toLowerCase()
        .replace(/\s/g, '-') // Convert spaces to hyphens
        .replace(/[^A-Za-z0-9-]/g, '') // Remove non-alphanumerics
        .replace(/-*$|^-*/g, ''); // Trim hyphens off the front & back
}
exports.default = {
    createBody: validateBodyCreate,
    createAllowed: validateCreateAllowed,
    readAllowed: validateReadAllowed,
    updateBody: validateBodyUpdate,
    updateAllowed: validateUpdateAllowed,
    deleteBody: validateBodyDelete,
    deleteAllowed: validateDeleteAllowed,
    matchLoginBody: matchLoginBody,
    matchPasswordResetBody: matchPasswordResetBody,
    cleanName: cleanDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxtQ0FBc0Q7QUFDdEQsd0RBQWtDO0FBQzFCLElBQUEsb0NBQU8sRUFBRSxzQ0FBUSxDQUFjO0FBQ3ZDLG1DQUErSjtBQUUvSixtQ0FBa0c7QUFFbEcsSUFBTSxtQkFBbUI7SUFDckIsR0FBQyxrQkFBUyxDQUFDLEdBQUcsSUFBRyxrQkFBa0I7SUFDbkMsR0FBQyxrQkFBUyxDQUFDLFFBQVEsSUFBRyx1QkFBdUI7SUFDN0MsR0FBQyxrQkFBUyxDQUFDLFlBQVksSUFBRywyQkFBMkI7SUFDckQsR0FBQyxrQkFBUyxDQUFDLFVBQVUsSUFBRyx5QkFBeUI7T0FDcEQsQ0FBQztBQUVGLHNEQUFzRDtBQUN0RCxJQUFNLGlCQUFpQixHQUFHLElBQUksR0FBRyxDQUFDO0lBQzlCLEtBQUs7SUFDTCxVQUFVO0lBQ1YsV0FBVztJQUNYLE9BQU87SUFDUCxlQUFlO0lBQ2YsS0FBSztJQUNMLEtBQUs7SUFDTCxVQUFVO0lBQ1YsV0FBVztJQUNYLGFBQWE7SUFDYixXQUFXO0lBQ1gsWUFBWTtJQUNaLFNBQVM7SUFDVCxXQUFXO0lBQ1gsTUFBTTtJQUNOLFNBQVM7SUFDVCxVQUFVO0lBQ1YsWUFBWTtJQUNaLFVBQVU7SUFDVixXQUFXO0lBQ1gsV0FBVztJQUNYLFlBQVk7SUFDWixRQUFRO0lBQ1IsV0FBVztJQUNYLE1BQU07SUFDTixXQUFXO0lBQ1gsT0FBTztJQUNQLE9BQU87SUFDUCxVQUFVO0lBQ1YsTUFBTTtJQUNOLE1BQU07SUFDTixLQUFLO0lBQ0wsYUFBYTtJQUNiLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsTUFBTTtJQUNOLFNBQVM7SUFDVCxPQUFPO0lBQ1AsUUFBUTtJQUNSLE1BQU07SUFDTixTQUFTO0lBQ1QsWUFBWTtJQUNaLGdCQUFnQjtDQUNuQixDQUFDLENBQUM7QUFFSCxJQUFNLGNBQWMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtCQUFTLENBQUMsQ0FBQyxDQUFDO0FBRXZELG9CQUFvQjtBQUVwQixTQUFTLGtCQUFrQixDQUFDLElBQVc7SUFDbkMsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSwyQ0FBMkMsQ0FBQyxDQUFDO0lBQzlGLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUNoSCw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLCtDQUErQyxDQUFDLENBQUM7SUFDdEcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsRUFBRSxtREFBbUQsQ0FBQyxDQUFDO0lBQzlHLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUUsNENBQTRDLENBQUMsQ0FBQztJQUVoRyxJQUFJLFVBQVUsR0FBRyxJQUF1QixDQUFDO0lBQ3pDLElBQUksVUFBVSxDQUFDLElBQUksS0FBSyxrQkFBUyxDQUFDLFVBQVUsRUFBRTtRQUMxQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLEVBQUUseUVBQXlFLENBQUMsQ0FBQztRQUN2SSw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDLEVBQUUseUVBQXlFLENBQUMsQ0FBQztLQUMzSTtBQUNMLENBQUM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLGVBQXNCLEVBQUUsVUFBaUIsRUFBRSxJQUFjOzs7Ozs7b0JBQ3pGLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsZUFBZSxDQUFDLENBQUM7Ozs7b0JBRzVDLHFCQUFNLE9BQU8sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQUE7O29CQUE3QyxJQUFJLEdBQUcsU0FBc0M7b0JBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRXBDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBa0UsQ0FBQztvQkFDbkYsYUFBYSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxJQUFJLENBQUMsSUFBSSxLQUFLLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUF2QyxDQUF1QyxDQUFDLENBQUM7b0JBQ2pGLFNBQVMsU0FBQSxDQUFDO29CQUNkLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQzVCLFNBQVMsR0FBRyxDQUFDLENBQUM7cUJBQ2pCO3lCQUFNO3dCQUNILHVCQUFjLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQzt3QkFDM0MsU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBZSxDQUFDLENBQUM7cUJBQzFEO29CQUVlLHFCQUFNLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLEVBQUE7O29CQUE5RCxTQUFTLEdBQUcsU0FBa0Q7b0JBQ2xFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBRTdDLGFBQWEsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDO29CQUNyQywrQkFBc0IsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLFNBQVMsRUFBRSxPQUFPLEdBQUcsVUFBVSxHQUFHLDBCQUEwQixHQUFHLFNBQVMsQ0FBQyxDQUFDO29CQUN0SCxzQkFBTyxJQUFJLEVBQUM7OztvQkFFWixPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUMzQyxxQ0FBNEIsRUFBRSxDQUFDOzs7Ozs7Q0FFdEM7QUFFRCxTQUFTLHVCQUF1QixDQUFDLFFBQWUsRUFBRSxLQUFZO0lBQzFELGdDQUFnQztJQUNoQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNoQixPQUFPLElBQUksQ0FBQztLQUNmO0lBQ0QsK0JBQXNCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsd0JBQXNCLFFBQVEsNEJBQXlCLENBQUMsQ0FBQztJQUNsSCxPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUMsUUFBZTtJQUNqQywrQkFBc0IsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLG1CQUFpQixRQUFRLGdCQUFhLENBQUMsQ0FBQztBQUNqRyxDQUFDO0FBRUQsU0FBZSxvQkFBb0IsQ0FBQyxRQUFlOzs7Ozs7b0JBQzNDLFlBQVksR0FBRyxJQUFJLENBQUM7Ozs7b0JBRUwscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQS9DLFlBQVksR0FBRyxTQUFnQyxDQUFDOzs7O29CQUVoRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNuRSxNQUFNLEtBQUcsQ0FBQzs7b0JBRWQsK0JBQXNCLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLGNBQVksUUFBUSxtREFBZ0QsQ0FBQyxDQUFDOzs7OztDQUNwSDtBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLGVBQXNCLEVBQUUsV0FBa0IsRUFBRSxRQUFrQjs7Ozs7b0JBQ2hILHVCQUF1QixDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztvQkFDL0MsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUN2QixxQkFBTSxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXBDLFNBQW9DLENBQUM7b0JBQ3JDLHFCQUFNLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUE7O29CQUFsRSxTQUFrRSxDQUFDOzs7OztDQUN0RTtBQUVELGtCQUFrQjtBQUVsQixTQUFlLG1CQUFtQixDQUFDLE1BQVUsRUFBRSxXQUFrQjs7OztZQUM3RCxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFBRSxzQkFBTzthQUFFO1lBRWpDLE9BQU8sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDdkMsK0JBQXNCLENBQUMsV0FBVyxLQUFLLE9BQU8sRUFBRSx3REFBd0QsQ0FBQyxDQUFDOzs7O0NBQzdHO0FBRUQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7QUFDekQsQ0FBQztBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLFdBQWtCOzs7Ozt3QkFDdkQscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXpDLE1BQU0sR0FBRyxTQUFnQztvQkFDN0Msd0JBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBQzNDLElBQUksR0FBRyxNQUFNLENBQUMsSUFBNkIsQ0FBQztvQkFFNUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUNoQywrQkFBc0IsQ0FBQyxXQUFXLEtBQUssT0FBTyxFQUFFLDBEQUEwRCxDQUFDLENBQUM7b0JBRTVHLHNCQUFPLElBQUksRUFBQzs7OztDQUNmO0FBRUQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7QUFDekQsQ0FBQztBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLFdBQWtCOzs7Ozt3QkFDdkQscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXpDLE1BQU0sR0FBRyxTQUFnQztvQkFDN0Msd0JBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBQzNDLElBQUksR0FBRyxNQUFNLENBQUMsSUFBNkIsQ0FBQztvQkFFaEQsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3RCLHNCQUFPLElBQUksRUFBQztxQkFDZjtvQkFFRyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLCtCQUFzQixDQUFDLFdBQVcsS0FBSyxPQUFPLEVBQUUsMERBQTBELENBQUMsQ0FBQztvQkFFNUcsc0JBQU8sSUFBSSxFQUFDOzs7O0NBQ2Y7QUFFRCxtQkFBbUI7QUFFbkIsU0FBUyxPQUFPLENBQUMsSUFBVyxFQUFFLGFBQXNCO0lBQ2hELE9BQU8sYUFBYSxDQUFDLEtBQUssQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQXpCLENBQXlCLENBQUMsQ0FBQTtBQUNqRSxDQUFDO0FBRUQsU0FBUyxjQUFjLENBQUMsSUFBVztJQUMvQixJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsa0JBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNsQyxPQUFPLG1CQUFZLENBQUMsS0FBSyxDQUFDO0tBQzdCO1NBQU0sSUFBSSxPQUFPLENBQUMsSUFBSSxFQUFFLGtCQUFXLENBQUMsa0JBQWtCLENBQUMsRUFBRTtRQUN0RCxPQUFPLG1CQUFZLENBQUMsa0JBQWtCLENBQUM7S0FDMUM7U0FBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsa0JBQVcsQ0FBQyxlQUFlLENBQUMsRUFBRTtRQUNuRCxPQUFPLG1CQUFZLENBQUMsZUFBZSxDQUFDO0tBQ3ZDO1NBQU0sSUFBSSxPQUFPLENBQUMsSUFBSSxFQUFFLGtCQUFXLENBQUMsZUFBZSxDQUFDLEVBQUU7UUFDbkQsT0FBTyxtQkFBWSxDQUFDLGVBQWUsQ0FBQztLQUN2QztTQUFNO1FBQ0gsT0FBTyxLQUFLLENBQUM7S0FDaEI7QUFDTCxDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxJQUFXO0lBQ3ZDLG9EQUFvRDtJQUNwRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsMEJBQW1CLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDNUMsT0FBTywyQkFBb0IsQ0FBQyxPQUFPLENBQUM7S0FDdkM7U0FBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsMEJBQW1CLENBQUMsS0FBSyxDQUFDLEVBQUU7UUFDakQsT0FBTywyQkFBb0IsQ0FBQyxLQUFLLENBQUM7S0FDckM7U0FBTTtRQUNILE9BQU8sS0FBSyxDQUFDO0tBQ2hCO0FBQ0wsQ0FBQztBQUVELG1CQUFtQjtBQUVuQjs7Ozs7OztFQU9FO0FBQ0YsU0FBUyxPQUFPLENBQUMsS0FBWTtJQUN6QixJQUFJLFVBQVUsR0FBRyxxQkFBcUIsQ0FBQztJQUN2QyxPQUFPLEtBQUssS0FBSyxVQUFVLENBQUM7QUFDaEMsQ0FBQztBQUVELFNBQVMsYUFBYSxDQUFDLElBQVc7SUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFO1NBQ3BCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsNEJBQTRCO1NBQ2hELE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQywyQkFBMkI7U0FDekQsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQSxDQUFDLG9DQUFvQztBQUNyRSxDQUFDO0FBRUQsa0JBQWU7SUFDWCxVQUFVLEVBQUcsa0JBQWtCO0lBQy9CLGFBQWEsRUFBRyxxQkFBcUI7SUFDckMsV0FBVyxFQUFHLG1CQUFtQjtJQUNqQyxVQUFVLEVBQUcsa0JBQWtCO0lBQy9CLGFBQWEsRUFBRyxxQkFBcUI7SUFDckMsVUFBVSxFQUFHLGtCQUFrQjtJQUMvQixhQUFhLEVBQUcscUJBQXFCO0lBQ3JDLGNBQWMsRUFBRyxjQUFjO0lBQy9CLHNCQUFzQixFQUFHLHNCQUFzQjtJQUMvQyxTQUFTLEVBQUcsYUFBYTtDQUM1QixDQUFBIn0=