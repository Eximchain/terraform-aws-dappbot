"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var common_1 = require("./common");
var services_1 = __importDefault(require("./services"));
var cognito = services_1.default.cognito, dynamoDB = services_1.default.dynamoDB;
var errors_1 = require("./errors");
var dappTierToLimitAttr = (_a = {},
    _a[common_1.DappTiers.POC] = 'custom:num_dapps',
    _a[common_1.DappTiers.STANDARD] = 'custom:standard_limit',
    _a[common_1.DappTiers.PROFESSIONAL] = 'custom:professional_limit',
    _a[common_1.DappTiers.ENTERPRISE] = 'custom:enterprise_limit',
    _a);
// Names that should be disallowed for DappName values
var reservedDappNames = new Set([
    'abi',
    'abiclerk',
    'abi-clerk',
    'admin',
    'administrator',
    'api',
    'app',
    'automate',
    'blockvote',
    'blockvoting',
    'community',
    'conference',
    'console',
    'dashboard',
    'dapp',
    'dappbot',
    'dapp-bot',
    'dapperator',
    'dappname',
    'dapp-name',
    'dappsmith',
    'dapp-smith',
    'deploy',
    'directory',
    'exim',
    'eximchain',
    'forum',
    'guard',
    'guardian',
    'help',
    'home',
    'hub',
    'marketplace',
    'quadraticvote',
    'quadraticvoting',
    'root',
    'support',
    'vault',
    'wallet',
    'weyl',
    'weylgov',
    'weylgovern',
    'weylgovernance'
]);
var validDappTiers = new Set(Object.keys(common_1.DappTiers));
// CREATE VALIDATION
function validateBodyCreate(body) {
    errors_1.assertParameterValid(body.hasOwnProperty('Abi'), "create: required argument 'Abi' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('ContractAddr'), "create: required argument 'ContractAddr' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Web3URL'), "create: required argument 'Web3URL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('GuardianURL'), "create: required argument 'GuardianURL' not found");
    errors_1.assertParameterValid(body.hasOwnProperty('Tier'), "create: required argument 'Tier' not found");
    var createBody = body;
    if (createBody.Tier === common_1.DappTiers.ENTERPRISE) {
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoName'), "create: enterprise version required argument 'TargetRepoName' not found");
        errors_1.assertParameterValid(body.hasOwnProperty('TargetRepoOwner'), "create: enterprise version required argument 'TargetRepoName' not found");
    }
}
function validateLimitsCreate(cognitoUsername, ownerEmail, tier) {
    return __awaiter(this, void 0, void 0, function () {
        var user, attrList, dappLimitAttr, dappLimit, dappItems, numDappsOwned, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    console.log("Validating Limits for User", cognitoUsername);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, cognito.getUser(cognitoUsername)];
                case 2:
                    user = _a.sent();
                    console.log("Found Cognito User", user);
                    attrList = user.UserAttributes;
                    dappLimitAttr = attrList.filter(function (attr) { return attr.Name === dappTierToLimitAttr[tier]; });
                    dappLimit = void 0;
                    if (dappLimitAttr.length === 0) {
                        dappLimit = 0;
                    }
                    else {
                        errors_1.assertInternal(dappLimitAttr.length === 1);
                        dappLimit = parseInt(dappLimitAttr[0].Value);
                    }
                    return [4 /*yield*/, dynamoDB.getByOwnerAndTier(ownerEmail, tier)];
                case 3:
                    dappItems = _a.sent();
                    console.log("Queried DynamoDB Table", dappItems);
                    numDappsOwned = dappItems.length;
                    errors_1.assertOperationAllowed(numDappsOwned + 1 <= dappLimit, "User " + ownerEmail + " already at dapp limit: " + dappLimit);
                    return [2 /*return*/, true];
                case 4:
                    err_1 = _a.sent();
                    console.log("Error Validating Limit", err_1);
                    errors_1.throwInternalValidationError();
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
function validateAllowedDappName(dappName, email) {
    // Admins can use reserved names
    if (isAdmin(email)) {
        return true;
    }
    errors_1.assertOperationAllowed(!reservedDappNames.has(dappName), "Specified DappName " + dappName + " is not an allowed name");
    return true;
}
function validateTier(dappTier) {
    errors_1.assertOperationAllowed(validDappTiers.has(dappTier), "Invalid Tier '" + dappTier + "' specified");
}
function validateNameNotTaken(dappName) {
    return __awaiter(this, void 0, void 0, function () {
        var existingItem, err_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    existingItem = null;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 2:
                    existingItem = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    err_2 = _a.sent();
                    console.log("Error retrieving DB Item for create validation", err_2);
                    throw err_2;
                case 4:
                    errors_1.assertDappNameNotTaken(!existingItem.Item, "DappName " + dappName + " is already taken. Please choose another name.");
                    return [2 /*return*/];
            }
        });
    });
}
function validateCreateAllowed(dappName, cognitoUsername, callerEmail, dappTier) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    validateAllowedDappName(dappName, callerEmail);
                    validateTier(dappTier);
                    return [4 /*yield*/, validateNameNotTaken(dappName)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, validateLimitsCreate(cognitoUsername, callerEmail, dappTier)];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
// READ VALIDATION
function validateReadAllowed(dbItem, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbOwner;
        return __generator(this, function (_a) {
            if (isAdmin(callerEmail)) {
                return [2 /*return*/];
            }
            dbOwner = dbItem.Item.OwnerEmail.S;
            errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to read the specified Dapp.");
            return [2 /*return*/];
        });
    });
}
// UPDATE VALIDATION
function validateBodyUpdate(body) {
    console.log("Nothing to validate for 'update' body");
}
function validateUpdateAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertDappFound(dbItem.Item, "Dapp Not Found");
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to update the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// DELETE VALIDATION
function validateBodyDelete(body) {
    console.log("Nothing to validate for 'delete' body");
}
function validateDeleteAllowed(dappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dbItem, dbOwner;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, dynamoDB.getItem(dappName)];
                case 1:
                    dbItem = _a.sent();
                    errors_1.assertDappFound(dbItem.Item, "Dapp Not Found");
                    if (isAdmin(callerEmail)) {
                        return [2 /*return*/, dbItem.Item];
                    }
                    dbOwner = dbItem.Item.OwnerEmail.S;
                    errors_1.assertOperationAllowed(callerEmail === dbOwner, "You do not have permission to delete the specified Dapp.");
                    return [2 /*return*/, dbItem.Item];
            }
        });
    });
}
// HELPER FUNCTIONS
/*
Returns whether an email has Admin rights
Admins can bypass certain restrictions

- Admins can delete other users' Dapps
- Admins can read other users' Dapps
- Admins can create Dapps using a reserved name
*/
function isAdmin(email) {
    var adminEmail = 'louis@eximchain.com';
    return email === adminEmail;
}
function cleanDappName(name) {
    return name.toLowerCase()
        .replace(/\s/g, '-') // Convert spaces to hyphens
        .replace(/[^A-Za-z0-9-]/g, '') // Remove non-alphanumerics
        .replace(/-*$|^-*/g, ''); // Trim hyphens off the front & back
}
exports.default = {
    createBody: validateBodyCreate,
    createAllowed: validateCreateAllowed,
    readAllowed: validateReadAllowed,
    updateBody: validateBodyUpdate,
    updateAllowed: validateUpdateAllowed,
    deleteBody: validateBodyDelete,
    deleteAllowed: validateDeleteAllowed,
    cleanName: cleanDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsidmFsaWRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxtQ0FBc0Q7QUFDdEQsd0RBQWtDO0FBQzFCLElBQUEsb0NBQU8sRUFBRSxzQ0FBUSxDQUFjO0FBQ3ZDLG1DQUErSjtBQUcvSixJQUFNLG1CQUFtQjtJQUNyQixHQUFDLGtCQUFTLENBQUMsR0FBRyxJQUFHLGtCQUFrQjtJQUNuQyxHQUFDLGtCQUFTLENBQUMsUUFBUSxJQUFHLHVCQUF1QjtJQUM3QyxHQUFDLGtCQUFTLENBQUMsWUFBWSxJQUFHLDJCQUEyQjtJQUNyRCxHQUFDLGtCQUFTLENBQUMsVUFBVSxJQUFHLHlCQUF5QjtPQUNwRCxDQUFDO0FBRUYsc0RBQXNEO0FBQ3RELElBQU0saUJBQWlCLEdBQUcsSUFBSSxHQUFHLENBQUM7SUFDOUIsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsT0FBTztJQUNQLGVBQWU7SUFDZixLQUFLO0lBQ0wsS0FBSztJQUNMLFVBQVU7SUFDVixXQUFXO0lBQ1gsYUFBYTtJQUNiLFdBQVc7SUFDWCxZQUFZO0lBQ1osU0FBUztJQUNULFdBQVc7SUFDWCxNQUFNO0lBQ04sU0FBUztJQUNULFVBQVU7SUFDVixZQUFZO0lBQ1osVUFBVTtJQUNWLFdBQVc7SUFDWCxXQUFXO0lBQ1gsWUFBWTtJQUNaLFFBQVE7SUFDUixXQUFXO0lBQ1gsTUFBTTtJQUNOLFdBQVc7SUFDWCxPQUFPO0lBQ1AsT0FBTztJQUNQLFVBQVU7SUFDVixNQUFNO0lBQ04sTUFBTTtJQUNOLEtBQUs7SUFDTCxhQUFhO0lBQ2IsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixNQUFNO0lBQ04sU0FBUztJQUNULE9BQU87SUFDUCxRQUFRO0lBQ1IsTUFBTTtJQUNOLFNBQVM7SUFDVCxZQUFZO0lBQ1osZ0JBQWdCO0NBQ25CLENBQUMsQ0FBQztBQUVILElBQU0sY0FBYyxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0JBQVMsQ0FBQyxDQUFDLENBQUM7QUFFdkQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLDJDQUEyQyxDQUFDLENBQUM7SUFDOUYsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxvREFBb0QsQ0FBQyxDQUFDO0lBQ2hILDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUUsK0NBQStDLENBQUMsQ0FBQztJQUN0Ryw2QkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxFQUFFLG1EQUFtRCxDQUFDLENBQUM7SUFDOUcsNkJBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSw0Q0FBNEMsQ0FBQyxDQUFDO0lBRWhHLElBQUksVUFBVSxHQUFHLElBQXVCLENBQUM7SUFDekMsSUFBSSxVQUFVLENBQUMsSUFBSSxLQUFLLGtCQUFTLENBQUMsVUFBVSxFQUFFO1FBQzFDLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsRUFBRSx5RUFBeUUsQ0FBQyxDQUFDO1FBQ3ZJLDZCQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLENBQUMsRUFBRSx5RUFBeUUsQ0FBQyxDQUFDO0tBQzNJO0FBQ0wsQ0FBQztBQUVELFNBQWUsb0JBQW9CLENBQUMsZUFBc0IsRUFBRSxVQUFpQixFQUFFLElBQWM7Ozs7OztvQkFDekYsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxlQUFlLENBQUMsQ0FBQzs7OztvQkFHNUMscUJBQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBQTs7b0JBQTdDLElBQUksR0FBRyxTQUFzQztvQkFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFFcEMsUUFBUSxHQUFxQixJQUFJLENBQUMsY0FBYyxDQUFDO29CQUNqRCxhQUFhLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxJQUFJLEtBQUssbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQXZDLENBQXVDLENBQUMsQ0FBQztvQkFDakYsU0FBUyxTQUFBLENBQUM7b0JBQ2QsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDNUIsU0FBUyxHQUFHLENBQUMsQ0FBQztxQkFDakI7eUJBQU07d0JBQ0gsdUJBQWMsQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO3dCQUMzQyxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFlLENBQUMsQ0FBQztxQkFDMUQ7b0JBRWUscUJBQU0sUUFBUSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsRUFBQTs7b0JBQTlELFNBQVMsR0FBRyxTQUFrRDtvQkFDbEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFFN0MsYUFBYSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUM7b0JBQ3JDLCtCQUFzQixDQUFDLGFBQWEsR0FBRyxDQUFDLElBQUksU0FBUyxFQUFFLE9BQU8sR0FBRyxVQUFVLEdBQUcsMEJBQTBCLEdBQUcsU0FBUyxDQUFDLENBQUM7b0JBQ3RILHNCQUFPLElBQUksRUFBQzs7O29CQUVaLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsS0FBRyxDQUFDLENBQUM7b0JBQzNDLHFDQUE0QixFQUFFLENBQUM7Ozs7OztDQUV0QztBQUVELFNBQVMsdUJBQXVCLENBQUMsUUFBZSxFQUFFLEtBQVk7SUFDMUQsZ0NBQWdDO0lBQ2hDLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ2hCLE9BQU8sSUFBSSxDQUFDO0tBQ2Y7SUFDRCwrQkFBc0IsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSx3QkFBc0IsUUFBUSw0QkFBeUIsQ0FBQyxDQUFDO0lBQ2xILE9BQU8sSUFBSSxDQUFDO0FBQ2hCLENBQUM7QUFFRCxTQUFTLFlBQVksQ0FBQyxRQUFlO0lBQ2pDLCtCQUFzQixDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsbUJBQWlCLFFBQVEsZ0JBQWEsQ0FBQyxDQUFDO0FBQ2pHLENBQUM7QUFFRCxTQUFlLG9CQUFvQixDQUFDLFFBQWU7Ozs7OztvQkFDM0MsWUFBWSxHQUFHLElBQUksQ0FBQzs7OztvQkFFTCxxQkFBTSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBL0MsWUFBWSxHQUFHLFNBQWdDLENBQUM7Ozs7b0JBRWhELE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELEVBQUUsS0FBRyxDQUFDLENBQUM7b0JBQ25FLE1BQU0sS0FBRyxDQUFDOztvQkFFZCwrQkFBc0IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsY0FBWSxRQUFRLG1EQUFnRCxDQUFDLENBQUM7Ozs7O0NBQ3BIO0FBRUQsU0FBZSxxQkFBcUIsQ0FBQyxRQUFlLEVBQUUsZUFBc0IsRUFBRSxXQUFrQixFQUFFLFFBQWtCOzs7OztvQkFDaEgsdUJBQXVCLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUMvQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3ZCLHFCQUFNLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBcEMsU0FBb0MsQ0FBQztvQkFDckMscUJBQU0sb0JBQW9CLENBQUMsZUFBZSxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsRUFBQTs7b0JBQWxFLFNBQWtFLENBQUM7Ozs7O0NBQ3RFO0FBRUQsa0JBQWtCO0FBRWxCLFNBQWUsbUJBQW1CLENBQUMsTUFBVSxFQUFFLFdBQWtCOzs7O1lBQzdELElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUFFLHNCQUFPO2FBQUU7WUFFakMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUN2QywrQkFBc0IsQ0FBQyxXQUFXLEtBQUssT0FBTyxFQUFFLHdEQUF3RCxDQUFDLENBQUM7Ozs7Q0FDN0c7QUFFRCxvQkFBb0I7QUFFcEIsU0FBUyxrQkFBa0IsQ0FBQyxJQUFXO0lBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLENBQUMsQ0FBQztBQUN6RCxDQUFDO0FBRUQsU0FBZSxxQkFBcUIsQ0FBQyxRQUFlLEVBQUUsV0FBa0I7Ozs7O3dCQUN2RCxxQkFBTSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBekMsTUFBTSxHQUFHLFNBQWdDO29CQUM3Qyx3QkFBZSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztvQkFFM0MsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztvQkFDdkMsK0JBQXNCLENBQUMsV0FBVyxLQUFLLE9BQU8sRUFBRSwwREFBMEQsQ0FBQyxDQUFDO29CQUU1RyxzQkFBTyxNQUFNLENBQUMsSUFBSSxFQUFDOzs7O0NBQ3RCO0FBRUQsb0JBQW9CO0FBRXBCLFNBQVMsa0JBQWtCLENBQUMsSUFBVztJQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7QUFDekQsQ0FBQztBQUVELFNBQWUscUJBQXFCLENBQUMsUUFBZSxFQUFFLFdBQWtCOzs7Ozt3QkFDdkQscUJBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQXpDLE1BQU0sR0FBRyxTQUFnQztvQkFDN0Msd0JBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBRS9DLElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUN0QixzQkFBTyxNQUFNLENBQUMsSUFBSSxFQUFDO3FCQUN0QjtvQkFFRyxPQUFPLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUN2QywrQkFBc0IsQ0FBQyxXQUFXLEtBQUssT0FBTyxFQUFFLDBEQUEwRCxDQUFDLENBQUM7b0JBRTVHLHNCQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUM7Ozs7Q0FDdEI7QUFFRCxtQkFBbUI7QUFFbkI7Ozs7Ozs7RUFPRTtBQUNGLFNBQVMsT0FBTyxDQUFDLEtBQVk7SUFDekIsSUFBSSxVQUFVLEdBQUcscUJBQXFCLENBQUM7SUFDdkMsT0FBTyxLQUFLLEtBQUssVUFBVSxDQUFDO0FBQ2hDLENBQUM7QUFFRCxTQUFTLGFBQWEsQ0FBQyxJQUFXO0lBQzlCLE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRTtTQUNwQixPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QjtTQUNoRCxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDLENBQUMsMkJBQTJCO1NBQ3pELE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUEsQ0FBQyxvQ0FBb0M7QUFDckUsQ0FBQztBQUVELGtCQUFlO0lBQ1gsVUFBVSxFQUFHLGtCQUFrQjtJQUMvQixhQUFhLEVBQUcscUJBQXFCO0lBQ3JDLFdBQVcsRUFBRyxtQkFBbUI7SUFDakMsVUFBVSxFQUFHLGtCQUFrQjtJQUMvQixhQUFhLEVBQUcscUJBQXFCO0lBQ3JDLFVBQVUsRUFBRyxrQkFBa0I7SUFDL0IsYUFBYSxFQUFHLHFCQUFxQjtJQUNyQyxTQUFTLEVBQUcsYUFBYTtDQUM1QixDQUFBIn0=