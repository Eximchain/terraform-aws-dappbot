"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
// CUSTOM ERROR TYPES
var ValidationError = /** @class */ (function () {
    function ValidationError(message) {
        this.name = "ValidationError";
        this.message = message;
    }
    return ValidationError;
}());
exports.ValidationError = ValidationError;
var Error422 = /** @class */ (function (_super) {
    __extends(Error422, _super);
    function Error422(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error422";
        return _this;
    }
    return Error422;
}(ValidationError));
exports.Error422 = Error422;
var ParameterValidationError = /** @class */ (function (_super) {
    __extends(ParameterValidationError, _super);
    function ParameterValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "ParameterValidationError";
        return _this;
    }
    return ParameterValidationError;
}(Error422));
exports.ParameterValidationError = ParameterValidationError;
var OperationNotAllowedError = /** @class */ (function (_super) {
    __extends(OperationNotAllowedError, _super);
    function OperationNotAllowedError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "OperationNotAllowed";
        return _this;
    }
    return OperationNotAllowedError;
}(ValidationError));
exports.OperationNotAllowedError = OperationNotAllowedError;
var Error409 = /** @class */ (function (_super) {
    __extends(Error409, _super);
    function Error409(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error409";
        return _this;
    }
    return Error409;
}(OperationNotAllowedError));
exports.Error409 = Error409;
var DappNameTakenError = /** @class */ (function (_super) {
    __extends(DappNameTakenError, _super);
    function DappNameTakenError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappNameTakenError";
        return _this;
    }
    return DappNameTakenError;
}(Error409));
exports.DappNameTakenError = DappNameTakenError;
var Error404 = /** @class */ (function (_super) {
    __extends(Error404, _super);
    function Error404(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error404";
        return _this;
    }
    return Error404;
}(OperationNotAllowedError));
exports.Error404 = Error404;
var DappNotFound = /** @class */ (function (_super) {
    __extends(DappNotFound, _super);
    function DappNotFound(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappNotFound";
        return _this;
    }
    return DappNotFound;
}(Error404));
exports.DappNotFound = DappNotFound;
var DappItemValidationError = /** @class */ (function (_super) {
    __extends(DappItemValidationError, _super);
    function DappItemValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappItemValidationError";
        return _this;
    }
    return DappItemValidationError;
}(ValidationError));
exports.DappItemValidationError = DappItemValidationError;
var InternalValidationError = /** @class */ (function (_super) {
    __extends(InternalValidationError, _super);
    function InternalValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "InternalValidationError";
        return _this;
    }
    return InternalValidationError;
}(ValidationError));
exports.InternalValidationError = InternalValidationError;
// ASSERT METHODS
function assert(condition, message, errorType) {
    if (errorType === void 0) { errorType = ValidationError; }
    if (!condition) {
        throw new errorType(message);
    }
}
function assertParameterValid(condition, message) {
    return assert(condition, message, ParameterValidationError);
}
exports.assertParameterValid = assertParameterValid;
function assertOperationAllowed(condition, message) {
    return assert(condition, message, OperationNotAllowedError);
}
exports.assertOperationAllowed = assertOperationAllowed;
function assertDappNameNotTaken(condition, message) {
    return assert(condition, message, DappNameTakenError);
}
exports.assertDappNameNotTaken = assertDappNameNotTaken;
function assertDappFound(condition, message) {
    return assert(condition, message, DappNotFound);
}
exports.assertDappFound = assertDappFound;
function assertDappItemValid(condition, message) {
    return assert(condition, message, DappItemValidationError);
}
exports.assertDappItemValid = assertDappItemValid;
function assertInternal(condition) {
    var message = "Internal error during validation";
    return assert(condition, message, InternalValidationError);
}
exports.assertInternal = assertInternal;
function throwInternalValidationError() {
    return assertInternal(false);
}
exports.throwInternalValidationError = throwInternalValidationError;
exports.default = {
    assertParamValid: assertParameterValid,
    assertOpAllowed: assertOperationAllowed,
    assertDappValid: assertDappItemValid,
    assertInternal: assertInternal,
    throwInternalValidationError: throwInternalValidationError
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JzLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVycm9ycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxQkFBcUI7QUFDckI7SUFHSSx5QkFBWSxPQUFjO1FBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUcsaUJBQWlCLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0IsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0FBQyxBQVBELElBT0M7QUFQWSwwQ0FBZTtBQVM1QjtJQUE4Qiw0QkFBZTtJQUN6QyxrQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7O0lBQzNCLENBQUM7SUFDTCxlQUFDO0FBQUQsQ0FBQyxBQUxELENBQThCLGVBQWUsR0FLNUM7QUFMWSw0QkFBUTtBQU9yQjtJQUE4Qyw0Q0FBUTtJQUNsRCxrQ0FBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRywwQkFBMEIsQ0FBQzs7SUFDM0MsQ0FBQztJQUNMLCtCQUFDO0FBQUQsQ0FBQyxBQUxELENBQThDLFFBQVEsR0FLckQ7QUFMWSw0REFBd0I7QUFPckM7SUFBOEMsNENBQWU7SUFDekQsa0NBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcscUJBQXFCLENBQUM7O0lBQ3RDLENBQUM7SUFDTCwrQkFBQztBQUFELENBQUMsQUFMRCxDQUE4QyxlQUFlLEdBSzVEO0FBTFksNERBQXdCO0FBT3JDO0lBQThCLDRCQUF3QjtJQUNsRCxrQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7O0lBQzNCLENBQUM7SUFDTCxlQUFDO0FBQUQsQ0FBQyxBQUxELENBQThCLHdCQUF3QixHQUtyRDtBQUxZLDRCQUFRO0FBT3JCO0lBQXdDLHNDQUFRO0lBQzVDLDRCQUFZLE9BQWM7UUFBMUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFERyxLQUFJLENBQUMsSUFBSSxHQUFHLG9CQUFvQixDQUFDOztJQUNyQyxDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQUFDLEFBTEQsQ0FBd0MsUUFBUSxHQUsvQztBQUxZLGdEQUFrQjtBQU8vQjtJQUE4Qiw0QkFBd0I7SUFDbEQsa0JBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDOztJQUMzQixDQUFDO0lBQ0wsZUFBQztBQUFELENBQUMsQUFMRCxDQUE4Qix3QkFBd0IsR0FLckQ7QUFMWSw0QkFBUTtBQU9yQjtJQUFrQyxnQ0FBUTtJQUN0QyxzQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxjQUFjLENBQUM7O0lBQy9CLENBQUM7SUFDTCxtQkFBQztBQUFELENBQUMsQUFMRCxDQUFrQyxRQUFRLEdBS3pDO0FBTFksb0NBQVk7QUFPekI7SUFBNkMsMkNBQWU7SUFDeEQsaUNBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcseUJBQXlCLENBQUM7O0lBQzFDLENBQUM7SUFDTCw4QkFBQztBQUFELENBQUMsQUFMRCxDQUE2QyxlQUFlLEdBSzNEO0FBTFksMERBQXVCO0FBT3BDO0lBQTZDLDJDQUFlO0lBQ3hELGlDQUFZLE9BQWM7UUFBMUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFERyxLQUFJLENBQUMsSUFBSSxHQUFHLHlCQUF5QixDQUFDOztJQUMxQyxDQUFDO0lBQ0wsOEJBQUM7QUFBRCxDQUFDLEFBTEQsQ0FBNkMsZUFBZSxHQUszRDtBQUxZLDBEQUF1QjtBQU9wQyxpQkFBaUI7QUFDakIsU0FBUyxNQUFNLENBQUMsU0FBYSxFQUFFLE9BQWMsRUFBRSxTQUF5QjtJQUF6QiwwQkFBQSxFQUFBLDJCQUF5QjtJQUNwRSxJQUFJLENBQUMsU0FBUyxFQUFFO1FBQ1osTUFBTSxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUNoQztBQUNMLENBQUM7QUFFRCxTQUFnQixvQkFBb0IsQ0FBQyxTQUFhLEVBQUUsT0FBYztJQUM5RCxPQUFPLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLHdCQUF3QixDQUFDLENBQUM7QUFDaEUsQ0FBQztBQUZELG9EQUVDO0FBRUQsU0FBZ0Isc0JBQXNCLENBQUMsU0FBYSxFQUFFLE9BQWM7SUFDaEUsT0FBTyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO0FBQ2hFLENBQUM7QUFGRCx3REFFQztBQUVELFNBQWdCLHNCQUFzQixDQUFDLFNBQWEsRUFBRSxPQUFjO0lBQ2hFLE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztBQUMxRCxDQUFDO0FBRkQsd0RBRUM7QUFFRCxTQUFnQixlQUFlLENBQUMsU0FBYSxFQUFFLE9BQWM7SUFDekQsT0FBTyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNwRCxDQUFDO0FBRkQsMENBRUM7QUFFRCxTQUFnQixtQkFBbUIsQ0FBQyxTQUFhLEVBQUUsT0FBYztJQUM3RCxPQUFPLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLHVCQUF1QixDQUFDLENBQUM7QUFDL0QsQ0FBQztBQUZELGtEQUVDO0FBRUQsU0FBZ0IsY0FBYyxDQUFDLFNBQWE7SUFDeEMsSUFBSSxPQUFPLEdBQUcsa0NBQWtDLENBQUM7SUFDakQsT0FBTyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0FBQy9ELENBQUM7QUFIRCx3Q0FHQztBQUVELFNBQWdCLDRCQUE0QjtJQUN4QyxPQUFPLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBRkQsb0VBRUM7QUFFRCxrQkFBZTtJQUNYLGdCQUFnQixFQUFHLG9CQUFvQjtJQUN2QyxlQUFlLEVBQUcsc0JBQXNCO0lBQ3hDLGVBQWUsRUFBRyxtQkFBbUI7SUFDckMsY0FBYyxFQUFHLGNBQWM7SUFDL0IsNEJBQTRCLEVBQUcsNEJBQTRCO0NBQzlELENBQUEifQ==