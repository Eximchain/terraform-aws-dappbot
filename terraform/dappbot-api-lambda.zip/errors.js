"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
// CUSTOM ERROR TYPES
var ValidationError = /** @class */ (function () {
    function ValidationError(message) {
        this.name = "ValidationError";
        this.message = message;
    }
    ValidationError.prototype.toString = function () {
        return this.message;
    };
    return ValidationError;
}());
exports.ValidationError = ValidationError;
var Error422 = /** @class */ (function (_super) {
    __extends(Error422, _super);
    function Error422(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error422";
        return _this;
    }
    return Error422;
}(ValidationError));
exports.Error422 = Error422;
var ParameterValidationError = /** @class */ (function (_super) {
    __extends(ParameterValidationError, _super);
    function ParameterValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "ParameterValidationError";
        return _this;
    }
    return ParameterValidationError;
}(Error422));
exports.ParameterValidationError = ParameterValidationError;
var OperationNotAllowedError = /** @class */ (function (_super) {
    __extends(OperationNotAllowedError, _super);
    function OperationNotAllowedError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "OperationNotAllowed";
        return _this;
    }
    return OperationNotAllowedError;
}(ValidationError));
exports.OperationNotAllowedError = OperationNotAllowedError;
var Error409 = /** @class */ (function (_super) {
    __extends(Error409, _super);
    function Error409(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error409";
        return _this;
    }
    return Error409;
}(OperationNotAllowedError));
exports.Error409 = Error409;
var DappNameTakenError = /** @class */ (function (_super) {
    __extends(DappNameTakenError, _super);
    function DappNameTakenError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappNameTakenError";
        return _this;
    }
    return DappNameTakenError;
}(Error409));
exports.DappNameTakenError = DappNameTakenError;
var Error404 = /** @class */ (function (_super) {
    __extends(Error404, _super);
    function Error404(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error404";
        return _this;
    }
    return Error404;
}(OperationNotAllowedError));
exports.Error404 = Error404;
var DappNotFound = /** @class */ (function (_super) {
    __extends(DappNotFound, _super);
    function DappNotFound(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappNotFound";
        return _this;
    }
    return DappNotFound;
}(Error404));
exports.DappNotFound = DappNotFound;
var DappItemValidationError = /** @class */ (function (_super) {
    __extends(DappItemValidationError, _super);
    function DappItemValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "DappItemValidationError";
        return _this;
    }
    return DappItemValidationError;
}(ValidationError));
exports.DappItemValidationError = DappItemValidationError;
var InternalValidationError = /** @class */ (function (_super) {
    __extends(InternalValidationError, _super);
    function InternalValidationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "InternalValidationError";
        return _this;
    }
    return InternalValidationError;
}(ValidationError));
exports.InternalValidationError = InternalValidationError;
var AuthError = /** @class */ (function () {
    function AuthError(message) {
        this.name = "AuthError";
        this.message = message;
    }
    AuthError.prototype.toString = function () {
        return this.message;
    };
    return AuthError;
}());
exports.AuthError = AuthError;
var Error401 = /** @class */ (function (_super) {
    __extends(Error401, _super);
    function Error401(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "Error401";
        return _this;
    }
    return Error401;
}(ValidationError));
exports.Error401 = Error401;
var UnrecognizedCredentialsError = /** @class */ (function (_super) {
    __extends(UnrecognizedCredentialsError, _super);
    function UnrecognizedCredentialsError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "UnrecognizedCredentialsError";
        return _this;
    }
    return UnrecognizedCredentialsError;
}(Error401));
exports.UnrecognizedCredentialsError = UnrecognizedCredentialsError;
var EmailNotConfirmedError = /** @class */ (function (_super) {
    __extends(EmailNotConfirmedError, _super);
    function EmailNotConfirmedError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "EmailNotConfirmedError";
        return _this;
    }
    return EmailNotConfirmedError;
}(Error401));
exports.EmailNotConfirmedError = EmailNotConfirmedError;
var PasswordResetRequiredError = /** @class */ (function (_super) {
    __extends(PasswordResetRequiredError, _super);
    function PasswordResetRequiredError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "PasswordResetRequiredError";
        return _this;
    }
    return PasswordResetRequiredError;
}(Error401));
exports.PasswordResetRequiredError = PasswordResetRequiredError;
var InvalidPasswordError = /** @class */ (function (_super) {
    __extends(InvalidPasswordError, _super);
    function InvalidPasswordError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "InvalidPasswordError";
        return _this;
    }
    return InvalidPasswordError;
}(Error401));
exports.InvalidPasswordError = InvalidPasswordError;
// ASSERT METHODS
function assert(condition, message, errorType) {
    if (errorType === void 0) { errorType = ValidationError; }
    if (!condition) {
        throw new errorType(message);
    }
}
function assertParameterValid(condition, message) {
    return assert(condition, message, ParameterValidationError);
}
exports.assertParameterValid = assertParameterValid;
function assertOperationAllowed(condition, message) {
    return assert(condition, message, OperationNotAllowedError);
}
exports.assertOperationAllowed = assertOperationAllowed;
function assertDappNameNotTaken(condition, message) {
    return assert(condition, message, DappNameTakenError);
}
exports.assertDappNameNotTaken = assertDappNameNotTaken;
function assertDappFound(condition, message) {
    return assert(condition, message, DappNotFound);
}
exports.assertDappFound = assertDappFound;
function assertDappItemValid(condition, message) {
    return assert(condition, message, DappItemValidationError);
}
exports.assertDappItemValid = assertDappItemValid;
function assertInternal(condition) {
    var message = "Internal error during validation";
    return assert(condition, message, InternalValidationError);
}
exports.assertInternal = assertInternal;
function throwInternalValidationError() {
    return assertInternal(false);
}
exports.throwInternalValidationError = throwInternalValidationError;
exports.default = {
    assertParamValid: assertParameterValid,
    assertOpAllowed: assertOperationAllowed,
    assertDappValid: assertDappItemValid,
    assertInternal: assertInternal,
    throwInternalValidationError: throwInternalValidationError
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JzLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVycm9ycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxQkFBcUI7QUFDckI7SUFHSSx5QkFBWSxPQUFjO1FBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUcsaUJBQWlCLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0IsQ0FBQztJQUNELGtDQUFRLEdBQVI7UUFDSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDeEIsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0FBQyxBQVZELElBVUM7QUFWWSwwQ0FBZTtBQVk1QjtJQUE4Qiw0QkFBZTtJQUN6QyxrQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7O0lBQzNCLENBQUM7SUFDTCxlQUFDO0FBQUQsQ0FBQyxBQUxELENBQThCLGVBQWUsR0FLNUM7QUFMWSw0QkFBUTtBQU9yQjtJQUE4Qyw0Q0FBUTtJQUNsRCxrQ0FBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRywwQkFBMEIsQ0FBQzs7SUFDM0MsQ0FBQztJQUNMLCtCQUFDO0FBQUQsQ0FBQyxBQUxELENBQThDLFFBQVEsR0FLckQ7QUFMWSw0REFBd0I7QUFPckM7SUFBOEMsNENBQWU7SUFDekQsa0NBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcscUJBQXFCLENBQUM7O0lBQ3RDLENBQUM7SUFDTCwrQkFBQztBQUFELENBQUMsQUFMRCxDQUE4QyxlQUFlLEdBSzVEO0FBTFksNERBQXdCO0FBT3JDO0lBQThCLDRCQUF3QjtJQUNsRCxrQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7O0lBQzNCLENBQUM7SUFDTCxlQUFDO0FBQUQsQ0FBQyxBQUxELENBQThCLHdCQUF3QixHQUtyRDtBQUxZLDRCQUFRO0FBT3JCO0lBQXdDLHNDQUFRO0lBQzVDLDRCQUFZLE9BQWM7UUFBMUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFERyxLQUFJLENBQUMsSUFBSSxHQUFHLG9CQUFvQixDQUFDOztJQUNyQyxDQUFDO0lBQ0wseUJBQUM7QUFBRCxDQUFDLEFBTEQsQ0FBd0MsUUFBUSxHQUsvQztBQUxZLGdEQUFrQjtBQU8vQjtJQUE4Qiw0QkFBd0I7SUFDbEQsa0JBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDOztJQUMzQixDQUFDO0lBQ0wsZUFBQztBQUFELENBQUMsQUFMRCxDQUE4Qix3QkFBd0IsR0FLckQ7QUFMWSw0QkFBUTtBQU9yQjtJQUFrQyxnQ0FBUTtJQUN0QyxzQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxjQUFjLENBQUM7O0lBQy9CLENBQUM7SUFDTCxtQkFBQztBQUFELENBQUMsQUFMRCxDQUFrQyxRQUFRLEdBS3pDO0FBTFksb0NBQVk7QUFPekI7SUFBNkMsMkNBQWU7SUFDeEQsaUNBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcseUJBQXlCLENBQUM7O0lBQzFDLENBQUM7SUFDTCw4QkFBQztBQUFELENBQUMsQUFMRCxDQUE2QyxlQUFlLEdBSzNEO0FBTFksMERBQXVCO0FBT3BDO0lBQTZDLDJDQUFlO0lBQ3hELGlDQUFZLE9BQWM7UUFBMUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFERyxLQUFJLENBQUMsSUFBSSxHQUFHLHlCQUF5QixDQUFDOztJQUMxQyxDQUFDO0lBQ0wsOEJBQUM7QUFBRCxDQUFDLEFBTEQsQ0FBNkMsZUFBZSxHQUszRDtBQUxZLDBEQUF1QjtBQU9wQztJQUdJLG1CQUFZLE9BQWM7UUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7UUFDeEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0IsQ0FBQztJQUNELDRCQUFRLEdBQVI7UUFDSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDeEIsQ0FBQztJQUNMLGdCQUFDO0FBQUQsQ0FBQyxBQVZELElBVUM7QUFWWSw4QkFBUztBQVl0QjtJQUE4Qiw0QkFBZTtJQUN6QyxrQkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7O0lBQzNCLENBQUM7SUFDTCxlQUFDO0FBQUQsQ0FBQyxBQUxELENBQThCLGVBQWUsR0FLNUM7QUFMWSw0QkFBUTtBQU9yQjtJQUFrRCxnREFBUTtJQUN0RCxzQ0FBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyw4QkFBOEIsQ0FBQzs7SUFDL0MsQ0FBQztJQUNMLG1DQUFDO0FBQUQsQ0FBQyxBQUxELENBQWtELFFBQVEsR0FLekQ7QUFMWSxvRUFBNEI7QUFPekM7SUFBNEMsMENBQVE7SUFDaEQsZ0NBQVksT0FBYztRQUExQixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxJQUFJLEdBQUcsd0JBQXdCLENBQUM7O0lBQ3pDLENBQUM7SUFDTCw2QkFBQztBQUFELENBQUMsQUFMRCxDQUE0QyxRQUFRLEdBS25EO0FBTFksd0RBQXNCO0FBT25DO0lBQWdELDhDQUFRO0lBQ3BELG9DQUFZLE9BQWM7UUFBMUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFERyxLQUFJLENBQUMsSUFBSSxHQUFHLDRCQUE0QixDQUFDOztJQUM3QyxDQUFDO0lBQ0wsaUNBQUM7QUFBRCxDQUFDLEFBTEQsQ0FBZ0QsUUFBUSxHQUt2RDtBQUxZLGdFQUEwQjtBQU92QztJQUEwQyx3Q0FBUTtJQUM5Qyw4QkFBWSxPQUFjO1FBQTFCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBRWpCO1FBREcsS0FBSSxDQUFDLElBQUksR0FBRyxzQkFBc0IsQ0FBQzs7SUFDdkMsQ0FBQztJQUNMLDJCQUFDO0FBQUQsQ0FBQyxBQUxELENBQTBDLFFBQVEsR0FLakQ7QUFMWSxvREFBb0I7QUFPakMsaUJBQWlCO0FBQ2pCLFNBQVMsTUFBTSxDQUFDLFNBQWEsRUFBRSxPQUFjLEVBQUUsU0FBeUI7SUFBekIsMEJBQUEsRUFBQSwyQkFBeUI7SUFDcEUsSUFBSSxDQUFDLFNBQVMsRUFBRTtRQUNaLE1BQU0sSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDaEM7QUFDTCxDQUFDO0FBRUQsU0FBZ0Isb0JBQW9CLENBQUMsU0FBYSxFQUFFLE9BQWM7SUFDOUQsT0FBTyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO0FBQ2hFLENBQUM7QUFGRCxvREFFQztBQUVELFNBQWdCLHNCQUFzQixDQUFDLFNBQWEsRUFBRSxPQUFjO0lBQ2hFLE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztBQUNoRSxDQUFDO0FBRkQsd0RBRUM7QUFFRCxTQUFnQixzQkFBc0IsQ0FBQyxTQUFhLEVBQUUsT0FBYztJQUNoRSxPQUFPLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLGtCQUFrQixDQUFDLENBQUM7QUFDMUQsQ0FBQztBQUZELHdEQUVDO0FBRUQsU0FBZ0IsZUFBZSxDQUFDLFNBQWEsRUFBRSxPQUFjO0lBQ3pELE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDcEQsQ0FBQztBQUZELDBDQUVDO0FBRUQsU0FBZ0IsbUJBQW1CLENBQUMsU0FBYSxFQUFFLE9BQWM7SUFDN0QsT0FBTyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0FBQy9ELENBQUM7QUFGRCxrREFFQztBQUVELFNBQWdCLGNBQWMsQ0FBQyxTQUFhO0lBQ3hDLElBQUksT0FBTyxHQUFHLGtDQUFrQyxDQUFDO0lBQ2pELE9BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztBQUMvRCxDQUFDO0FBSEQsd0NBR0M7QUFFRCxTQUFnQiw0QkFBNEI7SUFDeEMsT0FBTyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakMsQ0FBQztBQUZELG9FQUVDO0FBRUQsa0JBQWU7SUFDWCxnQkFBZ0IsRUFBRyxvQkFBb0I7SUFDdkMsZUFBZSxFQUFHLHNCQUFzQjtJQUN4QyxlQUFlLEVBQUcsbUJBQW1CO0lBQ3JDLGNBQWMsRUFBRyxjQUFjO0lBQy9CLDRCQUE0QixFQUFHLDRCQUE0QjtDQUM5RCxDQUFBIn0=