"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function promiseAdminGetUser(cognitoUsername) {
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); });
}
function promiseLogin(cognitoUsername, cognitoPassword) {
    var params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        AuthParameters: {
            'USERNAME': cognitoUsername,
            'PASSWORD': cognitoPassword
        },
        ClientId: env_1.cognitoClientId
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.initiateAuth(params).promise(); });
}
var CognitoChallengeNames;
(function (CognitoChallengeNames) {
    CognitoChallengeNames["NewPassword"] = "NEW_PASSWORD_REQUIRED";
    CognitoChallengeNames["SMS_MFA"] = "SMS_MFA";
    CognitoChallengeNames["MFASetup"] = "MFA_SETUP";
})(CognitoChallengeNames = exports.CognitoChallengeNames || (exports.CognitoChallengeNames = {}));
function promiseConfirmNewPassword(userSession, username, newPassword) {
    var params = {
        ChallengeName: CognitoChallengeNames.NewPassword,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'NEW_PASSWORD': newPassword
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseConfirmMFALogin(userSession, username, code) {
    var params = {
        ChallengeName: CognitoChallengeNames.SMS_MFA,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'SMS_MFA_CODE': code
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseBeginForgotPassword(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.forgotPassword(params).promise(); });
}
function promiseConfirmForgotPassword(cognitoUsername, confirmationCode, newPassword) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername,
        ConfirmationCode: confirmationCode,
        Password: newPassword
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.confirmForgotPassword(params).promise(); });
}
function promiseResendSignUpConfirmCode(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.resendConfirmationCode(params).promise(); });
}
function promiseBeginMFASetup(cognitoSession) {
    var params = {
        Session: cognitoSession
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.associateSoftwareToken(params).promise(); });
}
function promiseConfirmMFASetup(cognitoSession, mfaSetupCode) {
    var params = {
        Session: cognitoSession,
        UserCode: mfaSetupCode
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.verifySoftwareToken(params).promise(); });
}
exports.default = {
    getUser: promiseAdminGetUser,
    login: promiseLogin,
    confirmNewPassword: promiseConfirmNewPassword,
    confirmMFALogin: promiseConfirmMFALogin,
    beginMFASetup: promiseBeginMFASetup,
    confirmMFASetup: promiseConfirmMFASetup,
    beginForgotPassword: promiseBeginForgotPassword,
    confirmForgotPassword: promiseConfirmForgotPassword,
    resendSignUpConfirmCode: promiseResendSignUpConfirmCode
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsOEJBQWlFO0FBQ2pFLG9DQUFpRDtBQUNqRCxJQUFNLE9BQU8sR0FBRyxJQUFJLFNBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQVMsbUJBQW1CLENBQUMsZUFBc0I7SUFDL0MsSUFBSSxNQUFNLEdBQUc7UUFDVCxVQUFVLEVBQUUsdUJBQWlCO1FBQzdCLFFBQVEsRUFBRSxlQUFlO0tBQzVCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUVELFNBQVMsWUFBWSxDQUFDLGVBQXNCLEVBQUUsZUFBc0I7SUFDaEUsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcsb0JBQW9CO1FBQy9CLGNBQWMsRUFBRztZQUNiLFVBQVUsRUFBRyxlQUFlO1lBQzVCLFVBQVUsRUFBRyxlQUFlO1NBQy9CO1FBQ0QsUUFBUSxFQUFHLHFCQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUE7QUFDN0UsQ0FBQztBQUVELElBQVkscUJBSVg7QUFKRCxXQUFZLHFCQUFxQjtJQUM3Qiw4REFBcUMsQ0FBQTtJQUNyQyw0Q0FBbUIsQ0FBQTtJQUNuQiwrQ0FBc0IsQ0FBQTtBQUMxQixDQUFDLEVBSlcscUJBQXFCLEdBQXJCLDZCQUFxQixLQUFyQiw2QkFBcUIsUUFJaEM7QUFFRCxTQUFTLHlCQUF5QixDQUFDLFdBQWtCLEVBQUUsUUFBZSxFQUFFLFdBQWtCO0lBQ3RGLElBQUksTUFBTSxHQUFHO1FBQ1QsYUFBYSxFQUFHLHFCQUFxQixDQUFDLFdBQVc7UUFDakQsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLE9BQU8sRUFBRyxXQUFXO1FBQ3JCLGtCQUFrQixFQUFHO1lBQ2pCLFVBQVUsRUFBRyxRQUFRO1lBQ3JCLGNBQWMsRUFBRyxXQUFXO1NBQy9CO0tBQ0osQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLFdBQWtCLEVBQUUsUUFBZSxFQUFFLElBQVc7SUFDNUUsSUFBSSxNQUFNLEdBQUc7UUFDVCxhQUFhLEVBQUcscUJBQXFCLENBQUMsT0FBTztRQUM3QyxRQUFRLEVBQUcscUJBQWU7UUFDMUIsT0FBTyxFQUFHLFdBQVc7UUFDckIsa0JBQWtCLEVBQUc7WUFDakIsVUFBVSxFQUFHLFFBQVE7WUFDckIsY0FBYyxFQUFHLElBQUk7U0FDeEI7S0FDSixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoRCxDQUFnRCxDQUFDLENBQUM7QUFDeEYsQ0FBQztBQUVELFNBQVMsMEJBQTBCLENBQUMsZUFBc0I7SUFDdEQsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcscUJBQWU7UUFDMUIsUUFBUSxFQUFHLGVBQWU7S0FDN0IsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXhDLENBQXdDLENBQUMsQ0FBQTtBQUMvRSxDQUFDO0FBRUQsU0FBUyw0QkFBNEIsQ0FBQyxlQUFzQixFQUFFLGdCQUF1QixFQUFFLFdBQWtCO0lBQ3JHLElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLFFBQVEsRUFBRyxlQUFlO1FBQzFCLGdCQUFnQixFQUFHLGdCQUFnQjtRQUNuQyxRQUFRLEVBQUcsV0FBVztLQUN6QixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUEvQyxDQUErQyxDQUFDLENBQUE7QUFDdEYsQ0FBQztBQUVELFNBQVMsOEJBQThCLENBQUMsZUFBc0I7SUFDMUQsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcscUJBQWU7UUFDMUIsUUFBUSxFQUFHLGVBQWU7S0FDN0IsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFBO0FBQ3ZGLENBQUM7QUFFRCxTQUFTLG9CQUFvQixDQUFDLGNBQXFCO0lBQy9DLElBQUksTUFBTSxHQUFHO1FBQ1QsT0FBTyxFQUFHLGNBQWM7S0FDM0IsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLGNBQXFCLEVBQUUsWUFBbUI7SUFDdEUsSUFBSSxNQUFNLEdBQUc7UUFDVCxPQUFPLEVBQUcsY0FBYztRQUN4QixRQUFRLEVBQUcsWUFBWTtLQUMxQixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE3QyxDQUE2QyxDQUFDLENBQUM7QUFDckYsQ0FBQztBQUVELGtCQUFlO0lBQ1gsT0FBTyxFQUFtQixtQkFBbUI7SUFDN0MsS0FBSyxFQUFxQixZQUFZO0lBQ3RDLGtCQUFrQixFQUFRLHlCQUF5QjtJQUNuRCxlQUFlLEVBQVcsc0JBQXNCO0lBQ2hELGFBQWEsRUFBYSxvQkFBb0I7SUFDOUMsZUFBZSxFQUFXLHNCQUFzQjtJQUNoRCxtQkFBbUIsRUFBTywwQkFBMEI7SUFDcEQscUJBQXFCLEVBQUssNEJBQTRCO0lBQ3RELHVCQUF1QixFQUFHLDhCQUE4QjtDQUMzRCxDQUFBIn0=