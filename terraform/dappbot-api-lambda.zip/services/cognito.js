"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function promiseAdminGetUser(cognitoUsername) {
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); });
}
function promiseLogin(cognitoUsername, cognitoPassword) {
    var params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        AuthParameters: {
            'USERNAME': cognitoUsername,
            'PASSWORD': cognitoPassword
        },
        ClientId: env_1.cognitoClientId
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.initiateAuth(params).promise(); });
}
function promiseConfirmNewPassword(userSession, username, newPassword) {
    var params = {
        ChallengeName: 'NEW_PASSWORD_REQUIRED',
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'NEW_PASSWORD': newPassword
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseConfirmMFALogin(userSession, username, code) {
    var params = {
        ChallengeName: 'SMS_MFA',
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'SMS_MFA_CODE': code
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseBeginForgotPassword(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.forgotPassword(params).promise(); });
}
function promiseConfirmForgotPassword(cognitoUsername, confirmationCode, newPassword) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername,
        ConfirmationCode: confirmationCode,
        Password: newPassword
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.confirmForgotPassword(params).promise(); });
}
function promiseResendSignUpConfirmCode(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.resendConfirmationCode(params).promise(); });
}
function promiseBeginMFASetup(cognitoSession) {
    var params = {
        Session: cognitoSession
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.associateSoftwareToken(params).promise(); });
}
function promiseConfirmMFASetup(cognitoSession, mfaSetupCode) {
    var params = {
        Session: cognitoSession,
        UserCode: mfaSetupCode
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.verifySoftwareToken(params).promise(); });
}
exports.default = {
    getUser: promiseAdminGetUser,
    login: promiseLogin,
    confirmNewPassword: promiseConfirmNewPassword,
    confirmMFALogin: promiseConfirmMFALogin,
    beginMFASetup: promiseBeginMFASetup,
    confirmMFASetup: promiseConfirmMFASetup,
    beginForgotPassword: promiseBeginForgotPassword,
    confirmForgotPassword: promiseConfirmForgotPassword,
    resendSignUpConfirmCode: promiseResendSignUpConfirmCode
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsOEJBQWlFO0FBQ2pFLG9DQUFpRDtBQUNqRCxJQUFNLE9BQU8sR0FBRyxJQUFJLFNBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQVMsbUJBQW1CLENBQUMsZUFBc0I7SUFDL0MsSUFBSSxNQUFNLEdBQUc7UUFDVCxVQUFVLEVBQUUsdUJBQWlCO1FBQzdCLFFBQVEsRUFBRSxlQUFlO0tBQzVCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUVELFNBQVMsWUFBWSxDQUFDLGVBQXNCLEVBQUUsZUFBc0I7SUFDaEUsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcsb0JBQW9CO1FBQy9CLGNBQWMsRUFBRztZQUNiLFVBQVUsRUFBRyxlQUFlO1lBQzVCLFVBQVUsRUFBRyxlQUFlO1NBQy9CO1FBQ0QsUUFBUSxFQUFHLHFCQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUE7QUFDN0UsQ0FBQztBQUVELFNBQVMseUJBQXlCLENBQUMsV0FBa0IsRUFBRSxRQUFlLEVBQUUsV0FBa0I7SUFDdEYsSUFBSSxNQUFNLEdBQUc7UUFDVCxhQUFhLEVBQUcsdUJBQXVCO1FBQ3ZDLFFBQVEsRUFBRyxxQkFBZTtRQUMxQixPQUFPLEVBQUcsV0FBVztRQUNyQixrQkFBa0IsRUFBRztZQUNqQixVQUFVLEVBQUcsUUFBUTtZQUNyQixjQUFjLEVBQUcsV0FBVztTQUMvQjtLQUNKLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxXQUFrQixFQUFFLFFBQWUsRUFBRSxJQUFXO0lBQzVFLElBQUksTUFBTSxHQUFHO1FBQ1QsYUFBYSxFQUFHLFNBQVM7UUFDekIsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLE9BQU8sRUFBRyxXQUFXO1FBQ3JCLGtCQUFrQixFQUFHO1lBQ2pCLFVBQVUsRUFBRyxRQUFRO1lBQ3JCLGNBQWMsRUFBRyxJQUFJO1NBQ3hCO0tBQ0osQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLDBCQUEwQixDQUFDLGVBQXNCO0lBQ3RELElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLFFBQVEsRUFBRyxlQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF4QyxDQUF3QyxDQUFDLENBQUE7QUFDL0UsQ0FBQztBQUVELFNBQVMsNEJBQTRCLENBQUMsZUFBc0IsRUFBRSxnQkFBdUIsRUFBRSxXQUFrQjtJQUNyRyxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxxQkFBZTtRQUMxQixRQUFRLEVBQUcsZUFBZTtRQUMxQixnQkFBZ0IsRUFBRyxnQkFBZ0I7UUFDbkMsUUFBUSxFQUFHLFdBQVc7S0FDekIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsQ0FBQyxDQUFBO0FBQ3RGLENBQUM7QUFFRCxTQUFTLDhCQUE4QixDQUFDLGVBQXNCO0lBQzFELElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLFFBQVEsRUFBRyxlQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQTtBQUN2RixDQUFDO0FBRUQsU0FBUyxvQkFBb0IsQ0FBQyxjQUFxQjtJQUMvQyxJQUFJLE1BQU0sR0FBRztRQUNULE9BQU8sRUFBRyxjQUFjO0tBQzNCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxjQUFxQixFQUFFLFlBQW1CO0lBQ3RFLElBQUksTUFBTSxHQUFHO1FBQ1QsT0FBTyxFQUFHLGNBQWM7UUFDeEIsUUFBUSxFQUFHLFlBQVk7S0FDMUIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBN0MsQ0FBNkMsQ0FBQyxDQUFDO0FBQ3JGLENBQUM7QUFFRCxrQkFBZTtJQUNYLE9BQU8sRUFBbUIsbUJBQW1CO0lBQzdDLEtBQUssRUFBcUIsWUFBWTtJQUN0QyxrQkFBa0IsRUFBUSx5QkFBeUI7SUFDbkQsZUFBZSxFQUFXLHNCQUFzQjtJQUNoRCxhQUFhLEVBQWEsb0JBQW9CO0lBQzlDLGVBQWUsRUFBVyxzQkFBc0I7SUFDaEQsbUJBQW1CLEVBQU8sMEJBQTBCO0lBQ3BELHFCQUFxQixFQUFLLDRCQUE0QjtJQUN0RCx1QkFBdUIsRUFBRyw4QkFBOEI7Q0FDM0QsQ0FBQSJ9