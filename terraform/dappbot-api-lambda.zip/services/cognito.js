"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function promiseAdminGetUser(cognitoUsername) {
    var maxRetries = 5;
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); }, maxRetries);
}
exports.default = {
    getUser: promiseAdminGetUser
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsOEJBQWdEO0FBQ2hELG9DQUFpRDtBQUNqRCxJQUFNLE9BQU8sR0FBRyxJQUFJLFNBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQVMsbUJBQW1CLENBQUMsZUFBc0I7SUFDL0MsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksTUFBTSxHQUFHO1FBQ1QsVUFBVSxFQUFFLHVCQUFpQjtRQUM3QixRQUFRLEVBQUUsZUFBZTtLQUM1QixDQUFDO0lBQ0YsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBdEMsQ0FBc0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUMxRixDQUFDO0FBRUQsa0JBQWU7SUFDWCxPQUFPLEVBQUcsbUJBQW1CO0NBQ2hDLENBQUEifQ==