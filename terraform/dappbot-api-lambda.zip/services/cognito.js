"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function promiseAdminGetUser(cognitoUsername) {
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); });
}
function promiseGetUser(accessToken) {
    var params = {
        AccessToken: accessToken
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.getUser(params).promise(); });
}
function promiseLogin(cognitoUsername, cognitoPassword) {
    var params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        AuthParameters: {
            'USERNAME': cognitoUsername,
            'PASSWORD': cognitoPassword
        },
        ClientId: env_1.cognitoClientId
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.initiateAuth(params).promise(); });
}
var CognitoChallengeNames;
(function (CognitoChallengeNames) {
    CognitoChallengeNames["NewPassword"] = "NEW_PASSWORD_REQUIRED";
    CognitoChallengeNames["SMS_MFA"] = "SMS_MFA";
    CognitoChallengeNames["MFASetup"] = "MFA_SETUP";
})(CognitoChallengeNames = exports.CognitoChallengeNames || (exports.CognitoChallengeNames = {}));
function promiseConfirmNewPassword(userSession, username, newPassword) {
    var params = {
        ChallengeName: CognitoChallengeNames.NewPassword,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'NEW_PASSWORD': newPassword
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseConfirmMFALogin(userSession, username, code) {
    var params = {
        ChallengeName: CognitoChallengeNames.SMS_MFA,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'SMS_MFA_CODE': code
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseBeginForgotPassword(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.forgotPassword(params).promise(); });
}
function promiseConfirmForgotPassword(cognitoUsername, confirmationCode, newPassword) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername,
        ConfirmationCode: confirmationCode,
        Password: newPassword
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.confirmForgotPassword(params).promise(); });
}
function promiseResendSignUpConfirmCode(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.resendConfirmationCode(params).promise(); });
}
function promiseBeginMFASetup(cognitoSession) {
    var params = {
        Session: cognitoSession
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.associateSoftwareToken(params).promise(); });
}
function promiseConfirmMFASetup(cognitoSession, mfaSetupCode) {
    var params = {
        Session: cognitoSession,
        UserCode: mfaSetupCode
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.verifySoftwareToken(params).promise(); });
}
exports.default = {
    getUser: promiseAdminGetUser,
    getUserByToken: promiseGetUser,
    login: promiseLogin,
    confirmNewPassword: promiseConfirmNewPassword,
    confirmMFALogin: promiseConfirmMFALogin,
    beginMFASetup: promiseBeginMFASetup,
    confirmMFASetup: promiseConfirmMFASetup,
    beginForgotPassword: promiseBeginForgotPassword,
    confirmForgotPassword: promiseConfirmForgotPassword,
    resendSignUpConfirmCode: promiseResendSignUpConfirmCode
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsOEJBQWlFO0FBQ2pFLG9DQUFpRDtBQUNqRCxJQUFNLE9BQU8sR0FBRyxJQUFJLFNBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQVMsbUJBQW1CLENBQUMsZUFBc0I7SUFDL0MsSUFBSSxNQUFNLEdBQUc7UUFDVCxVQUFVLEVBQUUsdUJBQWlCO1FBQzdCLFFBQVEsRUFBRSxlQUFlO0tBQzVCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLFdBQWtCO0lBQ3RDLElBQUksTUFBTSxHQUFHO1FBQ1QsV0FBVyxFQUFHLFdBQVc7S0FDNUIsQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLENBQUMsQ0FBQztBQUN6RSxDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUMsZUFBc0IsRUFBRSxlQUFzQjtJQUNoRSxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxvQkFBb0I7UUFDL0IsY0FBYyxFQUFHO1lBQ2IsVUFBVSxFQUFHLGVBQWU7WUFDNUIsVUFBVSxFQUFHLGVBQWU7U0FDL0I7UUFDRCxRQUFRLEVBQUcscUJBQWU7S0FDN0IsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXRDLENBQXNDLENBQUMsQ0FBQTtBQUM3RSxDQUFDO0FBRUQsSUFBWSxxQkFJWDtBQUpELFdBQVkscUJBQXFCO0lBQzdCLDhEQUFxQyxDQUFBO0lBQ3JDLDRDQUFtQixDQUFBO0lBQ25CLCtDQUFzQixDQUFBO0FBQzFCLENBQUMsRUFKVyxxQkFBcUIsR0FBckIsNkJBQXFCLEtBQXJCLDZCQUFxQixRQUloQztBQUVELFNBQVMseUJBQXlCLENBQUMsV0FBa0IsRUFBRSxRQUFlLEVBQUUsV0FBa0I7SUFDdEYsSUFBSSxNQUFNLEdBQUc7UUFDVCxhQUFhLEVBQUcscUJBQXFCLENBQUMsV0FBVztRQUNqRCxRQUFRLEVBQUcscUJBQWU7UUFDMUIsT0FBTyxFQUFHLFdBQVc7UUFDckIsa0JBQWtCLEVBQUc7WUFDakIsVUFBVSxFQUFHLFFBQVE7WUFDckIsY0FBYyxFQUFHLFdBQVc7U0FDL0I7S0FDSixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoRCxDQUFnRCxDQUFDLENBQUM7QUFDeEYsQ0FBQztBQUVELFNBQVMsc0JBQXNCLENBQUMsV0FBa0IsRUFBRSxRQUFlLEVBQUUsSUFBVztJQUM1RSxJQUFJLE1BQU0sR0FBRztRQUNULGFBQWEsRUFBRyxxQkFBcUIsQ0FBQyxPQUFPO1FBQzdDLFFBQVEsRUFBRyxxQkFBZTtRQUMxQixPQUFPLEVBQUcsV0FBVztRQUNyQixrQkFBa0IsRUFBRztZQUNqQixVQUFVLEVBQUcsUUFBUTtZQUNyQixjQUFjLEVBQUcsSUFBSTtTQUN4QjtLQUNKLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUywwQkFBMEIsQ0FBQyxlQUFzQjtJQUN0RCxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxxQkFBZTtRQUMxQixRQUFRLEVBQUcsZUFBZTtLQUM3QixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBeEMsQ0FBd0MsQ0FBQyxDQUFBO0FBQy9FLENBQUM7QUFFRCxTQUFTLDRCQUE0QixDQUFDLGVBQXNCLEVBQUUsZ0JBQXVCLEVBQUUsV0FBa0I7SUFDckcsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcscUJBQWU7UUFDMUIsUUFBUSxFQUFHLGVBQWU7UUFDMUIsZ0JBQWdCLEVBQUcsZ0JBQWdCO1FBQ25DLFFBQVEsRUFBRyxXQUFXO0tBQ3pCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQS9DLENBQStDLENBQUMsQ0FBQTtBQUN0RixDQUFDO0FBRUQsU0FBUyw4QkFBOEIsQ0FBQyxlQUFzQjtJQUMxRCxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxxQkFBZTtRQUMxQixRQUFRLEVBQUcsZUFBZTtLQUM3QixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoRCxDQUFnRCxDQUFDLENBQUE7QUFDdkYsQ0FBQztBQUVELFNBQVMsb0JBQW9CLENBQUMsY0FBcUI7SUFDL0MsSUFBSSxNQUFNLEdBQUc7UUFDVCxPQUFPLEVBQUcsY0FBYztLQUMzQixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFoRCxDQUFnRCxDQUFDLENBQUM7QUFDeEYsQ0FBQztBQUVELFNBQVMsc0JBQXNCLENBQUMsY0FBcUIsRUFBRSxZQUFtQjtJQUN0RSxJQUFJLE1BQU0sR0FBRztRQUNULE9BQU8sRUFBRyxjQUFjO1FBQ3hCLFFBQVEsRUFBRyxZQUFZO0tBQzFCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQTdDLENBQTZDLENBQUMsQ0FBQztBQUNyRixDQUFDO0FBRUQsa0JBQWU7SUFDWCxPQUFPLEVBQW1CLG1CQUFtQjtJQUM3QyxjQUFjLEVBQVksY0FBYztJQUN4QyxLQUFLLEVBQXFCLFlBQVk7SUFDdEMsa0JBQWtCLEVBQVEseUJBQXlCO0lBQ25ELGVBQWUsRUFBVyxzQkFBc0I7SUFDaEQsYUFBYSxFQUFhLG9CQUFvQjtJQUM5QyxlQUFlLEVBQVcsc0JBQXNCO0lBQ2hELG1CQUFtQixFQUFPLDBCQUEwQjtJQUNwRCxxQkFBcUIsRUFBSyw0QkFBNEI7SUFDdEQsdUJBQXVCLEVBQUcsOEJBQThCO0NBQzNELENBQUEifQ==