"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var common_1 = require("../common");
var cognito = new env_1.AWS.CognitoIdentityServiceProvider({ apiVersion: '2016-04-18' });
function promiseAdminGetUser(cognitoUsername) {
    var params = {
        UserPoolId: env_1.cognitoUserPoolId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.adminGetUser(params).promise(); });
}
function promiseGetUser(accessToken) {
    var params = {
        AccessToken: accessToken
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.getUser(params).promise(); });
}
function promiseLogin(cognitoUsername, cognitoPassword) {
    var params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        AuthParameters: {
            'USERNAME': cognitoUsername,
            'PASSWORD': cognitoPassword
        },
        ClientId: env_1.cognitoClientId
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.initiateAuth(params).promise(); });
}
function promiseRefresh(refreshToken) {
    var params = {
        AuthFlow: 'REFRESH_TOKEN',
        AuthParameters: {
            'REFRESH_TOKEN': refreshToken
        },
        ClientId: env_1.cognitoClientId
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.initiateAuth(params).promise(); });
}
var CognitoChallengeNames;
(function (CognitoChallengeNames) {
    CognitoChallengeNames["NewPassword"] = "NEW_PASSWORD_REQUIRED";
    CognitoChallengeNames["SMS_MFA"] = "SMS_MFA";
    CognitoChallengeNames["MFASetup"] = "MFA_SETUP";
})(CognitoChallengeNames = exports.CognitoChallengeNames || (exports.CognitoChallengeNames = {}));
function promiseConfirmNewPassword(userSession, username, newPassword) {
    var params = {
        ChallengeName: CognitoChallengeNames.NewPassword,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'NEW_PASSWORD': newPassword
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseConfirmMFALogin(userSession, username, code) {
    var params = {
        ChallengeName: CognitoChallengeNames.SMS_MFA,
        ClientId: env_1.cognitoClientId,
        Session: userSession,
        ChallengeResponses: {
            'USERNAME': username,
            'SMS_MFA_CODE': code
        }
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.respondToAuthChallenge(params).promise(); });
}
function promiseBeginForgotPassword(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.forgotPassword(params).promise(); });
}
function promiseConfirmForgotPassword(cognitoUsername, confirmationCode, newPassword) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername,
        ConfirmationCode: confirmationCode,
        Password: newPassword
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.confirmForgotPassword(params).promise(); });
}
function promiseResendSignUpConfirmCode(cognitoUsername) {
    var params = {
        ClientId: env_1.cognitoClientId,
        Username: cognitoUsername
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.resendConfirmationCode(params).promise(); });
}
function promiseBeginMFASetup(cognitoSession) {
    var params = {
        Session: cognitoSession
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.associateSoftwareToken(params).promise(); });
}
function promiseConfirmMFASetup(cognitoSession, mfaSetupCode) {
    var params = {
        Session: cognitoSession,
        UserCode: mfaSetupCode
    };
    return common_1.addAwsPromiseRetries(function () { return cognito.verifySoftwareToken(params).promise(); });
}
exports.default = {
    getUser: promiseAdminGetUser,
    getUserByToken: promiseGetUser,
    login: promiseLogin,
    refresh: promiseRefresh,
    confirmNewPassword: promiseConfirmNewPassword,
    confirmMFALogin: promiseConfirmMFALogin,
    beginMFASetup: promiseBeginMFASetup,
    confirmMFASetup: promiseConfirmMFASetup,
    beginForgotPassword: promiseBeginForgotPassword,
    confirmForgotPassword: promiseConfirmForgotPassword,
    resendSignUpConfirmCode: promiseResendSignUpConfirmCode
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jb2duaXRvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsOEJBQWlFO0FBQ2pFLG9DQUFpRDtBQUNqRCxJQUFNLE9BQU8sR0FBRyxJQUFJLFNBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0FBRW5GLFNBQVMsbUJBQW1CLENBQUMsZUFBc0I7SUFDL0MsSUFBSSxNQUFNLEdBQUc7UUFDVCxVQUFVLEVBQUUsdUJBQWlCO1FBQzdCLFFBQVEsRUFBRSxlQUFlO0tBQzVCLENBQUM7SUFDRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF0QyxDQUFzQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLFdBQWtCO0lBQ3RDLElBQUksTUFBTSxHQUFHO1FBQ1QsV0FBVyxFQUFHLFdBQVc7S0FDNUIsQ0FBQztJQUNGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLENBQUMsQ0FBQztBQUN6RSxDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUMsZUFBc0IsRUFBRSxlQUFzQjtJQUNoRSxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxvQkFBb0I7UUFDL0IsY0FBYyxFQUFHO1lBQ2IsVUFBVSxFQUFHLGVBQWU7WUFDNUIsVUFBVSxFQUFHLGVBQWU7U0FDL0I7UUFDRCxRQUFRLEVBQUcscUJBQWU7S0FDN0IsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQXRDLENBQXNDLENBQUMsQ0FBQTtBQUM3RSxDQUFDO0FBRUQsU0FBUyxjQUFjLENBQUMsWUFBbUI7SUFDdkMsSUFBSSxNQUFNLEdBQUc7UUFDVCxRQUFRLEVBQUcsZUFBZTtRQUMxQixjQUFjLEVBQUc7WUFDYixlQUFlLEVBQUcsWUFBWTtTQUNqQztRQUNELFFBQVEsRUFBRyxxQkFBZTtLQUM3QixDQUFBO0lBQ0QsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBdEMsQ0FBc0MsQ0FBQyxDQUFBO0FBQzdFLENBQUM7QUFFRCxJQUFZLHFCQUlYO0FBSkQsV0FBWSxxQkFBcUI7SUFDN0IsOERBQXFDLENBQUE7SUFDckMsNENBQW1CLENBQUE7SUFDbkIsK0NBQXNCLENBQUE7QUFDMUIsQ0FBQyxFQUpXLHFCQUFxQixHQUFyQiw2QkFBcUIsS0FBckIsNkJBQXFCLFFBSWhDO0FBRUQsU0FBUyx5QkFBeUIsQ0FBQyxXQUFrQixFQUFFLFFBQWUsRUFBRSxXQUFrQjtJQUN0RixJQUFJLE1BQU0sR0FBRztRQUNULGFBQWEsRUFBRyxxQkFBcUIsQ0FBQyxXQUFXO1FBQ2pELFFBQVEsRUFBRyxxQkFBZTtRQUMxQixPQUFPLEVBQUcsV0FBVztRQUNyQixrQkFBa0IsRUFBRztZQUNqQixVQUFVLEVBQUcsUUFBUTtZQUNyQixjQUFjLEVBQUcsV0FBVztTQUMvQjtLQUNKLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxXQUFrQixFQUFFLFFBQWUsRUFBRSxJQUFXO0lBQzVFLElBQUksTUFBTSxHQUFHO1FBQ1QsYUFBYSxFQUFHLHFCQUFxQixDQUFDLE9BQU87UUFDN0MsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLE9BQU8sRUFBRyxXQUFXO1FBQ3JCLGtCQUFrQixFQUFHO1lBQ2pCLFVBQVUsRUFBRyxRQUFRO1lBQ3JCLGNBQWMsRUFBRyxJQUFJO1NBQ3hCO0tBQ0osQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLDBCQUEwQixDQUFDLGVBQXNCO0lBQ3RELElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLFFBQVEsRUFBRyxlQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUF4QyxDQUF3QyxDQUFDLENBQUE7QUFDL0UsQ0FBQztBQUVELFNBQVMsNEJBQTRCLENBQUMsZUFBc0IsRUFBRSxnQkFBdUIsRUFBRSxXQUFrQjtJQUNyRyxJQUFJLE1BQU0sR0FBRztRQUNULFFBQVEsRUFBRyxxQkFBZTtRQUMxQixRQUFRLEVBQUcsZUFBZTtRQUMxQixnQkFBZ0IsRUFBRyxnQkFBZ0I7UUFDbkMsUUFBUSxFQUFHLFdBQVc7S0FDekIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBL0MsQ0FBK0MsQ0FBQyxDQUFBO0FBQ3RGLENBQUM7QUFFRCxTQUFTLDhCQUE4QixDQUFDLGVBQXNCO0lBQzFELElBQUksTUFBTSxHQUFHO1FBQ1QsUUFBUSxFQUFHLHFCQUFlO1FBQzFCLFFBQVEsRUFBRyxlQUFlO0tBQzdCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQTtBQUN2RixDQUFDO0FBRUQsU0FBUyxvQkFBb0IsQ0FBQyxjQUFxQjtJQUMvQyxJQUFJLE1BQU0sR0FBRztRQUNULE9BQU8sRUFBRyxjQUFjO0tBQzNCLENBQUE7SUFDRCxPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWhELENBQWdELENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxjQUFxQixFQUFFLFlBQW1CO0lBQ3RFLElBQUksTUFBTSxHQUFHO1FBQ1QsT0FBTyxFQUFHLGNBQWM7UUFDeEIsUUFBUSxFQUFHLFlBQVk7S0FDMUIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBN0MsQ0FBNkMsQ0FBQyxDQUFDO0FBQ3JGLENBQUM7QUFFRCxrQkFBZTtJQUNYLE9BQU8sRUFBbUIsbUJBQW1CO0lBQzdDLGNBQWMsRUFBWSxjQUFjO0lBQ3hDLEtBQUssRUFBcUIsWUFBWTtJQUN0QyxPQUFPLEVBQW1CLGNBQWM7SUFDeEMsa0JBQWtCLEVBQVEseUJBQXlCO0lBQ25ELGVBQWUsRUFBVyxzQkFBc0I7SUFDaEQsYUFBYSxFQUFhLG9CQUFvQjtJQUM5QyxlQUFlLEVBQVcsc0JBQXNCO0lBQ2hELG1CQUFtQixFQUFPLDBCQUEwQjtJQUNwRCxxQkFBcUIsRUFBSyw0QkFBNEI7SUFDdEQsdUJBQXVCLEVBQUcsOEJBQThCO0NBQzNELENBQUEifQ==