"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var env_1 = require("../env");
var addAwsPromiseRetries = require('../common').addAwsPromiseRetries;
var sqs = new env_1.AWS.SQS({ apiVersion: '2012-11-05' });
function promiseSendMessage(method, body) {
    var maxRetries = 5;
    var params = {
        QueueUrl: env_1.sqsQueue,
        MessageBody: body,
        MessageAttributes: {
            Method: {
                DataType: 'String',
                StringValue: method
            }
        }
    };
    return addAwsPromiseRetries(function () { return sqs.sendMessage(params).promise(); }, maxRetries);
}
exports.default = {
    sendMessage: promiseSendMessage
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3FzLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbInNlcnZpY2VzL3Nxcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDhCQUF1QztBQUUvQixJQUFBLGdFQUFvQixDQUEwQjtBQUV0RCxJQUFNLEdBQUcsR0FBRyxJQUFJLFNBQUcsQ0FBQyxHQUFHLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUVwRCxTQUFTLGtCQUFrQixDQUFDLE1BQWEsRUFBRSxJQUFXO0lBQ2xELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLE1BQU0sR0FBc0I7UUFDNUIsUUFBUSxFQUFFLGNBQWtCO1FBQzVCLFdBQVcsRUFBRSxJQUFJO1FBQ2pCLGlCQUFpQixFQUFFO1lBQ2YsTUFBTSxFQUFFO2dCQUNKLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixXQUFXLEVBQUUsTUFBTTthQUN0QjtTQUNKO0tBQ0osQ0FBQztJQUNGLE9BQU8sb0JBQW9CLENBQUMsY0FBTSxPQUFBLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDckYsQ0FBQztBQUVELGtCQUFlO0lBQ1gsV0FBVyxFQUFHLGtCQUFrQjtDQUNuQyxDQUFBIn0=