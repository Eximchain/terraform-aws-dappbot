"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var uuidv4 = require('uuid/v4');
var _a = require('../env'), dnsRoot = _a.dnsRoot, dapphubDns = _a.dapphubDns;
var s3BucketPrefix = "exim-dappbot-";
function createS3BucketName() {
    return s3BucketPrefix.concat(uuidv4());
}
exports.createS3BucketName = createS3BucketName;
function hubUrlFromDappName(dappName) {
    return dapphubDns + "/" + dappName;
}
exports.hubUrlFromDappName = hubUrlFromDappName;
function enterpriseDnsNameFromDappName(dappName) {
    return dappName.concat(dnsRoot);
}
exports.enterpriseDnsNameFromDappName = enterpriseDnsNameFromDappName;
function pipelineNameFromDappName(dappName) {
    return "" + dappName + dnsRoot;
}
exports.pipelineNameFromDappName = pipelineNameFromDappName;
function srcPipelineNameFromDappName(dappName) {
    var prefix = 'src-';
    return prefix.concat(pipelineNameFromDappName(dappName));
}
exports.srcPipelineNameFromDappName = srcPipelineNameFromDappName;
exports.default = {
    newS3BucketName: createS3BucketName,
    hubUrlFromDappName: hubUrlFromDappName,
    enterpriseDnsNameFromDappName: enterpriseDnsNameFromDappName,
    pipelineNameFromDappName: pipelineNameFromDappName,
    srcPipelineNameFromDappName: srcPipelineNameFromDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmFtZXMuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvbmFtZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDNUIsSUFBQSxzQkFBMkMsRUFBekMsb0JBQU8sRUFBRSwwQkFBZ0MsQ0FBQztBQUVsRCxJQUFNLGNBQWMsR0FBRyxlQUFlLENBQUM7QUFFdkMsU0FBZ0Isa0JBQWtCO0lBQzlCLE9BQU8sY0FBYyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0FBQzNDLENBQUM7QUFGRCxnREFFQztBQUVELFNBQWdCLGtCQUFrQixDQUFDLFFBQWU7SUFDOUMsT0FBVSxVQUFVLFNBQUksUUFBVSxDQUFDO0FBQ3ZDLENBQUM7QUFGRCxnREFFQztBQUVELFNBQWdCLDZCQUE2QixDQUFDLFFBQWU7SUFDekQsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BDLENBQUM7QUFGRCxzRUFFQztBQUVELFNBQWdCLHdCQUF3QixDQUFDLFFBQWU7SUFDcEQsT0FBTyxLQUFHLFFBQVEsR0FBRyxPQUFTLENBQUE7QUFDbEMsQ0FBQztBQUZELDREQUVDO0FBRUQsU0FBZ0IsMkJBQTJCLENBQUMsUUFBZTtJQUN2RCxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFDcEIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQztBQUhELGtFQUdDO0FBRUQsa0JBQWU7SUFDWCxlQUFlLEVBQUcsa0JBQWtCO0lBQ3BDLGtCQUFrQixFQUFHLGtCQUFrQjtJQUN2Qyw2QkFBNkIsRUFBRyw2QkFBNkI7SUFDN0Qsd0JBQXdCLEVBQUcsd0JBQXdCO0lBQ25ELDJCQUEyQixFQUFHLDJCQUEyQjtDQUM1RCxDQUFBIn0=