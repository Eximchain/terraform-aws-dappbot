"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var uuidv4 = require('uuid/v4');
var dnsRoot = require('../env').dnsRoot;
var s3BucketPrefix = "exim-abi-clerk-";
function createS3BucketName() {
    return s3BucketPrefix.concat(uuidv4());
}
exports.createS3BucketName = createS3BucketName;
function dnsNameFromDappName(dappName) {
    return dappName.concat(dnsRoot);
}
exports.dnsNameFromDappName = dnsNameFromDappName;
function pipelineNameFromDappName(dappName) {
    return "" + dappName + dnsRoot;
}
exports.pipelineNameFromDappName = pipelineNameFromDappName;
function srcPipelineNameFromDappName(dappName) {
    var prefix = 'src-';
    return prefix.concat(pipelineNameFromDappName(dappName));
}
exports.srcPipelineNameFromDappName = srcPipelineNameFromDappName;
exports.default = {
    newS3BucketName: createS3BucketName,
    dnsNameFromDappName: dnsNameFromDappName,
    pipelineNameFromDappName: pipelineNameFromDappName,
    srcPipelineNameFromDappName: srcPipelineNameFromDappName
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmFtZXMuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvbmFtZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDMUIsSUFBQSxtQ0FBTyxDQUF1QjtBQUV0QyxJQUFNLGNBQWMsR0FBRyxpQkFBaUIsQ0FBQztBQUV6QyxTQUFnQixrQkFBa0I7SUFDOUIsT0FBTyxjQUFjLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7QUFDM0MsQ0FBQztBQUZELGdEQUVDO0FBRUQsU0FBZ0IsbUJBQW1CLENBQUMsUUFBZTtJQUMvQyxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEMsQ0FBQztBQUZELGtEQUVDO0FBRUQsU0FBZ0Isd0JBQXdCLENBQUMsUUFBZTtJQUNwRCxPQUFPLEtBQUcsUUFBUSxHQUFHLE9BQVMsQ0FBQTtBQUNsQyxDQUFDO0FBRkQsNERBRUM7QUFFRCxTQUFnQiwyQkFBMkIsQ0FBQyxRQUFlO0lBQ3ZELElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQztJQUNwQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDO0FBSEQsa0VBR0M7QUFFRCxrQkFBZTtJQUNYLGVBQWUsRUFBRyxrQkFBa0I7SUFDcEMsbUJBQW1CLEVBQUcsbUJBQW1CO0lBQ3pDLHdCQUF3QixFQUFHLHdCQUF3QjtJQUNuRCwyQkFBMkIsRUFBRywyQkFBMkI7Q0FDNUQsQ0FBQSJ9