"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var names_1 = require("./names");
var common_1 = require("../common");
var env_1 = require("../env");
var errors_1 = require("../errors");
var ddb = new env_1.AWS.DynamoDB({ apiVersion: '2012-08-10' });
function serializeDdbKey(dappName) {
    var keyItem = {
        'DappName': { S: dappName }
    };
    return keyItem;
}
function serializeDdbItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl, bucketName, pipelineName, dnsName, state, cloudfrontDistroId, cloudfrontDns) {
    var now = new Date().toISOString();
    // Required Params
    var item = {
        'DappName': { S: dappName },
        'OwnerEmail': { S: ownerEmail },
        'CreationTime': { S: now },
        'UpdatedAt': { S: now },
        'Abi': { S: abi },
        'ContractAddr': { S: contractAddr },
        'Web3URL': { S: web3Url },
        'GuardianURL': { S: guardianUrl },
        'S3BucketName': { S: bucketName },
        'PipelineName': { S: pipelineName },
        'DnsName': { S: dnsName },
        'State': { S: state }
    };
    // Optional Params
    if (cloudfrontDistroId) {
        item.CloudfrontDistributionId = { S: cloudfrontDistroId };
    }
    if (cloudfrontDns) {
        item.CloudfrontDnsName = { S: cloudfrontDns };
    }
    return item;
}
function dbItemToApiRepresentation(dbItem) {
    if (!dbItem) {
        return {};
    }
    validateDbItemForOutput(dbItem);
    var dappName = dbItem.DappName.S;
    var ownerEmail = dbItem.OwnerEmail.S;
    var creationTime = dbItem.CreationTime.S;
    var updatedAt = dbItem.UpdatedAt.S;
    var dnsName = dbItem.DnsName.S;
    var abi = dbItem.Abi.S;
    var contractAddr = dbItem.ContractAddr.S;
    var web3Url = dbItem.Web3URL.S;
    var guardianUrl = dbItem.GuardianURL.S;
    var state = dbItem.State.S;
    var apiItem = {
        "DappName": dappName,
        "OwnerEmail": ownerEmail,
        "CreationTime": creationTime,
        "UpdatedAt": updatedAt,
        "DnsName": dnsName,
        "Abi": abi,
        "ContractAddr": contractAddr,
        "Web3URL": web3Url,
        "GuardianURL": guardianUrl,
        "State": state
    };
    return apiItem;
}
function promisePutCreatingDappItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl) {
    var maxRetries = 5;
    var bucketName = names_1.createS3BucketName();
    var pipelineName = names_1.pipelineNameFromDappName(dappName);
    var dnsName = names_1.dnsNameFromDappName(dappName);
    var state = 'CREATING';
    var cloudfrontDistroId = null;
    var cloudfrontDns = null;
    var putItemParams = {
        TableName: env_1.tableName,
        Item: serializeDdbItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl, bucketName, pipelineName, dnsName, state, cloudfrontDistroId, cloudfrontDns)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promisePutRawDappItem(item) {
    var maxRetries = 5;
    var putItemParams = {
        TableName: env_1.tableName,
        Item: item
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promiseSetDappStateBuildingWithUpdate(dappItem, updateAttrs) {
    return __awaiter(this, void 0, void 0, function () {
        var now;
        return __generator(this, function (_a) {
            now = new Date().toISOString();
            dappItem.State.S = 'BUILDING_DAPP';
            dappItem.UpdatedAt.S = now;
            if (updateAttrs.Abi) {
                dappItem.Abi.S = updateAttrs.Abi;
            }
            if (updateAttrs.ContractAddr) {
                dappItem.ContractAddr.S = updateAttrs.ContractAddr;
            }
            if (updateAttrs.Web3URL) {
                dappItem.Web3URL.S = updateAttrs.Web3URL;
            }
            if (updateAttrs.GuardianURL) {
                dappItem.GuardianURL.S = updateAttrs.GuardianURL;
            }
            return [2 /*return*/, promisePutRawDappItem(dappItem)];
        });
    });
}
function promiseSetDappStateDeleting(dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var now;
        return __generator(this, function (_a) {
            now = new Date().toISOString();
            dappItem.State.S = 'DELETING';
            dappItem.UpdatedAt.S = now;
            return [2 /*return*/, promisePutRawDappItem(dappItem)];
        });
    });
}
function promiseGetDappItem(dappName) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.getItem(getItemParams).promise(); }, maxRetries);
}
function promiseGetItemsByOwner(ownerEmail) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        IndexName: 'OwnerEmailIndex',
        ExpressionAttributeNames: {
            "#OE": "OwnerEmail"
        },
        ExpressionAttributeValues: {
            ":e": {
                S: ownerEmail
            }
        },
        KeyConditionExpression: "#OE = :e",
        Select: 'ALL_PROJECTED_ATTRIBUTES'
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.query(getItemParams).promise(); }, maxRetries);
}
function validateDbItemForOutput(dbItem) {
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('DappName'), "dbItem: required attribute 'DappName' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('OwnerEmail'), "dbItem: required attribute 'OwnerEmail' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('CreationTime'), "dbItem: required attribute 'CreationTime' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('UpdatedAt'), "dbItem: required attribute 'UpdatedAt' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('DnsName'), "dbItem: required attribute 'DnsName' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('Abi'), "dbItem: required attribute 'Abi' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('ContractAddr'), "dbItem: required attribute 'ContractAddr' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('Web3URL'), "dbItem: required attribute 'Web3URL' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('GuardianURL'), "dbItem: required attribute 'GuardianURL' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('State'), "dbItem: required attribute 'State' not found");
    errors_1.assertDappItemValid(dbItem.DappName.hasOwnProperty('S'), "dbItem: required attribute 'DappName' has wrong shape");
    errors_1.assertDappItemValid(dbItem.OwnerEmail.hasOwnProperty('S'), "dbItem: required attribute 'OwnerEmail' has wrong shape");
    errors_1.assertDappItemValid(dbItem.CreationTime.hasOwnProperty('S'), "dbItem: required attribute 'CreationTime' has wrong shape");
    errors_1.assertDappItemValid(dbItem.UpdatedAt.hasOwnProperty('S'), "dbItem: required attribute 'UpdatedAt' has wrong shape");
    errors_1.assertDappItemValid(dbItem.DnsName.hasOwnProperty('S'), "dbItem: required attribute 'DnsName' has wrong shape");
    errors_1.assertDappItemValid(dbItem.Abi.hasOwnProperty('S'), "dbItem: required attribute 'Abi' has wrong shape");
    errors_1.assertDappItemValid(dbItem.ContractAddr.hasOwnProperty('S'), "dbItem: required attribute 'ContractAddr' has wrong shape");
    errors_1.assertDappItemValid(dbItem.Web3URL.hasOwnProperty('S'), "dbItem: required attribute 'Web3URL' has wrong shape");
    errors_1.assertDappItemValid(dbItem.GuardianURL.hasOwnProperty('S'), "dbItem: required attribute 'GuardianURL' has wrong shape");
    errors_1.assertDappItemValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'State' has wrong shape");
}
exports.default = {
    putItem: promisePutCreatingDappItem,
    putRawItem: promisePutRawDappItem,
    getItem: promiseGetDappItem,
    getByOwner: promiseGetItemsByOwner,
    setStateBuildingWithUpdate: promiseSetDappStateBuildingWithUpdate,
    setStateDeleting: promiseSetDappStateDeleting,
    toApiRepresentation: dbItemToApiRepresentation
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1vREIuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvZHluYW1vREIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLGlDQUE0RjtBQUM1RixvQ0FBd0U7QUFDeEUsOEJBQXdDO0FBQ3hDLG9DQUFnRDtBQUNoRCxJQUFNLEdBQUcsR0FBRyxJQUFJLFNBQUcsQ0FBQyxRQUFRLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUV6RCxTQUFTLGVBQWUsQ0FBQyxRQUFlO0lBQ3BDLElBQUksT0FBTyxHQUFHO1FBQ1YsVUFBVSxFQUFFLEVBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBQztLQUM1QixDQUFDO0lBQ0YsT0FBTyxPQUFPLENBQUM7QUFDbkIsQ0FBQztBQUVELFNBQVMsZ0JBQWdCLENBQ3JCLFFBQWUsRUFBRSxVQUFpQixFQUFFLEdBQVUsRUFBRSxZQUFtQixFQUFFLE9BQWMsRUFDbkYsV0FBa0IsRUFBRSxVQUFpQixFQUFFLFlBQW1CLEVBQUUsT0FBYyxFQUFFLEtBQVksRUFDeEYsa0JBQWdDLEVBQUUsYUFBMkI7SUFDN0QsSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNuQyxrQkFBa0I7SUFDbEIsSUFBSSxJQUFJLEdBQTRCO1FBQ2hDLFVBQVUsRUFBRyxFQUFDLENBQUMsRUFBRSxRQUFRLEVBQUM7UUFDMUIsWUFBWSxFQUFHLEVBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBQztRQUM5QixjQUFjLEVBQUcsRUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFDO1FBQ3pCLFdBQVcsRUFBRyxFQUFDLENBQUMsRUFBRSxHQUFHLEVBQUM7UUFDdEIsS0FBSyxFQUFHLEVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBQztRQUNoQixjQUFjLEVBQUcsRUFBQyxDQUFDLEVBQUUsWUFBWSxFQUFDO1FBQ2xDLFNBQVMsRUFBRyxFQUFDLENBQUMsRUFBRSxPQUFPLEVBQUM7UUFDeEIsYUFBYSxFQUFHLEVBQUMsQ0FBQyxFQUFFLFdBQVcsRUFBQztRQUNoQyxjQUFjLEVBQUcsRUFBQyxDQUFDLEVBQUUsVUFBVSxFQUFDO1FBQ2hDLGNBQWMsRUFBRyxFQUFDLENBQUMsRUFBRSxZQUFZLEVBQUM7UUFDbEMsU0FBUyxFQUFHLEVBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBQztRQUN4QixPQUFPLEVBQUcsRUFBQyxDQUFDLEVBQUUsS0FBSyxFQUFDO0tBQ3ZCLENBQUM7SUFFRixrQkFBa0I7SUFDbEIsSUFBSSxrQkFBa0IsRUFBRTtRQUNwQixJQUFJLENBQUMsd0JBQXdCLEdBQUcsRUFBRSxDQUFDLEVBQUcsa0JBQWtCLEVBQUUsQ0FBQztLQUM5RDtJQUNELElBQUksYUFBYSxFQUFFO1FBQ2YsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxFQUFFLGFBQWEsRUFBRSxDQUFDO0tBQ2pEO0lBQ0QsT0FBTyxJQUFJLENBQUM7QUFDaEIsQ0FBQztBQUVELFNBQVMseUJBQXlCLENBQUMsTUFBK0I7SUFDOUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNULE9BQU8sRUFBRSxDQUFDO0tBQ2I7SUFDRCx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUVoQyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNqQyxJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUNyQyxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QyxJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUNuQyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQixJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2QixJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQixJQUFJLFdBQVcsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUN2QyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUUzQixJQUFJLE9BQU8sR0FBRztRQUNWLFVBQVUsRUFBRSxRQUFRO1FBQ3BCLFlBQVksRUFBRSxVQUFVO1FBQ3hCLGNBQWMsRUFBRSxZQUFZO1FBQzVCLFdBQVcsRUFBRSxTQUFTO1FBQ3RCLFNBQVMsRUFBRSxPQUFPO1FBQ2xCLEtBQUssRUFBRSxHQUFHO1FBQ1YsY0FBYyxFQUFFLFlBQVk7UUFDNUIsU0FBUyxFQUFFLE9BQU87UUFDbEIsYUFBYSxFQUFFLFdBQVc7UUFDMUIsT0FBTyxFQUFFLEtBQUs7S0FDakIsQ0FBQztJQUNGLE9BQU8sT0FBTyxDQUFDO0FBQ25CLENBQUM7QUFFRCxTQUFTLDBCQUEwQixDQUFDLFFBQWUsRUFBRSxVQUFpQixFQUFFLEdBQVUsRUFBRSxZQUFtQixFQUFFLE9BQWMsRUFBRSxXQUFrQjtJQUN2SSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFFbkIsSUFBSSxVQUFVLEdBQUcsMEJBQWtCLEVBQUUsQ0FBQztJQUN0QyxJQUFJLFlBQVksR0FBRyxnQ0FBd0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxJQUFJLE9BQU8sR0FBRywyQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1QyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUM7SUFDdkIsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLENBQUM7SUFDOUIsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDO0lBRXpCLElBQUksYUFBYSxHQUFHO1FBQ2hCLFNBQVMsRUFBRSxlQUFTO1FBQ3BCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsa0JBQWtCLEVBQUUsYUFBYSxDQUFDO0tBQ3JLLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHFCQUFxQixDQUFDLElBQTZCO0lBQ3hELElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGFBQWEsR0FBRztRQUNoQixTQUFTLEVBQUUsZUFBUztRQUNwQixJQUFJLEVBQUUsSUFBSTtLQUNiLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFTRCxTQUFlLHFDQUFxQyxDQUFDLFFBQWlDLEVBQUUsV0FBMkI7Ozs7WUFDM0csR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsZUFBZSxDQUFDO1lBQ25DLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUUzQixJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pCLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUM7YUFDcEM7WUFDRCxJQUFJLFdBQVcsQ0FBQyxZQUFZLEVBQUU7Z0JBQzFCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxZQUFZLENBQUM7YUFDdEQ7WUFDRCxJQUFJLFdBQVcsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3JCLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUM7YUFDNUM7WUFDRCxJQUFJLFdBQVcsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3pCLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUM7YUFDcEQ7WUFFRCxzQkFBTyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsRUFBQzs7O0NBQzFDO0FBRUQsU0FBZSwyQkFBMkIsQ0FBQyxRQUFpQzs7OztZQUNwRSxHQUFHLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7WUFDOUIsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1lBQzNCLHNCQUFPLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxFQUFDOzs7Q0FDMUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLFFBQWU7SUFDdkMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQUksYUFBYSxHQUFHO1FBQ2hCLFNBQVMsRUFBRSxlQUFTO1FBQ3BCLEdBQUcsRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDO0tBQ2pDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFwQyxDQUFvQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3hGLENBQUM7QUFFRCxTQUFTLHNCQUFzQixDQUFDLFVBQWlCO0lBQzdDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGFBQWEsR0FBRztRQUNoQixTQUFTLEVBQUUsZUFBUztRQUNwQixTQUFTLEVBQUUsaUJBQWlCO1FBQzVCLHdCQUF3QixFQUFFO1lBQ3RCLEtBQUssRUFBRSxZQUFZO1NBQ3RCO1FBQ0QseUJBQXlCLEVBQUU7WUFDdkIsSUFBSSxFQUFFO2dCQUNGLENBQUMsRUFBRSxVQUFVO2FBQ2hCO1NBQ0o7UUFDRCxzQkFBc0IsRUFBRSxVQUFVO1FBQ2xDLE1BQU0sRUFBRSwwQkFBMEI7S0FDckMsQ0FBQztJQUVGLE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxDLENBQWtDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEYsQ0FBQztBQUVELFNBQVMsdUJBQXVCLENBQUMsTUFBK0I7SUFDNUQsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRSxpREFBaUQsQ0FBQyxDQUFDO0lBQzFHLDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsbURBQW1ELENBQUMsQ0FBQztJQUM5Ryw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxFQUFFLHFEQUFxRCxDQUFDLENBQUM7SUFDbEgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRSxrREFBa0QsQ0FBQyxDQUFDO0lBQzVHLDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUUsZ0RBQWdELENBQUMsQ0FBQztJQUN4Ryw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLDRDQUE0QyxDQUFDLENBQUM7SUFDaEcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxxREFBcUQsQ0FBQyxDQUFDO0lBQ2xILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUUsZ0RBQWdELENBQUMsQ0FBQztJQUN4Ryw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxFQUFFLG9EQUFvRCxDQUFDLENBQUM7SUFDaEgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRSw4Q0FBOEMsQ0FBQyxDQUFDO0lBRXBHLDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHVEQUF1RCxDQUFDLENBQUM7SUFDbEgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUseURBQXlELENBQUMsQ0FBQztJQUN0SCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSwyREFBMkQsQ0FBQyxDQUFDO0lBQzFILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLHdEQUF3RCxDQUFDLENBQUM7SUFDcEgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsc0RBQXNELENBQUMsQ0FBQztJQUNoSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxrREFBa0QsQ0FBQyxDQUFDO0lBQ3hHLDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDJEQUEyRCxDQUFDLENBQUM7SUFDMUgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsc0RBQXNELENBQUMsQ0FBQztJQUNoSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSwwREFBMEQsQ0FBQyxDQUFDO0lBQ3hILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLG9EQUFvRCxDQUFDLENBQUM7QUFDaEgsQ0FBQztBQUVELGtCQUFlO0lBQ1gsT0FBTyxFQUFHLDBCQUEwQjtJQUNwQyxVQUFVLEVBQUcscUJBQXFCO0lBQ2xDLE9BQU8sRUFBRyxrQkFBa0I7SUFDNUIsVUFBVSxFQUFHLHNCQUFzQjtJQUNuQywwQkFBMEIsRUFBRyxxQ0FBcUM7SUFDbEUsZ0JBQWdCLEVBQUcsMkJBQTJCO0lBQzlDLG1CQUFtQixFQUFHLHlCQUF5QjtDQUNsRCxDQUFDIn0=