"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var names_1 = require("./names");
var common_1 = require("../common");
var env_1 = require("../env");
var errors_1 = require("../errors");
var ddb = new env_1.AWS.DynamoDB({ apiVersion: '2012-08-10' });
function serializeDdbKey(dappName) {
    var keyItem = {
        'DappName': { S: dappName }
    };
    return keyItem;
}
function serializeDdbItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl, bucketName, pipelineName, srcPipelineName, dnsName, state, dappTier, cloudfrontDistroId, cloudfrontDns, targetRepoName, targetRepoOwner) {
    var now = new Date().toISOString();
    // Required Params
    var item = {
        'DappName': { S: dappName },
        'OwnerEmail': { S: ownerEmail },
        'CreationTime': { S: now },
        'UpdatedAt': { S: now },
        'Abi': { S: abi },
        'ContractAddr': { S: contractAddr },
        'Web3URL': { S: web3Url },
        'GuardianURL': { S: guardianUrl },
        'S3BucketName': { S: bucketName },
        'PipelineName': { S: pipelineName },
        'SrcPipelineName': { S: srcPipelineName },
        'DnsName': { S: dnsName },
        'State': { S: state },
        'Tier': { S: dappTier }
    };
    // Optional Params
    if (cloudfrontDistroId) {
        item.CloudfrontDistributionId = { S: cloudfrontDistroId };
    }
    if (cloudfrontDns) {
        item.CloudfrontDnsName = { S: cloudfrontDns };
    }
    if (targetRepoName) {
        item.TargetRepoName = { S: targetRepoName };
    }
    if (targetRepoOwner) {
        item.TargetRepoOwner = { S: targetRepoOwner };
    }
    return item;
}
function dbItemToApiRepresentation(dbItem) {
    if (!dbItem) {
        return {};
    }
    validateDbItemForOutput(dbItem);
    var dappName = dbItem.DappName.S;
    var ownerEmail = dbItem.OwnerEmail.S;
    var creationTime = dbItem.CreationTime.S;
    var updatedAt = dbItem.UpdatedAt.S;
    var dnsName = dbItem.DnsName.S;
    var abi = dbItem.Abi.S;
    var contractAddr = dbItem.ContractAddr.S;
    var web3Url = dbItem.Web3URL.S;
    var guardianUrl = dbItem.GuardianURL.S;
    var state = dbItem.State.S;
    var tier = dbItem.Tier.S;
    var apiItem = {
        "DappName": dappName,
        "OwnerEmail": ownerEmail,
        "CreationTime": creationTime,
        "UpdatedAt": updatedAt,
        "DnsName": dnsName,
        "Abi": abi,
        "ContractAddr": contractAddr,
        "Web3URL": web3Url,
        "GuardianURL": guardianUrl,
        "State": state,
        "Tier": tier
    };
    return apiItem;
}
function promisePutCreatingDappItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl, dappTier, targetRepoName, targetRepoOwner) {
    var maxRetries = 5;
    var bucketName = names_1.createS3BucketName();
    var pipelineName = names_1.pipelineNameFromDappName(dappName);
    var srcPipelineName = names_1.srcPipelineNameFromDappName(dappName);
    var dnsName = names_1.dnsNameFromDappName(dappName);
    var state = 'CREATING';
    var cloudfrontDistroId = null;
    var cloudfrontDns = null;
    var putItemParams = {
        TableName: env_1.tableName,
        Item: serializeDdbItem(dappName, ownerEmail, abi, contractAddr, web3Url, guardianUrl, bucketName, pipelineName, srcPipelineName, dnsName, state, dappTier, cloudfrontDistroId, cloudfrontDns, targetRepoName, targetRepoOwner)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promisePutRawDappItem(item) {
    var maxRetries = 5;
    var putItemParams = {
        TableName: env_1.tableName,
        Item: item
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.putItem(putItemParams).promise(); }, maxRetries);
}
function promiseSetDappStateBuildingWithUpdate(dappItem, updateAttrs) {
    return __awaiter(this, void 0, void 0, function () {
        var now;
        return __generator(this, function (_a) {
            now = new Date().toISOString();
            dappItem.State.S = 'BUILDING_DAPP';
            dappItem.UpdatedAt.S = now;
            if (updateAttrs.Abi) {
                dappItem.Abi.S = updateAttrs.Abi;
            }
            if (updateAttrs.ContractAddr) {
                dappItem.ContractAddr.S = updateAttrs.ContractAddr;
            }
            if (updateAttrs.Web3URL) {
                dappItem.Web3URL.S = updateAttrs.Web3URL;
            }
            if (updateAttrs.GuardianURL) {
                dappItem.GuardianURL.S = updateAttrs.GuardianURL;
            }
            return [2 /*return*/, promisePutRawDappItem(dappItem)];
        });
    });
}
function promiseSetDappStateDeleting(dappItem) {
    return __awaiter(this, void 0, void 0, function () {
        var now;
        return __generator(this, function (_a) {
            now = new Date().toISOString();
            dappItem.State.S = 'DELETING';
            dappItem.UpdatedAt.S = now;
            return [2 /*return*/, promisePutRawDappItem(dappItem)];
        });
    });
}
function promiseGetDappItem(dappName) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        Key: serializeDdbKey(dappName)
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.getItem(getItemParams).promise(); }, maxRetries);
}
function promiseGetItemsByOwner(ownerEmail) {
    var maxRetries = 5;
    var getItemParams = {
        TableName: env_1.tableName,
        IndexName: 'OwnerEmailIndex',
        ExpressionAttributeNames: {
            "#OE": "OwnerEmail"
        },
        ExpressionAttributeValues: {
            ":e": {
                S: ownerEmail
            }
        },
        KeyConditionExpression: "#OE = :e",
        Select: 'ALL_PROJECTED_ATTRIBUTES'
    };
    return common_1.addAwsPromiseRetries(function () { return ddb.query(getItemParams).promise(); }, maxRetries);
}
function getItemsByOwnerAndTier(ownerEmail, tier) {
    return __awaiter(this, void 0, void 0, function () {
        var getByOwnerResult, allDappItems, dappItemsForTier;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetItemsByOwner(ownerEmail)];
                case 1:
                    getByOwnerResult = _a.sent();
                    allDappItems = getByOwnerResult.Items;
                    console.log("Number of dapps owned by " + ownerEmail + ": ", allDappItems.length);
                    dappItemsForTier = allDappItems.filter(function (item) { return item.Tier.S === tier; });
                    console.log("Number of dapps owned by " + ownerEmail + " for tier " + tier + ": ", dappItemsForTier.length);
                    return [2 /*return*/, dappItemsForTier];
            }
        });
    });
}
function validateDbItemForOutput(dbItem) {
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('DappName'), "dbItem: required attribute 'DappName' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('OwnerEmail'), "dbItem: required attribute 'OwnerEmail' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('CreationTime'), "dbItem: required attribute 'CreationTime' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('UpdatedAt'), "dbItem: required attribute 'UpdatedAt' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('DnsName'), "dbItem: required attribute 'DnsName' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('Abi'), "dbItem: required attribute 'Abi' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('ContractAddr'), "dbItem: required attribute 'ContractAddr' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('Web3URL'), "dbItem: required attribute 'Web3URL' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('GuardianURL'), "dbItem: required attribute 'GuardianURL' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('State'), "dbItem: required attribute 'State' not found");
    errors_1.assertDappItemValid(dbItem.hasOwnProperty('Tier'), "dbItem: required attribute 'Tier' not found");
    errors_1.assertDappItemValid(dbItem.DappName.hasOwnProperty('S'), "dbItem: required attribute 'DappName' has wrong shape");
    errors_1.assertDappItemValid(dbItem.OwnerEmail.hasOwnProperty('S'), "dbItem: required attribute 'OwnerEmail' has wrong shape");
    errors_1.assertDappItemValid(dbItem.CreationTime.hasOwnProperty('S'), "dbItem: required attribute 'CreationTime' has wrong shape");
    errors_1.assertDappItemValid(dbItem.UpdatedAt.hasOwnProperty('S'), "dbItem: required attribute 'UpdatedAt' has wrong shape");
    errors_1.assertDappItemValid(dbItem.DnsName.hasOwnProperty('S'), "dbItem: required attribute 'DnsName' has wrong shape");
    errors_1.assertDappItemValid(dbItem.Abi.hasOwnProperty('S'), "dbItem: required attribute 'Abi' has wrong shape");
    errors_1.assertDappItemValid(dbItem.ContractAddr.hasOwnProperty('S'), "dbItem: required attribute 'ContractAddr' has wrong shape");
    errors_1.assertDappItemValid(dbItem.Web3URL.hasOwnProperty('S'), "dbItem: required attribute 'Web3URL' has wrong shape");
    errors_1.assertDappItemValid(dbItem.GuardianURL.hasOwnProperty('S'), "dbItem: required attribute 'GuardianURL' has wrong shape");
    errors_1.assertDappItemValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'State' has wrong shape");
    errors_1.assertDappItemValid(dbItem.State.hasOwnProperty('S'), "dbItem: required attribute 'Tier' has wrong shape");
}
exports.default = {
    putItem: promisePutCreatingDappItem,
    putRawItem: promisePutRawDappItem,
    getItem: promiseGetDappItem,
    getByOwner: promiseGetItemsByOwner,
    getByOwnerAndTier: getItemsByOwnerAndTier,
    setStateBuildingWithUpdate: promiseSetDappStateBuildingWithUpdate,
    setStateDeleting: promiseSetDappStateDeleting,
    toApiRepresentation: dbItemToApiRepresentation
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1vREIuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvZHluYW1vREIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLGlDQUF5SDtBQUN6SCxvQ0FBbUY7QUFDbkYsOEJBQXdDO0FBQ3hDLG9DQUFnRDtBQUNoRCxJQUFNLEdBQUcsR0FBRyxJQUFJLFNBQUcsQ0FBQyxRQUFRLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUV6RCxTQUFTLGVBQWUsQ0FBQyxRQUFlO0lBQ3BDLElBQUksT0FBTyxHQUFHO1FBQ1YsVUFBVSxFQUFFLEVBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBQztLQUM1QixDQUFDO0lBQ0YsT0FBTyxPQUFPLENBQUM7QUFDbkIsQ0FBQztBQUVELFNBQVMsZ0JBQWdCLENBQ3JCLFFBQWUsRUFBRSxVQUFpQixFQUFFLEdBQVUsRUFBRSxZQUFtQixFQUFFLE9BQWMsRUFDbkYsV0FBa0IsRUFBRSxVQUFpQixFQUFFLFlBQW1CLEVBQUUsZUFBc0IsRUFBRSxPQUFjLEVBQUUsS0FBWSxFQUNoSCxRQUFlLEVBQUUsa0JBQWdDLEVBQUUsYUFBMkIsRUFBRSxjQUE0QixFQUFFLGVBQTZCO0lBQzNJLElBQUksR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDbkMsa0JBQWtCO0lBQ2xCLElBQUksSUFBSSxHQUE0QjtRQUNoQyxVQUFVLEVBQUcsRUFBQyxDQUFDLEVBQUUsUUFBUSxFQUFDO1FBQzFCLFlBQVksRUFBRyxFQUFDLENBQUMsRUFBRSxVQUFVLEVBQUM7UUFDOUIsY0FBYyxFQUFHLEVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBQztRQUN6QixXQUFXLEVBQUcsRUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFDO1FBQ3RCLEtBQUssRUFBRyxFQUFDLENBQUMsRUFBRSxHQUFHLEVBQUM7UUFDaEIsY0FBYyxFQUFHLEVBQUMsQ0FBQyxFQUFFLFlBQVksRUFBQztRQUNsQyxTQUFTLEVBQUcsRUFBQyxDQUFDLEVBQUUsT0FBTyxFQUFDO1FBQ3hCLGFBQWEsRUFBRyxFQUFDLENBQUMsRUFBRSxXQUFXLEVBQUM7UUFDaEMsY0FBYyxFQUFHLEVBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBQztRQUNoQyxjQUFjLEVBQUcsRUFBQyxDQUFDLEVBQUUsWUFBWSxFQUFDO1FBQ2xDLGlCQUFpQixFQUFHLEVBQUMsQ0FBQyxFQUFFLGVBQWUsRUFBQztRQUN4QyxTQUFTLEVBQUcsRUFBQyxDQUFDLEVBQUUsT0FBTyxFQUFDO1FBQ3hCLE9BQU8sRUFBRyxFQUFDLENBQUMsRUFBRSxLQUFLLEVBQUM7UUFDcEIsTUFBTSxFQUFHLEVBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBQztLQUN6QixDQUFDO0lBRUYsa0JBQWtCO0lBQ2xCLElBQUksa0JBQWtCLEVBQUU7UUFDcEIsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEVBQUUsQ0FBQyxFQUFHLGtCQUFrQixFQUFFLENBQUM7S0FDOUQ7SUFDRCxJQUFJLGFBQWEsRUFBRTtRQUNmLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUMsRUFBRSxhQUFhLEVBQUUsQ0FBQztLQUNqRDtJQUNELElBQUksY0FBYyxFQUFFO1FBQ2hCLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLEVBQUUsY0FBYyxFQUFFLENBQUM7S0FDL0M7SUFDRCxJQUFJLGVBQWUsRUFBRTtRQUNqQixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQyxFQUFFLGVBQWUsRUFBRSxDQUFDO0tBQ2pEO0lBQ0QsT0FBTyxJQUFJLENBQUM7QUFDaEIsQ0FBQztBQUVELFNBQVMseUJBQXlCLENBQUMsTUFBK0I7SUFDOUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNULE9BQU8sRUFBRSxDQUFDO0tBQ2I7SUFDRCx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUVoQyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNqQyxJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUNyQyxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QyxJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUNuQyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQixJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2QixJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QyxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQixJQUFJLFdBQVcsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUN2QyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUMzQixJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUV6QixJQUFJLE9BQU8sR0FBRztRQUNWLFVBQVUsRUFBRSxRQUFRO1FBQ3BCLFlBQVksRUFBRSxVQUFVO1FBQ3hCLGNBQWMsRUFBRSxZQUFZO1FBQzVCLFdBQVcsRUFBRSxTQUFTO1FBQ3RCLFNBQVMsRUFBRSxPQUFPO1FBQ2xCLEtBQUssRUFBRSxHQUFHO1FBQ1YsY0FBYyxFQUFFLFlBQVk7UUFDNUIsU0FBUyxFQUFFLE9BQU87UUFDbEIsYUFBYSxFQUFFLFdBQVc7UUFDMUIsT0FBTyxFQUFFLEtBQUs7UUFDZCxNQUFNLEVBQUUsSUFBSTtLQUNmLENBQUM7SUFDRixPQUFPLE9BQU8sQ0FBQztBQUNuQixDQUFDO0FBRUQsU0FBUywwQkFBMEIsQ0FBQyxRQUFlLEVBQUUsVUFBaUIsRUFBRSxHQUFVLEVBQUUsWUFBbUIsRUFBRSxPQUFjLEVBQUUsV0FBa0IsRUFBRSxRQUFlLEVBQUUsY0FBNEIsRUFBRSxlQUE2QjtJQUNyTixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFFbkIsSUFBSSxVQUFVLEdBQUcsMEJBQWtCLEVBQUUsQ0FBQztJQUN0QyxJQUFJLFlBQVksR0FBRyxnQ0FBd0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxJQUFJLGVBQWUsR0FBRyxtQ0FBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1RCxJQUFJLE9BQU8sR0FBRywyQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1QyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUM7SUFDdkIsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLENBQUM7SUFDOUIsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDO0lBRXpCLElBQUksYUFBYSxHQUFHO1FBQ2hCLFNBQVMsRUFBRSxlQUFTO1FBQ3BCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLGVBQWUsQ0FBQztLQUNqTyxDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxxQkFBcUIsQ0FBQyxJQUE2QjtJQUN4RCxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLGVBQVM7UUFDcEIsSUFBSSxFQUFFLElBQUk7S0FDYixDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBU0QsU0FBZSxxQ0FBcUMsQ0FBQyxRQUFpQyxFQUFFLFdBQTJCOzs7O1lBQzNHLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ25DLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLGVBQWUsQ0FBQztZQUNuQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFFM0IsSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFO2dCQUNqQixRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDO2FBQ3BDO1lBQ0QsSUFBSSxXQUFXLENBQUMsWUFBWSxFQUFFO2dCQUMxQixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDO2FBQ3REO1lBQ0QsSUFBSSxXQUFXLENBQUMsT0FBTyxFQUFFO2dCQUNyQixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDO2FBQzVDO1lBQ0QsSUFBSSxXQUFXLENBQUMsV0FBVyxFQUFFO2dCQUN6QixRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDO2FBQ3BEO1lBRUQsc0JBQU8scUJBQXFCLENBQUMsUUFBUSxDQUFDLEVBQUM7OztDQUMxQztBQUVELFNBQWUsMkJBQTJCLENBQUMsUUFBaUM7Ozs7WUFDcEUsR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO1lBQzlCLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUMzQixzQkFBTyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsRUFBQzs7O0NBQzFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxRQUFlO0lBQ3ZDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFJLGFBQWEsR0FBRztRQUNoQixTQUFTLEVBQUUsZUFBUztRQUNwQixHQUFHLEVBQUUsZUFBZSxDQUFDLFFBQVEsQ0FBQztLQUNqQyxDQUFDO0lBRUYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBcEMsQ0FBb0MsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxVQUFpQjtJQUM3QyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxhQUFhLEdBQUc7UUFDaEIsU0FBUyxFQUFFLGVBQVM7UUFDcEIsU0FBUyxFQUFFLGlCQUFpQjtRQUM1Qix3QkFBd0IsRUFBRTtZQUN0QixLQUFLLEVBQUUsWUFBWTtTQUN0QjtRQUNELHlCQUF5QixFQUFFO1lBQ3ZCLElBQUksRUFBRTtnQkFDRixDQUFDLEVBQUUsVUFBVTthQUNoQjtTQUNKO1FBQ0Qsc0JBQXNCLEVBQUUsVUFBVTtRQUNsQyxNQUFNLEVBQUUsMEJBQTBCO0tBQ3JDLENBQUM7SUFFRixPQUFPLDZCQUFvQixDQUFDLGNBQU0sT0FBQSxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFsQyxDQUFrQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ3RGLENBQUM7QUFFRCxTQUFlLHNCQUFzQixDQUFDLFVBQWlCLEVBQUUsSUFBYzs7Ozs7d0JBQzVDLHFCQUFNLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxFQUFBOztvQkFBM0QsZ0JBQWdCLEdBQUcsU0FBd0M7b0JBQzNELFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7b0JBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQTRCLFVBQVUsT0FBSSxFQUFFLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFFekUsZ0JBQWdCLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxVQUFDLElBQWlCLElBQUssT0FBQSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQXBCLENBQW9CLENBQUMsQ0FBQztvQkFDeEYsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBNEIsVUFBVSxrQkFBYSxJQUFJLE9BQUksRUFBRSxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbEcsc0JBQU8sZ0JBQWdCLEVBQUM7Ozs7Q0FDM0I7QUFFRCxTQUFTLHVCQUF1QixDQUFDLE1BQStCO0lBQzVELDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUUsaURBQWlELENBQUMsQ0FBQztJQUMxRyw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxFQUFFLG1EQUFtRCxDQUFDLENBQUM7SUFDOUcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRSxxREFBcUQsQ0FBQyxDQUFDO0lBQ2xILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsa0RBQWtELENBQUMsQ0FBQztJQUM1Ryw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDeEcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSw0Q0FBNEMsQ0FBQyxDQUFDO0lBQ2hHLDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEVBQUUscURBQXFELENBQUMsQ0FBQztJQUNsSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7SUFDeEcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsRUFBRSxvREFBb0QsQ0FBQyxDQUFDO0lBQ2hILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUUsOENBQThDLENBQUMsQ0FBQztJQUNwRyw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFLDZDQUE2QyxDQUFDLENBQUM7SUFFbEcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsdURBQXVELENBQUMsQ0FBQztJQUNsSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSx5REFBeUQsQ0FBQyxDQUFDO0lBQ3RILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDJEQUEyRCxDQUFDLENBQUM7SUFDMUgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsd0RBQXdELENBQUMsQ0FBQztJQUNwSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO0lBQ2hILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLGtEQUFrRCxDQUFDLENBQUM7SUFDeEcsNEJBQW1CLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsMkRBQTJELENBQUMsQ0FBQztJQUMxSCw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxzREFBc0QsQ0FBQyxDQUFDO0lBQ2hILDRCQUFtQixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLDBEQUEwRCxDQUFDLENBQUM7SUFDeEgsNEJBQW1CLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsb0RBQW9ELENBQUMsQ0FBQztJQUM1Ryw0QkFBbUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRSxtREFBbUQsQ0FBQyxDQUFDO0FBQy9HLENBQUM7QUFFRCxrQkFBZTtJQUNYLE9BQU8sRUFBRywwQkFBMEI7SUFDcEMsVUFBVSxFQUFHLHFCQUFxQjtJQUNsQyxPQUFPLEVBQUcsa0JBQWtCO0lBQzVCLFVBQVUsRUFBRyxzQkFBc0I7SUFDbkMsaUJBQWlCLEVBQUcsc0JBQXNCO0lBQzFDLDBCQUEwQixFQUFHLHFDQUFxQztJQUNsRSxnQkFBZ0IsRUFBRywyQkFBMkI7SUFDOUMsbUJBQW1CLEVBQUcseUJBQXlCO0NBQ2xELENBQUMifQ==