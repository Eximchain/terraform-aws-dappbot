"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var aws_sdk_1 = __importDefault(require("aws-sdk"));
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
// Provided to us via Terraform
exports.cognitoUserPoolId = process.env.COGNITO_USER_POOL;
exports.dnsRoot = process.env.DNS_ROOT;
exports.sqsQueue = process.env.SQS_QUEUE;
exports.tableName = process.env.DDB_TABLE;
aws_sdk_1.default.config.update({ region: exports.awsRegion });
exports.AWS = aws_sdk_1.default;
module.exports = {
    AWS: exports.AWS, awsRegion: exports.awsRegion, cognitoUserPoolId: exports.cognitoUserPoolId, dnsRoot: exports.dnsRoot, tableName: exports.tableName, sqsQueue: exports.sqsQueue
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLG9EQUFrQztBQUVsQyxnQ0FBZ0M7QUFDbkIsUUFBQSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFvQixDQUFDO0FBRTFELCtCQUErQjtBQUNsQixRQUFBLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQTJCLENBQUM7QUFDNUQsUUFBQSxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFrQixDQUFDO0FBQ3pDLFFBQUEsUUFBUSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBbUIsQ0FBQztBQUMzQyxRQUFBLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQW1CLENBQUM7QUFHekQsaUJBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsTUFBTSxFQUFFLGlCQUFTLEVBQUMsQ0FBQyxDQUFDO0FBRWxDLFFBQUEsR0FBRyxHQUFHLGlCQUFXLENBQUM7QUFFL0IsTUFBTSxDQUFDLE9BQU8sR0FBRztJQUNiLEdBQUcsYUFBQSxFQUFFLFNBQVMsbUJBQUEsRUFBRSxpQkFBaUIsMkJBQUEsRUFBRSxPQUFPLGlCQUFBLEVBQUUsU0FBUyxtQkFBQSxFQUFFLFFBQVEsa0JBQUE7Q0FDbEUsQ0FBQyJ9