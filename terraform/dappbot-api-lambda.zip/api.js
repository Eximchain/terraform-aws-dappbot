"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __importDefault(require("./services"));
var sqs = services_1.default.sqs, dynamoDB = services_1.default.dynamoDB;
var common_1 = require("./common");
var validate_1 = __importDefault(require("./validate"));
var logSuccess = function (stage, res) { console.log("Successfully completed " + stage + "; result: ", res); };
var logErr = function (stage, err) { console.log("Error on " + stage + ": ", err); };
function callAndLog(stage, promise) {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, promise];
                case 1:
                    res = _a.sent();
                    logSuccess(stage, res);
                    return [2 /*return*/, res];
                case 2:
                    err_1 = _a.sent();
                    logErr(stage, err_1);
                    throw err_1;
                case 3: return [2 /*return*/];
            }
        });
    });
}
function apiCreate(rawDappName, body, callerEmail, cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, abi, addr, web3URL, guardianURL, dappTier, targetRepoName, targetRepoOwner, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = common_1.ApiMethods.create;
                    validate_1.default.createBody(body);
                    dappName = validate_1.default.cleanName(rawDappName);
                    abi = body.Abi;
                    addr = body.ContractAddr;
                    web3URL = body.Web3URL;
                    guardianURL = body.GuardianURL;
                    dappTier = body.Tier;
                    targetRepoName = null;
                    targetRepoOwner = null;
                    if (dappTier === common_1.DappTiers.ENTERPRISE) {
                        targetRepoName = body.TargetRepoName;
                        targetRepoOwner = body.TargetRepoOwner;
                    }
                    return [4 /*yield*/, validate_1.default.createAllowed(dappName, cognitoUsername, callerEmail, dappTier)];
                case 1:
                    _a.sent();
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog('Put DynamoDB Item', dynamoDB.putItem(dappName, callerEmail, abi, addr, web3URL, guardianURL, dappTier, targetRepoName, targetRepoOwner))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        message: "Dapp generation successfully initialized!  Check your URL in about 5 minutes."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiRead(rawDappName, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var dappName, dbItem, outputItem, err_2, itemExists, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    dappName = validate_1.default.cleanName(rawDappName);
                    return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, validate_1.default.readAllowed(dbItem, callerEmail)];
                case 3:
                    _a.sent();
                    outputItem = dynamoDB.toApiRepresentation(dbItem.Item);
                    return [3 /*break*/, 5];
                case 4:
                    err_2 = _a.sent();
                    console.log("Read permission denied. Returning empty object.", err_2);
                    outputItem = {};
                    return [3 /*break*/, 5];
                case 5:
                    itemExists = !!outputItem.DappName;
                    responseBody = {
                        exists: itemExists,
                        item: outputItem
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiUpdate(rawDappName, body, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, abi, addr, web3URL, guardianURL, responseBody_1, dbItem, updateAttrs, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = common_1.ApiMethods.update;
                    validate_1.default.updateBody(body);
                    dappName = validate_1.default.cleanName(rawDappName);
                    abi = body.Abi;
                    addr = body.ContractAddr;
                    web3URL = body.Web3URL;
                    guardianURL = body.GuardianURL;
                    if (!abi && !web3URL && !guardianURL && !addr) {
                        responseBody_1 = {
                            message: "No attributes specified to update."
                        };
                        return [2 /*return*/, responseBody_1];
                    }
                    return [4 /*yield*/, validate_1.default.updateAllowed(dappName, callerEmail)];
                case 1:
                    dbItem = _a.sent();
                    updateAttrs = {
                        Abi: abi,
                        ContractAddr: addr,
                        Web3URL: web3URL,
                        GuardianURL: guardianURL
                    };
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog("Set DynamoDB Item State Building And Update Attributes", dynamoDB.setStateBuildingWithUpdate(dbItem, updateAttrs))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        message: "Your Dapp was successfully updated! Allow 5 minutes for rebuild, then check your URL."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiDelete(rawDappName, body, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, dbItem, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = common_1.ApiMethods.delete;
                    validate_1.default.deleteBody(body);
                    dappName = validate_1.default.cleanName(rawDappName);
                    return [4 /*yield*/, validate_1.default.deleteAllowed(dappName, callerEmail)];
                case 1:
                    dbItem = _a.sent();
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog("Set DynamoDB Item State Deleting", dynamoDB.setStateDeleting(dbItem))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        message: "Your Dapp was successfully deleted."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiList(callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var ddbResponse, outputItems, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, callAndLog('List DynamoDB Items', dynamoDB.getByOwner(callerEmail))];
                case 1:
                    ddbResponse = _a.sent();
                    outputItems = ddbResponse.Items.map(function (item) { return dynamoDB.toApiRepresentation(item); });
                    responseBody = {
                        count: ddbResponse.Count,
                        items: outputItems
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function transformForDappHub(_a) {
    var Abi = _a.Abi, DappName = _a.DappName, GuardianURL = _a.GuardianURL, Web3URL = _a.Web3URL, ContractAddr = _a.ContractAddr;
    return { Abi: Abi, DappName: DappName, GuardianURL: GuardianURL, Web3URL: Web3URL, ContractAddr: ContractAddr };
}
;
function apiView(rawDappName) {
    return __awaiter(this, void 0, void 0, function () {
        var dappName, dbItem, apiItem, itemExists, dappHubItem, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    dappName = validate_1.default.cleanName(rawDappName);
                    return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    apiItem = dynamoDB.toApiRepresentation(dbItem.Item);
                    itemExists = 'DappName' in apiItem;
                    dappHubItem = 'DappName' in apiItem ? transformForDappHub(apiItem) : {};
                    responseBody = {
                        exists: itemExists,
                        item: dappHubItem
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
exports.default = {
    create: apiCreate,
    read: apiRead,
    update: apiUpdate,
    delete: apiDelete,
    list: apiList,
    view: apiView
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0RBQWtDO0FBQzFCLElBQUEsNEJBQUcsRUFBRSxzQ0FBUSxDQUFjO0FBQ25DLG1DQUF3RTtBQUN4RSx3REFBa0M7QUFHbEMsSUFBTSxVQUFVLEdBQUcsVUFBQyxLQUFZLEVBQUUsR0FBTyxJQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTBCLEtBQUssZUFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFBO0FBQy9HLElBQU0sTUFBTSxHQUFHLFVBQUMsS0FBWSxFQUFFLEdBQU8sSUFBTyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQVksS0FBSyxPQUFJLEVBQUUsR0FBRyxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUE7QUFHckYsU0FBZSxVQUFVLENBQUMsS0FBWSxFQUFFLE9BQW9COzs7Ozs7O29CQUUxQyxxQkFBTSxPQUFPLEVBQUE7O29CQUFuQixHQUFHLEdBQUcsU0FBYTtvQkFDdkIsVUFBVSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDdkIsc0JBQU8sR0FBRyxFQUFDOzs7b0JBRVgsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDbkIsTUFBTSxLQUFHLENBQUM7Ozs7O0NBRWpCO0FBRUQsU0FBZSxTQUFTLENBQUMsV0FBa0IsRUFBRSxJQUFRLEVBQUUsV0FBa0IsRUFBRSxlQUFzQjs7Ozs7O29CQUN2RixVQUFVLEdBQUcsbUJBQVUsQ0FBQyxNQUFNLENBQUM7b0JBQ3JDLGtCQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUV0QixRQUFRLEdBQUcsa0JBQVEsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzNDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO29CQUNmLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO29CQUN6QixPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDdkIsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7b0JBQy9CLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO29CQUNyQixjQUFjLEdBQUcsSUFBSSxDQUFDO29CQUN0QixlQUFlLEdBQUcsSUFBSSxDQUFDO29CQUMzQixJQUFJLFFBQVEsS0FBSyxrQkFBUyxDQUFDLFVBQVUsRUFBRTt3QkFDbkMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7d0JBQ3JDLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO3FCQUMxQztvQkFFRCxxQkFBTSxrQkFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsRUFBQTs7b0JBQTlFLFNBQThFLENBQUM7b0JBRTNFLGNBQWMsR0FBRzt3QkFDakIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLFFBQVEsRUFBRSxRQUFRO3FCQUNyQixDQUFDO29CQUVGLHFCQUFNLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxjQUFjLEVBQUUsZUFBZSxDQUFDLENBQUMsRUFBQTs7b0JBQTFKLFNBQTBKLENBQUM7b0JBQzNKLHFCQUFNLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBQTs7b0JBQWpHLFNBQWlHLENBQUM7b0JBRTlGLFlBQVksR0FBRzt3QkFDZixPQUFPLEVBQUUsK0VBQStFO3FCQUMzRixDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELFNBQWUsT0FBTyxDQUFDLFdBQWtCLEVBQUUsV0FBa0I7Ozs7OztvQkFDckQsUUFBUSxHQUFHLGtCQUFRLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUVsQyxxQkFBTSxVQUFVLENBQUMsbUJBQW1CLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBMUUsTUFBTSxHQUFHLFNBQWlFOzs7O29CQUkxRSxxQkFBTSxrQkFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUE7O29CQUEvQyxTQUErQyxDQUFDO29CQUNoRCxVQUFVLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzs7OztvQkFFdkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpREFBaUQsRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDcEUsVUFBVSxHQUFHLEVBQUUsQ0FBQzs7O29CQUdoQixVQUFVLEdBQUcsQ0FBQyxDQUFFLFVBQW9DLENBQUMsUUFBUSxDQUFDO29CQUM5RCxZQUFZLEdBQUc7d0JBQ2YsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLElBQUksRUFBRSxVQUFVO3FCQUNuQixDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELFNBQWUsU0FBUyxDQUFDLFdBQWtCLEVBQUUsSUFBUSxFQUFFLFdBQWtCOzs7Ozs7b0JBQy9ELFVBQVUsR0FBRyxtQkFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDckMsa0JBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXRCLFFBQVEsR0FBRyxrQkFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFFM0MsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7b0JBQ2YsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUN2QixXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFFbkMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRTt3QkFDdkMsaUJBQWU7NEJBQ2YsT0FBTyxFQUFFLG9DQUFvQzt5QkFDaEQsQ0FBQzt3QkFDRixzQkFBTyxjQUFZLEVBQUM7cUJBQ3ZCO29CQUVZLHFCQUFNLGtCQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsRUFBQTs7b0JBQTVELE1BQU0sR0FBRyxTQUFtRDtvQkFFNUQsV0FBVyxHQUFHO3dCQUNkLEdBQUcsRUFBRSxHQUFHO3dCQUNSLFlBQVksRUFBRSxJQUFJO3dCQUNsQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLFdBQVc7cUJBQzNCLENBQUM7b0JBQ0UsY0FBYyxHQUFHO3dCQUNqQixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsUUFBUSxFQUFFLFFBQVE7cUJBQ3JCLENBQUM7b0JBRUYscUJBQU0sVUFBVSxDQUFDLHdEQUF3RCxFQUFFLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFBQTs7b0JBQXBJLFNBQW9JLENBQUM7b0JBQ3JJLHFCQUFNLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBQTs7b0JBQWpHLFNBQWlHLENBQUM7b0JBRTlGLFlBQVksR0FBRzt3QkFDZixPQUFPLEVBQUUsdUZBQXVGO3FCQUNuRyxDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELFNBQWUsU0FBUyxDQUFDLFdBQWtCLEVBQUUsSUFBUSxFQUFFLFdBQWtCOzs7Ozs7b0JBQy9ELFVBQVUsR0FBRyxtQkFBVSxDQUFDLE1BQU0sQ0FBQztvQkFDckMsa0JBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXRCLFFBQVEsR0FBRyxrQkFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFFbEMscUJBQU0sa0JBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxFQUFBOztvQkFBNUQsTUFBTSxHQUFHLFNBQW1EO29CQUU1RCxjQUFjLEdBQUc7d0JBQ2pCLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixRQUFRLEVBQUUsUUFBUTtxQkFDckIsQ0FBQztvQkFFRixxQkFBTSxVQUFVLENBQUMsa0NBQWtDLEVBQUUsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUE7O29CQUF2RixTQUF1RixDQUFDO29CQUN4RixxQkFBTSxVQUFVLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUE7O29CQUFqRyxTQUFpRyxDQUFDO29CQUU5RixZQUFZLEdBQUc7d0JBQ2YsT0FBTyxFQUFFLHFDQUFxQztxQkFDakQsQ0FBQztvQkFDRixzQkFBTyxZQUFZLEVBQUM7Ozs7Q0FDdkI7QUFFRCxTQUFlLE9BQU8sQ0FBQyxXQUFrQjs7Ozs7d0JBQ25CLHFCQUFNLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RixXQUFXLEdBQUcsU0FBeUU7b0JBQ3ZGLFdBQVcsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFDLElBQTZCLElBQUssT0FBQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQWxDLENBQWtDLENBQUMsQ0FBQztvQkFDM0csWUFBWSxHQUFHO3dCQUNmLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSzt3QkFDeEIsS0FBSyxFQUFFLFdBQVc7cUJBQ3JCLENBQUM7b0JBQ0Ysc0JBQU8sWUFBWSxFQUFDOzs7O0NBQ3ZCO0FBRUQsU0FBUyxtQkFBbUIsQ0FDeEIsRUFBeUU7UUFBeEUsWUFBRyxFQUFFLHNCQUFRLEVBQUUsNEJBQVcsRUFBRSxvQkFBTyxFQUFFLDhCQUFZO0lBRWxELE9BQU8sRUFBQyxHQUFHLEtBQUEsRUFBRSxRQUFRLFVBQUEsRUFBRSxXQUFXLGFBQUEsRUFBRSxPQUFPLFNBQUEsRUFBRSxZQUFZLGNBQUEsRUFBQyxDQUFDO0FBQy9ELENBQUM7QUFBQSxDQUFDO0FBRUYsU0FBZSxPQUFPLENBQUMsV0FBa0I7Ozs7OztvQkFDakMsUUFBUSxHQUFHLGtCQUFRLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUVsQyxxQkFBTSxVQUFVLENBQUMsbUJBQW1CLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBMUUsTUFBTSxHQUFHLFNBQWlFO29CQUUxRSxPQUFPLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFcEQsVUFBVSxHQUFHLFVBQVUsSUFBSSxPQUFPLENBQUM7b0JBQ25DLFdBQVcsR0FBRyxVQUFVLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUV4RSxZQUFZLEdBQUc7d0JBQ2YsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLElBQUksRUFBRSxXQUFXO3FCQUNwQixDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELGtCQUFlO0lBQ1gsTUFBTSxFQUFHLFNBQVM7SUFDbEIsSUFBSSxFQUFHLE9BQU87SUFDZCxNQUFNLEVBQUcsU0FBUztJQUNsQixNQUFNLEVBQUcsU0FBUztJQUNsQixJQUFJLEVBQUcsT0FBTztJQUNkLElBQUksRUFBRyxPQUFPO0NBQ2pCLENBQUEifQ==