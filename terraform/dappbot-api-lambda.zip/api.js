"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __importDefault(require("./services"));
var sqs = services_1.default.sqs, dynamoDB = services_1.default.dynamoDB;
var validate_1 = __importDefault(require("./validate"));
var logSuccess = function (stage, res) { console.log("Successfully completed " + stage + "; result: ", res); };
var logErr = function (stage, err) { console.log("Error on " + stage + ": ", err); };
function callAndLog(stage, promise) {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, promise];
                case 1:
                    res = _a.sent();
                    logSuccess(stage, res);
                    return [2 /*return*/, res];
                case 2:
                    err_1 = _a.sent();
                    logErr(stage, err_1);
                    throw err_1;
                case 3: return [2 /*return*/];
            }
        });
    });
}
function apiCreate(body, callerEmail, cognitoUsername) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, abi, addr, web3URL, guardianURL, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'create';
                    validate_1.default.createBody(body);
                    dappName = validate_1.default.cleanName(body.DappName);
                    abi = body.Abi;
                    addr = body.ContractAddr;
                    web3URL = body.Web3URL;
                    guardianURL = body.GuardianURL;
                    return [4 /*yield*/, validate_1.default.createAllowed(dappName, cognitoUsername, callerEmail)];
                case 1:
                    _a.sent();
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog('Put DynamoDB Item', dynamoDB.putItem(dappName, callerEmail, abi, addr, web3URL, guardianURL))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        method: methodName,
                        message: "Dapp generation successfully initialized!  Check your URL in about 5 minutes."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiRead(body, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, dbItem, outputItem, err_2, itemExists, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'read';
                    validate_1.default.readBody(body);
                    dappName = validate_1.default.cleanName(body.DappName);
                    return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, validate_1.default.readAllowed(dbItem, callerEmail)];
                case 3:
                    _a.sent();
                    outputItem = dynamoDB.toApiRepresentation(dbItem.Item);
                    return [3 /*break*/, 5];
                case 4:
                    err_2 = _a.sent();
                    console.log("Read permission denied. Returning empty object.", err_2);
                    outputItem = {};
                    return [3 /*break*/, 5];
                case 5:
                    itemExists = !!outputItem.DappName;
                    responseBody = {
                        method: methodName,
                        exists: itemExists,
                        item: outputItem
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiUpdate(body, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, abi, addr, web3URL, guardianURL, responseBody_1, dbItem, updateAttrs, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'update';
                    validate_1.default.updateBody(body);
                    dappName = validate_1.default.cleanName(body.DappName);
                    abi = body.Abi;
                    addr = body.ContractAddr;
                    web3URL = body.Web3URL;
                    guardianURL = body.GuardianURL;
                    if (!abi && !web3URL && !guardianURL && !addr) {
                        responseBody_1 = {
                            method: methodName,
                            message: "No attributes specified to update."
                        };
                        return [2 /*return*/, responseBody_1];
                    }
                    return [4 /*yield*/, validate_1.default.updateAllowed(dappName, callerEmail)];
                case 1:
                    dbItem = _a.sent();
                    updateAttrs = {
                        Abi: abi,
                        ContractAddr: addr,
                        Web3URL: web3URL,
                        GuardianURL: guardianURL
                    };
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog("Set DynamoDB Item State Building And Update Attributes", dynamoDB.setStateBuildingWithUpdate(dbItem, updateAttrs))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        method: methodName,
                        message: "Your Dapp was successfully updated! Allow 5 minutes for rebuild, then check your URL."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiDelete(body, callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, dbItem, sqsMessageBody, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'delete';
                    validate_1.default.deleteBody(body);
                    dappName = validate_1.default.cleanName(body.DappName);
                    return [4 /*yield*/, validate_1.default.deleteAllowed(dappName, callerEmail)];
                case 1:
                    dbItem = _a.sent();
                    sqsMessageBody = {
                        Method: methodName,
                        DappName: dappName
                    };
                    return [4 /*yield*/, callAndLog("Set DynamoDB Item State Deleting", dynamoDB.setStateDeleting(dbItem))];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, callAndLog('Send SQS Message', sqs.sendMessage(methodName, JSON.stringify(sqsMessageBody)))];
                case 3:
                    _a.sent();
                    responseBody = {
                        method: methodName,
                        message: "Your Dapp was successfully deleted."
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiList(callerEmail) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, ddbResponse, outputItems, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'list';
                    return [4 /*yield*/, callAndLog('List DynamoDB Items', dynamoDB.getByOwner(callerEmail))];
                case 1:
                    ddbResponse = _a.sent();
                    outputItems = ddbResponse.Items.map(function (item) { return dynamoDB.toApiRepresentation(item); });
                    responseBody = {
                        method: methodName,
                        count: ddbResponse.Count,
                        items: outputItems
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
function apiView(body) {
    return __awaiter(this, void 0, void 0, function () {
        var methodName, dappName, dbItem, outputItem, transformForDappHub, finalItem, itemExists, responseBody;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    methodName = 'view';
                    validate_1.default.readBody(body);
                    dappName = validate_1.default.cleanName(body.DappName);
                    return [4 /*yield*/, callAndLog('Get DynamoDB Item', dynamoDB.getItem(dappName))];
                case 1:
                    dbItem = _a.sent();
                    outputItem = dynamoDB.toApiRepresentation(dbItem.Item);
                    transformForDappHub = function (_a) {
                        var Abi = _a.Abi, DappName = _a.DappName, GuardianURL = _a.GuardianURL, Web3URL = _a.Web3URL, ContractAddr = _a.ContractAddr;
                        return ({ Abi: Abi, DappName: DappName, GuardianURL: GuardianURL, Web3URL: Web3URL, ContractAddr: ContractAddr });
                    };
                    if (outputItem === {}) {
                        finalItem = {};
                    }
                    else {
                        // @ts-ignore
                        finalItem = transformForDappHub(outputItem);
                    }
                    itemExists = !!outputItem.DappName;
                    responseBody = {
                        method: methodName,
                        exists: itemExists,
                        item: finalItem
                    };
                    return [2 /*return*/, responseBody];
            }
        });
    });
}
exports.default = {
    create: apiCreate,
    read: apiRead,
    update: apiUpdate,
    delete: apiDelete,
    list: apiList,
    view: apiView
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsd0RBQWtDO0FBQzFCLElBQUEsNEJBQUcsRUFBRSxzQ0FBUSxDQUFjO0FBRW5DLHdEQUFrQztBQUdsQyxJQUFNLFVBQVUsR0FBRyxVQUFDLEtBQVksRUFBRSxHQUFPLElBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBMEIsS0FBSyxlQUFZLEVBQUUsR0FBRyxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUE7QUFDL0csSUFBTSxNQUFNLEdBQUcsVUFBQyxLQUFZLEVBQUUsR0FBTyxJQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBWSxLQUFLLE9BQUksRUFBRSxHQUFHLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQTtBQUdyRixTQUFlLFVBQVUsQ0FBQyxLQUFZLEVBQUUsT0FBb0I7Ozs7Ozs7b0JBRTFDLHFCQUFNLE9BQU8sRUFBQTs7b0JBQW5CLEdBQUcsR0FBRyxTQUFhO29CQUN2QixVQUFVLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUN2QixzQkFBTyxHQUFHLEVBQUM7OztvQkFFWCxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNuQixNQUFNLEtBQUcsQ0FBQzs7Ozs7Q0FFakI7QUFFRCxTQUFlLFNBQVMsQ0FBQyxJQUFRLEVBQUUsV0FBa0IsRUFBRSxlQUFzQjs7Ozs7O29CQUNuRSxVQUFVLEdBQUcsUUFBUSxDQUFDO29CQUM1QixrQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFdEIsUUFBUSxHQUFHLGtCQUFRLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDN0MsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7b0JBQ2YsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUN2QixXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFFbkMscUJBQU0sa0JBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRSxXQUFXLENBQUMsRUFBQTs7b0JBQXBFLFNBQW9FLENBQUM7b0JBRWpFLGNBQWMsR0FBRzt3QkFDakIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLFFBQVEsRUFBRSxRQUFRO3FCQUNyQixDQUFDO29CQUVGLHFCQUFNLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFBQTs7b0JBQS9HLFNBQStHLENBQUM7b0JBQ2hILHFCQUFNLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBQTs7b0JBQWpHLFNBQWlHLENBQUM7b0JBRTlGLFlBQVksR0FBRzt3QkFDZixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLCtFQUErRTtxQkFDM0YsQ0FBQztvQkFDRixzQkFBTyxZQUFZLEVBQUM7Ozs7Q0FDdkI7QUFFRCxTQUFlLE9BQU8sQ0FBQyxJQUFRLEVBQUUsV0FBa0I7Ozs7OztvQkFDekMsVUFBVSxHQUFHLE1BQU0sQ0FBQztvQkFDMUIsa0JBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXBCLFFBQVEsR0FBRyxrQkFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRXBDLHFCQUFNLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUE7O29CQUExRSxNQUFNLEdBQUcsU0FBaUU7Ozs7b0JBSTFFLHFCQUFNLGtCQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBQTs7b0JBQS9DLFNBQStDLENBQUM7b0JBQ2hELFVBQVUsR0FBRyxRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDOzs7O29CQUV2RCxPQUFPLENBQUMsR0FBRyxDQUFDLGlEQUFpRCxFQUFFLEtBQUcsQ0FBQyxDQUFDO29CQUNwRSxVQUFVLEdBQUcsRUFBRSxDQUFDOzs7b0JBR2hCLFVBQVUsR0FBRyxDQUFDLENBQUUsVUFBb0MsQ0FBQyxRQUFRLENBQUM7b0JBQzlELFlBQVksR0FBRzt3QkFDZixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLElBQUksRUFBRSxVQUFVO3FCQUNuQixDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELFNBQWUsU0FBUyxDQUFDLElBQVEsRUFBRSxXQUFrQjs7Ozs7O29CQUMzQyxVQUFVLEdBQUcsUUFBUSxDQUFDO29CQUM1QixrQkFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFdEIsUUFBUSxHQUFHLGtCQUFRLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFN0MsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7b0JBQ2YsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7b0JBQ3pCLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUN2QixXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFFbkMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRTt3QkFDdkMsaUJBQWU7NEJBQ2YsTUFBTSxFQUFFLFVBQVU7NEJBQ2xCLE9BQU8sRUFBRSxvQ0FBb0M7eUJBQ2hELENBQUM7d0JBQ0Ysc0JBQU8sY0FBWSxFQUFDO3FCQUN2QjtvQkFFWSxxQkFBTSxrQkFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUE7O29CQUE1RCxNQUFNLEdBQUcsU0FBbUQ7b0JBRTVELFdBQVcsR0FBRzt3QkFDZCxHQUFHLEVBQUUsR0FBRzt3QkFDUixZQUFZLEVBQUUsSUFBSTt3QkFDbEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxXQUFXO3FCQUMzQixDQUFDO29CQUNFLGNBQWMsR0FBRzt3QkFDakIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLFFBQVEsRUFBRSxRQUFRO3FCQUNyQixDQUFDO29CQUVGLHFCQUFNLFVBQVUsQ0FBQyx3REFBd0QsRUFBRSxRQUFRLENBQUMsMEJBQTBCLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDLEVBQUE7O29CQUFwSSxTQUFvSSxDQUFDO29CQUNySSxxQkFBTSxVQUFVLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUE7O29CQUFqRyxTQUFpRyxDQUFDO29CQUU5RixZQUFZLEdBQUc7d0JBQ2YsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLE9BQU8sRUFBRSx1RkFBdUY7cUJBQ25HLENBQUM7b0JBQ0Ysc0JBQU8sWUFBWSxFQUFDOzs7O0NBQ3ZCO0FBRUQsU0FBZSxTQUFTLENBQUMsSUFBUSxFQUFFLFdBQWtCOzs7Ozs7b0JBQzNDLFVBQVUsR0FBRyxRQUFRLENBQUM7b0JBQzVCLGtCQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUV0QixRQUFRLEdBQUcsa0JBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUVwQyxxQkFBTSxrQkFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUE7O29CQUE1RCxNQUFNLEdBQUcsU0FBbUQ7b0JBRTVELGNBQWMsR0FBRzt3QkFDakIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLFFBQVEsRUFBRSxRQUFRO3FCQUNyQixDQUFDO29CQUVGLHFCQUFNLFVBQVUsQ0FBQyxrQ0FBa0MsRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQTs7b0JBQXZGLFNBQXVGLENBQUM7b0JBQ3hGLHFCQUFNLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBQTs7b0JBQWpHLFNBQWlHLENBQUM7b0JBRTlGLFlBQVksR0FBRzt3QkFDZixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLHFDQUFxQztxQkFDakQsQ0FBQztvQkFDRixzQkFBTyxZQUFZLEVBQUM7Ozs7Q0FDdkI7QUFFRCxTQUFlLE9BQU8sQ0FBQyxXQUFrQjs7Ozs7O29CQUMvQixVQUFVLEdBQUcsTUFBTSxDQUFDO29CQUVSLHFCQUFNLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RixXQUFXLEdBQUcsU0FBeUU7b0JBQ3ZGLFdBQVcsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFDLElBQTZCLElBQUssT0FBQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQWxDLENBQWtDLENBQUMsQ0FBQztvQkFDM0csWUFBWSxHQUFHO3dCQUNmLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7d0JBQ3hCLEtBQUssRUFBRSxXQUFXO3FCQUNyQixDQUFDO29CQUNGLHNCQUFPLFlBQVksRUFBQzs7OztDQUN2QjtBQUVELFNBQWUsT0FBTyxDQUFDLElBQVE7Ozs7OztvQkFDckIsVUFBVSxHQUFHLE1BQU0sQ0FBQztvQkFDMUIsa0JBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3BCLFFBQVEsR0FBRyxrQkFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRXBDLHFCQUFNLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUE7O29CQUExRSxNQUFNLEdBQUcsU0FBaUU7b0JBRTFFLFVBQVUsR0FBRyxRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUVyRCxtQkFBbUIsR0FBRyxVQUN4QixFQUF5RTs0QkFBeEUsWUFBRyxFQUFFLHNCQUFRLEVBQUUsNEJBQVcsRUFBRSxvQkFBTyxFQUFFLDhCQUFZO3dCQUNuRCxPQUFBLENBQ0MsRUFBQyxHQUFHLEtBQUEsRUFBRSxRQUFRLFVBQUEsRUFBRSxXQUFXLGFBQUEsRUFBRSxPQUFPLFNBQUEsRUFBRSxZQUFZLGNBQUEsRUFBQyxDQUN0RDtvQkFGRSxDQUVGLENBQUM7b0JBR0YsSUFBSSxVQUFVLEtBQUssRUFBRSxFQUFDO3dCQUNsQixTQUFTLEdBQUcsRUFBRSxDQUFBO3FCQUNqQjt5QkFBTTt3QkFDSCxhQUFhO3dCQUNiLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtxQkFDOUM7b0JBQ0csVUFBVSxHQUFHLENBQUMsQ0FBRSxVQUFvQyxDQUFDLFFBQVEsQ0FBQztvQkFFOUQsWUFBWSxHQUFHO3dCQUNmLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsSUFBSSxFQUFFLFNBQVM7cUJBQ2xCLENBQUM7b0JBQ0Ysc0JBQU8sWUFBWSxFQUFDOzs7O0NBQ3ZCO0FBRUQsa0JBQWU7SUFDWCxNQUFNLEVBQUcsU0FBUztJQUNsQixJQUFJLEVBQUcsT0FBTztJQUNkLE1BQU0sRUFBRyxTQUFTO0lBQ2xCLE1BQU0sRUFBRyxTQUFTO0lBQ2xCLElBQUksRUFBRyxPQUFPO0lBQ2QsSUFBSSxFQUFHLE9BQU87Q0FDakIsQ0FBQSJ9