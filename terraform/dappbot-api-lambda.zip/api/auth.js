"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var errors_1 = require("../errors");
var cognito_1 = __importStar(require("../services/cognito"));
var validate_1 = __importDefault(require("../validate"));
function bodyMissing(body, propertyNames) {
    return propertyNames.filter(function (name) { return !body.hasOwnProperty(name); });
}
var AuthParamNames;
(function (AuthParamNames) {
    AuthParamNames["Username"] = "username";
    AuthParamNames["Password"] = "password";
    AuthParamNames["NewPassword"] = "newPassword";
    AuthParamNames["Session"] = "session";
    AuthParamNames["MFALoginCode"] = "mfaLoginCode";
    AuthParamNames["MFASetupCode"] = "mfaSetupCode";
    AuthParamNames["PasswordResetCode"] = "passwordResetCode";
})(AuthParamNames = exports.AuthParamNames || (exports.AuthParamNames = {}));
function perCaseErrMsg(_a) {
    var endpoint = _a.endpoint, actionsMissing = _a.actionsMissing;
    return [
        "Your request body did not match any options for " + endpoint + ":\n"
    ].concat(actionsMissing.map(function (missing) { return "- If you want to " + missing.action + ", then also provide " + missing.parameters.join(', ') + "."; })).join('\n');
}
function buildChallengeResponseBody(authResult) {
    return __awaiter(this, void 0, void 0, function () {
        var responseBody, User, ExpiresAt, mfaSetup, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!authResult.AuthenticationResult) return [3 /*break*/, 2];
                    return [4 /*yield*/, cognito_1.default.getUserByToken(authResult.AuthenticationResult.AccessToken)];
                case 1:
                    User = _a.sent();
                    ExpiresAt = new Date(Date.now() + 1000 * authResult.AuthenticationResult.ExpiresIn).toISOString();
                    responseBody = {
                        Authorization: authResult.AuthenticationResult.IdToken,
                        Refresh: {
                            Token: authResult.AuthenticationResult.RefreshToken,
                            ExpiresAt: ExpiresAt,
                        },
                        User: User
                    };
                    return [3 /*break*/, 6];
                case 2:
                    responseBody = {
                        ChallengeName: authResult.ChallengeName,
                        ChallengeParameters: authResult.ChallengeParameters,
                        Session: authResult.Session
                    };
                    if (!(authResult.ChallengeName === cognito_1.CognitoChallengeNames.MFASetup)) return [3 /*break*/, 6];
                    _a.label = 3;
                case 3:
                    _a.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, common_1.callAndLog("Beginning MFA setup", cognito_1.default.beginMFASetup(authResult.Session))];
                case 4:
                    mfaSetup = _a.sent();
                    responseBody.ChallengeParameters.mfaSetupCode = mfaSetup.SecretCode;
                    return [3 /*break*/, 6];
                case 5:
                    err_1 = _a.sent();
                    throw err_1;
                case 6: return [2 /*return*/, responseBody];
            }
        });
    });
}
var LoginActions;
(function (LoginActions) {
    LoginActions["Login"] = "LOGIN";
    LoginActions["ConfirmNewPassword"] = "CONFIRM_NEW_PASSWORD";
    LoginActions["ConfirmMFALogin"] = "CONFIRM_MFA_LOGIN";
    LoginActions["ConfirmMFASetup"] = "CONFIRM_MFA_SETUP";
})(LoginActions = exports.LoginActions || (exports.LoginActions = {}));
exports.LoginParams = {
    Login: [AuthParamNames.Username, AuthParamNames.Password],
    ConfirmNewPassword: [AuthParamNames.Username, AuthParamNames.Session, AuthParamNames.NewPassword],
    ConfirmMFALogin: [AuthParamNames.Username, AuthParamNames.Session, AuthParamNames.MFALoginCode],
    ConfirmMFASetup: [AuthParamNames.Session, AuthParamNames.MFASetupCode]
};
var LoginExceptions;
(function (LoginExceptions) {
    LoginExceptions["NotConfirmed"] = "UserNotConfirmedException";
    LoginExceptions["ResetRequired"] = "PasswordResetRequiredException";
    LoginExceptions["NotAuthorized"] = "NotAuthorizedException";
    LoginExceptions["NotFound"] = "UserNotFoundException";
})(LoginExceptions || (LoginExceptions = {}));
function apiLogin(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, loginResult, err_2, _b, msg, newPassResult, confirmMFASetupResult, confirmMFALoginResult;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = validate_1.default.matchLoginBody(body);
                    switch (_a) {
                        case LoginActions.Login: return [3 /*break*/, 1];
                        case LoginActions.ConfirmNewPassword: return [3 /*break*/, 11];
                        case LoginActions.ConfirmMFASetup: return [3 /*break*/, 13];
                        case LoginActions.ConfirmMFALogin: return [3 /*break*/, 15];
                    }
                    return [3 /*break*/, 17];
                case 1:
                    _c.trys.push([1, 3, , 11]);
                    return [4 /*yield*/, common_1.callAndLog('Logging into Cognito', cognito_1.default.login(body.username, body.password))];
                case 2:
                    loginResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(loginResult)];
                case 3:
                    err_2 = _c.sent();
                    _b = err_2.code;
                    switch (_b) {
                        case LoginExceptions.NotConfirmed: return [3 /*break*/, 4];
                        case LoginExceptions.ResetRequired: return [3 /*break*/, 6];
                        case LoginExceptions.NotAuthorized: return [3 /*break*/, 8];
                        case LoginExceptions.NotFound: return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 9];
                case 4: return [4 /*yield*/, cognito_1.default.resendSignUpConfirmCode(body.username)];
                case 5:
                    _c.sent();
                    throw new errors_1.EmailNotConfirmedError("Please finish confirming your account, we've resent your confirmation code.");
                case 6: return [4 /*yield*/, cognito_1.default.beginForgotPassword(body.username)];
                case 7:
                    _c.sent();
                    throw new errors_1.PasswordResetRequiredError("Please reset your password, we've emailed you a confirmation code.");
                case 8: throw new errors_1.UnrecognizedCredentialsError("We could not log you in with these credentials.");
                case 9:
                    msg = err_2.code ? err_2.code + " - " + err_2.message : err_2.toString();
                    throw new errors_1.AuthError(msg);
                case 10: return [3 /*break*/, 11];
                case 11: return [4 /*yield*/, common_1.callAndLog('Confirming new password', cognito_1.default.confirmNewPassword(body.session, body.username, body.newPassword))];
                case 12:
                    newPassResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(newPassResult)];
                case 13: return [4 /*yield*/, common_1.callAndLog('Confirming MFA Setup', cognito_1.default.confirmMFASetup(body.session, body.mfaSetupCode))];
                case 14:
                    confirmMFASetupResult = _c.sent();
                    if (confirmMFASetupResult.Status === 'SUCCESS') {
                        return [2 /*return*/, {
                                message: 'MFA was successfully set up, you can now log in.'
                            }];
                    }
                    else {
                        return [2 /*return*/, {
                                message: 'MFA setup was unsuccessful. Please use session to try again.',
                                session: confirmMFASetupResult.Session
                            }];
                    }
                    _c.label = 15;
                case 15: return [4 /*yield*/, common_1.callAndLog('Confirming MFA Login', cognito_1.default.confirmMFALogin(body.session, body.username, body.mfaLoginCode))];
                case 16:
                    confirmMFALoginResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(confirmMFALoginResult)];
                case 17: throw new errors_1.AuthError(perCaseErrMsg({
                    endpoint: common_1.ApiMethods.login,
                    actionsMissing: [
                        { action: 'login', parameters: bodyMissing(body, exports.LoginParams.Login) },
                        { action: 'confirm new password', parameters: bodyMissing(body, exports.LoginParams.ConfirmNewPassword) },
                        { action: 'confirm an MFA login', parameters: bodyMissing(body, exports.LoginParams.ConfirmMFALogin) },
                        { action: 'confirm MFA setup', parameters: bodyMissing(body, exports.LoginParams.ConfirmMFASetup) }
                    ]
                }));
            }
        });
    });
}
var PasswordResetActions;
(function (PasswordResetActions) {
    PasswordResetActions["Begin"] = "BEGIN_PASSWORD_RESET";
    PasswordResetActions["Confirm"] = "CONFIRM_PASSWORD_RESET";
})(PasswordResetActions = exports.PasswordResetActions || (exports.PasswordResetActions = {}));
exports.PasswordResetParams = {
    Begin: [AuthParamNames.Username],
    Confirm: [AuthParamNames.Username, AuthParamNames.PasswordResetCode, AuthParamNames.NewPassword]
};
var PasswordResetExceptions;
(function (PasswordResetExceptions) {
    PasswordResetExceptions["Expired"] = "ExpiredCodeException";
    PasswordResetExceptions["InvalidPassword"] = "InvalidPasswordException";
    PasswordResetExceptions["NotConfirmed"] = "UserNotConfirmedException";
})(PasswordResetExceptions || (PasswordResetExceptions = {}));
function apiPasswordReset(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, username, passwordResetCode, newPassword, err_3, _b, msg;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = validate_1.default.matchPasswordResetBody(body);
                    switch (_a) {
                        case PasswordResetActions.Confirm: return [3 /*break*/, 1];
                        case PasswordResetActions.Begin: return [3 /*break*/, 12];
                    }
                    return [3 /*break*/, 14];
                case 1:
                    username = body.username, passwordResetCode = body.passwordResetCode, newPassword = body.newPassword;
                    _c.label = 2;
                case 2:
                    _c.trys.push([2, 4, , 12]);
                    return [4 /*yield*/, common_1.callAndLog('Confirming password reset', cognito_1.default.confirmForgotPassword(username, passwordResetCode, newPassword))];
                case 3:
                    _c.sent();
                    return [2 /*return*/, {
                            message: 'Your password was successfully set, you may now login.'
                        }];
                case 4:
                    err_3 = _c.sent();
                    _b = err_3.code;
                    switch (_b) {
                        case PasswordResetExceptions.Expired: return [3 /*break*/, 5];
                        case PasswordResetExceptions.InvalidPassword: return [3 /*break*/, 7];
                        case PasswordResetExceptions.NotConfirmed: return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 10];
                case 5: return [4 /*yield*/, common_1.callAndLog('Sending new password reset code to replace expired one', cognito_1.default.beginForgotPassword(username))];
                case 6:
                    _c.sent();
                    throw new errors_1.PasswordResetRequiredError("Your password reset code expired, a new one has been sent.");
                case 7: throw new errors_1.InvalidPasswordError("Your new password was not valid, please select another one.");
                case 8: return [4 /*yield*/, common_1.callAndLog('Resending account confirmation code', cognito_1.default.resendSignUpConfirmCode(username))];
                case 9:
                    _c.sent();
                    throw new errors_1.EmailNotConfirmedError("Your account still has not been confirmed, we have resent your signup confirmation code.");
                case 10:
                    msg = err_3.code ? err_3.code + " - " + err_3.message : err_3.toString();
                    throw new errors_1.AuthError(msg);
                case 11: return [3 /*break*/, 12];
                case 12: return [4 /*yield*/, common_1.callAndLog('Beginning password reset', cognito_1.default.beginForgotPassword(body.username))];
                case 13:
                    _c.sent();
                    return [2 /*return*/, {
                            message: "Please reset your password, we've emailed you a confirmation code."
                        }];
                case 14: throw new errors_1.AuthError(perCaseErrMsg({
                    endpoint: common_1.ApiMethods.passwordReset,
                    actionsMissing: [
                        { action: 'begin password reset', parameters: bodyMissing(body, exports.PasswordResetParams.Begin) },
                        { action: 'confirm password reset', parameters: bodyMissing(body, exports.PasswordResetParams.Confirm) }
                    ]
                }));
            }
        });
    });
}
exports.default = {
    login: apiLogin,
    passwordReset: apiPasswordReset
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJhcGkvYXV0aC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLG9DQUFtRDtBQUNuRCxvQ0FBOEk7QUFDOUksNkRBQXFFO0FBQ3JFLHlEQUFtQztBQUVuQyxTQUFTLFdBQVcsQ0FBQyxJQUFXLEVBQUUsYUFBc0I7SUFDdEQsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUExQixDQUEwQixDQUFDLENBQUM7QUFDbEUsQ0FBQztBQUVELElBQVksY0FRWDtBQVJELFdBQVksY0FBYztJQUN4Qix1Q0FBcUIsQ0FBQTtJQUNyQix1Q0FBcUIsQ0FBQTtJQUNyQiw2Q0FBMkIsQ0FBQTtJQUMzQixxQ0FBbUIsQ0FBQTtJQUNuQiwrQ0FBNkIsQ0FBQTtJQUM3QiwrQ0FBNkIsQ0FBQTtJQUM3Qix5REFBdUMsQ0FBQTtBQUN6QyxDQUFDLEVBUlcsY0FBYyxHQUFkLHNCQUFjLEtBQWQsc0JBQWMsUUFRekI7QUFZRCxTQUFTLGFBQWEsQ0FBQyxFQUE4QztRQUE1QyxzQkFBUSxFQUFFLGtDQUFjO0lBQy9DLE9BQU87UUFDTCxxREFBbUQsUUFBUSxRQUFLO2FBQzdELGNBQWMsQ0FBQyxHQUFHLENBQUMsVUFBQSxPQUFPLElBQUksT0FBQSxzQkFBb0IsT0FBTyxDQUFDLE1BQU0sNEJBQXVCLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFHLEVBQXpGLENBQXlGLENBQUMsRUFDM0gsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ2QsQ0FBQztBQUlELFNBQWUsMEJBQTBCLENBQUMsVUFBcUI7Ozs7Ozt5QkFFekQsVUFBVSxDQUFDLG9CQUFvQixFQUEvQix3QkFBK0I7b0JBQ3BCLHFCQUFNLGlCQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFxQixDQUFDLEVBQUE7O29CQUExRixJQUFJLEdBQUcsU0FBbUY7b0JBQzFGLFNBQVMsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxHQUFZLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtvQkFDaEgsWUFBWSxHQUFHO3dCQUNiLGFBQWEsRUFBRSxVQUFVLENBQUMsb0JBQW9CLENBQUMsT0FBaUI7d0JBQ2hFLE9BQU8sRUFBRTs0QkFDUCxLQUFLLEVBQUcsVUFBVSxDQUFDLG9CQUFvQixDQUFDLFlBQXNCOzRCQUM5RCxTQUFTLFdBQUE7eUJBQ1Y7d0JBQ0QsSUFBSSxNQUFBO3FCQUNMLENBQUE7OztvQkFFRCxZQUFZLEdBQUc7d0JBQ2IsYUFBYSxFQUFFLFVBQVUsQ0FBQyxhQUF1Qjt3QkFDakQsbUJBQW1CLEVBQUUsVUFBVSxDQUFDLG1CQUEyRDt3QkFDM0YsT0FBTyxFQUFFLFVBQVUsQ0FBQyxPQUFtQztxQkFDeEQsQ0FBQTt5QkFDRyxDQUFBLFVBQVUsQ0FBQyxhQUFhLEtBQUssK0JBQXFCLENBQUMsUUFBUSxDQUFBLEVBQTNELHdCQUEyRDs7OztvQkFFMUMscUJBQU0sbUJBQVUsQ0FBQyxxQkFBcUIsRUFBRSxpQkFBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsT0FBaUIsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RyxRQUFRLEdBQUcsU0FBNEY7b0JBQzdHLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFVBQW9CLENBQUM7Ozs7b0JBRTlFLE1BQU0sS0FBRyxDQUFDO3dCQUloQixzQkFBTyxZQUFZLEVBQUM7Ozs7Q0FDckI7QUFFRCxJQUFZLFlBS1g7QUFMRCxXQUFZLFlBQVk7SUFDdEIsK0JBQWUsQ0FBQTtJQUNmLDJEQUEyQyxDQUFBO0lBQzNDLHFEQUFxQyxDQUFBO0lBQ3JDLHFEQUFxQyxDQUFBO0FBQ3ZDLENBQUMsRUFMVyxZQUFZLEdBQVosb0JBQVksS0FBWixvQkFBWSxRQUt2QjtBQUVZLFFBQUEsV0FBVyxHQUFHO0lBQ3pCLEtBQUssRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLFFBQVEsQ0FBQztJQUMxRCxrQkFBa0IsRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsV0FBVyxDQUFDO0lBQ2xHLGVBQWUsRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsWUFBWSxDQUFDO0lBQ2hHLGVBQWUsRUFBRyxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLFlBQVksQ0FBQztDQUN4RSxDQUFBO0FBRUQsSUFBSyxlQUtKO0FBTEQsV0FBSyxlQUFlO0lBQ2xCLDZEQUEwQyxDQUFBO0lBQzFDLG1FQUFnRCxDQUFBO0lBQ2hELDJEQUF3QyxDQUFBO0lBQ3hDLHFEQUFrQyxDQUFBO0FBQ3BDLENBQUMsRUFMSSxlQUFlLEtBQWYsZUFBZSxRQUtuQjtBQUVELFNBQWUsUUFBUSxDQUFDLElBQVM7Ozs7OztvQkFDeEIsS0FBQSxrQkFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQTs7NkJBRTdCLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBbkIsd0JBQWtCOzZCQThCbEIsWUFBWSxDQUFDLGtCQUFrQixDQUFDLENBQWhDLHlCQUErQjs2QkFNL0IsWUFBWSxDQUFDLGVBQWUsQ0FBQyxDQUE3Qix5QkFBNEI7NkJBZTVCLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBN0IseUJBQTRCOzs7OztvQkFqRFgscUJBQU0sbUJBQVUsQ0FBQyxzQkFBc0IsRUFDdkQsaUJBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQzVDLEVBQUE7O29CQUZHLFdBQVcsR0FBRyxTQUVqQjtvQkFDRCxzQkFBTywwQkFBMEIsQ0FBQyxXQUFXLENBQUMsRUFBQzs7O29CQUl4QyxLQUFBLEtBQUcsQ0FBQyxJQUFJLENBQUE7OzZCQUVSLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBN0Isd0JBQTRCOzZCQUk1QixlQUFlLENBQUMsYUFBYSxDQUFDLENBQTlCLHdCQUE2Qjs2QkFJN0IsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUE5Qix3QkFBNkI7NkJBQzdCLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBekIsd0JBQXdCOzs7d0JBUjNCLHFCQUFNLGlCQUFPLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBcEQsU0FBb0QsQ0FBQztvQkFDckQsTUFBTSxJQUFJLCtCQUFzQixDQUFDLDZFQUE2RSxDQUFDLENBQUE7d0JBRy9HLHFCQUFNLGlCQUFPLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBaEQsU0FBZ0QsQ0FBQztvQkFDakQsTUFBTSxJQUFJLG1DQUEwQixDQUFDLG9FQUFvRSxDQUFDLENBQUE7d0JBSTFHLE1BQU0sSUFBSSxxQ0FBNEIsQ0FBQyxpREFBaUQsQ0FBQyxDQUFDOztvQkFHdEYsR0FBRyxHQUFHLEtBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFJLEtBQUcsQ0FBQyxJQUFJLFdBQU0sS0FBRyxDQUFDLE9BQVMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNyRSxNQUFNLElBQUksa0JBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7eUJBTVQscUJBQU0sbUJBQVUsQ0FBQyx5QkFBeUIsRUFDOUQsaUJBQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUMxRSxFQUFBOztvQkFGSyxhQUFhLEdBQUcsU0FFckI7b0JBQ0Qsc0JBQU8sMEJBQTBCLENBQUMsYUFBYSxDQUFDLEVBQUM7eUJBR25CLHFCQUFNLG1CQUFVLENBQUMsc0JBQXNCLEVBQ25FLGlCQUFPLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUN6RCxFQUFBOztvQkFGSyxxQkFBcUIsR0FBRyxTQUU3QjtvQkFDRCxJQUFJLHFCQUFxQixDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUU7d0JBQzlDLHNCQUFPO2dDQUNMLE9BQU8sRUFBRyxrREFBa0Q7NkJBQzdELEVBQUE7cUJBQ0Y7eUJBQU07d0JBQ0wsc0JBQU87Z0NBQ0wsT0FBTyxFQUFHLDhEQUE4RDtnQ0FDeEUsT0FBTyxFQUFHLHFCQUFxQixDQUFDLE9BQU87NkJBQ3hDLEVBQUE7cUJBQ0Y7O3lCQUcrQixxQkFBTSxtQkFBVSxDQUFDLHNCQUFzQixFQUNuRSxpQkFBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUN4RSxFQUFBOztvQkFGSyxxQkFBcUIsR0FBRyxTQUU3QjtvQkFDRCxzQkFBTywwQkFBMEIsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFDO3lCQUczRCxNQUFNLElBQUksa0JBQVMsQ0FBQyxhQUFhLENBQUM7b0JBQ2hDLFFBQVEsRUFBRyxtQkFBVSxDQUFDLEtBQUs7b0JBQzNCLGNBQWMsRUFBRzt3QkFDZixFQUFFLE1BQU0sRUFBRyxPQUFPLEVBQUUsVUFBVSxFQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsbUJBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDdkUsRUFBRSxNQUFNLEVBQUcsc0JBQXNCLEVBQUUsVUFBVSxFQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsbUJBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO3dCQUNuRyxFQUFFLE1BQU0sRUFBRyxzQkFBc0IsRUFBRSxVQUFVLEVBQUcsV0FBVyxDQUFDLElBQUksRUFBRSxtQkFBVyxDQUFDLGVBQWUsQ0FBQyxFQUFDO3dCQUMvRixFQUFFLE1BQU0sRUFBRyxtQkFBbUIsRUFBRSxVQUFVLEVBQUcsV0FBVyxDQUFDLElBQUksRUFBRSxtQkFBVyxDQUFDLGVBQWUsQ0FBQyxFQUFFO3FCQUM5RjtpQkFDRixDQUFDLENBQUMsQ0FBQTs7OztDQUdSO0FBRUQsSUFBWSxvQkFHWDtBQUhELFdBQVksb0JBQW9CO0lBQzlCLHNEQUE4QixDQUFBO0lBQzlCLDBEQUFrQyxDQUFBO0FBQ3BDLENBQUMsRUFIVyxvQkFBb0IsR0FBcEIsNEJBQW9CLEtBQXBCLDRCQUFvQixRQUcvQjtBQUVZLFFBQUEsbUJBQW1CLEdBQUc7SUFDakMsS0FBSyxFQUFHLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQztJQUNqQyxPQUFPLEVBQUcsQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxpQkFBaUIsRUFBRSxjQUFjLENBQUMsV0FBVyxDQUFDO0NBQ2xHLENBQUE7QUFFRCxJQUFLLHVCQUlKO0FBSkQsV0FBSyx1QkFBdUI7SUFDMUIsMkRBQWdDLENBQUE7SUFDaEMsdUVBQTRDLENBQUE7SUFDNUMscUVBQTBDLENBQUE7QUFDNUMsQ0FBQyxFQUpJLHVCQUF1QixLQUF2Qix1QkFBdUIsUUFJM0I7QUFFRCxTQUFlLGdCQUFnQixDQUFDLElBQVM7Ozs7OztvQkFDL0IsS0FBQSxrQkFBUSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFBOzs2QkFDdEMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQTdCLHdCQUE0Qjs2QkF3QjVCLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUEzQix5QkFBMEI7Ozs7b0JBdkJyQixRQUFRLEdBQXFDLElBQUksU0FBekMsRUFBRSxpQkFBaUIsR0FBa0IsSUFBSSxrQkFBdEIsRUFBRSxXQUFXLEdBQUssSUFBSSxZQUFULENBQVU7Ozs7b0JBRXhELHFCQUFNLG1CQUFVLENBQUMsMkJBQTJCLEVBQUUsaUJBQU8sQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsV0FBVyxDQUFDLENBQUMsRUFBQTs7b0JBQXRILFNBQXNILENBQUM7b0JBQ3ZILHNCQUFPOzRCQUNMLE9BQU8sRUFBRyx3REFBd0Q7eUJBQ25FLEVBQUE7OztvQkFHTSxLQUFBLEtBQUcsQ0FBQyxJQUFJLENBQUE7OzZCQUNSLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFoQyx3QkFBK0I7NkJBRy9CLHVCQUF1QixDQUFDLGVBQWUsQ0FBQyxDQUF4Qyx3QkFBdUM7NkJBRXZDLHVCQUF1QixDQUFDLFlBQVksQ0FBQyxDQUFyQyx3QkFBb0M7Ozt3QkFKdkMscUJBQU0sbUJBQVUsQ0FBQyx3REFBd0QsRUFBRSxpQkFBTyxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUE7O29CQUFqSCxTQUFpSCxDQUFDO29CQUNsSCxNQUFNLElBQUksbUNBQTBCLENBQUMsNERBQTRELENBQUMsQ0FBQzt3QkFFbkcsTUFBTSxJQUFJLDZCQUFvQixDQUFDLDZEQUE2RCxDQUFDLENBQUM7d0JBRTlGLHFCQUFNLG1CQUFVLENBQUMscUNBQXFDLEVBQUUsaUJBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBbEcsU0FBa0csQ0FBQztvQkFDbkcsTUFBTSxJQUFJLCtCQUFzQixDQUFDLDBGQUEwRixDQUFDLENBQUM7O29CQUV6SCxHQUFHLEdBQUcsS0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUksS0FBRyxDQUFDLElBQUksV0FBTSxLQUFHLENBQUMsT0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3JFLE1BQU0sSUFBSSxrQkFBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzt5QkFLL0IscUJBQU0sbUJBQVUsQ0FBQywwQkFBMEIsRUFBRSxpQkFBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBeEYsU0FBd0YsQ0FBQztvQkFDekYsc0JBQU87NEJBQ0wsT0FBTyxFQUFHLG9FQUFvRTt5QkFDL0UsRUFBQTt5QkFHRCxNQUFNLElBQUksa0JBQVMsQ0FBQyxhQUFhLENBQUM7b0JBQ2hDLFFBQVEsRUFBRyxtQkFBVSxDQUFDLGFBQWE7b0JBQ25DLGNBQWMsRUFBRzt3QkFDZixFQUFFLE1BQU0sRUFBRyxzQkFBc0IsRUFBRSxVQUFVLEVBQUcsV0FBVyxDQUFDLElBQUksRUFBRSwyQkFBbUIsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDOUYsRUFBRSxNQUFNLEVBQUcsd0JBQXdCLEVBQUUsVUFBVSxFQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsMkJBQW1CLENBQUMsT0FBTyxDQUFDLEVBQUU7cUJBQ25HO2lCQUNGLENBQUMsQ0FBQyxDQUFBOzs7O0NBRVI7QUFFRCxrQkFBZTtJQUNiLEtBQUssRUFBRSxRQUFRO0lBQ2YsYUFBYSxFQUFFLGdCQUFnQjtDQUNoQyxDQUFBIn0=