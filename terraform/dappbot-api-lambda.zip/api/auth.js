"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
var cognito_1 = __importStar(require("../services/cognito"));
var validate_1 = __importDefault(require("../validate"));
function bodyMissing(body, propertyNames) {
    return propertyNames.filter(function (name) { return !body.hasOwnProperty(name); });
}
var AuthParamNames;
(function (AuthParamNames) {
    AuthParamNames["Username"] = "username";
    AuthParamNames["Password"] = "password";
    AuthParamNames["NewPassword"] = "newPassword";
    AuthParamNames["Session"] = "session";
    AuthParamNames["MFALoginCode"] = "mfaLoginCode";
    AuthParamNames["MFASetupCode"] = "mfaSetupCode";
    AuthParamNames["PasswordResetCode"] = "passwordResetCode";
})(AuthParamNames = exports.AuthParamNames || (exports.AuthParamNames = {}));
function perCaseErrMsg(_a) {
    var endpoint = _a.endpoint, actionsMissing = _a.actionsMissing;
    return [
        "Your request body did not match any options for " + endpoint + ":\n"
    ].concat(actionsMissing.map(function (missing) { return "- If you want to " + missing.action + ", then also provide " + missing.parameters.join(', ') + "."; })).join('\n');
}
function buildChallengeResponseBody(authResult) {
    return __awaiter(this, void 0, void 0, function () {
        var responseBody, mfaSetup, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!authResult.AuthenticationResult) return [3 /*break*/, 1];
                    responseBody = {
                        AuthToken: authResult.AuthenticationResult.IdToken
                    };
                    return [3 /*break*/, 5];
                case 1:
                    responseBody = {
                        ChallengeName: authResult.ChallengeName,
                        ChallengeParameters: authResult.ChallengeParameters,
                        Session: authResult.Session
                    };
                    if (!(authResult.ChallengeName === cognito_1.CognitoChallengeNames.MFASetup)) return [3 /*break*/, 5];
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, common_1.callAndLog("Beginning MFA setup", cognito_1.default.beginMFASetup(authResult.Session))];
                case 3:
                    mfaSetup = _a.sent();
                    responseBody.ChallengeParameters.mfaSetupCode = mfaSetup.SecretCode;
                    return [3 /*break*/, 5];
                case 4:
                    err_1 = _a.sent();
                    throw err_1;
                case 5: return [2 /*return*/, responseBody];
            }
        });
    });
}
var LoginActions;
(function (LoginActions) {
    LoginActions["Login"] = "LOGIN";
    LoginActions["ConfirmNewPassword"] = "CONFIRM_NEW_PASSWORD";
    LoginActions["ConfirmMFALogin"] = "CONFIRM_MFA_LOGIN";
    LoginActions["ConfirmMFASetup"] = "CONFIRM_MFA_SETUP";
})(LoginActions = exports.LoginActions || (exports.LoginActions = {}));
exports.LoginParams = {
    Login: [AuthParamNames.Username, AuthParamNames.Password],
    ConfirmNewPassword: [AuthParamNames.Username, AuthParamNames.Session, AuthParamNames.NewPassword],
    ConfirmMFALogin: [AuthParamNames.Username, AuthParamNames.Session, AuthParamNames.MFALoginCode],
    ConfirmMFASetup: [AuthParamNames.Session, AuthParamNames.MFASetupCode]
};
var LoginExceptions;
(function (LoginExceptions) {
    LoginExceptions["NotConfirmed"] = "UserNotConfirmedException";
    LoginExceptions["ResetRequired"] = "PasswordResetRequiredException";
    LoginExceptions["NotAuthorized"] = "NotAuthorizedException";
    LoginExceptions["NotFound"] = "UserNotFoundException";
})(LoginExceptions || (LoginExceptions = {}));
function apiLogin(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, loginResult, err_2, _b, msg, newPassResult, confirmMFASetupResult, confirmMFALoginResult;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = validate_1.default.matchLoginBody(body);
                    switch (_a) {
                        case LoginActions.Login: return [3 /*break*/, 1];
                        case LoginActions.ConfirmNewPassword: return [3 /*break*/, 11];
                        case LoginActions.ConfirmMFASetup: return [3 /*break*/, 13];
                        case LoginActions.ConfirmMFALogin: return [3 /*break*/, 15];
                    }
                    return [3 /*break*/, 17];
                case 1:
                    _c.trys.push([1, 3, , 11]);
                    return [4 /*yield*/, common_1.callAndLog('Logging into Cognito', cognito_1.default.login(body.username, body.password))];
                case 2:
                    loginResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(loginResult)];
                case 3:
                    err_2 = _c.sent();
                    _b = err_2.code;
                    switch (_b) {
                        case LoginExceptions.NotConfirmed: return [3 /*break*/, 4];
                        case LoginExceptions.ResetRequired: return [3 /*break*/, 6];
                        case LoginExceptions.NotAuthorized: return [3 /*break*/, 8];
                        case LoginExceptions.NotFound: return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 9];
                case 4: return [4 /*yield*/, cognito_1.default.resendSignUpConfirmCode(body.username)];
                case 5:
                    _c.sent();
                    throw new Error("Please finish confirming your account, we've resent your confirmation code.");
                case 6: return [4 /*yield*/, cognito_1.default.beginForgotPassword(body.username)];
                case 7:
                    _c.sent();
                    throw new Error("Please reset your password, we've emailed you a confirmation code.");
                case 8: throw new Error("We could not log you in with these credentials.");
                case 9:
                    msg = err_2.code ? err_2.code + " - " + err_2.message : err_2.toString();
                    throw new Error(msg);
                case 10: return [3 /*break*/, 11];
                case 11: return [4 /*yield*/, common_1.callAndLog('Confirming new password', cognito_1.default.confirmNewPassword(body.session, body.username, body.newPassword))];
                case 12:
                    newPassResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(newPassResult)];
                case 13: return [4 /*yield*/, common_1.callAndLog('Confirming MFA Setup', cognito_1.default.confirmMFASetup(body.session, body.mfaSetupCode))];
                case 14:
                    confirmMFASetupResult = _c.sent();
                    if (confirmMFASetupResult.Status === 'SUCCESS') {
                        return [2 /*return*/, {
                                message: 'MFA was successfully set up, you can now log in.'
                            }];
                    }
                    else {
                        return [2 /*return*/, {
                                message: 'MFA setup was unsuccessful. Please use session to try again.',
                                session: confirmMFASetupResult.Session
                            }];
                    }
                    _c.label = 15;
                case 15: return [4 /*yield*/, common_1.callAndLog('Confirming MFA Login', cognito_1.default.confirmMFALogin(body.session, body.username, body.mfaLoginCode))];
                case 16:
                    confirmMFALoginResult = _c.sent();
                    return [2 /*return*/, buildChallengeResponseBody(confirmMFALoginResult)];
                case 17: throw new Error(perCaseErrMsg({
                    endpoint: common_1.ApiMethods.login,
                    actionsMissing: [
                        { action: 'login', parameters: bodyMissing(body, exports.LoginParams.Login) },
                        { action: 'confirm new password', parameters: bodyMissing(body, exports.LoginParams.ConfirmNewPassword) },
                        { action: 'confirm an MFA login', parameters: bodyMissing(body, exports.LoginParams.ConfirmMFALogin) },
                        { action: 'confirm MFA setup', parameters: bodyMissing(body, exports.LoginParams.ConfirmMFASetup) }
                    ]
                }));
            }
        });
    });
}
var PasswordResetActions;
(function (PasswordResetActions) {
    PasswordResetActions["Begin"] = "BEGIN_PASSWORD_RESET";
    PasswordResetActions["Confirm"] = "CONFIRM_PASSWORD_RESET";
})(PasswordResetActions = exports.PasswordResetActions || (exports.PasswordResetActions = {}));
exports.PasswordResetParams = {
    Begin: [AuthParamNames.Username],
    Confirm: [AuthParamNames.Username, AuthParamNames.PasswordResetCode, AuthParamNames.NewPassword]
};
var PasswordResetExceptions;
(function (PasswordResetExceptions) {
    PasswordResetExceptions["Expired"] = "ExpiredCodeException";
    PasswordResetExceptions["InvalidPassword"] = "InvalidPasswordException";
    PasswordResetExceptions["NotConfirmed"] = "UserNotConfirmedException";
})(PasswordResetExceptions || (PasswordResetExceptions = {}));
function apiPasswordReset(body) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, username, passwordResetCode, newPassword, err_3, _b, msg;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _a = validate_1.default.matchPasswordResetBody(body);
                    switch (_a) {
                        case PasswordResetActions.Confirm: return [3 /*break*/, 1];
                        case PasswordResetActions.Begin: return [3 /*break*/, 12];
                    }
                    return [3 /*break*/, 14];
                case 1:
                    username = body.username, passwordResetCode = body.passwordResetCode, newPassword = body.newPassword;
                    _c.label = 2;
                case 2:
                    _c.trys.push([2, 4, , 12]);
                    return [4 /*yield*/, common_1.callAndLog('Confirming password reset', cognito_1.default.confirmForgotPassword(username, passwordResetCode, newPassword))];
                case 3:
                    _c.sent();
                    return [2 /*return*/, {
                            message: 'Your password was successfully set, you may now login.'
                        }];
                case 4:
                    err_3 = _c.sent();
                    _b = err_3.code;
                    switch (_b) {
                        case PasswordResetExceptions.Expired: return [3 /*break*/, 5];
                        case PasswordResetExceptions.InvalidPassword: return [3 /*break*/, 7];
                        case PasswordResetExceptions.NotConfirmed: return [3 /*break*/, 8];
                    }
                    return [3 /*break*/, 10];
                case 5: return [4 /*yield*/, common_1.callAndLog('Sending new password reset code to replace expired one', cognito_1.default.beginForgotPassword(username))];
                case 6:
                    _c.sent();
                    throw new Error("Your password reset code expired, a new one has been sent.");
                case 7: throw new Error("Your new password was not valid, please select another one.");
                case 8: return [4 /*yield*/, common_1.callAndLog('Resending account confirmation code', cognito_1.default.resendSignUpConfirmCode(username))];
                case 9:
                    _c.sent();
                    throw new Error("Your account still has not been confirmed, we have resent your signup confirmation code.");
                case 10:
                    msg = err_3.code ? err_3.code + " - " + err_3.message : err_3.toString();
                    throw new Error(msg);
                case 11: return [3 /*break*/, 12];
                case 12: return [4 /*yield*/, common_1.callAndLog('Beginning password reset', cognito_1.default.beginForgotPassword(body.username))];
                case 13:
                    _c.sent();
                    return [2 /*return*/, {
                            message: "Please reset your password, we've emailed you a confirmation code."
                        }];
                case 14: throw new Error(perCaseErrMsg({
                    endpoint: common_1.ApiMethods.passwordReset,
                    actionsMissing: [
                        { action: 'begin password reset', parameters: bodyMissing(body, exports.PasswordResetParams.Begin) },
                        { action: 'confirm password reset', parameters: bodyMissing(body, exports.PasswordResetParams.Confirm) }
                    ]
                }));
            }
        });
    });
}
exports.default = {
    login: apiLogin,
    passwordReset: apiPasswordReset
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZVJvb3QiOiJzcmMvIiwic291cmNlcyI6WyJhcGkvYXV0aC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLG9DQUFtRDtBQUNuRCw2REFBcUU7QUFDckUseURBQW1DO0FBRW5DLFNBQVMsV0FBVyxDQUFDLElBQVcsRUFBRSxhQUFzQjtJQUN0RCxPQUFPLGFBQWEsQ0FBQyxNQUFNLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQTFCLENBQTBCLENBQUMsQ0FBQztBQUNsRSxDQUFDO0FBRUQsSUFBWSxjQVFYO0FBUkQsV0FBWSxjQUFjO0lBQ3hCLHVDQUFxQixDQUFBO0lBQ3JCLHVDQUFxQixDQUFBO0lBQ3JCLDZDQUEyQixDQUFBO0lBQzNCLHFDQUFtQixDQUFBO0lBQ25CLCtDQUE2QixDQUFBO0lBQzdCLCtDQUE2QixDQUFBO0lBQzdCLHlEQUF1QyxDQUFBO0FBQ3pDLENBQUMsRUFSVyxjQUFjLEdBQWQsc0JBQWMsS0FBZCxzQkFBYyxRQVF6QjtBQVlELFNBQVMsYUFBYSxDQUFDLEVBQThDO1FBQTVDLHNCQUFRLEVBQUUsa0NBQWM7SUFDL0MsT0FBTztRQUNMLHFEQUFtRCxRQUFRLFFBQUs7YUFDN0QsY0FBYyxDQUFDLEdBQUcsQ0FBQyxVQUFBLE9BQU8sSUFBSSxPQUFBLHNCQUFvQixPQUFPLENBQUMsTUFBTSw0QkFBdUIsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQUcsRUFBekYsQ0FBeUYsQ0FBQyxFQUMzSCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDZCxDQUFDO0FBSUQsU0FBZSwwQkFBMEIsQ0FBQyxVQUFxQjs7Ozs7O3lCQUV6RCxVQUFVLENBQUMsb0JBQW9CLEVBQS9CLHdCQUErQjtvQkFDakMsWUFBWSxHQUFHO3dCQUNiLFNBQVMsRUFBRSxVQUFVLENBQUMsb0JBQW9CLENBQUMsT0FBaUI7cUJBQzdELENBQUE7OztvQkFFRCxZQUFZLEdBQUc7d0JBQ2IsYUFBYSxFQUFFLFVBQVUsQ0FBQyxhQUF1Qjt3QkFDakQsbUJBQW1CLEVBQUUsVUFBVSxDQUFDLG1CQUEyRDt3QkFDM0YsT0FBTyxFQUFFLFVBQVUsQ0FBQyxPQUFtQztxQkFDeEQsQ0FBQTt5QkFDRyxDQUFBLFVBQVUsQ0FBQyxhQUFhLEtBQUssK0JBQXFCLENBQUMsUUFBUSxDQUFBLEVBQTNELHdCQUEyRDs7OztvQkFFMUMscUJBQU0sbUJBQVUsQ0FBQyxxQkFBcUIsRUFBRSxpQkFBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsT0FBaUIsQ0FBQyxDQUFDLEVBQUE7O29CQUF2RyxRQUFRLEdBQUcsU0FBNEY7b0JBQzdHLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFVBQW9CLENBQUM7Ozs7b0JBRTlFLE1BQU0sS0FBRyxDQUFDO3dCQUloQixzQkFBTyxZQUFZLEVBQUM7Ozs7Q0FDckI7QUFFRCxJQUFZLFlBS1g7QUFMRCxXQUFZLFlBQVk7SUFDdEIsK0JBQWUsQ0FBQTtJQUNmLDJEQUEyQyxDQUFBO0lBQzNDLHFEQUFxQyxDQUFBO0lBQ3JDLHFEQUFxQyxDQUFBO0FBQ3ZDLENBQUMsRUFMVyxZQUFZLEdBQVosb0JBQVksS0FBWixvQkFBWSxRQUt2QjtBQUVZLFFBQUEsV0FBVyxHQUFHO0lBQ3pCLEtBQUssRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLFFBQVEsQ0FBQztJQUMxRCxrQkFBa0IsRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsV0FBVyxDQUFDO0lBQ2xHLGVBQWUsRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsWUFBWSxDQUFDO0lBQ2hHLGVBQWUsRUFBRyxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLFlBQVksQ0FBQztDQUN4RSxDQUFBO0FBRUQsSUFBSyxlQUtKO0FBTEQsV0FBSyxlQUFlO0lBQ2xCLDZEQUEwQyxDQUFBO0lBQzFDLG1FQUFnRCxDQUFBO0lBQ2hELDJEQUF3QyxDQUFBO0lBQ3hDLHFEQUFrQyxDQUFBO0FBQ3BDLENBQUMsRUFMSSxlQUFlLEtBQWYsZUFBZSxRQUtuQjtBQUVELFNBQWUsUUFBUSxDQUFDLElBQVM7Ozs7OztvQkFDeEIsS0FBQSxrQkFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQTs7NkJBRTdCLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBbkIsd0JBQWtCOzZCQStCbEIsWUFBWSxDQUFDLGtCQUFrQixDQUFDLENBQWhDLHlCQUErQjs2QkFNL0IsWUFBWSxDQUFDLGVBQWUsQ0FBQyxDQUE3Qix5QkFBNEI7NkJBZTVCLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBN0IseUJBQTRCOzs7OztvQkFqRFgscUJBQU0sbUJBQVUsQ0FBQyxzQkFBc0IsRUFDdkQsaUJBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQzVDLEVBQUE7O29CQUZHLFdBQVcsR0FBRyxTQUVqQjtvQkFDRCxzQkFBTywwQkFBMEIsQ0FBQyxXQUFXLENBQUMsRUFBQzs7O29CQUl4QyxLQUFBLEtBQUcsQ0FBQyxJQUFJLENBQUE7OzZCQUVSLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBN0Isd0JBQTRCOzZCQUk1QixlQUFlLENBQUMsYUFBYSxDQUFDLENBQTlCLHdCQUE2Qjs2QkFJN0IsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUE5Qix3QkFBNkI7NkJBQzdCLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBekIsd0JBQXdCOzs7d0JBUjNCLHFCQUFNLGlCQUFPLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFBOztvQkFBcEQsU0FBb0QsQ0FBQztvQkFDckQsTUFBTSxJQUFJLEtBQUssQ0FBQyw2RUFBNkUsQ0FBQyxDQUFBO3dCQUc5RixxQkFBTSxpQkFBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBQTs7b0JBQWhELFNBQWdELENBQUM7b0JBQ2pELE1BQU0sSUFBSSxLQUFLLENBQUMsb0VBQW9FLENBQUMsQ0FBQTt3QkFJckYsTUFBTSxJQUFJLEtBQUssQ0FBQyxpREFBaUQsQ0FBQyxDQUFDOztvQkFHL0QsR0FBRyxHQUFHLEtBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFJLEtBQUcsQ0FBQyxJQUFJLFdBQU0sS0FBRyxDQUFDLE9BQVMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNyRSxNQUFNLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzt5QkFNTCxxQkFBTSxtQkFBVSxDQUFDLHlCQUF5QixFQUM5RCxpQkFBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQzFFLEVBQUE7O29CQUZLLGFBQWEsR0FBRyxTQUVyQjtvQkFDRCxzQkFBTywwQkFBMEIsQ0FBQyxhQUFhLENBQUMsRUFBQzt5QkFHbkIscUJBQU0sbUJBQVUsQ0FBQyxzQkFBc0IsRUFDbkUsaUJBQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQ3pELEVBQUE7O29CQUZLLHFCQUFxQixHQUFHLFNBRTdCO29CQUNELElBQUkscUJBQXFCLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTt3QkFDOUMsc0JBQU87Z0NBQ0wsT0FBTyxFQUFHLGtEQUFrRDs2QkFDN0QsRUFBQTtxQkFDRjt5QkFBTTt3QkFDTCxzQkFBTztnQ0FDTCxPQUFPLEVBQUcsOERBQThEO2dDQUN4RSxPQUFPLEVBQUcscUJBQXFCLENBQUMsT0FBTzs2QkFDeEMsRUFBQTtxQkFDRjs7eUJBRytCLHFCQUFNLG1CQUFVLENBQUMsc0JBQXNCLEVBQ25FLGlCQUFPLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQ3hFLEVBQUE7O29CQUZLLHFCQUFxQixHQUFHLFNBRTdCO29CQUNELHNCQUFPLDBCQUEwQixDQUFDLHFCQUFxQixDQUFDLEVBQUM7eUJBRzNELE1BQU0sSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDO29CQUM1QixRQUFRLEVBQUcsbUJBQVUsQ0FBQyxLQUFLO29CQUMzQixjQUFjLEVBQUc7d0JBQ2YsRUFBRSxNQUFNLEVBQUcsT0FBTyxFQUFFLFVBQVUsRUFBRyxXQUFXLENBQUMsSUFBSSxFQUFFLG1CQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ3ZFLEVBQUUsTUFBTSxFQUFHLHNCQUFzQixFQUFFLFVBQVUsRUFBRyxXQUFXLENBQUMsSUFBSSxFQUFFLG1CQUFXLENBQUMsa0JBQWtCLENBQUMsRUFBRTt3QkFDbkcsRUFBRSxNQUFNLEVBQUcsc0JBQXNCLEVBQUUsVUFBVSxFQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsbUJBQVcsQ0FBQyxlQUFlLENBQUMsRUFBQzt3QkFDL0YsRUFBRSxNQUFNLEVBQUcsbUJBQW1CLEVBQUUsVUFBVSxFQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsbUJBQVcsQ0FBQyxlQUFlLENBQUMsRUFBRTtxQkFDOUY7aUJBQ0YsQ0FBQyxDQUFDLENBQUE7Ozs7Q0FHUjtBQUVELElBQVksb0JBR1g7QUFIRCxXQUFZLG9CQUFvQjtJQUM5QixzREFBOEIsQ0FBQTtJQUM5QiwwREFBa0MsQ0FBQTtBQUNwQyxDQUFDLEVBSFcsb0JBQW9CLEdBQXBCLDRCQUFvQixLQUFwQiw0QkFBb0IsUUFHL0I7QUFFWSxRQUFBLG1CQUFtQixHQUFHO0lBQ2pDLEtBQUssRUFBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUM7SUFDakMsT0FBTyxFQUFHLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDLFdBQVcsQ0FBQztDQUNsRyxDQUFBO0FBRUQsSUFBSyx1QkFJSjtBQUpELFdBQUssdUJBQXVCO0lBQzFCLDJEQUFnQyxDQUFBO0lBQ2hDLHVFQUE0QyxDQUFBO0lBQzVDLHFFQUEwQyxDQUFBO0FBQzVDLENBQUMsRUFKSSx1QkFBdUIsS0FBdkIsdUJBQXVCLFFBSTNCO0FBRUQsU0FBZSxnQkFBZ0IsQ0FBQyxJQUFTOzs7Ozs7b0JBQy9CLEtBQUEsa0JBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsQ0FBQTs7NkJBQ3RDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUE3Qix3QkFBNEI7NkJBd0I1QixvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBM0IseUJBQTBCOzs7O29CQXZCckIsUUFBUSxHQUFxQyxJQUFJLFNBQXpDLEVBQUUsaUJBQWlCLEdBQWtCLElBQUksa0JBQXRCLEVBQUUsV0FBVyxHQUFLLElBQUksWUFBVCxDQUFVOzs7O29CQUV4RCxxQkFBTSxtQkFBVSxDQUFDLDJCQUEyQixFQUFFLGlCQUFPLENBQUMscUJBQXFCLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsQ0FBQyxDQUFDLEVBQUE7O29CQUF0SCxTQUFzSCxDQUFDO29CQUN2SCxzQkFBTzs0QkFDTCxPQUFPLEVBQUcsd0RBQXdEO3lCQUNuRSxFQUFBOzs7b0JBR00sS0FBQSxLQUFHLENBQUMsSUFBSSxDQUFBOzs2QkFDUix1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBaEMsd0JBQStCOzZCQUcvQix1QkFBdUIsQ0FBQyxlQUFlLENBQUMsQ0FBeEMsd0JBQXVDOzZCQUV2Qyx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsQ0FBckMsd0JBQW9DOzs7d0JBSnZDLHFCQUFNLG1CQUFVLENBQUMsd0RBQXdELEVBQUUsaUJBQU8sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBakgsU0FBaUgsQ0FBQztvQkFDbEgsTUFBTSxJQUFJLEtBQUssQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO3dCQUU5RSxNQUFNLElBQUksS0FBSyxDQUFDLDZEQUE2RCxDQUFDLENBQUM7d0JBRS9FLHFCQUFNLG1CQUFVLENBQUMscUNBQXFDLEVBQUUsaUJBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBbEcsU0FBa0csQ0FBQztvQkFDbkcsTUFBTSxJQUFJLEtBQUssQ0FBQywwRkFBMEYsQ0FBQyxDQUFDOztvQkFFeEcsR0FBRyxHQUFHLEtBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFJLEtBQUcsQ0FBQyxJQUFJLFdBQU0sS0FBRyxDQUFDLE9BQVMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNyRSxNQUFNLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzt5QkFLM0IscUJBQU0sbUJBQVUsQ0FBQywwQkFBMEIsRUFBRSxpQkFBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFBOztvQkFBeEYsU0FBd0YsQ0FBQztvQkFDekYsc0JBQU87NEJBQ0wsT0FBTyxFQUFHLG9FQUFvRTt5QkFDL0UsRUFBQTt5QkFHRCxNQUFNLElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQztvQkFDNUIsUUFBUSxFQUFHLG1CQUFVLENBQUMsYUFBYTtvQkFDbkMsY0FBYyxFQUFHO3dCQUNmLEVBQUUsTUFBTSxFQUFHLHNCQUFzQixFQUFFLFVBQVUsRUFBRyxXQUFXLENBQUMsSUFBSSxFQUFFLDJCQUFtQixDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUM5RixFQUFFLE1BQU0sRUFBRyx3QkFBd0IsRUFBRSxVQUFVLEVBQUcsV0FBVyxDQUFDLElBQUksRUFBRSwyQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBRTtxQkFDbkc7aUJBQ0YsQ0FBQyxDQUFDLENBQUE7Ozs7Q0FFUjtBQUVELGtCQUFlO0lBQ2IsS0FBSyxFQUFFLFFBQVE7SUFDZixhQUFhLEVBQUUsZ0JBQWdCO0NBQ2hDLENBQUEifQ==