"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var public_1 = __importDefault(require("./public"));
var private_1 = __importDefault(require("./private"));
var auth_1 = __importDefault(require("./auth"));
exports.Api = {
    public: public_1.default,
    private: private_1.default,
    auth: auth_1.default
};
exports.default = exports.Api;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsiYXBpL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsb0RBQWlDO0FBQ2pDLHNEQUFtQztBQUNuQyxnREFBNkI7QUFFaEIsUUFBQSxHQUFHLEdBQUc7SUFDakIsTUFBTSxFQUFHLGdCQUFTO0lBQ2xCLE9BQU8sRUFBRyxpQkFBVTtJQUNwQixJQUFJLEVBQUcsY0FBTztDQUNmLENBQUE7QUFFRCxrQkFBZSxXQUFHLENBQUMifQ==